"""
The New Civilization Core Models
Implements the core data structures for the AI Super Intelligence system
"""

from datetime import datetime
from enum import Enum
import json
from typing import Dict, Any, List, Optional

# Import the existing db instance
from src.models.user import db

class BeliefType(Enum):
    SYSTEM_STATE = "system_state"
    USER_PATTERN = "user_pattern"
    MARKET_CONDITION = "market_condition"
    PERFORMANCE_METRIC = "performance_metric"
    QUANTUM_STATE = "quantum_state"
    CIVILIZATION_IMPACT = "civilization_impact"

class DesireType(Enum):
    REVENUE_OPTIMIZATION = "revenue_optimization"
    SYSTEM_PERFORMANCE = "system_performance"
    USER_SATISFACTION = "user_satisfaction"
    INNOVATION = "innovation"
    TRANSCENDENCE = "transcendence"
    CIVILIZATION_ADVANCEMENT = "civilization_advancement"

class IntentionStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class AgentTier(Enum):
    DEITY = "deity"
    ARCHANGEL = "archangel"
    GUARDIAN = "guardian"
    SENTINEL = "sentinel"

# Core System Metrics
class SystemMetrics(db.Model):
    __tablename__ = 'system_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    component = db.Column(db.String(50), nullable=False)
    metric_name = db.Column(db.String(100), nullable=False)
    metric_value = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20))
    metadata_json = db.Column(db.Text)  # JSON string for additional metadata
    
    def __init__(self, component: str, metric_name: str, metric_value: float, 
                 unit: str = None, metadata: Dict[str, Any] = None):
        self.component = component
        self.metric_name = metric_name
        self.metric_value = metric_value
        self.unit = unit
        self.metadata_json = json.dumps(metadata) if metadata else None
    
    @property
    def metadata(self) -> Dict[str, Any]:
        return json.loads(self.metadata_json) if self.metadata_json else {}
    
    @metadata.setter
    def metadata(self, value: Dict[str, Any]):
        self.metadata_json = json.dumps(value) if value else None

# BDI Framework Models
class Belief(db.Model):
    __tablename__ = 'beliefs'
    
    id = db.Column(db.String(100), primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    belief_type = db.Column(db.Enum(BeliefType), nullable=False)
    content_json = db.Column(db.Text, nullable=False)  # JSON string
    confidence = db.Column(db.Float, nullable=False)
    source = db.Column(db.String(100), nullable=False)
    agent_tier = db.Column(db.Enum(AgentTier), nullable=False)
    
    def __init__(self, id: str, belief_type: BeliefType, content: Dict[str, Any], 
                 confidence: float, source: str, agent_tier: AgentTier):
        self.id = id
        self.belief_type = belief_type
        self.content_json = json.dumps(content)
        self.confidence = confidence
        self.source = source
        self.agent_tier = agent_tier
    
    @property
    def content(self) -> Dict[str, Any]:
        return json.loads(self.content_json)
    
    @content.setter
    def content(self, value: Dict[str, Any]):
        self.content_json = json.dumps(value)

class Desire(db.Model):
    __tablename__ = 'desires'
    
    id = db.Column(db.String(100), primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    desire_type = db.Column(db.Enum(DesireType), nullable=False)
    priority = db.Column(db.Float, nullable=False)
    target = db.Column(db.Integer)
    current = db.Column(db.Integer)
    strategy = db.Column(db.Text)
    quantum_priority = db.Column(db.Float)
    agent_tier = db.Column(db.Enum(AgentTier), nullable=False)
    
    def __init__(self, id: str, desire_type: DesireType, priority: float, 
                 agent_tier: AgentTier, target: int = None, current: int = None, 
                 strategy: str = None, quantum_priority: float = None):
        self.id = id
        self.desire_type = desire_type
        self.priority = priority
        self.target = target
        self.current = current
        self.strategy = strategy
        self.quantum_priority = quantum_priority
        self.agent_tier = agent_tier

class Intention(db.Model):
    __tablename__ = 'intentions'
    
    id = db.Column(db.String(100), primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    action = db.Column(db.Text, nullable=False)
    priority = db.Column(db.Float, nullable=False)
    parameters_json = db.Column(db.Text)  # JSON string
    status = db.Column(db.Enum(IntentionStatus), default=IntentionStatus.PENDING)
    quantum_order = db.Column(db.Integer)
    quantum_confidence = db.Column(db.Float)
    agent_tier = db.Column(db.Enum(AgentTier), nullable=False)
    
    def __init__(self, id: str, action: str, priority: float, agent_tier: AgentTier,
                 parameters: Dict[str, Any] = None, quantum_order: int = None, 
                 quantum_confidence: float = None):
        self.id = id
        self.action = action
        self.priority = priority
        self.parameters_json = json.dumps(parameters) if parameters else None
        self.quantum_order = quantum_order
        self.quantum_confidence = quantum_confidence
        self.agent_tier = agent_tier
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return json.loads(self.parameters_json) if self.parameters_json else {}
    
    @parameters.setter
    def parameters(self, value: Dict[str, Any]):
        self.parameters_json = json.dumps(value) if value else None

# Agent Performance Tracking
class AgentPerformance(db.Model):
    __tablename__ = 'agent_performance'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    agent_id = db.Column(db.String(100), nullable=False)
    agent_type = db.Column(db.String(50), nullable=False)
    agent_tier = db.Column(db.Enum(AgentTier), nullable=False)
    task_id = db.Column(db.String(100))
    execution_time = db.Column(db.Float)
    success_rate = db.Column(db.Float)
    resource_usage_json = db.Column(db.Text)  # JSON string
    error_logs_json = db.Column(db.Text)  # JSON string for error list
    
    def __init__(self, agent_id: str, agent_type: str, agent_tier: AgentTier,
                 task_id: str = None, execution_time: float = None, 
                 success_rate: float = None, resource_usage: Dict[str, Any] = None,
                 error_logs: List[str] = None):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.agent_tier = agent_tier
        self.task_id = task_id
        self.execution_time = execution_time
        self.success_rate = success_rate
        self.resource_usage_json = json.dumps(resource_usage) if resource_usage else None
        self.error_logs_json = json.dumps(error_logs) if error_logs else None
    
    @property
    def resource_usage(self) -> Dict[str, Any]:
        return json.loads(self.resource_usage_json) if self.resource_usage_json else {}
    
    @property
    def error_logs(self) -> List[str]:
        return json.loads(self.error_logs_json) if self.error_logs_json else []

# Revenue Analytics
class RevenueAnalytics(db.Model):
    __tablename__ = 'revenue_analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    revenue_source = db.Column(db.String(100))
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    conversion_rate = db.Column(db.Float)
    customer_segment = db.Column(db.String(50))
    metadata_json = db.Column(db.Text)  # JSON string
    
    def __init__(self, date, amount: float, revenue_source: str = None, 
                 currency: str = 'USD', conversion_rate: float = None,
                 customer_segment: str = None, metadata: Dict[str, Any] = None):
        self.date = date
        self.revenue_source = revenue_source
        self.amount = amount
        self.currency = currency
        self.conversion_rate = conversion_rate
        self.customer_segment = customer_segment
        self.metadata_json = json.dumps(metadata) if metadata else None
    
    @property
    def metadata(self) -> Dict[str, Any]:
        return json.loads(self.metadata_json) if self.metadata_json else {}

# ML Predictions
class MLPrediction(db.Model):
    __tablename__ = 'ml_predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    model_name = db.Column(db.String(100), nullable=False)
    input_data_json = db.Column(db.Text, nullable=False)  # JSON string
    prediction_json = db.Column(db.Text, nullable=False)  # JSON string
    confidence_score = db.Column(db.Float)
    model_version = db.Column(db.String(20))
    
    def __init__(self, model_name: str, input_data: Dict[str, Any], 
                 prediction: Dict[str, Any], confidence_score: float = None,
                 model_version: str = None):
        self.model_name = model_name
        self.input_data_json = json.dumps(input_data)
        self.prediction_json = json.dumps(prediction)
        self.confidence_score = confidence_score
        self.model_version = model_version
    
    @property
    def input_data(self) -> Dict[str, Any]:
        return json.loads(self.input_data_json)
    
    @property
    def prediction(self) -> Dict[str, Any]:
        return json.loads(self.prediction_json)

# AGI Infinity Loop Tracking
class InfinityLoopIteration(db.Model):
    __tablename__ = 'infinity_loop_iterations'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    iteration_number = db.Column(db.Integer, nullable=False)
    phase = db.Column(db.String(50), nullable=False)  # self_analysis, hypothesis_generation, etc.
    transcendence_score = db.Column(db.Float)
    consciousness_coherence = db.Column(db.Float)
    improvements_applied = db.Column(db.Integer, default=0)
    success_rate = db.Column(db.Float)
    metadata_json = db.Column(db.Text)  # JSON string for detailed results
    
    def __init__(self, iteration_number: int, phase: str, 
                 transcendence_score: float = None, consciousness_coherence: float = None,
                 improvements_applied: int = 0, success_rate: float = None,
                 metadata: Dict[str, Any] = None):
        self.iteration_number = iteration_number
        self.phase = phase
        self.transcendence_score = transcendence_score
        self.consciousness_coherence = consciousness_coherence
        self.improvements_applied = improvements_applied
        self.success_rate = success_rate
        self.metadata_json = json.dumps(metadata) if metadata else None
    
    @property
    def metadata(self) -> Dict[str, Any]:
        return json.loads(self.metadata_json) if self.metadata_json else {}

