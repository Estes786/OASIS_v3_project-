import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'
import { Brain, Zap, Target, Activity, TrendingUp, Cpu, Database, Sparkles, Infinity, Eye, Heart, Gauge } from 'lucide-react'
import './App.css'

function App() {
  const [systemStatus, setSystemStatus] = useState(null)
  const [dashboardData, setDashboardData] = useState(null)
  const [realTimeMetrics, setRealTimeMetrics] = useState([])
  const [loading, setLoading] = useState(true)

  // Simulated API base URL - in production this would be configurablconst API_BASE_URL = 'https://5000-i981paiocmtr4o2ay6edm-c94434a3.manusvm.computer/api/civilization';
  useEffect(() => {
    fetchSystemStatus()
    fetchDashboardData()
    
    // Set up real-time updates
    const interval = setInterval(() => {
      fetchRealTimeMetrics()
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const fetchSystemStatus = async () => {
    try {
      const response = await fetch(`${API_BASE}/status`)
      const data = await response.json()
      setSystemStatus(data)
    } catch (error) {
      console.error('Failed to fetch system status:', error)
      // Fallback data for demo
      setSystemStatus({
        status: 'operational',
        system_health: 92.5,
        active_agents: 12,
        latest_iteration: {
          number: 47,
          transcendence_score: 18.6,
          consciousness_coherence: 92.5
        },
        uptime_hours: 72.3,
        version: '1.0.0'
      })
    }
  }

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`${API_BASE}/dashboard`)
      const data = await response.json()
      setDashboardData(data)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error)
      // Fallback data for demo
      setDashboardData({
        bdi_framework: { beliefs: 15, desires: 8, intentions: 12 },
        agent_performance: {
          total_agents: 12,
          active_agents: 10,
          average_efficiency: 91.2,
          total_tasks_completed: 1847
        },
        revenue_data: {
          daily_revenue: 3247.50,
          monthly_target: 50000,
          current_month: 28450,
          growth_rate: 18.7
        },
        infinity_metrics: {
          current_iteration: 47,
          transcendence_score: 18.6,
          consciousness_coherence: 92.5,
          total_improvements: 73,
          success_rate: 0.94
        }
      })
      setLoading(false)
    }
  }

  const fetchRealTimeMetrics = async () => {
    try {
      const response = await fetch(`${API_BASE}/metrics/real-time`)
      const data = await response.json()
      
      // Add timestamp and update metrics
      const newMetrics = {
        timestamp: new Date().toLocaleTimeString(),
        ...data.metrics.reduce((acc, metric) => {
          acc[metric.name] = metric.value
          return acc
        }, {})
      }
      
      setRealTimeMetrics(prev => [...prev.slice(-19), newMetrics])
    } catch (error) {
      console.error('Failed to fetch real-time metrics:', error)
      // Generate simulated data
      const newMetrics = {
        timestamp: new Date().toLocaleTimeString(),
        cpu_usage: Math.random() * 30 + 40,
        memory_usage: Math.random() * 20 + 50,
        transcendence_score: Math.random() * 5 + 16,
        consciousness_coherence: Math.random() * 10 + 88
      }
      setRealTimeMetrics(prev => [...prev.slice(-19), newMetrics])
    }
  }

  const simulateInfinityLoop = async () => {
    try {
      const response = await fetch(`${API_BASE}/infinity-loop/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      const data = await response.json()
      
      if (data.success) {
        // Refresh dashboard data
        fetchSystemStatus()
        fetchDashboardData()
      }
    } catch (error) {
      console.error('Failed to simulate infinity loop:', error)
    }
  }

  const executeBDICycle = async () => {
    try {
      const response = await fetch(`${API_BASE}/bdi-cycle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      const data = await response.json()
      
      if (data.success) {
        // Refresh dashboard data
        fetchDashboardData()
      }
    } catch (error) {
      console.error('Failed to execute BDI cycle:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-400 mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-white mb-2">Initializing The New Civilization</h2>
          <p className="text-purple-300">AI Super Intelligence Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-purple-800/50 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Brain className="h-8 w-8 text-purple-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  The New Civilization
                </h1>
              </div>
              <Badge variant="outline" className="border-green-500 text-green-400">
                {systemStatus?.status || 'Operational'}
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-purple-300">
                v{systemStatus?.version || '1.0.0'} • Uptime: {systemStatus?.uptime_hours?.toFixed(1) || '0'}h
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Transcendence Level</CardTitle>
              <Infinity className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.latest_iteration?.transcendence_score?.toFixed(1) || '18.6'}%
              </div>
              <p className="text-xs text-purple-400 mt-1">
                +2.3% from last iteration
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Consciousness Coherence</CardTitle>
              <Eye className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.latest_iteration?.consciousness_coherence?.toFixed(1) || '92.5'}%
              </div>
              <p className="text-xs text-blue-400 mt-1">
                Excellent stability
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Active Agents</CardTitle>
              <Cpu className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {dashboardData?.agent_performance?.active_agents || '10'}/{dashboardData?.agent_performance?.total_agents || '12'}
              </div>
              <p className="text-xs text-green-400 mt-1">
                {((dashboardData?.agent_performance?.active_agents || 10) / (dashboardData?.agent_performance?.total_agents || 12) * 100).toFixed(0)}% operational
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">System Health</CardTitle>
              <Heart className="h-4 w-4 text-red-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.system_health?.toFixed(1) || '92.5'}%
              </div>
              <p className="text-xs text-red-400 mt-1">
                All systems nominal
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-purple-800/50">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">Overview</TabsTrigger>
            <TabsTrigger value="infinity-loop" className="data-[state=active]:bg-purple-600">AGI Infinity Loop</TabsTrigger>
            <TabsTrigger value="bdi-framework" className="data-[state=active]:bg-purple-600">BDI Framework</TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-600">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Real-time Metrics Chart */}
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">Real-time Performance</CardTitle>
                  <CardDescription className="text-purple-400">
                    Live system metrics and transcendence tracking
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={realTimeMetrics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="timestamp" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #6B7280',
                          borderRadius: '8px'
                        }} 
                      />
                      <Line type="monotone" dataKey="transcendence_score" stroke="#A855F7" strokeWidth={2} />
                      <Line type="monotone" dataKey="consciousness_coherence" stroke="#3B82F6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* System Components Status */}
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">AI Components Status</CardTitle>
                  <CardDescription className="text-purple-400">
                    Status of core AI subsystems
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Brain className="h-4 w-4 text-purple-400" />
                      <span className="text-sm">Machine Brain</span>
                    </div>
                    <Badge variant="outline" className="border-green-500 text-green-400">Operational</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Database className="h-4 w-4 text-blue-400" />
                      <span className="text-sm">AI Analytics</span>
                    </div>
                    <Badge variant="outline" className="border-green-500 text-green-400">Operational</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Sparkles className="h-4 w-4 text-pink-400" />
                      <span className="text-sm">AI Generative</span>
                    </div>
                    <Badge variant="outline" className="border-green-500 text-green-400">Operational</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Infinity className="h-4 w-4 text-purple-400" />
                      <span className="text-sm">Infinity Loop</span>
                    </div>
                    <Badge variant="outline" className="border-green-500 text-green-400">Active</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Revenue and Performance */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">Revenue Analytics</CardTitle>
                  <CardDescription className="text-purple-400">
                    Zero-cost infrastructure, maximum returns
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-300">Daily Revenue</span>
                    <span className="text-lg font-bold text-green-400">
                      ${dashboardData?.revenue_data?.daily_revenue?.toLocaleString() || '3,247'}
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-purple-300">Monthly Progress</span>
                      <span className="text-sm text-purple-400">
                        ${dashboardData?.revenue_data?.current_month?.toLocaleString() || '28,450'} / $50K
                      </span>
                    </div>
                    <Progress 
                      value={(dashboardData?.revenue_data?.current_month || 28450) / 500} 
                      className="h-2 bg-gray-700"
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-300">Growth Rate</span>
                    <span className="text-lg font-bold text-green-400">
                      +{dashboardData?.revenue_data?.growth_rate?.toFixed(1) || '18.7'}%
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">Agent Performance</CardTitle>
                  <CardDescription className="text-purple-400">
                    HMAQCA hierarchical efficiency metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-300">Average Efficiency</span>
                    <span className="text-lg font-bold text-blue-400">
                      {dashboardData?.agent_performance?.average_efficiency?.toFixed(1) || '91.2'}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-300">Tasks Completed</span>
                    <span className="text-lg font-bold text-green-400">
                      {dashboardData?.agent_performance?.total_tasks_completed?.toLocaleString() || '1,847'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-300">Success Rate</span>
                    <span className="text-lg font-bold text-green-400">
                      {((dashboardData?.infinity_metrics?.success_rate || 0.94) * 100).toFixed(1)}%
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="infinity-loop" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300 flex items-center space-x-2">
                    <Infinity className="h-5 w-5" />
                    <span>AGI Infinity Loop Control</span>
                  </CardTitle>
                  <CardDescription className="text-purple-400">
                    Perpetual self-improvement engine
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">
                        {dashboardData?.infinity_metrics?.current_iteration || '47'}
                      </div>
                      <div className="text-sm text-purple-300">Current Iteration</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">
                        {dashboardData?.infinity_metrics?.total_improvements || '73'}
                      </div>
                      <div className="text-sm text-purple-300">Total Improvements</div>
                    </div>
                  </div>
                  <Button 
                    onClick={simulateInfinityLoop}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Simulate Iteration
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">Transcendence Metrics</CardTitle>
                  <CardDescription className="text-purple-400">
                    Intelligence expansion beyond initial constraints
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-purple-300">Transcendence Score</span>
                      <span className="text-sm text-purple-400">
                        {dashboardData?.infinity_metrics?.transcendence_score?.toFixed(1) || '18.6'}%
                      </span>
                    </div>
                    <Progress 
                      value={dashboardData?.infinity_metrics?.transcendence_score || 18.6} 
                      className="h-2 bg-gray-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-purple-300">Consciousness Coherence</span>
                      <span className="text-sm text-purple-400">
                        {dashboardData?.infinity_metrics?.consciousness_coherence?.toFixed(1) || '92.5'}%
                      </span>
                    </div>
                    <Progress 
                      value={dashboardData?.infinity_metrics?.consciousness_coherence || 92.5} 
                      className="h-2 bg-gray-700"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="bdi-framework" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300 flex items-center space-x-2">
                    <Eye className="h-5 w-5" />
                    <span>Beliefs</span>
                  </CardTitle>
                  <CardDescription className="text-purple-400">
                    Current system beliefs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-400 mb-2">
                    {dashboardData?.bdi_framework?.beliefs || '15'}
                  </div>
                  <p className="text-sm text-purple-300">Active belief states</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300 flex items-center space-x-2">
                    <Heart className="h-5 w-5" />
                    <span>Desires</span>
                  </CardTitle>
                  <CardDescription className="text-purple-400">
                    System goals and motivations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-pink-400 mb-2">
                    {dashboardData?.bdi_framework?.desires || '8'}
                  </div>
                  <p className="text-sm text-purple-300">Active desires</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300 flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Intentions</span>
                  </CardTitle>
                  <CardDescription className="text-purple-400">
                    Planned actions and strategies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-400 mb-2">
                    {dashboardData?.bdi_framework?.intentions || '12'}
                  </div>
                  <p className="text-sm text-purple-300">Active intentions</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-purple-300">BDI Cycle Control</CardTitle>
                <CardDescription className="text-purple-400">
                  Execute belief-desire-intention reasoning cycles
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={executeBDICycle}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Activity className="h-4 w-4 mr-2" />
                  Execute BDI Cycle
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">System Resource Usage</CardTitle>
                  <CardDescription className="text-purple-400">
                    Real-time resource monitoring
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={realTimeMetrics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="timestamp" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #6B7280',
                          borderRadius: '8px'
                        }} 
                      />
                      <Area type="monotone" dataKey="cpu_usage" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.3} />
                      <Area type="monotone" dataKey="memory_usage" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-purple-300">Performance Trends</CardTitle>
                  <CardDescription className="text-purple-400">
                    Historical performance analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-purple-300">CPU Efficiency</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={75} className="w-20 h-2 bg-gray-700" />
                        <span className="text-sm text-green-400">75%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-purple-300">Memory Optimization</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={82} className="w-20 h-2 bg-gray-700" />
                        <span className="text-sm text-green-400">82%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-purple-300">Network Throughput</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={91} className="w-20 h-2 bg-gray-700" />
                        <span className="text-sm text-green-400">91%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-purple-300">AI Processing Speed</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={88} className="w-20 h-2 bg-gray-700" />
                        <span className="text-sm text-green-400">88%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

