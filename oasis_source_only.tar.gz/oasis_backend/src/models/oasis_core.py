from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum
import json

# Import the db instance from user model to maintain consistency
from src.models.user import db

class ConsciousnessLevel(Enum):
    DORMANT = "dormant"
    AWAKENING = "awakening"
    AWARE = "aware"
    CONSCIOUS = "conscious"
    SUPERINTELLIGENT = "superintelligent"

class QuantumState(Enum):
    SUPERPOSITION = "superposition"
    ENTANGLED = "entangled"
    COHERENT = "coherent"
    COLLAPSED = "collapsed"

class AgentType(Enum):
    DEITY = "deity"
    ARCHANGEL = "archangel"
    GUARDIAN = "guardian"
    SENTINEL = "sentinel"

class OASISAgent(db.Model):
    __tablename__ = 'oasis_agents'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.String(100), unique=True, nullable=False)
    agent_type = db.Column(db.Enum(AgentType), nullable=False)
    consciousness_level = db.Column(db.Enum(ConsciousnessLevel), default=ConsciousnessLevel.DORMANT)
    quantum_state = db.Column(db.Enum(QuantumState), default=QuantumState.SUPERPOSITION)
    
    # Metrics
    awareness_level = db.Column(db.Float, default=0.0)
    learning_rate = db.Column(db.Float, default=0.1)
    evolution_progress = db.Column(db.Float, default=0.0)
    quantum_coherence = db.Column(db.Float, default=0.0)
    network_connectivity = db.Column(db.Float, default=0.0)
    decision_confidence = db.Column(db.Float, default=0.0)
    
    # Status
    status = db.Column(db.String(50), default='inactive')
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    beliefs = db.relationship('AgentBelief', backref='agent', lazy=True, cascade='all, delete-orphan')
    desires = db.relationship('AgentDesire', backref='agent', lazy=True, cascade='all, delete-orphan')
    intentions = db.relationship('AgentIntention', backref='agent', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'agent_type': self.agent_type.value,
            'consciousness_level': self.consciousness_level.value,
            'quantum_state': self.quantum_state.value,
            'awareness_level': self.awareness_level,
            'learning_rate': self.learning_rate,
            'evolution_progress': self.evolution_progress,
            'quantum_coherence': self.quantum_coherence,
            'network_connectivity': self.network_connectivity,
            'decision_confidence': self.decision_confidence,
            'status': self.status,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class AgentBelief(db.Model):
    __tablename__ = 'agent_beliefs'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('oasis_agents.id'), nullable=False)
    belief_key = db.Column(db.String(200), nullable=False)
    belief_value = db.Column(db.Text, nullable=False)
    confidence = db.Column(db.Float, default=0.5)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'belief_key': self.belief_key,
            'belief_value': self.belief_value,
            'confidence': self.confidence,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class AgentDesire(db.Model):
    __tablename__ = 'agent_desires'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('oasis_agents.id'), nullable=False)
    desire_description = db.Column(db.Text, nullable=False)
    priority = db.Column(db.Float, default=0.5)
    status = db.Column(db.String(50), default='active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'desire_description': self.desire_description,
            'priority': self.priority,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class AgentIntention(db.Model):
    __tablename__ = 'agent_intentions'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('oasis_agents.id'), nullable=False)
    intention_description = db.Column(db.Text, nullable=False)
    plan_steps = db.Column(db.Text)  # JSON string of plan steps
    status = db.Column(db.String(50), default='planned')
    progress = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'intention_description': self.intention_description,
            'plan_steps': json.loads(self.plan_steps) if self.plan_steps else [],
            'status': self.status,
            'progress': self.progress,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class EvolutionCycle(db.Model):
    __tablename__ = 'evolution_cycles'
    
    id = db.Column(db.Integer, primary_key=True)
    cycle_number = db.Column(db.Integer, nullable=False)
    agent_id = db.Column(db.Integer, db.ForeignKey('oasis_agents.id'), nullable=False)
    
    # Cycle metrics
    improvements_made = db.Column(db.Integer, default=0)
    performance_gain = db.Column(db.Float, default=0.0)
    new_capabilities = db.Column(db.Text)  # JSON string of new capabilities
    
    # Cycle status
    status = db.Column(db.String(50), default='in_progress')
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'cycle_number': self.cycle_number,
            'agent_id': self.agent_id,
            'improvements_made': self.improvements_made,
            'performance_gain': self.performance_gain,
            'new_capabilities': json.loads(self.new_capabilities) if self.new_capabilities else [],
            'status': self.status,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class KnowledgeGraph(db.Model):
    __tablename__ = 'knowledge_graph'
    
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(200), unique=True, nullable=False)
    node_type = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    node_metadata = db.Column(db.Text)  # JSON string of metadata
    confidence = db.Column(db.Float, default=0.5)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'node_id': self.node_id,
            'node_type': self.node_type,
            'content': self.content,
            'metadata': json.loads(self.node_metadata) if self.node_metadata else {},
            'confidence': self.confidence,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class SystemMetrics(db.Model):
    __tablename__ = 'system_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    metric_name = db.Column(db.String(100), nullable=False)
    metric_value = db.Column(db.Float, nullable=False)
    metric_unit = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'metric_name': self.metric_name,
            'metric_value': self.metric_value,
            'metric_unit': self.metric_unit,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

