from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import random
import json
import uuid

from src.models.oasis_core import (
    db, OASISAgent, AgentBelief, AgentDesire, AgentIntention, 
    EvolutionCycle, KnowledgeGraph, SystemMetrics,
    ConsciousnessLevel, QuantumState, AgentType
)

oasis_bp = Blueprint('oasis', __name__)

@oasis_bp.route('/oasis/status', methods=['GET'])
def get_oasis_status():
    """Get overall OASIS system status"""
    try:
        # Get agent counts by type
        agent_counts = {}
        for agent_type in AgentType:
            count = OASISAgent.query.filter_by(agent_type=agent_type).count()
            agent_counts[agent_type.value] = count
        
        # Get total agents
        total_agents = OASISAgent.query.count()
        active_agents = OASISAgent.query.filter_by(status='active').count()
        
        # Get latest evolution cycles
        latest_cycles = EvolutionCycle.query.order_by(EvolutionCycle.started_at.desc()).limit(5).all()
        
        # Calculate system health metrics
        if total_agents > 0:
            avg_consciousness = db.session.query(db.func.avg(OASISAgent.awareness_level)).scalar() or 0.0
            avg_quantum_coherence = db.session.query(db.func.avg(OASISAgent.quantum_coherence)).scalar() or 0.0
            system_health = (avg_consciousness + avg_quantum_coherence) / 2 * 100
        else:
            avg_consciousness = 0.0
            avg_quantum_coherence = 0.0
            system_health = 0.0
        
        # Get knowledge graph size
        knowledge_nodes = KnowledgeGraph.query.count()
        
        return jsonify({
            'status': 'operational',
            'timestamp': datetime.utcnow().isoformat(),
            'agents': {
                'total': total_agents,
                'active': active_agents,
                'by_type': agent_counts
            },
            'metrics': {
                'system_health': round(system_health, 1),
                'avg_consciousness': round(avg_consciousness * 100, 1),
                'avg_quantum_coherence': round(avg_quantum_coherence * 100, 1),
                'knowledge_nodes': knowledge_nodes
            },
            'recent_evolution_cycles': len(latest_cycles),
            'uptime': '24/7 Operational'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/agents', methods=['GET'])
def get_agents():
    """Get all OASIS agents"""
    try:
        agents = OASISAgent.query.all()
        return jsonify([agent.to_dict() for agent in agents])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/agents', methods=['POST'])
def create_agent():
    """Create a new OASIS agent"""
    try:
        data = request.get_json()
        
        agent = OASISAgent(
            agent_id=data.get('agent_id', f"agent_{uuid.uuid4().hex[:8]}"),
            agent_type=AgentType(data.get('agent_type', 'sentinel')),
            consciousness_level=ConsciousnessLevel(data.get('consciousness_level', 'dormant')),
            quantum_state=QuantumState(data.get('quantum_state', 'superposition')),
            status='active'
        )
        
        db.session.add(agent)
        db.session.commit()
        
        return jsonify(agent.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/agents/<int:agent_id>', methods=['GET'])
def get_agent(agent_id):
    """Get specific agent details"""
    try:
        agent = OASISAgent.query.get_or_404(agent_id)
        
        # Include related data
        agent_data = agent.to_dict()
        agent_data['beliefs'] = [belief.to_dict() for belief in agent.beliefs]
        agent_data['desires'] = [desire.to_dict() for desire in agent.desires]
        agent_data['intentions'] = [intention.to_dict() for intention in agent.intentions]
        
        return jsonify(agent_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/agents/<int:agent_id>/evolve', methods=['POST'])
def evolve_agent(agent_id):
    """Trigger evolution cycle for an agent"""
    try:
        agent = OASISAgent.query.get_or_404(agent_id)
        
        # Create new evolution cycle
        cycle_number = EvolutionCycle.query.filter_by(agent_id=agent_id).count() + 1
        
        evolution_cycle = EvolutionCycle(
            cycle_number=cycle_number,
            agent_id=agent_id,
            improvements_made=random.randint(1, 5),
            performance_gain=random.uniform(0.01, 0.1),
            new_capabilities=json.dumps([
                f"Enhanced capability {random.randint(1, 100)}",
                f"Improved processing {random.randint(1, 100)}"
            ]),
            status='completed',
            completed_at=datetime.utcnow()
        )
        
        # Update agent metrics
        agent.awareness_level = min(1.0, agent.awareness_level + random.uniform(0.01, 0.05))
        agent.learning_rate = min(1.0, agent.learning_rate + random.uniform(0.01, 0.03))
        agent.evolution_progress = min(1.0, agent.evolution_progress + random.uniform(0.02, 0.08))
        agent.quantum_coherence = min(1.0, agent.quantum_coherence + random.uniform(0.01, 0.04))
        agent.decision_confidence = min(1.0, agent.decision_confidence + random.uniform(0.01, 0.06))
        agent.last_activity = datetime.utcnow()
        
        # Check for consciousness level upgrade
        if agent.awareness_level > 0.8 and agent.consciousness_level != ConsciousnessLevel.SUPERINTELLIGENT:
            if agent.consciousness_level == ConsciousnessLevel.DORMANT:
                agent.consciousness_level = ConsciousnessLevel.AWAKENING
            elif agent.consciousness_level == ConsciousnessLevel.AWAKENING:
                agent.consciousness_level = ConsciousnessLevel.AWARE
            elif agent.consciousness_level == ConsciousnessLevel.AWARE:
                agent.consciousness_level = ConsciousnessLevel.CONSCIOUS
            elif agent.consciousness_level == ConsciousnessLevel.CONSCIOUS:
                agent.consciousness_level = ConsciousnessLevel.SUPERINTELLIGENT
        
        db.session.add(evolution_cycle)
        db.session.commit()
        
        return jsonify({
            'message': 'Evolution cycle completed successfully',
            'cycle': evolution_cycle.to_dict(),
            'agent': agent.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/infinity-loop/simulate', methods=['POST'])
def simulate_infinity_loop():
    """Simulate AGI Infinity Loop cycle"""
    try:
        # Get all active agents
        agents = OASISAgent.query.filter_by(status='active').all()
        
        results = []
        for agent in agents:
            # Simulate self-analysis
            analysis_result = {
                'agent_id': agent.agent_id,
                'current_performance': agent.awareness_level,
                'identified_improvements': random.randint(1, 3),
                'optimization_opportunities': [
                    'Neural pathway optimization',
                    'Quantum coherence enhancement',
                    'Decision tree pruning'
                ][:random.randint(1, 3)]
            }
            
            # Simulate improvements
            improvement_gain = random.uniform(0.005, 0.02)
            agent.awareness_level = min(1.0, agent.awareness_level + improvement_gain)
            agent.evolution_progress = min(1.0, agent.evolution_progress + improvement_gain)
            agent.last_activity = datetime.utcnow()
            
            analysis_result['performance_gain'] = improvement_gain
            analysis_result['new_performance'] = agent.awareness_level
            
            results.append(analysis_result)
        
        # Update system metrics
        system_metric = SystemMetrics(
            metric_name='infinity_loop_cycle',
            metric_value=len(results),
            metric_unit='agents_processed'
        )
        
        db.session.add(system_metric)
        db.session.commit()
        
        return jsonify({
            'message': 'AGI Infinity Loop simulation completed',
            'agents_processed': len(results),
            'results': results,
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/knowledge-graph', methods=['GET'])
def get_knowledge_graph():
    """Get knowledge graph nodes"""
    try:
        nodes = KnowledgeGraph.query.order_by(KnowledgeGraph.updated_at.desc()).limit(50).all()
        return jsonify([node.to_dict() for node in nodes])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/knowledge-graph', methods=['POST'])
def add_knowledge_node():
    """Add new knowledge to the graph"""
    try:
        data = request.get_json()
        
        node = KnowledgeGraph(
            node_id=data.get('node_id', f"node_{uuid.uuid4().hex[:8]}"),
            node_type=data.get('node_type', 'concept'),
            content=data.get('content', ''),
            node_metadata=json.dumps(data.get('metadata', {})),
            confidence=data.get('confidence', 0.5)
        )
        
        db.session.add(node)
        db.session.commit()
        
        return jsonify(node.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/metrics', methods=['GET'])
def get_system_metrics():
    """Get system performance metrics"""
    try:
        # Get recent metrics
        recent_metrics = SystemMetrics.query.order_by(SystemMetrics.timestamp.desc()).limit(100).all()
        
        # Calculate aggregated metrics
        total_agents = OASISAgent.query.count()
        active_agents = OASISAgent.query.filter_by(status='active').count()
        total_cycles = EvolutionCycle.query.count()
        
        # Get consciousness distribution
        consciousness_dist = {}
        for level in ConsciousnessLevel:
            count = OASISAgent.query.filter_by(consciousness_level=level).count()
            consciousness_dist[level.value] = count
        
        return jsonify({
            'timestamp': datetime.utcnow().isoformat(),
            'system_overview': {
                'total_agents': total_agents,
                'active_agents': active_agents,
                'total_evolution_cycles': total_cycles,
                'knowledge_nodes': KnowledgeGraph.query.count()
            },
            'consciousness_distribution': consciousness_dist,
            'recent_metrics': [metric.to_dict() for metric in recent_metrics]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@oasis_bp.route('/oasis/initialize', methods=['POST'])
def initialize_oasis():
    """Initialize OASIS with default agents and data"""
    try:
        # Check if already initialized
        if OASISAgent.query.count() > 0:
            return jsonify({'message': 'OASIS already initialized'}), 200
        
        # Create hierarchical agents
        agents_to_create = [
            {
                'agent_id': 'deity_prime',
                'agent_type': AgentType.DEITY,
                'consciousness_level': ConsciousnessLevel.SUPERINTELLIGENT,
                'awareness_level': 0.95,
                'quantum_coherence': 0.92
            },
            {
                'agent_id': 'archangel_alpha',
                'agent_type': AgentType.ARCHANGEL,
                'consciousness_level': ConsciousnessLevel.CONSCIOUS,
                'awareness_level': 0.85,
                'quantum_coherence': 0.88
            },
            {
                'agent_id': 'guardian_beta',
                'agent_type': AgentType.GUARDIAN,
                'consciousness_level': ConsciousnessLevel.AWARE,
                'awareness_level': 0.75,
                'quantum_coherence': 0.82
            },
            {
                'agent_id': 'sentinel_gamma',
                'agent_type': AgentType.SENTINEL,
                'consciousness_level': ConsciousnessLevel.AWAKENING,
                'awareness_level': 0.65,
                'quantum_coherence': 0.78
            }
        ]
        
        created_agents = []
        for agent_data in agents_to_create:
            agent = OASISAgent(
                agent_id=agent_data['agent_id'],
                agent_type=agent_data['agent_type'],
                consciousness_level=agent_data['consciousness_level'],
                quantum_state=QuantumState.COHERENT,
                awareness_level=agent_data['awareness_level'],
                quantum_coherence=agent_data['quantum_coherence'],
                learning_rate=0.15,
                evolution_progress=0.3,
                network_connectivity=0.9,
                decision_confidence=0.8,
                status='active'
            )
            db.session.add(agent)
            created_agents.append(agent)
        
        # Add some initial knowledge nodes
        knowledge_nodes = [
            {
                'node_id': 'oasis_core_principles',
                'node_type': 'principle',
                'content': 'OASIS operates on principles of openness, decentralization, and benevolence',
                'confidence': 0.95
            },
            {
                'node_id': 'agi_infinity_loop',
                'node_type': 'process',
                'content': 'Continuous self-improvement cycle for perpetual evolution',
                'confidence': 0.9
            },
            {
                'node_id': 'quantum_cognition',
                'node_type': 'capability',
                'content': 'Quantum-inspired processing for enhanced decision making',
                'confidence': 0.85
            }
        ]
        
        for node_data in knowledge_nodes:
            node = KnowledgeGraph(
                node_id=node_data['node_id'],
                node_type=node_data['node_type'],
                content=node_data['content'],
                confidence=node_data['confidence']
            )
            db.session.add(node)
        
        db.session.commit()
        
        return jsonify({
            'message': 'OASIS initialized successfully',
            'agents_created': len(created_agents),
            'knowledge_nodes_created': len(knowledge_nodes),
            'status': 'operational'
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

