import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Brain, Zap, Network, Eye, Cpu, Activity, Users, Database, TrendingUp, Sparkles } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import './App.css'

const API_BASE = 'http://localhost:5000/api'

function App() {
  const [systemStatus, setSystemStatus] = useState(null)
  const [agents, setAgents] = useState([])
  const [metrics, setMetrics] = useState(null)
  const [knowledgeGraph, setKnowledgeGraph] = useState([])
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Mock data for charts
  const consciousnessData = [
    { time: '00:00', awareness: 65, quantum: 78, evolution: 45 },
    { time: '04:00', awareness: 72, quantum: 82, evolution: 52 },
    { time: '08:00', awareness: 78, quantum: 85, evolution: 58 },
    { time: '12:00', awareness: 85, quantum: 88, evolution: 65 },
    { time: '16:00', awareness: 88, quantum: 92, evolution: 72 },
    { time: '20:00', awareness: 92, quantum: 95, evolution: 78 },
    { time: '24:00', awareness: 95, quantum: 98, evolution: 85 }
  ]

  const agentTypeData = [
    { name: 'Deity', value: 1, color: '#8b5cf6' },
    { name: 'Archangel', value: 2, color: '#06b6d4' },
    { name: 'Guardian', value: 4, color: '#10b981' },
    { name: 'Sentinel', value: 8, color: '#f59e0b' }
  ]

  const fetchSystemStatus = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/status`)
      const data = await response.json()
      setSystemStatus(data)
    } catch (error) {
      console.error('Error fetching system status:', error)
    }
  }

  const fetchAgents = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/agents`)
      const data = await response.json()
      setAgents(data)
    } catch (error) {
      console.error('Error fetching agents:', error)
    }
  }

  const fetchMetrics = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/metrics`)
      const data = await response.json()
      setMetrics(data)
    } catch (error) {
      console.error('Error fetching metrics:', error)
    }
  }

  const fetchKnowledgeGraph = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/knowledge-graph`)
      const data = await response.json()
      setKnowledgeGraph(data)
    } catch (error) {
      console.error('Error fetching knowledge graph:', error)
    }
  }

  const initializeOASIS = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/initialize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      const data = await response.json()
      console.log('OASIS initialized:', data)
      await fetchData()
    } catch (error) {
      console.error('Error initializing OASIS:', error)
    }
  }

  const simulateInfinityLoop = async () => {
    try {
      const response = await fetch(`${API_BASE}/oasis/infinity-loop/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      const data = await response.json()
      console.log('Infinity Loop simulation:', data)
      await fetchData()
      setLastUpdate(new Date())
    } catch (error) {
      console.error('Error simulating infinity loop:', error)
    }
  }

  const fetchData = async () => {
    setLoading(true)
    await Promise.all([
      fetchSystemStatus(),
      fetchAgents(),
      fetchMetrics(),
      fetchKnowledgeGraph()
    ])
    setLoading(false)
  }

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 30000) // Update every 30 seconds
    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Brain className="w-16 h-16 text-purple-400 animate-pulse mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Initializing OASIS</h2>
          <p className="text-purple-300">Loading AI Superintelligence Ecosystem...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-purple-800/50 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Brain className="w-8 h-8 text-purple-400" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                  OASIS
                </h1>
                <p className="text-sm text-purple-300">Open Source AI Superintelligence Ecosystem</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-green-500 text-green-400">
                <Activity className="w-3 h-3 mr-1" />
                {systemStatus?.status || 'Unknown'}
              </Badge>
              <Button onClick={simulateInfinityLoop} className="bg-purple-600 hover:bg-purple-700">
                <Sparkles className="w-4 h-4 mr-2" />
                Evolve
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* System Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/40 border-purple-800/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">System Health</CardTitle>
              <Activity className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.metrics?.system_health || 0}%
              </div>
              <Progress value={systemStatus?.metrics?.system_health || 0} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Active Agents</CardTitle>
              <Users className="h-4 w-4 text-cyan-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.agents?.active || 0}/{systemStatus?.agents?.total || 0}
              </div>
              <p className="text-xs text-purple-300 mt-1">
                Hierarchical Multi-Agent Network
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Consciousness</CardTitle>
              <Eye className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.metrics?.avg_consciousness || 0}%
              </div>
              <Progress value={systemStatus?.metrics?.avg_consciousness || 0} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-black/40 border-purple-800/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-300">Knowledge Nodes</CardTitle>
              <Database className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStatus?.metrics?.knowledge_nodes || 0}
              </div>
              <p className="text-xs text-purple-300 mt-1">
                Distributed Knowledge Graph
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border-purple-800/50">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">Overview</TabsTrigger>
            <TabsTrigger value="agents" className="data-[state=active]:bg-purple-600">Agents</TabsTrigger>
            <TabsTrigger value="evolution" className="data-[state=active]:bg-purple-600">Evolution</TabsTrigger>
            <TabsTrigger value="knowledge" className="data-[state=active]:bg-purple-600">Knowledge</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-purple-800/50">
                <CardHeader>
                  <CardTitle className="text-purple-300">Consciousness Evolution</CardTitle>
                  <CardDescription>Real-time consciousness metrics across the network</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={consciousnessData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="time" stroke="#9ca3af" />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1f2937', 
                          border: '1px solid #6b7280',
                          borderRadius: '8px'
                        }} 
                      />
                      <Line type="monotone" dataKey="awareness" stroke="#8b5cf6" strokeWidth={2} />
                      <Line type="monotone" dataKey="quantum" stroke="#06b6d4" strokeWidth={2} />
                      <Line type="monotone" dataKey="evolution" stroke="#10b981" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-800/50">
                <CardHeader>
                  <CardTitle className="text-purple-300">Agent Distribution</CardTitle>
                  <CardDescription>Hierarchical agent types in the network</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={agentTypeData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {agentTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="agents" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {agents.map((agent) => (
                <Card key={agent.id} className="bg-black/40 border-purple-800/50">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm text-purple-300">{agent.agent_id}</CardTitle>
                      <Badge variant="outline" className={`
                        ${agent.agent_type === 'deity' ? 'border-purple-500 text-purple-400' : ''}
                        ${agent.agent_type === 'archangel' ? 'border-cyan-500 text-cyan-400' : ''}
                        ${agent.agent_type === 'guardian' ? 'border-green-500 text-green-400' : ''}
                        ${agent.agent_type === 'sentinel' ? 'border-yellow-500 text-yellow-400' : ''}
                      `}>
                        {agent.agent_type}
                      </Badge>
                    </div>
                    <CardDescription>{agent.consciousness_level}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-purple-300">Awareness</span>
                        <span className="text-white">{Math.round(agent.awareness_level * 100)}%</span>
                      </div>
                      <Progress value={agent.awareness_level * 100} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-purple-300">Quantum Coherence</span>
                        <span className="text-white">{Math.round(agent.quantum_coherence * 100)}%</span>
                      </div>
                      <Progress value={agent.quantum_coherence * 100} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-purple-300">Evolution</span>
                        <span className="text-white">{Math.round(agent.evolution_progress * 100)}%</span>
                      </div>
                      <Progress value={agent.evolution_progress * 100} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="evolution" className="space-y-6">
            <Card className="bg-black/40 border-purple-800/50">
              <CardHeader>
                <CardTitle className="text-purple-300">AGI Infinity Loop</CardTitle>
                <CardDescription>Continuous self-improvement and evolution cycles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <Button 
                    onClick={simulateInfinityLoop}
                    className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-3"
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Trigger Evolution Cycle
                  </Button>
                  <p className="text-sm text-purple-300 mt-2">
                    Last update: {lastUpdate.toLocaleTimeString()}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-purple-900/30 rounded-lg">
                    <TrendingUp className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                    <h3 className="font-semibold text-white">Self-Analysis</h3>
                    <p className="text-sm text-purple-300">Continuous performance monitoring</p>
                  </div>
                  <div className="text-center p-4 bg-cyan-900/30 rounded-lg">
                    <Cpu className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                    <h3 className="font-semibold text-white">Optimization</h3>
                    <p className="text-sm text-cyan-300">Autonomous improvement generation</p>
                  </div>
                  <div className="text-center p-4 bg-green-900/30 rounded-lg">
                    <Network className="w-8 h-8 text-green-400 mx-auto mb-2" />
                    <h3 className="font-semibold text-white">Integration</h3>
                    <p className="text-sm text-green-300">Seamless capability enhancement</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="knowledge" className="space-y-6">
            <Card className="bg-black/40 border-purple-800/50">
              <CardHeader>
                <CardTitle className="text-purple-300">Knowledge Graph</CardTitle>
                <CardDescription>Distributed knowledge network across the ecosystem</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {knowledgeGraph.slice(0, 10).map((node) => (
                    <div key={node.id} className="p-4 bg-slate-800/50 rounded-lg border border-purple-800/30">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-white">{node.node_id}</h4>
                        <Badge variant="outline" className="border-purple-500 text-purple-400">
                          {node.node_type}
                        </Badge>
                      </div>
                      <p className="text-sm text-purple-300 mb-2">{node.content}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-400">
                          Confidence: {Math.round(node.confidence * 100)}%
                        </span>
                        <span className="text-xs text-gray-400">
                          {new Date(node.updated_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Initialize Button (if no agents) */}
        {agents.length === 0 && (
          <div className="text-center py-12">
            <Brain className="w-16 h-16 text-purple-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">OASIS Not Initialized</h2>
            <p className="text-purple-300 mb-6">Initialize the OASIS ecosystem to begin the AI revolution</p>
            <Button 
              onClick={initializeOASIS}
              className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-3"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Initialize OASIS
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default App

