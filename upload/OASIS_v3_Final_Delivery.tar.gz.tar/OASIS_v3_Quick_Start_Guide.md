# OASIS v3 Quick Start Guide
## Get Your AI Civilization Running in 5 Minutes

**🚀 Ultra-Fast Deployment • 💰 Instant Revenue Generation • 📱 Zero Heavy Dependencies**

---

## 🎯 What You'll Achieve

In just 5 minutes, you'll have:
- ✅ A fully functional AI orchestration system on your Android device
- ✅ Access to powerful AI models (text generation, sentiment analysis, image processing)
- ✅ Automated revenue tracking and business analytics
- ✅ A deployed HuggingFace Spaces AI backend
- ✅ Ready-to-use API endpoints for client services

**Revenue Potential:** $1K-10K/month with minimal effort

---

## 📋 Prerequisites (2 minutes)

### Required:
- Android device (7.0+) with Termux installed
- Internet connection
- HuggingFace account (free)

### Install Termux:
1. Download from [F-Droid](https://f-droid.org/packages/com.termux/) (recommended)
2. Or from [GitHub Releases](https://github.com/termux/termux-app/releases)
3. **DO NOT** use Google Play Store version (has limitations)

---

## ⚡ One-Command Installation

### Step 1: Install OASIS v3 (1 minute)

Open Termux and run:

```bash
curl -sSL https://raw.githubusercontent.com/oasis-ai/oasis-v3/main/install.sh | bash
```

This command will:
- ✅ Update Termux packages
- ✅ Install Python and essential tools
- ✅ Download and setup OASIS v3 components
- ✅ Create configuration files
- ✅ Test all components

**Expected output:**
```
🚀 OASIS v3 - One-Command Installer
====================================
📱 Termux environment detected
✅ Python installed: Python 3.11.0
✅ OASIS v3 installation complete!
🎯 Run 'oasis status' to begin
```

### Step 2: Deploy to HuggingFace Spaces (2 minutes)

```bash
# Navigate to OASIS directory
cd ~/oasis_v3

# Deploy to HuggingFace (replace with your details)
python deploy_to_hf.py oasis-v3-ai your-username
```

**Follow the prompts:**
1. Login to HuggingFace when prompted
2. Wait for deployment (1-2 minutes)
3. Note your Space URL: `https://your-username-oasis-v3-ai.hf.space`

---

## 🔧 Quick Configuration

### Step 3: Configure Your System

```bash
# Edit configuration
nano ~/oasis_v3/oasis_config.json
```

**Update these key settings:**
```json
{
    "hf_spaces": {
        "primary_url": "https://your-username-oasis-v3-ai.hf.space",
        "api_key": "your_secure_api_key_here"
    },
    "business": {
        "pricing": {
            "text_generation": 0.05,
            "sentiment_analysis": 0.01,
            "image_processing": 0.10
        }
    }
}
```

**Save and exit:** `Ctrl+X`, then `Y`, then `Enter`

---

## 🧪 Test Your System

### Step 4: Verify Everything Works

```bash
# Check system status
oasis status

# Test text generation
ai-text "Write a short story about AI"

# Test sentiment analysis
ai-sentiment "I love this new AI system!"

# Check business dashboard
oasis-business
```

**Expected results:**
- ✅ Status shows "operational"
- ✅ Text generation produces coherent content
- ✅ Sentiment analysis returns positive score
- ✅ Business dashboard shows $0.00 revenue (ready to grow!)

---

## 💰 Start Generating Revenue

### Step 5: Begin Offering AI Services

**Immediate opportunities:**

1. **Content Creation Services**
   ```bash
   # Generate blog posts for clients
   ai-text "Write a 500-word blog post about sustainable technology"
   # Charge: $5-25 per post
   ```

2. **Social Media Management**
   ```bash
   # Analyze customer feedback
   ai-sentiment "Customer review text here"
   # Charge: $0.01-0.05 per analysis
   ```

3. **Business Analytics**
   ```bash
   # Process business data
   ai-data "Analyze sales trends from uploaded CSV"
   # Charge: $10-50 per analysis
   ```

### Pricing Strategy:
- **Text Generation:** $0.05 per request
- **Sentiment Analysis:** $0.01 per request
- **Image Processing:** $0.10 per request
- **Custom Analysis:** $0.15+ per request

---

## 📈 Scale Your Business

### Advanced Features (Optional)

**1. API Integration for Clients:**
```python
import requests

# Your client's code
response = requests.post('https://your-space.hf.space/run_model', 
    json={
        'api_key': 'client_api_key',
        'model_name': 'text_generation',
        'input_data': {'prompt': 'Generate marketing copy'}
    })
```

**2. Automated Billing:**
```bash
# View revenue reports
oasis-business --report monthly

# Export client billing
oasis-business --export-billing client_id
```

**3. Multiple AI Models:**
- Add custom models to your HuggingFace Space
- Update configuration to include new services
- Adjust pricing for specialized models

---

## 🔧 Troubleshooting

### Common Issues:

**"Connection failed" error:**
```bash
# Check internet connection
ping google.com

# Verify HuggingFace Space URL
curl https://your-space.hf.space/status
```

**"API key invalid" error:**
```bash
# Update API key in config
nano ~/oasis_v3/oasis_config.json
```

**"Command not found" error:**
```bash
# Reload shell configuration
source ~/.bashrc

# Or restart Termux
```

---

## 🎉 Success Checklist

After completing this guide, you should have:

- [ ] ✅ OASIS v3 installed and running on Termux
- [ ] ✅ HuggingFace Spaces backend deployed and accessible
- [ ] ✅ All AI models responding correctly
- [ ] ✅ Business automation tracking revenue
- [ ] ✅ API endpoints ready for client integration
- [ ] ✅ Understanding of pricing and revenue opportunities

**🎯 Next Steps:**
1. Start offering services to friends/colleagues
2. Create social media presence for your AI services
3. Join the OASIS community for tips and support
4. Scale to $1K+/month revenue within 30 days

---

## 📞 Support and Community

- **Documentation:** [Complete Guide](./OASIS_v3_Complete_Documentation.md)
- **GitHub:** https://github.com/oasis-ai/oasis-v3
- **Community:** https://discord.gg/oasis-ai
- **Issues:** https://github.com/oasis-ai/oasis-v3/issues

---

**🌟 Welcome to the AI Revolution!**

You now have a complete AI business platform running on your Android device. Start small, think big, and scale to success!

**Estimated setup time:** 5 minutes  
**Revenue potential:** $1K-10K/month  
**Investment required:** $0 (free tier usage)  

---

*Built with ❤️ by the OASIS Team • MIT License • Version 3.0.0*

