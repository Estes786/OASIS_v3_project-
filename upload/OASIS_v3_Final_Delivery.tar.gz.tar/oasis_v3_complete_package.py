#!/usr/bin/env python3
"""
OASIS v3 - Complete Package Builder
Creates a comprehensive deployment package with all components
"""

import os
import shutil
import zipfile
import json
from pathlib import Path
from datetime import datetime

class OASISPackageBuilder:
    def __init__(self):
        self.package_name = "oasis_v3_complete_package"
        self.build_dir = Path(f"/tmp/{self.package_name}")
        self.source_dir = Path("/home/ubuntu")
        
    def create_package_structure(self):
        """Create the package directory structure"""
        print("📁 Creating package structure...")
        
        # Remove existing build directory
        if self.build_dir.exists():
            shutil.rmtree(self.build_dir)
        
        # Create main directories
        directories = [
            "termux_orchestrator",
            "huggingface_spaces",
            "deployment_scripts", 
            "documentation",
            "business_automation",
            "security",
            "examples",
            "tests"
        ]
        
        for directory in directories:
            (self.build_dir / directory).mkdir(parents=True, exist_ok=True)
        
        print("✅ Package structure created")
    
    def copy_termux_components(self):
        """Copy Termux orchestrator components"""
        print("📱 Copying Termux components...")
        
        termux_dir = self.build_dir / "termux_orchestrator"
        source_termux = self.source_dir / "oasis_v3_termux"
        
        # Copy main files
        files_to_copy = [
            "oasis.py",
            "requirements.txt", 
            "setup_termux.sh",
            "comprehensive_setup.sh",
            "termux_api_integration.py",
            "README.md"
        ]
        
        for file_name in files_to_copy:
            source_file = source_termux / file_name
            if source_file.exists():
                shutil.copy2(source_file, termux_dir / file_name)
                print(f"  ✓ {file_name}")
        
        print("✅ Termux components copied")
    
    def copy_huggingface_components(self):
        """Copy HuggingFace Spaces components"""
        print("🤗 Copying HuggingFace components...")
        
        hf_dir = self.build_dir / "huggingface_spaces"
        source_hf = self.source_dir / "oasis_v3_hf_app"
        
        # Copy main files
        files_to_copy = [
            "app.py",
            "requirements.txt",
            "README.md",
            "deploy_to_hf.sh",
            "quick_deploy.py"
        ]
        
        for file_name in files_to_copy:
            source_file = source_hf / file_name
            if source_file.exists():
                shutil.copy2(source_file, hf_dir / file_name)
                print(f"  ✓ {file_name}")
        
        print("✅ HuggingFace components copied")
    
    def copy_security_components(self):
        """Copy security components"""
        print("🔐 Copying security components...")
        
        security_dir = self.build_dir / "security"
        
        # Copy security files
        security_file = self.source_dir / "oasis_v3_security.py"
        if security_file.exists():
            shutil.copy2(security_file, security_dir / "oasis_v3_security.py")
            print("  ✓ oasis_v3_security.py")
        
        print("✅ Security components copied")
    
    def copy_business_components(self):
        """Copy business automation components"""
        print("💰 Copying business components...")
        
        business_dir = self.build_dir / "business_automation"
        
        # Copy business files from uploads
        business_files = [
            "business_automation.py",
            "hf_client.py"
        ]
        
        for file_name in business_files:
            source_file = self.source_dir / "upload" / file_name
            if source_file.exists():
                shutil.copy2(source_file, business_dir / file_name)
                print(f"  ✓ {file_name}")
        
        print("✅ Business components copied")
    
    def create_deployment_scripts(self):
        """Create unified deployment scripts"""
        print("🚀 Creating deployment scripts...")
        
        deploy_dir = self.build_dir / "deployment_scripts"
        
        # Create one-command installer
        installer_content = '''#!/bin/bash
# OASIS v3 - One-Command Installer
# Usage: curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/install.sh | bash

set -e

echo "🚀 OASIS v3 - One-Command Installer"
echo "===================================="

# Check if running on Termux
if [[ "$PREFIX" == *"com.termux"* ]]; then
    echo "📱 Termux environment detected"
    
    # Update packages
    pkg update -y && pkg upgrade -y
    
    # Install essentials
    pkg install -y python git curl wget
    
    # Download and run Termux setup
    curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/termux_setup.sh | bash
    
else
    echo "💻 Standard Linux environment detected"
    
    # Install Python and Git
    if command -v apt &> /dev/null; then
        sudo apt update && sudo apt install -y python3 python3-pip git curl wget
    elif command -v yum &> /dev/null; then
        sudo yum install -y python3 python3-pip git curl wget
    fi
    
    # Download and run standard setup
    curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/setup.sh | bash
fi

echo "✅ OASIS v3 installation complete!"
echo "🎯 Run 'oasis status' to begin"
'''
        
        with open(deploy_dir / "install.sh", "w") as f:
            f.write(installer_content)
        
        os.chmod(deploy_dir / "install.sh", 0o755)
        
        # Create HuggingFace deployment script
        hf_deploy_content = '''#!/bin/bash
# OASIS v3 - HuggingFace Spaces Deployment

SPACE_NAME="${1:-oasis-v3-ai-platform}"
HF_USERNAME="${2:-your-username}"

echo "🚀 Deploying OASIS v3 to HuggingFace Spaces"
echo "Space: $HF_USERNAME/$SPACE_NAME"

# Install HuggingFace CLI if needed
if ! command -v huggingface-cli &> /dev/null; then
    pip install huggingface_hub[cli]
fi

# Create space
huggingface-cli repo create "$SPACE_NAME" --type space --space_sdk gradio

# Clone and setup
git clone "https://huggingface.co/spaces/$HF_USERNAME/$SPACE_NAME" temp_space
cd temp_space

# Copy files
cp ../huggingface_spaces/* .

# Commit and push
git add .
git commit -m "Deploy OASIS v3 AI Platform"
git push origin main

echo "✅ Deployment complete!"
echo "🔗 Visit: https://huggingface.co/spaces/$HF_USERNAME/$SPACE_NAME"

# Cleanup
cd ..
rm -rf temp_space
'''
        
        with open(deploy_dir / "deploy_hf.sh", "w") as f:
            f.write(hf_deploy_content)
        
        os.chmod(deploy_dir / "deploy_hf.sh", 0o755)
        
        print("✅ Deployment scripts created")
    
    def create_documentation(self):
        """Create comprehensive documentation"""
        print("📚 Creating documentation...")
        
        docs_dir = self.build_dir / "documentation"
        
        # Main README
        readme_content = '''# OASIS v3 - Ultra-Lightweight AI Platform

🌟 **Revolutionary AI orchestration using Termux + HuggingFace Spaces**

## Features

- **Ultra-Lightweight**: <5MB footprint on Android devices
- **Zero Heavy Dependencies**: Python standard library + urllib only
- **Hybrid Architecture**: Termux orchestration + HuggingFace Spaces AI processing
- **Business Ready**: Built-in revenue tracking and automation
- **Secure**: API key authentication and encrypted communication
- **One-Command Setup**: Complete installation in minutes

## Quick Start

### Option 1: One-Command Install
```bash
curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/install.sh | bash
```

### Option 2: Manual Installation

#### On Termux (Android)
```bash
# Download and run setup
wget https://raw.githubusercontent.com/your-repo/oasis-v3/main/termux_setup.sh
bash termux_setup.sh
```

#### On Linux/macOS
```bash
# Download and run setup
wget https://raw.githubusercontent.com/your-repo/oasis-v3/main/setup.sh
bash setup.sh
```

## Architecture

```
[Android Device (Termux)]  ←→  [HuggingFace Spaces]
     Orchestrator                  AI Processing
     <5MB footprint               Heavy ML/DL models
     Business logic              GPU acceleration
     Revenue tracking            Scalable compute
```

## Usage

### Basic Commands
```bash
# Check system status
oasis status

# Generate text
ai-text "Write a story about AI"

# Analyze sentiment
ai-sentiment "I love this product!"

# Check revenue
oasis-business
```

### API Usage
```python
from oasis import OASISOrchestrator

orchestrator = OASISOrchestrator()
result = orchestrator.run_ai_model('text_generation', {'text': 'Hello, world!'})
print(result)
```

## Business Model

- **Text Generation**: $0.05 per request
- **Sentiment Analysis**: $0.01 per request  
- **Image Processing**: $0.10 per request
- **Data Analysis**: $0.15 per request
- **Batch Processing**: $0.50 per batch

**Target Revenue**: $1K-10K/month

## Deployment

### Deploy to HuggingFace Spaces
```bash
bash deployment_scripts/deploy_hf.sh oasis-v3-ai your-username
```

### Configure Termux Orchestrator
```bash
# Edit configuration
nano ~/oasis_v3/oasis_config.json

# Set HuggingFace Space URL
oasis config set hf_space_url https://your-space.hf.space
```

## Components

- **Termux Orchestrator**: Ultra-lightweight command center
- **HuggingFace Spaces App**: AI/ML/DL processing backend
- **Business Engine**: Revenue tracking and automation
- **Security Module**: Authentication and encryption
- **Deployment Scripts**: One-command setup and deployment

## Requirements

### Termux (Android)
- Android 7.0+
- Termux app
- 100MB free storage
- Internet connection

### HuggingFace Spaces
- HuggingFace account
- Spaces quota (free tier available)

## Support

- 📖 Documentation: `/documentation/`
- 🧪 Examples: `/examples/`
- 🔧 Tests: `/tests/`
- 🐛 Issues: GitHub Issues

## License

MIT License - See LICENSE file for details

---

**Built with ❤️ for the AI Revolution**
'''
        
        with open(docs_dir / "README.md", "w") as f:
            f.write(readme_content)
        
        # API Documentation
        api_docs_content = '''# OASIS v3 API Documentation

## Overview

OASIS v3 provides a RESTful API for AI/ML/DL operations through HuggingFace Spaces.

## Authentication

All requests require an API key:

```bash
curl -H "X-API-Key: your_api_key" https://your-space.hf.space/status
```

## Endpoints

### GET /status
Get system status and health information.

**Response:**
```json
{
    "status": "operational",
    "uptime_seconds": 86400,
    "active_requests": 3,
    "total_requests": 1250
}
```

### POST /run_model
Execute AI/ML/DL models.

**Request:**
```json
{
    "api_key": "your_api_key",
    "model_name": "text_generation",
    "input_data": {
        "prompt": "Write a story about AI",
        "max_length": 100
    }
}
```

**Response:**
```json
{
    "status": "success",
    "output_data": {
        "generated_text": "Once upon a time, in a world where artificial intelligence..."
    },
    "execution_time_ms": 2500
}
```

### POST /upload_data
Upload data files for processing.

### GET /download_results
Download processed results.

## Python SDK

```python
from oasis import OASISOrchestrator

# Initialize
orchestrator = OASISOrchestrator()

# Configure
orchestrator.set_config('hf_space_url', 'https://your-space.hf.space')
orchestrator.set_config('api_key', 'your_api_key')

# Generate text
result = orchestrator.run_ai_model('text_generation', {
    'prompt': 'Hello, world!',
    'max_length': 50
})

# Analyze sentiment
sentiment = orchestrator.run_ai_model('sentiment_analysis', {
    'text': 'I love this product!'
})

# Process image
image_result = orchestrator.run_ai_model('image_processing', {
    'image_url': 'https://example.com/image.jpg',
    'operation': 'analyze'
})
```

## Error Handling

All API responses include error information:

```json
{
    "status": "error",
    "message": "Invalid API key",
    "error_code": "AUTH_INVALID"
}
```

## Rate Limits

- Free tier: 100 requests/hour
- Pro tier: 1000 requests/hour
- Enterprise: Unlimited

## Webhooks

Configure webhooks for real-time notifications:

```json
{
    "webhook_url": "https://your-app.com/webhook",
    "events": ["model_complete", "error"]
}
```
'''
        
        with open(docs_dir / "API.md", "w") as f:
            f.write(api_docs_content)
        
        print("✅ Documentation created")
    
    def create_examples(self):
        """Create example scripts and use cases"""
        print("💡 Creating examples...")
        
        examples_dir = self.build_dir / "examples"
        
        # Basic usage example
        basic_example = '''#!/usr/bin/env python3
"""
OASIS v3 - Basic Usage Example
"""

from oasis import OASISOrchestrator

def main():
    # Initialize orchestrator
    orchestrator = OASISOrchestrator()
    
    # Configure (replace with your values)
    orchestrator.set_config('hf_space_url', 'https://your-space.hf.space')
    orchestrator.set_config('api_key', 'your_api_key')
    
    # Check status
    print("🔍 Checking system status...")
    status = orchestrator.get_status()
    if status:
        print(f"✅ System is {status.get('status', 'unknown')}")
    
    # Generate text
    print("📝 Generating text...")
    result = orchestrator.run_ai_model('text_generation', {
        'prompt': 'The future of AI is',
        'max_length': 100
    })
    
    if result:
        print(f"Generated: {result.get('generated_text', 'No output')}")
    
    # Analyze sentiment
    print("😊 Analyzing sentiment...")
    sentiment = orchestrator.run_ai_model('sentiment_analysis', {
        'text': 'OASIS v3 is amazing!'
    })
    
    if sentiment:
        print(f"Sentiment: {sentiment}")

if __name__ == '__main__':
    main()
'''
        
        with open(examples_dir / "basic_usage.py", "w") as f:
            f.write(basic_example)
        
        # Business automation example
        business_example = '''#!/usr/bin/env python3
"""
OASIS v3 - Business Automation Example
"""

from business_automation import RevenueEngine
from oasis import OASISOrchestrator

def main():
    # Initialize components
    orchestrator = OASISOrchestrator()
    revenue_engine = RevenueEngine()
    
    # Simulate AI service requests
    services = [
        ('text_generation', 'Generate marketing copy', 0.05),
        ('sentiment_analysis', 'Analyze customer feedback', 0.01),
        ('image_processing', 'Process product images', 0.10),
        ('data_analysis', 'Analyze sales data', 0.15)
    ]
    
    total_revenue = 0
    
    for service_type, description, price in services:
        print(f"🤖 Processing: {description}")
        
        # Execute AI service
        result = orchestrator.run_ai_model(service_type, {
            'text': description
        })
        
        if result:
            # Record revenue
            transaction_id = revenue_engine.add_transaction(
                service_type, price, client_id="demo_client"
            )
            total_revenue += price
            print(f"💰 Revenue recorded: ${price:.2f} (ID: {transaction_id})")
    
    # Show daily summary
    daily_revenue = revenue_engine.get_daily_revenue()
    monthly_revenue = revenue_engine.get_monthly_revenue()
    
    print(f"\\n📊 Revenue Summary:")
    print(f"Today: ${daily_revenue:.2f}")
    print(f"This month: ${monthly_revenue:.2f}")
    print(f"Session total: ${total_revenue:.2f}")
    
    # Save data
    revenue_engine.save_data()
    print("💾 Revenue data saved")

if __name__ == '__main__':
    main()
'''
        
        with open(examples_dir / "business_automation.py", "w") as f:
            f.write(business_example)
        
        print("✅ Examples created")
    
    def create_tests(self):
        """Create test scripts"""
        print("🧪 Creating tests...")
        
        tests_dir = self.build_dir / "tests"
        
        # Integration test
        test_content = '''#!/usr/bin/env python3
"""
OASIS v3 - Integration Tests
"""

import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from termux_orchestrator.oasis import OASISOrchestrator

class TestOASISIntegration(unittest.TestCase):
    
    def setUp(self):
        self.orchestrator = OASISOrchestrator()
    
    def test_configuration_loading(self):
        """Test configuration loading"""
        config = self.orchestrator.load_config()
        self.assertIsInstance(config, dict)
    
    def test_session_id_generation(self):
        """Test session ID generation"""
        session_id = self.orchestrator.generate_session_id()
        self.assertIsInstance(session_id, str)
        self.assertEqual(len(session_id), 8)
    
    def test_status_endpoint(self):
        """Test status endpoint (requires HF Spaces)"""
        # This test requires a configured HF Spaces URL
        # Skip if not configured
        hf_url = self.orchestrator.config.get('hf_spaces', {}).get('primary_url', '')
        if not hf_url or 'your-space' in hf_url:
            self.skipTest("HuggingFace Spaces not configured")
        
        result = self.orchestrator.get_status()
        self.assertIsNotNone(result)

if __name__ == '__main__':
    unittest.main()
'''
        
        with open(tests_dir / "test_integration.py", "w") as f:
            f.write(test_content)
        
        print("✅ Tests created")
    
    def create_package_info(self):
        """Create package information files"""
        print("📋 Creating package info...")
        
        # Package manifest
        manifest = {
            "name": "OASIS v3",
            "version": "3.0.0",
            "description": "Ultra-Lightweight AI Platform for Termux + HuggingFace Spaces",
            "author": "OASIS Team",
            "license": "MIT",
            "created": datetime.now().isoformat(),
            "components": {
                "termux_orchestrator": "Ultra-lightweight command center for Android",
                "huggingface_spaces": "AI/ML/DL processing backend",
                "business_automation": "Revenue tracking and automation",
                "security": "Authentication and encryption",
                "deployment_scripts": "One-command setup and deployment",
                "documentation": "Comprehensive guides and API docs",
                "examples": "Usage examples and tutorials",
                "tests": "Integration and unit tests"
            },
            "requirements": {
                "termux": ["python", "git", "curl", "wget"],
                "huggingface": ["gradio", "flask", "transformers"],
                "optional": ["termux-api"]
            },
            "targets": {
                "revenue": "$1K-10K/month",
                "footprint": "<5MB on Termux",
                "dependencies": "Python standard library only"
            }
        }
        
        with open(self.build_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
        
        # License file
        license_content = '''MIT License

Copyright (c) 2024 OASIS Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''
        
        with open(self.build_dir / "LICENSE", "w") as f:
            f.write(license_content)
        
        print("✅ Package info created")
    
    def create_zip_package(self):
        """Create ZIP package for distribution"""
        print("📦 Creating ZIP package...")
        
        zip_path = Path(f"/home/ubuntu/{self.package_name}.zip")
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(self.build_dir):
                for file in files:
                    file_path = Path(root) / file
                    arc_path = file_path.relative_to(self.build_dir)
                    zipf.write(file_path, arc_path)
        
        # Get package size
        size_mb = zip_path.stat().st_size / (1024 * 1024)
        
        print(f"✅ Package created: {zip_path}")
        print(f"📏 Package size: {size_mb:.2f} MB")
        
        return zip_path
    
    def build_complete_package(self):
        """Build the complete OASIS v3 package"""
        print("🚀 Building OASIS v3 Complete Package...")
        print("=" * 50)
        
        self.create_package_structure()
        self.copy_termux_components()
        self.copy_huggingface_components()
        self.copy_security_components()
        self.copy_business_components()
        self.create_deployment_scripts()
        self.create_documentation()
        self.create_examples()
        self.create_tests()
        self.create_package_info()
        zip_path = self.create_zip_package()
        
        print("=" * 50)
        print("🎉 OASIS v3 Complete Package Built Successfully!")
        print(f"📦 Package: {zip_path}")
        print(f"📁 Build directory: {self.build_dir}")
        print("")
        print("🚀 Ready for distribution and deployment!")
        
        return zip_path

def main():
    """Main function"""
    builder = OASISPackageBuilder()
    package_path = builder.build_complete_package()
    
    print(f"\n✅ Complete package available at: {package_path}")

if __name__ == '__main__':
    main()

