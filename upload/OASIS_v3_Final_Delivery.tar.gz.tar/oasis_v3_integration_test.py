#!/usr/bin/env python3
"""
OASIS v3 - Comprehensive Integration Test
Tests all components and their interactions
"""

import os
import sys
import json
import tempfile
import shutil
from pathlib import Path

class OASISIntegrationTester:
    def __init__(self):
        self.test_results = []
        self.package_dir = Path("/tmp/oasis_v3_complete_package")
        self.temp_dir = None
        
    def log_test(self, test_name, status, message=""):
        """Log test result"""
        result = {
            "test": test_name,
            "status": status,
            "message": message
        }
        self.test_results.append(result)
        
        status_icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{status_icon} {test_name}: {message}")
    
    def test_package_structure(self):
        """Test if package structure is correct"""
        required_dirs = [
            "termux_orchestrator",
            "huggingface_spaces", 
            "business_automation",
            "security",
            "deployment_scripts",
            "documentation",
            "examples",
            "tests"
        ]
        
        missing_dirs = []
        for dir_name in required_dirs:
            if not (self.package_dir / dir_name).exists():
                missing_dirs.append(dir_name)
        
        if missing_dirs:
            self.log_test("Package Structure", "FAIL", f"Missing directories: {missing_dirs}")
        else:
            self.log_test("Package Structure", "PASS", "All required directories present")
    
    def test_termux_orchestrator(self):
        """Test Termux orchestrator component"""
        orchestrator_dir = self.package_dir / "termux_orchestrator"
        
        # Check required files
        required_files = ["oasis.py", "requirements.txt", "README.md"]
        missing_files = []
        
        for file_name in required_files:
            if not (orchestrator_dir / file_name).exists():
                missing_files.append(file_name)
        
        if missing_files:
            self.log_test("Termux Orchestrator Files", "FAIL", f"Missing files: {missing_files}")
            return
        
        self.log_test("Termux Orchestrator Files", "PASS", "All required files present")
        
        # Test Python syntax
        try:
            with open(orchestrator_dir / "oasis.py", "r") as f:
                code = f.read()
            compile(code, "oasis.py", "exec")
            self.log_test("Termux Orchestrator Syntax", "PASS", "Python syntax valid")
        except SyntaxError as e:
            self.log_test("Termux Orchestrator Syntax", "FAIL", f"Syntax error: {e}")
    
    def test_huggingface_spaces(self):
        """Test HuggingFace Spaces component"""
        hf_dir = self.package_dir / "huggingface_spaces"
        
        # Check required files
        required_files = ["app.py", "requirements.txt", "README.md"]
        missing_files = []
        
        for file_name in required_files:
            if not (hf_dir / file_name).exists():
                missing_files.append(file_name)
        
        if missing_files:
            self.log_test("HuggingFace Spaces Files", "FAIL", f"Missing files: {missing_files}")
            return
        
        self.log_test("HuggingFace Spaces Files", "PASS", "All required files present")
        
        # Test Python syntax
        try:
            with open(hf_dir / "app.py", "r") as f:
                code = f.read()
            compile(code, "app.py", "exec")
            self.log_test("HuggingFace Spaces Syntax", "PASS", "Python syntax valid")
        except SyntaxError as e:
            self.log_test("HuggingFace Spaces Syntax", "FAIL", f"Syntax error: {e}")
    
    def test_business_automation(self):
        """Test business automation component"""
        business_dir = self.package_dir / "business_automation"
        
        # Check required files
        required_files = ["business_automation.py", "hf_client.py"]
        missing_files = []
        
        for file_name in required_files:
            if not (business_dir / file_name).exists():
                missing_files.append(file_name)
        
        if missing_files:
            self.log_test("Business Automation Files", "FAIL", f"Missing files: {missing_files}")
            return
        
        self.log_test("Business Automation Files", "PASS", "All required files present")
        
        # Test Python syntax
        try:
            with open(business_dir / "business_automation.py", "r") as f:
                code = f.read()
            compile(code, "business_automation.py", "exec")
            self.log_test("Business Automation Syntax", "PASS", "Python syntax valid")
        except SyntaxError as e:
            self.log_test("Business Automation Syntax", "FAIL", f"Syntax error: {e}")
    
    def test_deployment_scripts(self):
        """Test deployment scripts"""
        deploy_dir = self.package_dir / "deployment_scripts"
        
        # Check required files
        required_files = ["install.sh", "deploy_hf.sh"]
        missing_files = []
        
        for file_name in required_files:
            if not (deploy_dir / file_name).exists():
                missing_files.append(file_name)
        
        if missing_files:
            self.log_test("Deployment Scripts", "FAIL", f"Missing files: {missing_files}")
            return
        
        self.log_test("Deployment Scripts", "PASS", "All required files present")
        
        # Check if scripts are executable
        for script in ["install.sh", "deploy_hf.sh"]:
            script_path = deploy_dir / script
            if not os.access(script_path, os.X_OK):
                self.log_test("Script Permissions", "WARN", f"{script} not executable")
            else:
                self.log_test("Script Permissions", "PASS", f"{script} is executable")
    
    def test_documentation(self):
        """Test documentation"""
        docs_dir = self.package_dir / "documentation"
        
        # Check required files
        required_files = ["README.md", "API.md"]
        missing_files = []
        
        for file_name in required_files:
            if not (docs_dir / file_name).exists():
                missing_files.append(file_name)
        
        if missing_files:
            self.log_test("Documentation", "FAIL", f"Missing files: {missing_files}")
            return
        
        self.log_test("Documentation", "PASS", "All required documentation present")
        
        # Check documentation content
        readme_path = docs_dir / "README.md"
        with open(readme_path, "r") as f:
            readme_content = f.read()
        
        if len(readme_content) < 1000:
            self.log_test("Documentation Quality", "WARN", "README.md seems too short")
        else:
            self.log_test("Documentation Quality", "PASS", "README.md has substantial content")
    
    def test_examples(self):
        """Test example scripts"""
        examples_dir = self.package_dir / "examples"
        
        # Check if examples directory exists and has content
        if not examples_dir.exists():
            self.log_test("Examples", "FAIL", "Examples directory missing")
            return
        
        example_files = list(examples_dir.glob("*.py"))
        if not example_files:
            self.log_test("Examples", "FAIL", "No example files found")
            return
        
        self.log_test("Examples", "PASS", f"Found {len(example_files)} example files")
        
        # Test syntax of example files
        for example_file in example_files:
            try:
                with open(example_file, "r") as f:
                    code = f.read()
                compile(code, example_file.name, "exec")
                self.log_test(f"Example Syntax ({example_file.name})", "PASS", "Valid Python syntax")
            except SyntaxError as e:
                self.log_test(f"Example Syntax ({example_file.name})", "FAIL", f"Syntax error: {e}")
    
    def test_package_manifest(self):
        """Test package manifest"""
        manifest_path = self.package_dir / "manifest.json"
        
        if not manifest_path.exists():
            self.log_test("Package Manifest", "FAIL", "manifest.json missing")
            return
        
        try:
            with open(manifest_path, "r") as f:
                manifest = json.load(f)
            
            required_keys = ["name", "version", "description", "components"]
            missing_keys = [key for key in required_keys if key not in manifest]
            
            if missing_keys:
                self.log_test("Package Manifest", "FAIL", f"Missing keys: {missing_keys}")
            else:
                self.log_test("Package Manifest", "PASS", "Valid manifest structure")
                
        except json.JSONDecodeError as e:
            self.log_test("Package Manifest", "FAIL", f"Invalid JSON: {e}")
    
    def test_functional_components(self):
        """Test functional aspects of components"""
        # Create temporary config for testing
        self.temp_dir = tempfile.mkdtemp()
        config_path = Path(self.temp_dir) / "oasis_config.json"
        
        test_config = {
            "version": "3.0.0",
            "hf_spaces": {
                "primary_url": "https://test-space.hf.space",
                "api_key": "test_key"
            },
            "business": {
                "pricing": {
                    "text_generation": 0.05,
                    "sentiment_analysis": 0.01
                }
            }
        }
        
        with open(config_path, "w") as f:
            json.dump(test_config, f)
        
        # Test business automation with config
        try:
            sys.path.insert(0, str(self.package_dir / "business_automation"))
            
            # Import and test business automation
            import business_automation
            
            # Create revenue engine with test config
            revenue_engine = business_automation.RevenueEngine(str(config_path))
            
            # Test transaction recording
            transaction_id = revenue_engine.add_transaction("text_generation", 0.05, "test_client")
            
            if transaction_id:
                self.log_test("Business Automation Function", "PASS", "Transaction recording works")
            else:
                self.log_test("Business Automation Function", "FAIL", "Transaction recording failed")
                
        except Exception as e:
            self.log_test("Business Automation Function", "FAIL", f"Error: {e}")
        finally:
            # Cleanup
            if self.temp_dir:
                shutil.rmtree(self.temp_dir)
    
    def generate_report(self):
        """Generate test report"""
        print("\n" + "="*60)
        print("🧪 OASIS v3 Integration Test Report")
        print("="*60)
        
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.test_results if r["status"] == "FAIL"])
        warning_tests = len([r for r in self.test_results if r["status"] == "WARN"])
        
        print(f"📊 Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"⚠️  Warnings: {warning_tests}")
        print(f"📈 Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ Failed Tests:")
            for result in self.test_results:
                if result["status"] == "FAIL":
                    print(f"  • {result['test']}: {result['message']}")
        
        if warning_tests > 0:
            print("\n⚠️  Warnings:")
            for result in self.test_results:
                if result["status"] == "WARN":
                    print(f"  • {result['test']}: {result['message']}")
        
        print("\n" + "="*60)
        
        if failed_tests == 0:
            print("🎉 All critical tests passed! OASIS v3 is ready for deployment.")
            return True
        else:
            print("🔧 Some tests failed. Please review and fix issues before deployment.")
            return False
    
    def run_all_tests(self):
        """Run all integration tests"""
        print("🚀 Starting OASIS v3 Integration Tests...")
        print("="*60)
        
        self.test_package_structure()
        self.test_termux_orchestrator()
        self.test_huggingface_spaces()
        self.test_business_automation()
        self.test_deployment_scripts()
        self.test_documentation()
        self.test_examples()
        self.test_package_manifest()
        self.test_functional_components()
        
        return self.generate_report()

def main():
    """Main function"""
    tester = OASISIntegrationTester()
    success = tester.run_all_tests()
    
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()

