import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/providers'
import { Toaster } from '@/components/ui/toaster'
import { Analytics } from '@/components/analytics'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'OASIS v3 - AI Superintelligence Ecosystem',
  description: 'Ultra-Lightweight AI Superintelligence Ecosystem - Production Ready Revenue Generator targeting $10K+/month through automated AI services, content generation, and enterprise solutions.',
  keywords: ['AI', 'Superintelligence', 'Revenue Generation', 'Enterprise', 'Mobile-First', 'Quantum Computing'],
  authors: [{ name: 'OASIS v3 Development Team' }],
  creator: 'OASIS v3',
  publisher: 'OASIS v3',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://oasis-v3-ai-ecosystem.vercel.app'),
  openGraph: {
    title: 'OASIS v3 - AI Superintelligence Ecosystem',
    description: 'Ultra-Lightweight AI Superintelligence Ecosystem - Production Ready Revenue Generator',
    url: process.env.NEXT_PUBLIC_APP_URL,
    siteName: 'OASIS v3',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'OASIS v3 - AI Superintelligence Ecosystem',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'OASIS v3 - AI Superintelligence Ecosystem',
    description: 'Ultra-Lightweight AI Superintelligence Ecosystem - Production Ready Revenue Generator',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          <div className="relative flex min-h-screen flex-col">
            <main className="flex-1">
              {children}
            </main>
          </div>
          <Toaster />
          <Analytics />
        </Providers>
      </body>
    </html>
  )
}