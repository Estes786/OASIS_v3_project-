import { HeroSection } from '@/components/sections/hero-section'
import { FeaturesSection } from '@/components/sections/features-section'
import { RevenueSection } from '@/components/sections/revenue-section'
import { TechStackSection } from '@/components/sections/tech-stack-section'
import { PricingSection } from '@/components/sections/pricing-section'
import { DemoSection } from '@/components/sections/demo-section'
import { CTASection } from '@/components/sections/cta-section'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { RevenueTracker } from '@/components/revenue/revenue-tracker'

export default function HomePage() {
  return (
    <>
      <Header />
      <RevenueTracker />
      <main>
        <HeroSection />
        <FeaturesSection />
        <RevenueSection />
        <TechStackSection />
        <DemoSection />
        <PricingSection />
        <CTASection />
      </main>
      <Footer />
    </>
  )
}