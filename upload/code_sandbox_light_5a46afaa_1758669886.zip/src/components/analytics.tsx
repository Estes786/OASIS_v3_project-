'use client'

import { useEffect } from 'react'
import Script from 'next/script'

export function Analytics() {
  useEffect(() => {
    // Initialize analytics tracking
    if (typeof window !== 'undefined') {
      // Google Analytics
      if (process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID) {
        window.gtag?.('config', process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID, {
          page_title: document.title,
          page_location: window.location.href,
        })
      }

      // Revenue tracking
      window.addEventListener('revenue-event', (event: any) => {
        const { eventName, value, currency = 'USD' } = event.detail
        
        // Track revenue event
        window.gtag?.('event', 'purchase', {
          transaction_id: `rev_${Date.now()}`,
          value: value,
          currency: currency,
          event_category: 'revenue',
          event_label: eventName,
        })
      })
    }
  }, [])

  if (!process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID) {
    return null
  }

  return (
    <>
      <Script
        strategy="afterInteractive"
        src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID}`}
      />
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID}', {
              page_title: document.title,
              page_location: window.location.href,
            });
          `,
        }}
      />
    </>
  )
}