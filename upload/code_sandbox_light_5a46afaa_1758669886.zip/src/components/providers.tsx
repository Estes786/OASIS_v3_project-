'use client'

import { ReactNode } from 'react'
import { SupabaseProvider } from '@/lib/supabase/provider'
import { StripeProvider } from '@/lib/stripe/provider'
import { RevenueProvider } from '@/lib/revenue/provider'
import { QuantumProvider } from '@/lib/quantum/provider'

interface ProvidersProps {
  children: ReactNode
}

export function Providers({ children }: ProvidersProps) {
  return (
    <SupabaseProvider>
      <StripeProvider>
        <RevenueProvider>
          <QuantumProvider>
            {children}
          </QuantumProvider>
        </RevenueProvider>
      </StripeProvider>
    </SupabaseProvider>
  )
}