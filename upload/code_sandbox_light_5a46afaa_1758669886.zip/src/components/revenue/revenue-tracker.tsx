'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { TrendingUp, DollarSign, Target, Zap } from 'lucide-react'
import { useRevenue } from '@/hooks/use-revenue'
import { formatCurrency } from '@/lib/utils'

interface RevenueData {
  daily: number
  monthly: number
  yearly: number
  target: number
  growth: number
}

export function RevenueTracker() {
  const [isVisible, setIsVisible] = useState(false)
  const { revenueData, isLoading } = useRevenue()
  const [animatedValues, setAnimatedValues] = useState<RevenueData>({
    daily: 0,
    monthly: 0,
    yearly: 0,
    target: 10000,
    growth: 0,
  })

  useEffect(() => {
    setIsVisible(true)
    
    // Animate numbers when data loads
    if (revenueData && !isLoading) {
      const interval = setInterval(() => {
        setAnimatedValues(prev => ({
          daily: Math.min(prev.daily + revenueData.daily * 0.1, revenueData.daily),
          monthly: Math.min(prev.monthly + revenueData.monthly * 0.05, revenueData.monthly),
          yearly: Math.min(prev.yearly + revenueData.yearly * 0.02, revenueData.yearly),
          target: revenueData.target,
          growth: Math.min(prev.growth + revenueData.growth * 0.1, revenueData.growth),
        }))
      }, 100)

      return () => clearInterval(interval)
    }
  }, [revenueData, isLoading])

  if (!isVisible) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -100 }}
        className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-primary-600 to-primary-800 text-white shadow-lg"
      >
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Zap className="h-4 w-4 text-yellow-300 animate-pulse" />
                <span className="text-sm font-semibold">OASIS v3 LIVE</span>
              </div>
              
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-1">
                  <DollarSign className="h-3 w-3" />
                  <span className="revenue-counter">
                    {formatCurrency(animatedValues.daily)}/day
                  </span>
                </div>
                
                <div className="flex items-center space-x-1">
                  <Target className="h-3 w-3" />
                  <span className="revenue-counter">
                    {formatCurrency(animatedValues.monthly)}/mo
                  </span>
                </div>
                
                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-3 w-3" />
                  <span className="text-green-300">
                    +{animatedValues.growth.toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-xs opacity-80">
                Progress: {((animatedValues.monthly / animatedValues.target) * 100).toFixed(1)}%
              </div>
              
              <div className="w-20 h-2 bg-white/20 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-green-400 to-yellow-300"
                  initial={{ width: 0 }}
                  animate={{ 
                    width: `${Math.min((animatedValues.monthly / animatedValues.target) * 100, 100)}%` 
                  }}
                  transition={{ duration: 1, ease: "easeOut" }}
                />
              </div>
              
              <button
                onClick={() => setIsVisible(false)}
                className="text-white/60 hover:text-white transition-colors text-sm"
              >
                ×
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}