'use client'

import * as React from 'react'

export interface ToastProps {
  id: string
  title?: string
  description?: string
  action?: React.ReactNode
  variant?: 'default' | 'destructive'
}

const toastVariants = {
  default: 'bg-white border-gray-200 text-gray-900',
  destructive: 'bg-red-50 border-red-200 text-red-900',
}

export function Toast({ title, description, variant = 'default' }: Omit<ToastProps, 'id'>) {
  return (
    <div className={`fixed top-4 right-4 z-50 rounded-lg border p-4 shadow-lg ${toastVariants[variant]}`}>
      {title && <div className="font-semibold">{title}</div>}
      {description && <div className="text-sm opacity-90">{description}</div>}
    </div>
  )
}

export function Toaster() {
  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {/* Toast notifications will be rendered here */}
    </div>
  )
}