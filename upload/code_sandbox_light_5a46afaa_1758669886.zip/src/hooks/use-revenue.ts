import { useRevenueContext } from '@/lib/revenue/provider'

export function useRevenue() {
  return useRevenueContext()
}