'use client'

import { createContext, useContext, ReactNode, useState, useEffect } from 'react'
import { RevenueService } from './service'

interface RevenueData {
  daily: number
  monthly: number
  yearly: number
  target: number
  growth: number
  apiCalls: number
  conversions: number
  activeUsers: number
}

interface RevenueContextType {
  revenueData: RevenueData | null
  isLoading: boolean
  error: string | null
  refreshRevenue: () => Promise<void>
  trackEvent: (event: string, value?: number) => Promise<void>
}

const RevenueContext = createContext<RevenueContextType | undefined>(undefined)

export function useRevenueContext() {
  const context = useContext(RevenueContext)
  if (context === undefined) {
    throw new Error('useRevenueContext must be used within a RevenueProvider')
  }
  return context
}

interface RevenueProviderProps {
  children: ReactNode
}

export function RevenueProvider({ children }: RevenueProviderProps) {
  const [revenueData, setRevenueData] = useState<RevenueData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const revenueService = new RevenueService()

  const fetchRevenueData = async () => {
    try {
      setIsLoading(true)
      setError(null)
      
      const data = await revenueService.getCurrentRevenue()
      setRevenueData(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch revenue data')
    } finally {
      setIsLoading(false)
    }
  }

  const trackEvent = async (event: string, value?: number) => {
    try {
      await revenueService.trackEvent(event, value)
      // Optionally refresh data after tracking
      if (event === 'purchase' || event === 'subscription') {
        await fetchRevenueData()
      }
    } catch (err) {
      console.error('Failed to track event:', err)
    }
  }

  useEffect(() => {
    fetchRevenueData()
    
    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchRevenueData, 30000)
    
    return () => clearInterval(interval)
  }, [])

  return (
    <RevenueContext.Provider
      value={{
        revenueData,
        isLoading,
        error,
        refreshRevenue: fetchRevenueData,
        trackEvent,
      }}
    >
      {children}
    </RevenueContext.Provider>
  )
}