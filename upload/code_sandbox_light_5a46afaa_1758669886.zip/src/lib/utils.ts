import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('en-US').format(num)
}

export function formatPercentage(num: number): string {
  return `${num.toFixed(1)}%`
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength) + '...'
}

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

export function generateId(): string {
  return Math.random().toString(36).substr(2, 9)
}

export function capitalizeFirst(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  return String(error)
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function calculateRevenueMetrics(data: {
  current: number
  target: number
  previous?: number
}) {
  const progress = (data.current / data.target) * 100
  const growth = data.previous ? ((data.current - data.previous) / data.previous) * 100 : 0
  
  return {
    progress: Math.min(progress, 100),
    growth,
    remaining: Math.max(data.target - data.current, 0),
    status: progress >= 100 ? 'exceeded' : progress >= 80 ? 'on-track' : 'needs-attention'
  }
}

export function getRevenueStatusColor(status: string): string {
  switch (status) {
    case 'exceeded':
      return 'text-green-600'
    case 'on-track':
      return 'text-blue-600'
    case 'needs-attention':
      return 'text-red-600'
    default:
      return 'text-gray-600'
  }
}