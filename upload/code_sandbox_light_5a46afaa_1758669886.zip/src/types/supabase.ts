export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          subscription_tier: string
          api_calls_used: number
          api_calls_limit: number
          revenue_generated: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          subscription_tier?: string
          api_calls_used?: number
          api_calls_limit?: number
          revenue_generated?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          subscription_tier?: string
          api_calls_used?: number
          api_calls_limit?: number
          revenue_generated?: number
          created_at?: string
          updated_at?: string
        }
      }
      revenue_events: {
        Row: {
          id: string
          user_id: string | null
          event_name: string
          event_value: number
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          event_name: string
          event_value?: number
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          event_name?: string
          event_value?: number
          metadata?: Json
          created_at?: string
        }
      }
      api_calls: {
        Row: {
          id: string
          user_id: string | null
          endpoint: string
          method: string
          status_code: number | null
          response_time_ms: number | null
          cost: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          endpoint: string
          method: string
          status_code?: number | null
          response_time_ms?: number | null
          cost?: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          endpoint?: string
          method?: string
          status_code?: number | null
          response_time_ms?: number | null
          cost?: number
          created_at?: string
        }
      }
      subscriptions: {
        Row: {
          id: string
          user_id: string
          stripe_subscription_id: string | null
          stripe_customer_id: string | null
          plan_name: string
          status: string
          current_period_start: string | null
          current_period_end: string | null
          cancel_at_period_end: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          stripe_subscription_id?: string | null
          stripe_customer_id?: string | null
          plan_name: string
          status: string
          current_period_start?: string | null
          current_period_end?: string | null
          cancel_at_period_end?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          stripe_subscription_id?: string | null
          stripe_customer_id?: string | null
          plan_name?: string
          status?: string
          current_period_start?: string | null
          current_period_end?: string | null
          cancel_at_period_end?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_daily_revenue: {
        Args: {
          target_date?: string
        }
        Returns: number
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}