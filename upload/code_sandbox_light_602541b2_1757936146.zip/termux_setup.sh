#!/bin/bash
#
# OASIS v3 Termux Setup Script - Ultra-Lightweight Installation
# =============================================================
# Installs ONLY Python and essential components for <5MB footprint
# ZERO heavy dependencies - maximum compatibility
#
# Architecture: Termux Command Center ←→ HuggingFace Spaces AI Backend
#

set -e  # Exit on any error

echo "🚀 OASIS v3 Termux Setup - Ultra-Lightweight Installation"
echo "========================================================="
echo "Target footprint: <5MB"
echo "Dependencies: Python + urllib ONLY"
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Progress tracking
STEPS_TOTAL=8
STEP_CURRENT=0

progress() {
    STEP_CURRENT=$((STEP_CURRENT + 1))
    echo -e "${BLUE}[$STEP_CURRENT/$STEPS_TOTAL]${NC} $1"
}

success() {
    echo -e "${GREEN}✅${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠️${NC} $1"
}

error() {
    echo -e "${RED}❌${NC} $1"
    exit 1
}

# Check if running in Termux
progress "Checking Termux environment"
if [[ ! -d "/data/data/com.termux" ]]; then
    warning "Not running in Termux - proceeding with standard Linux setup"
    TERMUX_ENV=false
else
    success "Termux environment detected"
    TERMUX_ENV=true
fi

# Update package list
progress "Updating package repositories"
if $TERMUX_ENV; then
    pkg update -y || error "Failed to update Termux packages"
else
    sudo apt update -y || error "Failed to update packages"
fi
success "Package repositories updated"

# Install Python (minimal installation)
progress "Installing Python (minimal)"
if $TERMUX_ENV; then
    # Termux-specific Python installation
    pkg install -y python || error "Failed to install Python in Termux"
else
    # Standard Linux Python installation
    sudo apt install -y python3 python3-minimal || error "Failed to install Python"
fi
success "Python installed successfully"

# Verify Python installation
progress "Verifying Python installation"
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    error "Python installation failed - command not found"
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1)
success "Python verified: $PYTHON_VERSION"

# Check Python modules (standard library only)
progress "Checking required Python modules"
REQUIRED_MODULES="urllib json os sys time datetime threading queue hashlib base64"
for module in $REQUIRED_MODULES; do
    if $PYTHON_CMD -c "import $module" 2>/dev/null; then
        echo -e "  ✅ $module"
    else
        error "Required Python module '$module' not available"
    fi
done
success "All required Python modules available"

# Create OASIS directory structure
progress "Creating OASIS v3 directory structure"
OASIS_DIR="$HOME/oasis_v3"
mkdir -p "$OASIS_DIR"
mkdir -p "$OASIS_DIR/logs"
mkdir -p "$OASIS_DIR/config"
mkdir -p "$OASIS_DIR/data"
success "Directory structure created: $OASIS_DIR"

# Download OASIS orchestrator files
progress "Setting up OASIS orchestrator"
cd "$OASIS_DIR"

# Create configuration file
cat > config/oasis_config.json << 'EOF'
{
    "hf_space_url": "https://elmatador0197-my-oasis-agent.hf.space",
    "api_endpoints": {
        "sentiment": "/api/sentiment",
        "generate": "/api/generate",
        "classify": "/api/classify",
        "batch": "/api/batch",
        "health": "/api/health",
        "stats": "/api/stats"
    },
    "pricing": {
        "sentiment": 0.01,
        "generate": 0.05,
        "classify": 0.02,
        "batch": 0.10
    },
    "timeout": 30,
    "max_retries": 3,
    "log_level": "INFO"
}
EOF

success "Configuration file created"

# Create launcher script
progress "Creating OASIS launcher"
cat > oasis.sh << EOF
#!/bin/bash
#
# OASIS v3 Launcher Script
# Starts the ultra-lightweight Termux orchestrator
#

cd "$OASIS_DIR"
echo "🚀 Starting OASIS v3 Orchestrator..."
echo "Architecture: Termux (<5MB) ←→ HuggingFace Spaces (AI Power)"
echo ""

# Check if orchestrator exists
if [[ ! -f "oasis_orchestrator.py" ]]; then
    echo "❌ oasis_orchestrator.py not found!"
    echo "Please ensure all OASIS files are properly installed."
    exit 1
fi

# Start orchestrator
$PYTHON_CMD oasis_orchestrator.py "\$@"
EOF

chmod +x oasis.sh
success "OASIS launcher created"

# Create system info script
cat > system_info.py << 'EOF'
#!/usr/bin/env python3
"""
OASIS v3 System Information
Displays current system status and resource usage
"""

import os
import sys
import json
from datetime import datetime

def get_system_info():
    """Gather system information"""
    info = {
        "timestamp": datetime.now().isoformat(),
        "python_version": sys.version,
        "platform": sys.platform,
        "executable": sys.executable,
        "path": sys.path[:3],  # First 3 paths only
        "cwd": os.getcwd(),
        "home": os.path.expanduser("~"),
        "termux": os.path.exists("/data/data/com.termux")
    }
    
    # Memory info (if available)
    try:
        if os.path.exists("/proc/meminfo"):
            with open("/proc/meminfo", "r") as f:
                meminfo = f.read()
                for line in meminfo.split("\n"):
                    if "MemTotal" in line:
                        info["memory_total"] = line.split()[1] + " kB"
                    elif "MemAvailable" in line:
                        info["memory_available"] = line.split()[1] + " kB"
    except:
        info["memory"] = "unavailable"
    
    return info

def main():
    print("🔍 OASIS v3 System Information")
    print("=" * 40)
    
    info = get_system_info()
    
    print(f"Timestamp: {info['timestamp']}")
    print(f"Python: {info['python_version'].split()[0]}")
    print(f"Platform: {info['platform']}")
    print(f"Termux: {'Yes' if info['termux'] else 'No'}")
    print(f"Working Dir: {info['cwd']}")
    
    if "memory_total" in info:
        print(f"Memory Total: {info['memory_total']}")
    if "memory_available" in info:
        print(f"Memory Available: {info['memory_available']}")
    
    print("\n📦 Python Standard Library Modules:")
    modules = ["urllib", "json", "os", "sys", "time", "datetime", "threading", "queue", "hashlib", "base64"]
    for module in modules:
        try:
            __import__(module)
            print(f"  ✅ {module}")
        except ImportError:
            print(f"  ❌ {module}")
    
    print(f"\n💾 OASIS Installation: {os.getcwd()}")
    files = ["oasis_orchestrator.py", "hf_client.py", "config/oasis_config.json"]
    for file in files:
        status = "✅" if os.path.exists(file) else "❌"
        print(f"  {status} {file}")

if __name__ == "__main__":
    main()
EOF

success "System info script created"

# Installation summary
echo ""
echo -e "${GREEN}🎉 OASIS v3 Installation Complete!${NC}"
echo "=================================="
echo "📍 Installation directory: $OASIS_DIR"
echo "🚀 Launcher: ./oasis.sh"
echo "🔍 System info: $PYTHON_CMD system_info.py"
echo ""
echo "📋 Next Steps:"
echo "1. Copy oasis_orchestrator.py and hf_client.py to $OASIS_DIR"
echo "2. Run: ./oasis.sh"
echo "3. Test connection to HuggingFace Spaces backend"
echo ""
echo "🏗️ Architecture: Termux (<5MB) ←→ HF Spaces (Unlimited AI)"
echo "📦 Dependencies: Python standard library + urllib ONLY"
echo "💰 Revenue tracking: Built-in monetization"
echo ""

# Final verification
progress "Final installation verification"
cd "$OASIS_DIR"
$PYTHON_CMD system_info.py

success "OASIS v3 Termux setup completed successfully!"

# Show directory size
if command -v du &> /dev/null; then
    SIZE=$(du -sh "$OASIS_DIR" | cut -f1)
    echo -e "${BLUE}📏 Installation size: $SIZE${NC}"
fi

echo ""
echo "🎯 Ready for OASIS v3 orchestration!"
echo "Run './oasis.sh' to start the ultra-lightweight command center."