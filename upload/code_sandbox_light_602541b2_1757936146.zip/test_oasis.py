#!/usr/bin/env python3
"""
OASIS v3 Comprehensive Testing Suite - Ultra-Lightweight
========================================================
Complete testing framework using ONLY Python standard library.
Tests all components of the Termux orchestrator and HF Spaces integration.

Architecture: [TEST SUITE] → [TERMUX ORCHESTRATOR] ←→ [HF SPACES BACKEND]
"""

import json
import time
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime
import threading
import queue

class OasisTestSuite:
    """Comprehensive test suite for OASIS v3"""
    
    def __init__(self, config_file="oasis_config.json"):
        self.config = self._load_config(config_file)
        self.test_results = []
        self.start_time = None
        self.hf_space_url = self.config.get("hf_space_url", "https://elmatador0197-my-oasis-agent.hf.space")
        
        print("🧪 OASIS v3 Testing Suite Initialized")
        print(f"📡 Backend: {self.hf_space_url}")
    
    def _load_config(self, config_file):
        """Load test configuration"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  Config load error: {e}")
            return {
                "hf_space_url": "https://elmatador0197-my-oasis-agent.hf.space",
                "timeout": 30
            }
    
    def _record_test(self, test_name, success, duration, details=None, error=None):
        """Record test result"""
        result = {
            "test_name": test_name,
            "success": success,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
            "details": details or {},
            "error": error
        }
        
        self.test_results.append(result)
        
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name} ({duration:.2f}s)")
        if error:
            print(f"    Error: {error}")
    
    def test_python_environment(self):
        """Test Python environment and required modules"""
        test_start = time.time()
        
        try:
            # Test Python version
            python_version = sys.version_info
            if python_version.major < 3:
                raise Exception(f"Python 3 required, found {python_version.major}.{python_version.minor}")
            
            # Test required modules
            required_modules = [
                "urllib", "urllib.request", "urllib.parse", "urllib.error",
                "json", "os", "sys", "time", "datetime", "threading", "queue", "hashlib", "base64"
            ]
            
            missing_modules = []
            for module in required_modules:
                try:
                    __import__(module)
                except ImportError:
                    missing_modules.append(module)
            
            if missing_modules:
                raise Exception(f"Missing required modules: {', '.join(missing_modules)}")
            
            # Test memory constraints
            details = {
                "python_version": f"{python_version.major}.{python_version.minor}.{python_version.micro}",
                "platform": sys.platform,
                "executable": sys.executable,
                "modules_available": len(required_modules) - len(missing_modules)
            }
            
            duration = time.time() - test_start
            self._record_test("Python Environment", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("Python Environment", False, duration, error=str(e))
            return False
    
    def test_configuration_loading(self):
        """Test configuration file loading"""
        test_start = time.time()
        
        try:
            # Test config file exists
            if not os.path.exists("oasis_config.json"):
                raise Exception("Configuration file 'oasis_config.json' not found")
            
            # Test config parsing
            with open("oasis_config.json", 'r') as f:
                config = json.load(f)
            
            # Test required config keys
            required_keys = ["hf_space_url", "api_endpoints", "pricing", "timeout"]
            missing_keys = [key for key in required_keys if key not in config]
            
            if missing_keys:
                raise Exception(f"Missing config keys: {', '.join(missing_keys)}")
            
            details = {
                "config_size": len(json.dumps(config)),
                "endpoints_count": len(config.get("api_endpoints", {})),
                "pricing_models": len(config.get("pricing", {}))
            }
            
            duration = time.time() - test_start
            self._record_test("Configuration Loading", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("Configuration Loading", False, duration, error=str(e))
            return False
    
    def test_hf_backend_connectivity(self):
        """Test HuggingFace Spaces backend connectivity"""
        test_start = time.time()
        
        try:
            # Test basic HTTP connectivity
            url = f"{self.hf_space_url}/api/health"
            request = urllib.request.Request(url, headers={'User-Agent': 'OASIS-v3-Test'})
            
            with urllib.request.urlopen(request, timeout=self.config.get("timeout", 30)) as response:
                status_code = response.getcode()
                response_data = response.read().decode('utf-8')
            
            if status_code != 200:
                raise Exception(f"Backend returned HTTP {status_code}")
            
            # Try to parse JSON response
            try:
                json_response = json.loads(response_data)
                backend_status = json_response.get("status", "unknown")
            except json.JSONDecodeError:
                backend_status = "non-json-response"
            
            details = {
                "status_code": status_code,
                "backend_status": backend_status,
                "response_size": len(response_data),
                "backend_url": self.hf_space_url
            }
            
            duration = time.time() - test_start
            self._record_test("HF Backend Connectivity", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("HF Backend Connectivity", False, duration, error=str(e))
            return False
    
    def test_api_endpoints(self):
        """Test all API endpoints"""
        test_start = time.time()
        
        try:
            endpoints = self.config.get("api_endpoints", {})
            working_endpoints = []
            failed_endpoints = []
            
            for endpoint_name, endpoint_path in endpoints.items():
                try:
                    url = f"{self.hf_space_url}{endpoint_path}"
                    
                    # Prepare test data based on endpoint
                    test_data = self._get_test_data_for_endpoint(endpoint_name)
                    
                    if test_data:
                        # POST request with data
                        json_data = json.dumps(test_data).encode('utf-8')
                        headers = {
                            'Content-Type': 'application/json',
                            'User-Agent': 'OASIS-v3-Test'
                        }
                        request = urllib.request.Request(url, data=json_data, headers=headers, method='POST')
                    else:
                        # GET request
                        headers = {'User-Agent': 'OASIS-v3-Test'}
                        request = urllib.request.Request(url, headers=headers)
                    
                    with urllib.request.urlopen(request, timeout=10) as response:
                        if response.getcode() == 200:
                            working_endpoints.append(endpoint_name)
                        else:
                            failed_endpoints.append(f"{endpoint_name} (HTTP {response.getcode()})")
                
                except Exception as e:
                    failed_endpoints.append(f"{endpoint_name} ({str(e)[:50]})")
            
            if failed_endpoints and len(working_endpoints) == 0:
                raise Exception(f"All endpoints failed: {', '.join(failed_endpoints)}")
            
            details = {
                "total_endpoints": len(endpoints),
                "working_endpoints": working_endpoints,
                "failed_endpoints": failed_endpoints,
                "success_rate": len(working_endpoints) / len(endpoints) * 100 if endpoints else 0
            }
            
            duration = time.time() - test_start
            success = len(working_endpoints) > 0
            self._record_test("API Endpoints", success, duration, details)
            return success
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("API Endpoints", False, duration, error=str(e))
            return False
    
    def _get_test_data_for_endpoint(self, endpoint_name):
        """Get test data for specific endpoint"""
        test_data_map = {
            "sentiment": {"text": "This is a test message for sentiment analysis"},
            "generate": {"prompt": "Test prompt", "max_length": 50},
            "classify": {"image": "test_image_data", "model": "resnet50"},
            "batch": {"tasks": [{"type": "sentiment", "text": "test"}]}
        }
        return test_data_map.get(endpoint_name)
    
    def test_orchestrator_components(self):
        """Test orchestrator components"""
        test_start = time.time()
        
        try:
            # Test orchestrator file exists
            if not os.path.exists("oasis_orchestrator.py"):
                raise Exception("oasis_orchestrator.py not found")
            
            # Test HF client exists
            if not os.path.exists("hf_client.py"):
                raise Exception("hf_client.py not found")
            
            # Test business automation exists
            if not os.path.exists("business_automation.py"):
                raise Exception("business_automation.py not found")
            
            # Try importing components (syntax check)
            import importlib.util
            
            components = [
                ("oasis_orchestrator.py", "OasisOrchestrator"),
                ("hf_client.py", "HFSpacesClient"),
                ("business_automation.py", "RevenueEngine")
            ]
            
            import_errors = []
            for file_path, class_name in components:
                try:
                    spec = importlib.util.spec_from_file_location("test_module", file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    if not hasattr(module, class_name):
                        import_errors.append(f"{class_name} not found in {file_path}")
                except Exception as e:
                    import_errors.append(f"{file_path}: {str(e)}")
            
            if import_errors:
                raise Exception(f"Component errors: {'; '.join(import_errors)}")
            
            details = {
                "components_tested": len(components),
                "all_files_present": True,
                "syntax_valid": len(import_errors) == 0
            }
            
            duration = time.time() - test_start
            self._record_test("Orchestrator Components", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("Orchestrator Components", False, duration, error=str(e))
            return False
    
    def test_termux_constraints(self):
        """Test Termux-specific constraints"""
        test_start = time.time()
        
        try:
            constraints = self.config.get("termux_constraints", {})
            forbidden_modules = constraints.get("forbidden_modules", [])
            
            # Check for forbidden heavy dependencies
            forbidden_found = []
            for module in forbidden_modules:
                try:
                    __import__(module)
                    forbidden_found.append(module)
                except ImportError:
                    pass  # Good, module not available
            
            if forbidden_found:
                raise Exception(f"Forbidden modules found: {', '.join(forbidden_found)}")
            
            # Test memory footprint (estimate)
            file_sizes = {}
            total_size = 0
            for filename in ["oasis_orchestrator.py", "hf_client.py", "business_automation.py", "oasis_config.json"]:
                if os.path.exists(filename):
                    size = os.path.getsize(filename)
                    file_sizes[filename] = size
                    total_size += size
            
            # Convert to MB
            total_mb = total_size / (1024 * 1024)
            max_mb = constraints.get("max_memory_mb", 64)
            
            if total_mb > max_mb:
                raise Exception(f"Memory footprint too large: {total_mb:.2f}MB > {max_mb}MB")
            
            details = {
                "forbidden_modules_absent": len(forbidden_modules) - len(forbidden_found),
                "total_file_size_mb": total_mb,
                "memory_limit_mb": max_mb,
                "constraint_compliance": True
            }
            
            duration = time.time() - test_start
            self._record_test("Termux Constraints", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("Termux Constraints", False, duration, error=str(e))
            return False
    
    def test_revenue_tracking(self):
        """Test revenue tracking functionality"""
        test_start = time.time()
        
        try:
            # Import revenue engine
            import importlib.util
            spec = importlib.util.spec_from_file_location("business", "business_automation.py")
            business = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(business)
            
            # Test revenue engine
            revenue_engine = business.RevenueEngine()
            
            # Add test transactions
            test_transactions = [
                ("sentiment", 0.01),
                ("generate", 0.05),
                ("classify", 0.02)
            ]
            
            for service, amount in test_transactions:
                revenue_engine.add_transaction(service, amount, "test_client")
            
            # Test revenue calculation
            total_revenue = sum(amount for _, amount in test_transactions)
            calculated_total = sum(t["amount"] for t in revenue_engine.transactions)
            
            if abs(calculated_total - total_revenue) > 0.001:
                raise Exception(f"Revenue calculation error: {calculated_total} != {total_revenue}")
            
            # Test report generation
            report = revenue_engine.generate_revenue_report()
            
            if not isinstance(report, dict) or "summary" not in report:
                raise Exception("Revenue report generation failed")
            
            details = {
                "transactions_processed": len(test_transactions),
                "total_revenue": calculated_total,
                "report_generated": True,
                "service_stats": len(revenue_engine.service_stats)
            }
            
            duration = time.time() - test_start
            self._record_test("Revenue Tracking", True, duration, details)
            return True
            
        except Exception as e:
            duration = time.time() - test_start
            self._record_test("Revenue Tracking", False, duration, error=str(e))
            return False
    
    def run_full_test_suite(self):
        """Run complete test suite"""
        self.start_time = time.time()
        
        print("🧪 OASIS v3 Comprehensive Test Suite")
        print("=" * 60)
        print("Testing ultra-lightweight Termux orchestrator architecture")
        print("Constraint: Python standard library + urllib ONLY")
        print("")
        
        # Define test sequence
        tests = [
            ("Python Environment", self.test_python_environment),
            ("Configuration Loading", self.test_configuration_loading),
            ("Termux Constraints", self.test_termux_constraints),
            ("Orchestrator Components", self.test_orchestrator_components),
            ("HF Backend Connectivity", self.test_hf_backend_connectivity),
            ("API Endpoints", self.test_api_endpoints),
            ("Revenue Tracking", self.test_revenue_tracking)
        ]
        
        # Run tests
        passed_tests = 0
        for test_name, test_function in tests:
            print(f"\n🔍 Running: {test_name}")
            try:
                success = test_function()
                if success:
                    passed_tests += 1
            except Exception as e:
                self._record_test(test_name, False, 0, error=f"Test execution error: {str(e)}")
        
        # Generate summary
        total_duration = time.time() - self.start_time
        self._generate_test_summary(passed_tests, len(tests), total_duration)
        
        return self.test_results
    
    def _generate_test_summary(self, passed, total, duration):
        """Generate and display test summary"""
        success_rate = (passed / total) * 100 if total > 0 else 0
        
        print("\n" + "=" * 60)
        print("📋 TEST SUMMARY")
        print("=" * 60)
        print(f"Tests Run: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success Rate: {success_rate:.1f}%")
        print(f"Total Duration: {duration:.2f}s")
        
        # Status indicator
        if success_rate >= 90:
            print("🟢 OASIS v3 Status: READY FOR DEPLOYMENT")
        elif success_rate >= 70:
            print("🟡 OASIS v3 Status: NEEDS ATTENTION")
        else:
            print("🔴 OASIS v3 Status: REQUIRES FIXES")
        
        # Failed tests details
        failed_tests = [r for r in self.test_results if not r["success"]]
        if failed_tests:
            print("\n❌ Failed Tests:")
            for test in failed_tests:
                print(f"  - {test['test_name']}: {test['error']}")
        
        print("=" * 60)
    
    def save_test_report(self, filename="oasis_test_report.json"):
        """Save detailed test report to file"""
        report = {
            "generated_at": datetime.now().isoformat(),
            "test_suite_version": "1.0",
            "architecture": "Termux (<5MB) ←→ HuggingFace Spaces (AI)",
            "total_tests": len(self.test_results),
            "passed_tests": sum(1 for r in self.test_results if r["success"]),
            "total_duration": time.time() - self.start_time if self.start_time else 0,
            "test_results": self.test_results
        }
        
        try:
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"📄 Test report saved: {filename}")
        except Exception as e:
            print(f"❌ Failed to save test report: {e}")


def main():
    """Main entry point for test suite"""
    print("🚀 Starting OASIS v3 Test Suite")
    
    # Initialize and run tests
    test_suite = OasisTestSuite()
    results = test_suite.run_full_test_suite()
    
    # Save detailed report
    test_suite.save_test_report()
    
    # Exit code based on results
    passed = sum(1 for r in results if r["success"])
    total = len(results)
    success_rate = (passed / total) * 100 if total > 0 else 0
    
    if success_rate >= 90:
        sys.exit(0)  # Success
    else:
        sys.exit(1)  # Failure


if __name__ == "__main__":
    main()