// OASIS v3 Frontend - Main JavaScript
// Mobile-First AI Superintelligence Interface

class OASISApp {
    constructor() {
        this.apiBase = 'https://huggingface.co/spaces/oasis-v3/api/v1'; // Will be updated with actual HF Spaces URL
        this.revenueCounterTarget = 15000;
        this.currentRevenue = 0;
        this.charts = {};
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.startRevenueCounter();
        this.initCharts();
        this.checkMobileDevice();
        this.setupPWAFeatures();
        console.log('🚀 OASIS v3 Frontend Initialized');
    }

    setupEventListeners() {
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            });
        }

        // Smooth Scrolling for Navigation
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    // Close mobile menu if open
                    mobileMenu?.classList.add('hidden');
                }
            });
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    startRevenueCounter() {
        const counter = document.getElementById('revenueCounter');
        if (!counter) return;

        const duration = 3000; // 3 seconds
        const increment = this.revenueCounterTarget / (duration / 50);
        
        const timer = setInterval(() => {
            this.currentRevenue += increment;
            if (this.currentRevenue >= this.revenueCounterTarget) {
                this.currentRevenue = this.revenueCounterTarget;
                clearInterval(timer);
            }
            counter.textContent = '$' + Math.floor(this.currentRevenue).toLocaleString();
        }, 50);
    }

    initCharts() {
        this.initRevenueChart();
        this.initUserChart();
    }

    initRevenueChart() {
        const ctx = document.getElementById('revenueChart');
        if (!ctx) return;

        const data = {
            labels: ['Month 1', 'Month 3', 'Month 6', 'Month 9', 'Month 12'],
            datasets: [{
                label: 'Monthly Revenue ($)',
                data: [500, 2500, 8000, 15000, 25000],
                borderColor: '#06b6d4',
                backgroundColor: 'rgba(6, 182, 212, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        };

        this.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#94a3b8'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: '#374151' }
                    },
                    y: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: '#374151' }
                    }
                }
            }
        });
    }

    initUserChart() {
        const ctx = document.getElementById('userChart');
        if (!ctx) return;

        const data = {
            labels: ['Week 1', 'Week 4', 'Week 8', 'Week 12', 'Week 16'],
            datasets: [{
                label: 'Active Users',
                data: [50, 250, 800, 2000, 5000],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        };

        this.charts.users = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#94a3b8'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: '#374151' }
                    },
                    y: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: '#374151' }
                    }
                }
            }
        });
    }

    async processAI() {
        const processBtn = document.getElementById('processBtn');
        const aiModel = document.getElementById('aiModel').value;
        const aiInput = document.getElementById('aiInput').value.trim();
        const aiOutput = document.getElementById('aiOutput');
        const aiResult = document.getElementById('aiResult');

        if (!aiInput) {
            alert('Please enter some text to process.');
            return;
        }

        // Show loading state
        processBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
        processBtn.disabled = true;

        const startTime = Date.now();

        try {
            // Simulate AI processing with different responses based on model
            const result = await this.simulateAIProcessing(aiModel, aiInput);
            
            const endTime = Date.now();
            const processingTime = endTime - startTime;

            // Display results
            aiResult.textContent = result.output;
            aiOutput.classList.remove('hidden');

            // Update stats
            document.getElementById('processingTime').textContent = processingTime + 'ms';
            document.getElementById('tokensUsed').textContent = result.tokens.toLocaleString();
            document.getElementById('costSaved').textContent = '$' + result.costSaved.toFixed(2);

            // Scroll to results
            aiOutput.scrollIntoView({ behavior: 'smooth' });

        } catch (error) {
            console.error('AI Processing Error:', error);
            aiResult.textContent = 'Error processing request. Please try again.';
            aiOutput.classList.remove('hidden');
        } finally {
            // Reset button
            processBtn.innerHTML = '<i class="fas fa-magic mr-2"></i>Process with AI';
            processBtn.disabled = false;
        }
    }

    async simulateAIProcessing(model, input) {
        // Simulate different AI models with realistic responses
        await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));

        const responses = {
            'text-generation': {
                output: `Based on your input: "${input}"\n\nHere's an AI-generated response:\n\nThis is a sophisticated text generation that builds upon your input. The AI model has analyzed the context, semantics, and intent of your message to provide a relevant and coherent continuation. This demonstrates the power of large language models in understanding and generating human-like text responses.\n\nKey insights:\n• Context-aware processing\n• Natural language understanding\n• Coherent text generation\n• Real-time inference capabilities`,
                tokens: Math.floor(Math.random() * 500) + 200,
                costSaved: Math.random() * 0.15 + 0.05
            },
            'sentiment-analysis': {
                output: `Sentiment Analysis Results for: "${input}"\n\n📊 Overall Sentiment: ${Math.random() > 0.5 ? 'Positive' : 'Neutral'}\n📈 Confidence Score: ${(Math.random() * 0.3 + 0.7).toFixed(2)}\n\n📋 Detailed Analysis:\n• Emotional Tone: ${['Professional', 'Casual', 'Enthusiastic', 'Informative'][Math.floor(Math.random() * 4)]}\n• Key Emotions Detected: ${['Optimism', 'Curiosity', 'Confidence'][Math.floor(Math.random() * 3)]}\n• Polarity Score: ${(Math.random() * 2 - 1).toFixed(2)}\n\n✨ This analysis uses advanced NLP models trained on millions of text samples.`,
                tokens: Math.floor(Math.random() * 200) + 100,
                costSaved: Math.random() * 0.08 + 0.02
            },
            'summarization': {
                output: `📄 Summary of: "${input.substring(0, 50)}..."\n\n🎯 Key Points:\n• ${input.split(' ').slice(0, 3).join(' ')} - Primary topic\n• Advanced AI processing capabilities\n• Mobile-first implementation approach\n• Revenue generation potential\n\n📊 Summary Statistics:\n• Original Length: ${input.length} characters\n• Summary Compression: ${Math.floor((1 - 100/input.length) * 100)}%\n• Key Concepts Extracted: ${Math.floor(Math.random() * 5) + 3}\n\n✅ This summary maintains the core meaning while significantly reducing text length.`,
                tokens: Math.floor(Math.random() * 150) + 80,
                costSaved: Math.random() * 0.06 + 0.02
            },
            'translation': {
                output: `🌍 Translation Results:\n\n🇺🇸 English: "${input}"\n\n🇪🇸 Spanish: "Esta es una traducción de alta calidad de tu texto de entrada."\n🇫🇷 French: "Ceci est une traduction de haute qualité de votre texte d'entrée."\n🇩🇪 German: "Dies ist eine hochwertige Übersetzung Ihres Eingabetextes."\n🇯🇵 Japanese: "これはあなたの入力テキストの高品質な翻訳です。"\n\n📊 Translation Quality Score: ${(Math.random() * 0.2 + 0.8).toFixed(2)}\n🎯 Languages Supported: 100+\n⚡ Processing Speed: Near real-time`,
                tokens: Math.floor(Math.random() * 300) + 150,
                costSaved: Math.random() * 0.12 + 0.04
            },
            'question-answering': {
                output: `❓ Question: "${input}"\n\n💡 AI Answer:\n\nBased on the available knowledge and context analysis, here's a comprehensive answer:\n\nThe query you've submitted relates to AI and technology implementation. OASIS v3 represents a revolutionary approach to AI accessibility, particularly focusing on mobile-first deployment and zero-cost infrastructure.\n\n🔍 Key Insights:\n• Mobile optimization is crucial for global AI access\n• Zero-cost architecture enables democratic AI deployment\n• Hugging Face integration provides access to 100K+ models\n• Revenue potential exists through tiered service offerings\n\n📊 Confidence Level: ${(Math.random() * 0.25 + 0.75).toFixed(2)}\n🎯 Answer Quality: High\n⚡ Processing Method: Advanced question-answering models`,
                tokens: Math.floor(Math.random() * 400) + 200,
                costSaved: Math.random() * 0.18 + 0.06
            }
        };

        return responses[model] || responses['text-generation'];
    }

    checkMobileDevice() {
        const isMobile = window.innerWidth <= 768 || /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        if (isMobile) {
            document.body.classList.add('mobile-device');
            // Add mobile-specific optimizations
            this.optimizeForMobile();
        }
    }

    optimizeForMobile() {
        // Disable hover effects on mobile
        const style = document.createElement('style');
        style.textContent = `
            @media (hover: none) {
                .hover\\:scale-105:hover { transform: none !important; }
                .hover\\:bg-oasis-600:hover { background-color: inherit !important; }
            }
        `;
        document.head.appendChild(style);

        // Add touch-friendly improvements
        document.querySelectorAll('button, .mobile-optimized').forEach(el => {
            el.style.minHeight = '44px'; // iOS recommended touch target
        });
    }

    setupPWAFeatures() {
        // Add to home screen functionality
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            deferredPrompt = e;
            // Show custom install button
            this.showInstallPrompt();
        });
    }

    showInstallPrompt() {
        // Create install prompt banner
        const banner = document.createElement('div');
        banner.className = 'fixed bottom-4 left-4 right-4 bg-oasis-500 text-white p-4 rounded-lg shadow-lg z-50 flex items-center justify-between';
        banner.innerHTML = `
            <div>
                <div class="font-bold">Install OASIS v3</div>
                <div class="text-sm opacity-90">Add to home screen for best experience</div>
            </div>
            <div>
                <button onclick="oasisApp.installPWA()" class="bg-white text-oasis-500 px-4 py-2 rounded font-bold mr-2">Install</button>
                <button onclick="this.parentElement.parentElement.remove()" class="text-white opacity-75">×</button>
            </div>
        `;
        document.body.appendChild(banner);
    }

    async installPWA() {
        if (window.deferredPrompt) {
            window.deferredPrompt.prompt();
            const { outcome } = await window.deferredPrompt.userChoice;
            console.log(`PWA installation ${outcome}`);
            window.deferredPrompt = null;
        }
    }

    handleResize() {
        // Resize charts if they exist
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.resize();
        });
    }
}

// Global Functions (called from HTML)
function startAIDemo() {
    document.getElementById('ai-demo').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('aiInput').focus();
}

function showTermuxSetup() {
    document.getElementById('termux').scrollIntoView({ behavior: 'smooth' });
}

function showPricing() {
    document.getElementById('revenue').scrollIntoView({ behavior: 'smooth' });
}

function processAI() {
    oasisApp.processAI();
}

function downloadTermuxClient() {
    // Simulate download - in production, this would download the actual client
    const link = document.createElement('a');
    link.href = 'data:text/plain;charset=utf-8,# OASIS v3 Termux Setup Script\n# This is a placeholder for the actual setup script\n\necho "OASIS v3 - AI Superintelligence for Termux"\necho "Setting up ultra-lightweight client..."\n\n# In production, this would be the actual setup script';
    link.download = 'oasis-v3-setup.sh';
    link.click();
    
    // Show success message
    alert('🚀 OASIS v3 setup script downloaded!\n\nRun in Termux: bash oasis-v3-setup.sh');
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.oasisApp = new OASISApp();
});

// Performance monitoring
window.addEventListener('load', () => {
    const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
    console.log(`🚀 OASIS v3 loaded in ${loadTime}ms`);
    
    // Track performance for analytics
    if (loadTime > 3000) {
        console.warn('⚠️ Slow loading detected. Consider optimizing assets.');
    }
});

// Service Worker for offline capability
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => console.log('SW registered'))
            .catch(error => console.log('SW registration failed'));
    });
}

// Error handling
window.addEventListener('error', (e) => {
    console.error('🚨 Frontend Error:', e.error);
    // In production, send to analytics service
});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { OASISApp };
}