// OASIS v3 Revenue Engine
// Advanced Monetization & Business Automation System

class OASISRevenueEngine {
    constructor() {
        this.apiBase = 'https://api.oasis-v3.com/v1'; // Production API endpoint
        this.stripePublishableKey = 'pk_test_...'; // Will be replaced with actual key
        this.supabaseUrl = 'https://your-project.supabase.co';
        this.supabaseKey = 'your-anon-key';
        
        this.pricingTiers = {
            free: {
                name: 'Free',
                price: 0,
                monthlyRequests: 1000,
                features: ['Basic AI models', 'Mobile client', 'Community support'],
                stripePriceId: null
            },
            pro: {
                name: 'Pro',
                price: 12,
                monthlyRequests: 50000,
                features: ['All AI models', 'Priority processing', 'Analytics dashboard', 'API access'],
                stripePriceId: 'price_pro_monthly'
            },
            team: {
                name: 'Team',
                price: 39,
                monthlyRequests: 200000,
                features: ['Team collaboration', 'Custom models', 'White-label options', 'Priority support'],
                stripePriceId: 'price_team_monthly'
            },
            enterprise: {
                name: 'Enterprise',
                price: 199,
                monthlyRequests: 'unlimited',
                features: ['Dedicated infrastructure', 'Custom integrations', '24/7 support', 'SLA guarantees'],
                stripePriceId: 'price_enterprise_monthly'
            }
        };

        this.init();
    }

    init() {
        this.initStripe();
        this.initAnalytics();
        this.trackUserBehavior();
        this.startRevenueTracking();
        console.log('💰 OASIS Revenue Engine Initialized');
    }

    // Stripe Integration
    async initStripe() {
        if (typeof Stripe !== 'undefined') {
            this.stripe = Stripe(this.stripePublishableKey);
        } else {
            // Load Stripe.js dynamically
            const script = document.createElement('script');
            script.src = 'https://js.stripe.com/v3/';
            script.onload = () => {
                this.stripe = Stripe(this.stripePublishableKey);
            };
            document.head.appendChild(script);
        }
    }

    // Subscription Management
    async createSubscription(tierId, userEmail) {
        const tier = this.pricingTiers[tierId];
        if (!tier || !tier.stripePriceId) {
            throw new Error('Invalid pricing tier');
        }

        try {
            // Create checkout session
            const response = await fetch(`${this.apiBase}/create-checkout-session`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    priceId: tier.stripePriceId,
                    customerEmail: userEmail,
                    successUrl: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
                    cancelUrl: `${window.location.origin}/cancel`
                })
            });

            const session = await response.json();

            // Redirect to Stripe Checkout
            const result = await this.stripe.redirectToCheckout({
                sessionId: session.id
            });

            if (result.error) {
                throw new Error(result.error.message);
            }

            // Track conversion
            this.trackEvent('subscription_initiated', {
                tier: tierId,
                price: tier.price
            });

        } catch (error) {
            console.error('Subscription creation error:', error);
            this.showError('Failed to create subscription. Please try again.');
        }
    }

    // Usage Tracking & Billing
    async trackUsage(userId, modelType, tokens, processingTime) {
        const usageData = {
            userId,
            modelType,
            tokens,
            processingTime,
            timestamp: new Date().toISOString(),
            cost: this.calculateCost(modelType, tokens)
        };

        try {
            // Store in Supabase
            await this.supabaseClient
                .from('usage_logs')
                .insert([usageData]);

            // Update user's monthly usage
            await this.updateMonthlyUsage(userId, tokens);

            // Check if upgrade prompt needed
            this.checkUpgradeEligibility(userId);

        } catch (error) {
            console.error('Usage tracking error:', error);
        }
    }

    calculateCost(modelType, tokens) {
        const costPerToken = {
            'text-generation': 0.0001,
            'sentiment-analysis': 0.00005,
            'summarization': 0.00008,
            'translation': 0.0001,
            'question-answering': 0.00012
        };

        return (costPerToken[modelType] || 0.0001) * tokens;
    }

    async updateMonthlyUsage(userId, tokens) {
        const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format

        try {
            const { data: existingUsage } = await this.supabaseClient
                .from('monthly_usage')
                .select('*')
                .eq('user_id', userId)
                .eq('month', currentMonth)
                .single();

            if (existingUsage) {
                await this.supabaseClient
                    .from('monthly_usage')
                    .update({
                        total_tokens: existingUsage.total_tokens + tokens,
                        total_requests: existingUsage.total_requests + 1
                    })
                    .eq('id', existingUsage.id);
            } else {
                await this.supabaseClient
                    .from('monthly_usage')
                    .insert([{
                        user_id: userId,
                        month: currentMonth,
                        total_tokens: tokens,
                        total_requests: 1
                    }]);
            }
        } catch (error) {
            console.error('Monthly usage update error:', error);
        }
    }

    // Conversion Optimization
    async checkUpgradeEligibility(userId) {
        const usage = await this.getUserUsage(userId);
        const userTier = await this.getUserTier(userId);

        const currentTier = this.pricingTiers[userTier];
        
        if (usage.monthlyRequests > currentTier.monthlyRequests * 0.8) {
            this.showUpgradePrompt(userId, userTier, usage);
        }
    }

    showUpgradePrompt(userId, currentTier, usage) {
        const nextTier = this.getNextTier(currentTier);
        if (!nextTier) return;

        const modal = this.createUpgradeModal({
            currentTier: this.pricingTiers[currentTier],
            nextTier: this.pricingTiers[nextTier],
            usage,
            userId
        });

        document.body.appendChild(modal);
        modal.classList.add('active');

        // Track upgrade prompt shown
        this.trackEvent('upgrade_prompt_shown', {
            userId,
            currentTier,
            nextTier,
            usagePercent: usage.monthlyRequests / this.pricingTiers[currentTier].monthlyRequests
        });
    }

    createUpgradeModal({ currentTier, nextTier, usage, userId }) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 upgrade-modal';
        
        modal.innerHTML = `
            <div class="bg-slate-800 rounded-2xl p-8 max-w-md mx-4 text-white">
                <div class="text-center mb-6">
                    <div class="text-4xl mb-2">📈</div>
                    <h3 class="text-2xl font-bold text-oasis-500">Upgrade Recommended!</h3>
                    <p class="text-slate-300 mt-2">You're using ${Math.round(usage.monthlyRequests / currentTier.monthlyRequests * 100)}% of your ${currentTier.name} plan.</p>
                </div>
                
                <div class="space-y-4 mb-6">
                    <div class="bg-slate-900 rounded-lg p-4">
                        <div class="text-sm text-slate-400">Current Plan</div>
                        <div class="text-xl font-bold">${currentTier.name} - $${currentTier.price}/month</div>
                        <div class="text-sm text-red-400">${usage.monthlyRequests.toLocaleString()} / ${currentTier.monthlyRequests.toLocaleString()} requests used</div>
                    </div>
                    
                    <div class="bg-gradient-to-r from-oasis-500 to-green-500 rounded-lg p-4">
                        <div class="text-sm text-white opacity-90">Recommended Plan</div>
                        <div class="text-xl font-bold text-white">${nextTier.name} - $${nextTier.price}/month</div>
                        <div class="text-sm text-white opacity-90">${nextTier.monthlyRequests === 'unlimited' ? 'Unlimited' : nextTier.monthlyRequests.toLocaleString()} requests</div>
                    </div>
                </div>
                
                <div class="flex space-x-3">
                    <button onclick="this.closest('.upgrade-modal').remove()" class="flex-1 bg-slate-700 hover:bg-slate-600 px-4 py-3 rounded-lg font-semibold transition-colors">
                        Maybe Later
                    </button>
                    <button onclick="oasisRevenue.upgradeUser('${userId}', '${nextTier.name.toLowerCase()}')" class="flex-1 bg-oasis-500 hover:bg-oasis-600 px-4 py-3 rounded-lg font-semibold transition-colors">
                        Upgrade Now
                    </button>
                </div>
            </div>
        `;

        return modal;
    }

    async upgradeUser(userId, newTier) {
        try {
            const userEmail = await this.getUserEmail(userId);
            await this.createSubscription(newTier, userEmail);
            
            // Close modal
            document.querySelector('.upgrade-modal')?.remove();
            
        } catch (error) {
            console.error('Upgrade error:', error);
            this.showError('Upgrade failed. Please try again.');
        }
    }

    // Analytics & Tracking
    initAnalytics() {
        // Initialize analytics tracking
        this.analytics = {
            sessions: 0,
            pageViews: 0,
            conversions: 0,
            revenue: 0
        };

        // Track page view
        this.trackPageView();
        
        // Track session
        this.trackSession();
    }

    trackEvent(eventName, properties = {}) {
        // Send to analytics service (Google Analytics, Mixpanel, etc.)
        console.log('📊 Event:', eventName, properties);

        // Store locally for dashboard
        const events = JSON.parse(localStorage.getItem('oasis_events') || '[]');
        events.push({
            event: eventName,
            properties,
            timestamp: Date.now()
        });
        
        // Keep only last 100 events
        if (events.length > 100) {
            events.splice(0, events.length - 100);
        }
        
        localStorage.setItem('oasis_events', JSON.stringify(events));

        // Update dashboard if visible
        this.updateAnalyticsDashboard();
    }

    trackPageView() {
        this.trackEvent('page_view', {
            url: window.location.href,
            referrer: document.referrer,
            userAgent: navigator.userAgent
        });
    }

    trackSession() {
        const sessionId = this.getOrCreateSessionId();
        this.trackEvent('session_start', {
            sessionId,
            timestamp: Date.now()
        });
    }

    trackUserBehavior() {
        // Track scroll depth
        let maxScroll = 0;
        window.addEventListener('scroll', () => {
            const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
            if (scrollPercent > maxScroll) {
                maxScroll = scrollPercent;
                if (maxScroll % 25 === 0) { // Track at 25%, 50%, 75%, 100%
                    this.trackEvent('scroll_depth', { percent: maxScroll });
                }
            }
        });

        // Track time on page
        const startTime = Date.now();
        window.addEventListener('beforeunload', () => {
            const timeOnPage = Date.now() - startTime;
            this.trackEvent('time_on_page', { duration: timeOnPage });
        });

        // Track clicks on CTA buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('.btn-primary, .mobile-optimized')) {
                this.trackEvent('cta_click', {
                    text: e.target.textContent.trim(),
                    location: e.target.id || e.target.className
                });
            }
        });
    }

    // Revenue Calculations
    startRevenueTracking() {
        this.calculateProjectedRevenue();
        
        // Update every hour
        setInterval(() => {
            this.calculateProjectedRevenue();
        }, 3600000);
    }

    async calculateProjectedRevenue() {
        try {
            const metrics = await this.getRevenueMetrics();
            const projection = this.projectMonthlyRevenue(metrics);
            
            // Update revenue counter
            this.updateRevenueDisplay(projection);
            
            // Store for analytics
            this.trackEvent('revenue_projection', {
                amount: projection,
                metrics
            });

        } catch (error) {
            console.error('Revenue calculation error:', error);
        }
    }

    async getRevenueMetrics() {
        // In production, fetch from database
        const mockMetrics = {
            activeUsers: 1250,
            paidUsers: 89,
            averageRevenuePerUser: 18.50,
            conversionRate: 0.071,
            churnRate: 0.05
        };

        return mockMetrics;
    }

    projectMonthlyRevenue(metrics) {
        const { activeUsers, paidUsers, averageRevenuePerUser, conversionRate } = metrics;
        
        // Conservative projection based on current metrics
        const projectedPaidUsers = Math.round(activeUsers * conversionRate);
        const monthlyRevenue = projectedPaidUsers * averageRevenuePerUser;
        
        return monthlyRevenue;
    }

    updateRevenueDisplay(amount) {
        const counter = document.getElementById('revenueCounter');
        if (counter) {
            counter.textContent = '$' + Math.round(amount).toLocaleString();
        }
    }

    // Utility Methods
    getOrCreateSessionId() {
        let sessionId = sessionStorage.getItem('oasis_session_id');
        if (!sessionId) {
            sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            sessionStorage.setItem('oasis_session_id', sessionId);
        }
        return sessionId;
    }

    async getUserEmail(userId) {
        // Fetch from database or user input
        return 'user@example.com'; // Placeholder
    }

    async getUserTier(userId) {
        // Fetch from database
        return 'free'; // Placeholder
    }

    async getUserUsage(userId) {
        // Fetch from database
        return {
            monthlyRequests: 850,
            totalTokens: 125000
        }; // Placeholder
    }

    getNextTier(currentTier) {
        const tiers = ['free', 'pro', 'team', 'enterprise'];
        const currentIndex = tiers.indexOf(currentTier);
        return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : null;
    }

    showError(message) {
        // Create error notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-4 rounded-lg shadow-lg z-50';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    showSuccess(message) {
        // Create success notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    updateAnalyticsDashboard() {
        // Update analytics dashboard if visible
        const events = JSON.parse(localStorage.getItem('oasis_events') || '[]');
        const recentEvents = events.filter(e => Date.now() - e.timestamp < 86400000); // Last 24h
        
        // Update various metrics displays
        document.querySelectorAll('[data-metric]').forEach(element => {
            const metric = element.dataset.metric;
            const value = this.calculateMetric(metric, recentEvents);
            element.textContent = value;
        });
    }

    calculateMetric(metricName, events) {
        switch (metricName) {
            case 'page_views':
                return events.filter(e => e.event === 'page_view').length;
            case 'sessions':
                return new Set(events.filter(e => e.event === 'session_start').map(e => e.properties.sessionId)).size;
            case 'conversions':
                return events.filter(e => e.event === 'subscription_initiated').length;
            default:
                return 0;
        }
    }
}

// Global revenue engine instance
window.oasisRevenue = new OASISRevenueEngine();

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { OASISRevenueEngine };
}