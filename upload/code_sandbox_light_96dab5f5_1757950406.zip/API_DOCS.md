# 📚 OASIS v3 - API Documentation

**Complete API Reference for AI Superintelligence Platform**

---

## 🌐 Base Information

| Property | Value |
|----------|-------|
| **Base URL** | `https://your-username-oasis-v3.hf.space/api` |
| **Protocol** | HTTPS |
| **Authentication** | None (Open Access) |
| **Rate Limit** | 60 requests/minute |
| **Response Format** | JSON |

---

## 📋 Quick Reference

| Endpoint | Method | Description | Price |
|----------|---------|-------------|-------|
| `/api/generate` | POST | Text Generation | $0.01 |
| `/api/sentiment` | POST | Sentiment Analysis | $0.005 |
| `/api/classify` | POST | Text Classification | $0.008 |
| `/api/qa` | POST | Question Answering | $0.01 |
| `/api/summarize` | POST | Text Summarization | $0.015 |
| `/api/image` | POST | Image Classification | $0.02 |
| `/api/stats` | GET | Usage Statistics | Free |

---

## 🤖 Text Generation

### Endpoint
```http
POST /api/generate
```

### Description
Generate human-like text from a given prompt using advanced language models.

### Request Body
```json
{
  "prompt": "string (required)",
  "max_length": "integer (optional, default: 100)"
}
```

### Parameters
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `prompt` | string | Yes | - | Input text to generate from |
| `max_length` | integer | No | 100 | Maximum tokens to generate |

### Response
```json
{
  "success": true,
  "result": "Generated text content here...",
  "revenue": 0.01,
  "metadata": {
    "tokens_generated": 85,
    "processing_time": 1.2,
    "model": "microsoft/DialoGPT-medium"
  }
}
```

### Example Usage

#### cURL
```bash
curl -X POST "https://your-username-oasis-v3.hf.space/api/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Write a story about AI revolution",
    "max_length": 150
  }'
```

#### Python
```python
import requests

response = requests.post(
    "https://your-username-oasis-v3.hf.space/api/generate",
    json={
        "prompt": "Write a story about AI revolution",
        "max_length": 150
    }
)
result = response.json()
print(result["result"])
```

#### Termux
```bash
python oasis_termux_client.py --generate "Write a story about AI revolution"
```

---

## 😊 Sentiment Analysis

### Endpoint
```http
POST /api/sentiment
```

### Description
Analyze the emotional tone and sentiment of text with confidence scores.

### Request Body
```json
{
  "text": "string (required)"
}
```

### Parameters
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `text` | string | Yes | Text to analyze sentiment |

### Response
```json
{
  "success": true,
  "result": {
    "sentiment": "POSITIVE",
    "confidence": 0.9234,
    "text_length": 25,
    "processing_time": 0.3
  }
}
```

### Sentiment Values
- `POSITIVE` - Positive emotion/opinion
- `NEGATIVE` - Negative emotion/opinion  
- `NEUTRAL` - Neutral/mixed sentiment

### Example Usage

#### cURL
```bash
curl -X POST "https://your-username-oasis-v3.hf.space/api/sentiment" \
  -H "Content-Type: application/json" \
  -d '{"text": "This product is absolutely amazing!"}'
```

#### Termux
```bash
python oasis_termux_client.py --sentiment "This product is absolutely amazing!"
```

---

## 🏷️ Text Classification

### Endpoint
```http
POST /api/classify
```

### Description
Classify text into custom categories using zero-shot classification.

### Request Body
```json
{
  "text": "string (required)",
  "labels": "string (required, comma-separated)"
}
```

### Parameters
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `text` | string | Yes | Text to classify |
| `labels` | string | Yes | Categories (comma-separated) |

### Response
```json
{
  "success": true,
  "result": {
    "classification": "technology",
    "confidence": 0.8756,
    "all_scores": {
      "technology": 0.8756,
      "business": 0.0891,
      "science": 0.0353
    }
  }
}
```

### Example Usage

#### cURL
```bash
curl -X POST "https://your-username-oasis-v3.hf.space/api/classify" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "New AI breakthrough in neural networks",
    "labels": "technology, business, science, entertainment"
  }'
```

#### Termux
```bash
python oasis_termux_client.py --classify "AI breakthrough" "tech,business,science"
```

---

## ❓ Question Answering

### Endpoint
```http
POST /api/qa
```

### Description
Answer questions based on provided context using reading comprehension AI.

### Request Body
```json
{
  "context": "string (required)",
  "question": "string (required)"
}
```

### Parameters
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `context` | string | Yes | Background information |
| `question` | string | Yes | Question to answer |

### Response
```json
{
  "success": true,
  "result": {
    "answer": "The extracted answer from context",
    "confidence": 0.9123,
    "start": 45,
    "end": 67
  }
}
```

### Example Usage

#### cURL
```bash
curl -X POST "https://your-username-oasis-v3.hf.space/api/qa" \
  -H "Content-Type: application/json" \
  -d '{
    "context": "OASIS is a revolutionary AI platform that provides mobile-first artificial intelligence services through HuggingFace Spaces.",
    "question": "What is OASIS?"
  }'
```

#### Termux
```bash
python oasis_termux_client.py --qa "OASIS is an AI platform..." "What is OASIS?"
```

---

## 📋 Text Summarization

### Endpoint
```http
POST /api/summarize
```

### Description
Generate concise summaries of long text documents.

### Request Body
```json
{
  "text": "string (required)",
  "max_length": "integer (optional, default: 130)"
}
```

### Parameters
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to summarize |
| `max_length` | integer | No | 130 | Maximum summary length |

### Response
```json
{
  "success": true,
  "result": "Concise summary of the input text...",
  "metadata": {
    "original_length": 1250,
    "summary_length": 95,
    "compression_ratio": 0.076
  }
}
```

### Example Usage

#### cURL
```bash
curl -X POST "https://your-username-oasis-v3.hf.space/api/summarize" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Very long article content here...",
    "max_length": 100
  }'
```

#### Termux
```bash
python oasis_termux_client.py --summarize "Long text content..."
```

---

## 🖼️ Image Classification

### Endpoint
```http
POST /api/image
```

### Description
Classify and analyze uploaded images using computer vision models.

### Request Body
Form data with image file or JSON with base64 image.

### Response
```json
{
  "success": true,
  "result": {
    "classification": "golden retriever",
    "confidence": 0.8934,
    "top_3": [
      {"label": "golden retriever", "score": 0.8934},
      {"label": "labrador", "score": 0.0823},
      {"label": "dog", "score": 0.0243}
    ]
  }
}
```

---

## 📊 Usage Statistics

### Endpoint
```http
GET /api/stats
```

### Description
Get real-time usage statistics and revenue metrics.

### Response
```json
{
  "success": true,
  "stats": {
    "requests": 15432,
    "tokens": 234567,
    "revenue": 89.45,
    "uptime": "99.9%",
    "active_users": 1247
  }
}
```

### Example Usage

#### cURL
```bash
curl "https://your-username-oasis-v3.hf.space/api/stats"
```

#### Termux
```bash
python oasis_termux_client.py --stats
```

---

## 🚨 Error Handling

### Error Response Format
```json
{
  "success": false,
  "error": "Error description",
  "code": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Common Error Codes

| Code | Description | Solution |
|------|-------------|----------|
| `INVALID_INPUT` | Request parameters invalid | Check parameter types/values |
| `RATE_LIMIT_EXCEEDED` | Too many requests | Wait before retrying |
| `MODEL_ERROR` | AI model processing failed | Retry with different input |
| `TIMEOUT` | Request processing timeout | Reduce input size |
| `SERVER_ERROR` | Internal server error | Contact support |

---

## 📱 Termux Integration

### Installation
```bash
# Download and run setup script
bash <(curl -sL https://raw.githubusercontent.com/your-username/oasis-v3/main/termux_setup.sh)
```

### Quick Commands
```bash
# Test connection
oasis-test

# Generate text
oasis-generate "Your prompt here"

# Analyze sentiment  
oasis-sentiment "Text to analyze"

# Get statistics
oasis-stats
```

### Configuration
Edit `~/oasis/oasis_config.json`:
```json
{
  "server_url": "https://your-username-oasis-v3.hf.space",
  "timeout_seconds": 30,
  "max_retries": 3
}
```

---

## 💰 Pricing & Revenue

### Request Pricing
| Service | Price per Request | Typical Volume | Monthly Revenue |
|---------|-------------------|----------------|-----------------|
| Text Generation | $0.010 | 5,000 | $50.00 |
| Sentiment Analysis | $0.005 | 10,000 | $50.00 |
| Classification | $0.008 | 3,000 | $24.00 |
| Question Answering | $0.010 | 2,000 | $20.00 |
| Summarization | $0.015 | 1,500 | $22.50 |
| Image Analysis | $0.020 | 1,000 | $20.00 |

### Revenue Tracking
Monitor your usage and costs:
```bash
# Get revenue statistics
curl "https://your-username-oasis-v3.hf.space/api/stats"

# Termux revenue tracking
python oasis_termux_client.py --stats
```

---

## 🔧 Rate Limiting

### Limits
- **Free Tier**: 60 requests per minute
- **Burst Limit**: Up to 10 rapid requests
- **Daily Limit**: 10,000 requests per day

### Headers
Response includes rate limit information:
```http
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1642234567
```

### Handling Rate Limits
```python
import time
import requests

def make_request_with_retry(url, data, max_retries=3):
    for attempt in range(max_retries):
        response = requests.post(url, json=data)
        
        if response.status_code == 429:  # Rate limited
            wait_time = int(response.headers.get('Retry-After', 60))
            time.sleep(wait_time)
            continue
            
        return response.json()
    
    raise Exception("Max retries exceeded")
```

---

## 🎯 Best Practices

### Optimization Tips
1. **Batch Requests**: Group multiple operations when possible
2. **Cache Results**: Store responses for repeated queries  
3. **Minimize Payload**: Keep input sizes reasonable
4. **Error Handling**: Implement robust retry logic
5. **Monitor Usage**: Track costs and performance

### Example Optimized Client
```python
import requests
import json
import time
from functools import lru_cache

class OASISOptimizedClient:
    def __init__(self, base_url):
        self.base_url = base_url
        self.session = requests.Session()
        
    @lru_cache(maxsize=100)
    def cached_sentiment(self, text):
        """Cached sentiment analysis"""
        return self._make_request("sentiment", {"text": text})
    
    def _make_request(self, endpoint, data):
        """Request with retry logic"""
        for attempt in range(3):
            try:
                response = self.session.post(
                    f"{self.base_url}/{endpoint}",
                    json=data,
                    timeout=30
                )
                return response.json()
            except Exception as e:
                if attempt == 2:
                    raise e
                time.sleep(1)
```

---

## 🔗 SDKs & Libraries

### Official Termux Client
```bash
# Install via setup script
bash <(curl -sL https://setup.oasis-ai.com/termux)
```

### Python SDK (Unofficial)
```python
pip install oasis-ai-client
```

### JavaScript SDK (Unofficial)  
```javascript
npm install oasis-ai-js
```

---

## 📞 Support & Resources

### Documentation
- **Full Docs**: [docs.oasis-ai.org](https://docs.oasis-ai.org)
- **Tutorials**: [tutorials.oasis-ai.org](https://tutorials.oasis-ai.org)
- **Examples**: [examples.oasis-ai.org](https://examples.oasis-ai.org)

### Community
- **Discord**: [discord.gg/oasis-ai](https://discord.gg/oasis-ai)
- **GitHub**: [github.com/your-username/oasis-v3](https://github.com/your-username/oasis-v3)
- **Forum**: [forum.oasis-ai.org](https://forum.oasis-ai.org)

### Contact
- **Email**: api-support@oasis-ai.org
- **Issues**: [GitHub Issues](https://github.com/your-username/oasis-v3/issues)
- **Feature Requests**: [feature-requests@oasis-ai.org](mailto:feature-requests@oasis-ai.org)

---

**Built with ❤️ for the AI Revolution**

*Last Updated: 2024-01-15 | Version: 3.0.0*