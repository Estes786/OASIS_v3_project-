# ⚡ OASIS v3 - Quick Start Guide

**Get your AI Superintelligence platform running in under 5 minutes!**

---

## 🎯 Choose Your Path

### 🌐 Option 1: Web Interface (Instant)
**Perfect for: Testing, demonstrations, web users**

1. **Visit the Live App**
   ```
   https://your-username-oasis-v3.hf.space
   ```

2. **Start Using AI Immediately**
   - Click any tab (Generation, Analysis, Q&A, etc.)
   - Enter your text/prompt
   - Get instant AI results!

3. **Monitor Revenue** 
   - Go to "Revenue Dashboard" tab
   - See real-time earnings and usage stats

### 📱 Option 2: Mobile/Termux (Recommended)
**Perfect for: Android users, mobile AI access, developers**

#### One-Line Installation
```bash
bash <(curl -sL https://raw.githubusercontent.com/your-username/oasis-v3/main/termux_setup.sh)
```

#### Manual Setup
```bash
# Install Termux from F-Droid or Play Store
# Then run these commands:

pkg update && pkg upgrade
pkg install python wget curl git
cd ~
mkdir oasis && cd oasis
wget https://raw.githubusercontent.com/your-username/oasis-v3/main/oasis_termux_client.py
chmod +x oasis_termux_client.py

# Test installation
python oasis_termux_client.py --test
```

---

## 🚀 First Steps

### 1. Test Connection
```bash
# Web: Visit the app URL
# Termux:
python oasis_termux_client.py --test
```

### 2. Generate Your First AI Text
```bash
# Termux:
python oasis_termux_client.py --generate "Write a haiku about AI"

# Expected output:
# 📝 Generated Text:
# Silicon dreams wake,
# Neural networks learn and grow,
# Future unfolds bright.
```

### 3. Analyze Sentiment
```bash
# Termux:
python oasis_termux_client.py --sentiment "OASIS is revolutionary!"

# Expected output:
# 😊 Sentiment: POSITIVE
# 📊 Confidence: 89.2%
```

### 4. Check Your Revenue
```bash
# Termux:
python oasis_termux_client.py --stats

# Expected output:
# 📊 OASIS SESSION STATISTICS
# ⏱️  Session Duration: 2m 15s
# 📱 Requests Made: 3
# 💰 Session Cost: $0.025
```

---

## 🎮 Interactive Examples

### 💡 Creative Writing Assistant
```bash
# Generate story ideas
python oasis_termux_client.py --generate "A sci-fi story about"

# Analyze the mood of your writing
python oasis_termux_client.py --sentiment "The dark clouds gathered ominously..."

# Classify your content
python oasis_termux_client.py --classify "Space exploration story" "sci-fi,fantasy,adventure,romance"
```

### 📊 Business Intelligence
```bash
# Analyze customer feedback
python oasis_termux_client.py --sentiment "The product exceeded my expectations!"

# Classify business documents
python oasis_termux_client.py --classify "Q4 revenue report shows growth" "finance,marketing,operations,strategy"

# Summarize long reports
python oasis_termux_client.py --summarize "Very long business document here..."
```

### 🎓 Educational Assistant
```bash
# Q&A for learning
python oasis_termux_client.py --qa "AI uses neural networks to process information" "How does AI work?"

# Summarize study materials  
python oasis_termux_client.py --summarize "Long academic paper content..."

# Classify subjects
python oasis_termux_client.py --classify "Machine learning algorithms" "computer-science,mathematics,statistics,engineering"
```

---

## 💰 Revenue Quick Start

### Understanding Costs
| Operation | Cost | Example Use |
|-----------|------|-------------|
| Text Generation | $0.01 | Blog posts, stories, content |
| Sentiment Analysis | $0.005 | Social media monitoring, feedback |
| Classification | $0.008 | Document sorting, content tagging |
| Q&A | $0.01 | Customer support, education |
| Summarization | $0.015 | Report summaries, research |

### Revenue Projection Calculator
```bash
# Example daily usage scenario:
# 50 text generations = 50 × $0.01 = $0.50
# 100 sentiment analyses = 100 × $0.005 = $0.50  
# 30 classifications = 30 × $0.008 = $0.24
# 20 Q&As = 20 × $0.01 = $0.20
# 10 summaries = 10 × $0.015 = $0.15

# Daily Total = $1.59
# Monthly Potential = $47.70
# Scale to 1000 users = $47,700/month
```

### Track Your Growth
```bash
# Check stats regularly
python oasis_termux_client.py --stats

# View web dashboard
# Visit: https://your-username-oasis-v3.hf.space?tab=revenue
```

---

## 🛠️ Customization

### Configure Your Client
Edit `~/oasis/oasis_config.json`:
```json
{
  "server_url": "https://your-username-oasis-v3.hf.space",
  "timeout_seconds": 30,
  "daily_budget": 10.00,
  "show_costs": true
}
```

### Create Custom Aliases
Add to `~/.bashrc`:
```bash
# Quick AI commands
alias ai-write='python ~/oasis/oasis_termux_client.py --generate'
alias ai-feel='python ~/oasis/oasis_termux_client.py --sentiment'  
alias ai-sort='python ~/oasis/oasis_termux_client.py --classify'
alias ai-ask='python ~/oasis/oasis_termux_client.py --qa'
alias ai-sum='python ~/oasis/oasis_termux_client.py --summarize'
alias ai-stats='python ~/oasis/oasis_termux_client.py --stats'

# Example usage after restart:
# ai-write "Create a business plan"
# ai-feel "Customer feedback text"
```

---

## 🌟 Pro Tips

### 1. Batch Operations for Efficiency
```bash
# Create a script for multiple operations
cat > ai_batch.sh << 'EOF'
#!/bin/bash
echo "🤖 Running AI batch operations..."

python oasis_termux_client.py --generate "Business idea: AI-powered"
python oasis_termux_client.py --sentiment "This product is game-changing"  
python oasis_termux_client.py --classify "Startup pitch deck" "business,tech,finance"

python oasis_termux_client.py --stats
EOF

chmod +x ai_batch.sh
./ai_batch.sh
```

### 2. Create Templates
```bash
# Content generation templates
python oasis_termux_client.py --generate "Blog post about: [TOPIC]"
python oasis_termux_client.py --generate "Social media caption for: [PRODUCT]"
python oasis_termux_client.py --generate "Email subject line: [CAMPAIGN]"
```

### 3. Monitor Performance
```bash
# Create monitoring script
cat > monitor.sh << 'EOF'
#!/bin/bash
while true; do
    clear
    echo "🚀 OASIS Live Monitor"
    echo "===================="
    python oasis_termux_client.py --stats
    echo
    echo "Next update in 30 seconds..."
    sleep 30
done
EOF
```

---

## 🚨 Troubleshooting

### Common Issues

#### "Connection Error"
```bash
# Check internet connection
ping google.com

# Verify URL is correct
curl -I https://your-username-oasis-v3.hf.space

# Update client
cd ~/oasis
wget -O oasis_termux_client.py https://raw.githubusercontent.com/your-username/oasis-v3/main/oasis_termux_client.py
```

#### "Python Module Not Found"
```bash
# Reinstall Python packages
pkg update
pkg install python python-pip

# Install required modules
pip install urllib3
```

#### "Rate Limit Exceeded"
```bash
# Wait 1 minute then retry
sleep 60
python oasis_termux_client.py --test

# Check current limits
python oasis_termux_client.py --stats
```

### Debug Mode
```bash
# Run with verbose output
python -v oasis_termux_client.py --test

# Check network connectivity
curl -v https://your-username-oasis-v3.hf.space/api/stats
```

---

## 🎯 Next Steps

### 1. Scale Your Usage
- **Personal**: 10-50 requests/day → $5-25/month
- **Small Business**: 100-500 requests/day → $50-250/month  
- **Enterprise**: 1000+ requests/day → $500+/month

### 2. Integrate with Other Tools
```bash
# Add to existing scripts
result=$(python oasis_termux_client.py --sentiment "$user_feedback")
echo "Sentiment: $result" >> analytics.log

# Use in automation
for file in *.txt; do
    python oasis_termux_client.py --summarize "$(cat $file)" > "${file%.txt}_summary.txt"
done
```

### 3. Explore Advanced Features
- **Web Interface**: Full GUI with visualizations
- **API Integration**: Build custom applications  
- **Revenue Optimization**: Track and optimize usage patterns
- **Model Fine-tuning**: Custom AI models (coming soon)

### 4. Join the Community
- **GitHub**: Contribute to development
- **Discord**: Get support and share ideas
- **Newsletter**: Stay updated on new features

---

## 🎉 Success Checklist

- ✅ **Installed**: OASIS client working
- ✅ **Tested**: Generated first AI text
- ✅ **Analyzed**: Checked sentiment analysis
- ✅ **Classified**: Tried text classification  
- ✅ **Revenue**: Viewed earnings dashboard
- ✅ **Optimized**: Created shortcuts and aliases
- ✅ **Scaled**: Planning for increased usage

**🚀 Congratulations! You're now ready to harness AI superintelligence on mobile!**

---

## 📞 Need Help?

### Quick Support
- **Test Connection**: `python oasis_termux_client.py --test`
- **Check Status**: Visit [https://status.oasis-ai.org](https://status.oasis-ai.org)
- **Read Docs**: [https://docs.oasis-ai.org](https://docs.oasis-ai.org)

### Get In Touch
- **Discord**: [discord.gg/oasis-ai](https://discord.gg/oasis-ai)
- **Email**: support@oasis-ai.org
- **GitHub Issues**: Report bugs and request features

---

**Welcome to the AI Revolution! 🤖✨**

*Built with ❤️ by the OASIS Community*