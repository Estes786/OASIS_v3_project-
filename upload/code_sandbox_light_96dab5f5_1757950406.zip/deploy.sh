#!/bin/bash
# OASIS v3 - HuggingFace Spaces Deployment Script
# Automated deployment to production

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Configuration
SPACE_NAME="oasis-v3"
HF_USERNAME="${HF_USERNAME:-your-username}"
REPO_URL="https://huggingface.co/spaces/${HF_USERNAME}/${SPACE_NAME}"

print_step() {
    echo -e "${BLUE}🚀 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check requirements
check_requirements() {
    print_step "Checking deployment requirements..."
    
    if ! command -v git >/dev/null 2>&1; then
        print_error "Git is required but not installed"
        exit 1
    fi
    
    if ! command -v python >/dev/null 2>&1; then
        print_error "Python is required but not installed"
        exit 1
    fi
    
    if [[ -z "$HF_TOKEN" ]]; then
        print_warning "HF_TOKEN environment variable not set"
        echo "Please set your HuggingFace token:"
        read -s -p "Enter HF Token: " HF_TOKEN
        export HF_TOKEN
        echo
    fi
    
    print_success "Requirements check passed"
}

# Validate application
validate_app() {
    print_step "Validating application..."
    
    # Check essential files
    local required_files=("app.py" "requirements.txt" "README.md")
    for file in "${required_files[@]}"; do
        if [[ ! -f "$file" ]]; then
            print_error "Required file missing: $file"
            exit 1
        fi
    done
    
    # Validate Python syntax
    if ! python -m py_compile app.py; then
        print_error "Python syntax validation failed"
        exit 1
    fi
    
    # Check requirements format
    if ! pip check -r requirements.txt >/dev/null 2>&1; then
        print_warning "Requirements validation had warnings"
    fi
    
    print_success "Application validation passed"
}

# Test locally (optional)
test_locally() {
    if [[ "$1" == "--test-local" ]]; then
        print_step "Running local test..."
        
        # Install requirements in virtual environment
        python -m venv test_env
        source test_env/bin/activate
        
        pip install -r requirements.txt
        
        # Test import
        python -c "import app; print('✅ Import successful')" || {
            print_error "Local import test failed"
            deactivate
            rm -rf test_env
            exit 1
        }
        
        deactivate
        rm -rf test_env
        
        print_success "Local test passed"
    fi
}

# Setup Git repository
setup_git_repo() {
    print_step "Setting up Git repository..."
    
    if [[ ! -d ".git" ]]; then
        git init
        git branch -M main
    fi
    
    # Configure Git if needed
    if [[ -z "$(git config user.email)" ]]; then
        git config user.email "oasis@ai-revolution.com"
        git config user.name "OASIS AI"
    fi
    
    # Add HuggingFace remote
    if ! git remote get-url origin >/dev/null 2>&1; then
        git remote add origin "$REPO_URL"
    fi
    
    print_success "Git repository configured"
}

# Create Space metadata
create_metadata() {
    print_step "Creating Space metadata..."
    
    cat > README.md << EOF
---
title: OASIS v3 - AI Superintelligence
emoji: 🚀
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 4.0.0
app_file: app.py
pinned: true
license: mit
duplicated_from: your-username/oasis-v3
tags:
  - ai
  - superintelligence
  - mobile-first
  - revenue-ready
  - termux
  - zero-cost
short_description: Zero-Cost, Mobile-First, Revenue-Ready AI Processing Engine
---

# 🚀 OASIS v3 - AI Superintelligence Ecosystem

**Revolutionary AI processing platform leveraging 100,000+ HuggingFace models with ultra-lightweight mobile orchestration through Termux.**

## Features
- 🤖 Advanced AI capabilities (text, image, audio)
- 📱 Mobile-first design with Termux integration  
- 💰 Revenue-ready monetization system
- ⚡ Ultra-lightweight architecture (<5MB)
- 🌐 Zero-cost deployment on HuggingFace Spaces

## Quick Start
Visit the live app or install on Android/Termux:

\`\`\`bash
bash <(curl -sL https://raw.githubusercontent.com/your-username/oasis-v3/main/termux_setup.sh)
\`\`\`

## Revenue Model
- Text Generation: \$0.01 per request
- Sentiment Analysis: \$0.005 per request  
- Classification: \$0.008 per request
- Monthly potential: \$500-20,000

Built with ❤️ for the AI Revolution
EOF
    
    print_success "Metadata created"
}

# Deploy to HuggingFace
deploy_to_hf() {
    print_step "Deploying to HuggingFace Spaces..."
    
    # Add all files
    git add .
    
    # Create commit
    local commit_msg="🚀 OASIS v3 Production Deployment - $(date '+%Y-%m-%d %H:%M:%S')"
    git commit -m "$commit_msg" || {
        print_warning "No changes to commit"
    }
    
    # Configure Git credentials with token
    git remote set-url origin "https://${HF_USERNAME}:${HF_TOKEN}@huggingface.co/spaces/${HF_USERNAME}/${SPACE_NAME}"
    
    # Push to HuggingFace
    git push -u origin main || {
        print_error "Failed to push to HuggingFace"
        exit 1
    }
    
    print_success "Deployed to HuggingFace Spaces"
}

# Monitor deployment
monitor_deployment() {
    print_step "Monitoring deployment status..."
    
    local space_url="https://huggingface.co/spaces/${HF_USERNAME}/${SPACE_NAME}"
    local app_url="https://${HF_USERNAME}-${SPACE_NAME}.hf.space"
    
    echo -e "${BLUE}📊 Deployment Information:${NC}"
    echo "  Space URL: $space_url"
    echo "  App URL: $app_url"
    echo "  API Base: $app_url/api"
    
    print_step "Waiting for deployment to complete..."
    
    # Wait for deployment (basic check)
    local retries=0
    local max_retries=30
    
    while [[ $retries -lt $max_retries ]]; do
        if curl -s "$app_url" >/dev/null 2>&1; then
            print_success "Deployment completed successfully!"
            echo -e "${GREEN}🎉 Your OASIS v3 is live at: $app_url${NC}"
            break
        fi
        
        ((retries++))
        echo "  Waiting... (attempt $retries/$max_retries)"
        sleep 10
    done
    
    if [[ $retries -eq $max_retries ]]; then
        print_warning "Deployment monitoring timed out"
        echo "Please check the Space status manually at: $space_url"
    fi
}

# Update Termux client with new URL
update_client_config() {
    print_step "Updating client configuration..."
    
    local app_url="https://${HF_USERNAME}-${SPACE_NAME}.hf.space"
    
    # Update oasis_termux_client.py with correct URL
    sed -i "s|https://your-space-name.hf.space|$app_url|g" oasis_termux_client.py
    
    # Update config file
    sed -i "s|https://your-username-oasis-v3.hf.space|$app_url|g" oasis_config.json
    
    # Commit updates
    git add oasis_termux_client.py oasis_config.json
    git commit -m "🔧 Update URLs for production deployment" || true
    git push origin main || true
    
    print_success "Client configuration updated"
}

# Main deployment function
main() {
    echo -e "${BLUE}"
    echo "🚀 =================================="
    echo "   OASIS v3 Deployment Script"
    echo "   HuggingFace Spaces Production"
    echo "==================================${NC}"
    
    check_requirements
    validate_app
    test_locally "$@"
    setup_git_repo
    create_metadata
    deploy_to_hf
    update_client_config
    monitor_deployment
    
    echo
    echo -e "${GREEN}🎉 Deployment Complete!${NC}"
    echo -e "${BLUE}📱 Termux Setup: ${NC}bash <(curl -sL https://raw.githubusercontent.com/${HF_USERNAME}/oasis-v3/main/termux_setup.sh)"
    echo -e "${BLUE}🌐 Live App: ${NC}https://${HF_USERNAME}-${SPACE_NAME}.hf.space"
    echo -e "${BLUE}📊 Revenue Dashboard: ${NC}https://${HF_USERNAME}-${SPACE_NAME}.hf.space?tab=revenue"
}

# Error handling
trap 'print_error "Deployment failed at line $LINENO"' ERR

# Run deployment
main "$@"