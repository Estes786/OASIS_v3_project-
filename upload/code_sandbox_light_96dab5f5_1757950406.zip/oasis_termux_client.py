#!/usr/bin/env python3
"""
OASIS Termux Client - Ultra-Lightweight AI Access
Zero-dependency mobile AI orchestration for Android/Termux

Usage:
    python oasis_termux_client.py --generate "Hello AI"
    python oasis_termux_client.py --sentiment "This is amazing!"
    python oasis_termux_client.py --classify "Tech article" "tech,business,science"
"""

import urllib.request
import urllib.parse
import json
import sys
import argparse
import time
from typing import Dict, Any, Optional

class OASISTermuxClient:
    """Ultra-lightweight OASIS client for Termux/Android"""
    
    def __init__(self, base_url: str = "https://your-space-name.hf.space"):
        self.base_url = base_url.rstrip('/')
        self.api_base = f"{self.base_url}/api"
        self.session_stats = {
            "requests": 0,
            "total_cost": 0.0,
            "start_time": time.time()
        }
    
    def _make_request(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make HTTP request with minimal dependencies"""
        try:
            url = f"{self.api_base}/{endpoint}"
            
            # Prepare request data
            json_data = json.dumps(data).encode('utf-8')
            
            # Create request with headers
            request = urllib.request.Request(
                url,
                data=json_data,
                headers={
                    'Content-Type': 'application/json',
                    'User-Agent': 'OASIS-Termux-Client/1.0',
                    'Accept': 'application/json'
                },
                method='POST'
            )
            
            # Make request
            with urllib.request.urlopen(request, timeout=30) as response:
                response_data = json.loads(response.read().decode('utf-8'))
                
            self.session_stats["requests"] += 1
            
            # Track costs based on endpoint
            costs = {
                'generate': 0.01,
                'sentiment': 0.005,
                'classify': 0.008,
                'qa': 0.01,
                'summarize': 0.015,
                'image': 0.02
            }
            self.session_stats["total_cost"] += costs.get(endpoint, 0.01)
            
            return response_data
            
        except urllib.error.URLError as e:
            return {"success": False, "error": f"Network error: {e}"}
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"JSON decode error: {e}"}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {e}"}
    
    def generate_text(self, prompt: str, max_length: int = 100) -> str:
        """Generate text using AI"""
        print(f"🤖 Generating text for: '{prompt[:50]}...'")
        
        data = {
            "prompt": prompt,
            "max_length": max_length
        }
        
        result = self._make_request("generate", data)
        
        if result.get("success"):
            return result.get("result", "No result returned")
        else:
            return f"Error: {result.get('error', 'Unknown error')}"
    
    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """Analyze sentiment of text"""
        print(f"😊 Analyzing sentiment: '{text[:50]}...'")
        
        data = {"text": text}
        result = self._make_request("sentiment", data)
        
        if result.get("success"):
            sentiment_data = result.get("result", {})
            return {
                "sentiment": sentiment_data.get("sentiment", "unknown"),
                "confidence": sentiment_data.get("confidence", 0.0),
                "emoji": self._sentiment_to_emoji(sentiment_data.get("sentiment"))
            }
        else:
            return {"error": result.get("error", "Unknown error")}
    
    def classify_text(self, text: str, labels: str) -> Dict[str, Any]:
        """Classify text with custom labels"""
        print(f"🏷️ Classifying: '{text[:50]}...' with labels: {labels}")
        
        data = {
            "text": text,
            "labels": labels
        }
        
        result = self._make_request("classify", data)
        
        if result.get("success"):
            return result.get("result", {})
        else:
            return {"error": result.get("error", "Unknown error")}
    
    def answer_question(self, context: str, question: str) -> Dict[str, Any]:
        """Answer question based on context"""
        print(f"❓ Answering: '{question}' from context length: {len(context)}")
        
        data = {
            "context": context,
            "question": question
        }
        
        result = self._make_request("qa", data)
        
        if result.get("success"):
            return result.get("result", {})
        else:
            return {"error": result.get("error", "Unknown error")}
    
    def summarize_text(self, text: str, max_length: int = 130) -> str:
        """Summarize long text"""
        print(f"📋 Summarizing text of {len(text)} characters...")
        
        data = {
            "text": text,
            "max_length": max_length
        }
        
        result = self._make_request("summarize", data)
        
        if result.get("success"):
            return result.get("result", "No summary generated")
        else:
            return f"Error: {result.get('error', 'Unknown error')}"
    
    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics"""
        try:
            url = f"{self.api_base}/stats"
            request = urllib.request.Request(url, method='GET')
            
            with urllib.request.urlopen(request, timeout=10) as response:
                server_stats = json.loads(response.read().decode('utf-8'))
                
            return {
                "server_stats": server_stats.get("stats", {}),
                "session_stats": self.session_stats,
                "session_duration": time.time() - self.session_stats["start_time"]
            }
            
        except Exception as e:
            return {"error": f"Failed to get stats: {e}"}
    
    def _sentiment_to_emoji(self, sentiment: str) -> str:
        """Convert sentiment to emoji"""
        emoji_map = {
            "POSITIVE": "😊",
            "NEGATIVE": "😞", 
            "NEUTRAL": "😐",
            "positive": "😊",
            "negative": "😞",
            "neutral": "😐"
        }
        return emoji_map.get(sentiment, "🤔")
    
    def print_stats(self):
        """Print formatted statistics"""
        stats = self.get_stats()
        
        print("\n" + "="*50)
        print("📊 OASIS SESSION STATISTICS")
        print("="*50)
        
        if "error" not in stats:
            session = stats["session_stats"]
            duration = int(stats["session_duration"])
            
            print(f"⏱️  Session Duration: {duration//60}m {duration%60}s")
            print(f"📱 Requests Made: {session['requests']}")
            print(f"💰 Session Cost: ${session['total_cost']:.3f}")
            
            if session['requests'] > 0:
                avg_cost = session['total_cost'] / session['requests']
                print(f"📈 Avg Cost/Request: ${avg_cost:.4f}")
        else:
            print(f"❌ Error getting stats: {stats['error']}")
        
        print("="*50)

def main():
    """Main CLI interface"""
    parser = argparse.ArgumentParser(
        description="OASIS Termux Client - Ultra-Lightweight AI Access",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python oasis_termux_client.py --generate "Write a story about AI"
    python oasis_termux_client.py --sentiment "This product is amazing!"
    python oasis_termux_client.py --classify "Tech news article" "technology,business,science"
    python oasis_termux_client.py --qa "AI is amazing" "What is AI?"
    python oasis_termux_client.py --summarize "Very long text here..."
    python oasis_termux_client.py --stats
        """
    )
    
    # Configuration
    parser.add_argument('--url', default='https://your-space-name.hf.space',
                       help='OASIS server URL')
    
    # AI Operations
    parser.add_argument('--generate', metavar='PROMPT',
                       help='Generate text from prompt')
    parser.add_argument('--max-length', type=int, default=100,
                       help='Maximum generation length (default: 100)')
    
    parser.add_argument('--sentiment', metavar='TEXT',
                       help='Analyze sentiment of text')
    
    parser.add_argument('--classify', nargs=2, metavar=('TEXT', 'LABELS'),
                       help='Classify text with comma-separated labels')
    
    parser.add_argument('--qa', nargs=2, metavar=('CONTEXT', 'QUESTION'),
                       help='Answer question based on context')
    
    parser.add_argument('--summarize', metavar='TEXT',
                       help='Summarize long text')
    parser.add_argument('--summary-length', type=int, default=130,
                       help='Summary max length (default: 130)')
    
    # Utilities
    parser.add_argument('--stats', action='store_true',
                       help='Show usage statistics')
    parser.add_argument('--test', action='store_true',
                       help='Test connection to OASIS server')
    
    args = parser.parse_args()
    
    # Initialize client
    client = OASISTermuxClient(args.url)
    
    print("🚀 OASIS Termux Client v1.0")
    print(f"🌐 Connected to: {args.url}")
    print("-" * 50)
    
    # Handle commands
    if args.test:
        print("🔍 Testing connection...")
        stats = client.get_stats()
        if "error" not in stats:
            print("✅ Connection successful!")
            print(f"📊 Server requests: {stats.get('server_stats', {}).get('requests', 'N/A')}")
        else:
            print("❌ Connection failed!")
            print(f"Error: {stats['error']}")
    
    elif args.generate:
        result = client.generate_text(args.generate, args.max_length)
        print(f"\n📝 Generated Text:\n{result}")
    
    elif args.sentiment:
        result = client.analyze_sentiment(args.sentiment)
        if "error" not in result:
            print(f"\n{result['emoji']} Sentiment: {result['sentiment']}")
            print(f"📊 Confidence: {result['confidence']:.2%}")
        else:
            print(f"\n❌ Error: {result['error']}")
    
    elif args.classify:
        text, labels = args.classify
        result = client.classify_text(text, labels)
        if "error" not in result:
            print(f"\n🏷️ Classification: {result.get('classification', 'Unknown')}")
            print(f"📊 Confidence: {result.get('confidence', 0):.2%}")
        else:
            print(f"\n❌ Error: {result['error']}")
    
    elif args.qa:
        context, question = args.qa
        result = client.answer_question(context, question)
        if "error" not in result:
            print(f"\n❓ Question: {question}")
            print(f"✅ Answer: {result.get('answer', 'No answer found')}")
            print(f"📊 Confidence: {result.get('confidence', 0):.2%}")
        else:
            print(f"\n❌ Error: {result['error']}")
    
    elif args.summarize:
        result = client.summarize_text(args.summarize, args.summary_length)
        print(f"\n📋 Summary:\n{result}")
    
    elif args.stats:
        client.print_stats()
    
    else:
        print("❌ No command specified. Use --help for options.")
        sys.exit(1)
    
    # Show session stats if any operations were performed
    if client.session_stats["requests"] > 0:
        print(f"\n💰 Session cost: ${client.session_stats['total_cost']:.3f}")

if __name__ == "__main__":
    main()