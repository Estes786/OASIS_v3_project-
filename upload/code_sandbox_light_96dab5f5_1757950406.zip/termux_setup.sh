#!/bin/bash
# OASIS Termux Setup Script
# Ultra-lightweight AI client installation for Android/Termux

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
OASIS_CLIENT_URL="https://raw.githubusercontent.com/your-username/oasis-v3/main/oasis_termux_client.py"
OASIS_CONFIG_URL="https://raw.githubusercontent.com/your-username/oasis-v3/main/oasis_config.json"

# Helper functions
print_header() {
    echo -e "${BLUE}"
    echo "🚀 =================================="
    echo "   OASIS v3 - Termux Setup"
    echo "   Zero-Cost AI Superintelligence"
    echo "==================================${NC}"
}

print_step() {
    echo -e "${YELLOW}📱 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

check_termux() {
    if [[ ! -d "/data/data/com.termux" ]] && [[ ! "$PREFIX" =~ termux ]]; then
        print_error "This script is designed for Termux on Android!"
        echo "Please install Termux from F-Droid or Google Play Store"
        exit 1
    fi
    print_success "Termux environment detected"
}

install_dependencies() {
    print_step "Installing system dependencies..."
    
    # Update package lists
    pkg update -y || {
        print_error "Failed to update packages"
        exit 1
    }
    
    # Install essential packages
    pkg install -y python python-pip wget curl git || {
        print_error "Failed to install packages"
        exit 1
    }
    
    print_success "Dependencies installed"
}

setup_python_environment() {
    print_step "Setting up Python environment..."
    
    # Upgrade pip
    pip install --upgrade pip || {
        print_error "Failed to upgrade pip"
        exit 1
    }
    
    # Install minimal Python packages for OASIS
    pip install --user urllib3 || {
        print_error "Failed to install urllib3"
        exit 1
    }
    
    print_success "Python environment ready"
}

download_oasis_client() {
    print_step "Downloading OASIS client..."
    
    # Create OASIS directory
    mkdir -p ~/oasis
    cd ~/oasis
    
    # Download main client
    if command -v wget >/dev/null; then
        wget -O oasis_client.py "$OASIS_CLIENT_URL" || {
            print_error "Failed to download OASIS client with wget"
            exit 1
        }
    elif command -v curl >/dev/null; then
        curl -L -o oasis_client.py "$OASIS_CLIENT_URL" || {
            print_error "Failed to download OASIS client with curl"
            exit 1
        }
    else
        print_error "Neither wget nor curl available"
        exit 1
    fi
    
    # Make executable
    chmod +x oasis_client.py
    
    print_success "OASIS client downloaded"
}

create_config_file() {
    print_step "Creating configuration file..."
    
    cat > ~/oasis/oasis_config.json << EOF
{
    "server_url": "https://your-space-name.hf.space",
    "client_version": "1.0.0",
    "cache_enabled": true,
    "cache_directory": "~/.oasis_cache",
    "max_retries": 3,
    "timeout_seconds": 30,
    "rate_limit": {
        "requests_per_minute": 60,
        "burst_limit": 10
    },
    "mobile_optimizations": {
        "compress_requests": true,
        "minimize_bandwidth": true,
        "offline_mode": false
    },
    "revenue_tracking": {
        "enabled": true,
        "show_costs": true,
        "budget_alerts": true,
        "daily_budget": 5.00
    }
}
EOF
    
    print_success "Configuration created"
}

create_shortcuts() {
    print_step "Creating convenient shortcuts..."
    
    # Create alias file
    cat > ~/oasis/oasis_aliases.sh << 'EOF'
#!/bin/bash
# OASIS Convenience Aliases for Termux

# Base command
alias oasis='python ~/oasis/oasis_client.py'

# Quick operations
alias oasis-generate='oasis --generate'
alias oasis-sentiment='oasis --sentiment'
alias oasis-classify='oasis --classify'
alias oasis-qa='oasis --qa'
alias oasis-summarize='oasis --summarize'
alias oasis-stats='oasis --stats'
alias oasis-test='oasis --test'

# Advanced shortcuts
alias oasis-quick-sentiment='function _oqs() { echo "Input: $1" && oasis --sentiment "$1"; }; _oqs'
alias oasis-quick-generate='function _oqg() { oasis --generate "$1" --max-length 50; }; _oqg'

# System shortcuts
alias oasis-update='cd ~/oasis && wget -O oasis_client.py https://raw.githubusercontent.com/your-username/oasis-v3/main/oasis_termux_client.py && chmod +x oasis_client.py'
alias oasis-help='oasis --help'
alias oasis-version='echo "OASIS v3 - Termux Client 1.0"'

echo "🚀 OASIS aliases loaded! Type 'oasis-help' for commands."
EOF
    
    chmod +x ~/oasis/oasis_aliases.sh
    
    # Add to .bashrc for persistent aliases
    if [[ -f ~/.bashrc ]]; then
        echo "# OASIS Aliases" >> ~/.bashrc
        echo "source ~/oasis/oasis_aliases.sh" >> ~/.bashrc
    fi
    
    print_success "Shortcuts created"
}

create_desktop_integration() {
    print_step "Setting up desktop integration..."
    
    # Create .desktop file for Termux:Widget
    mkdir -p ~/.shortcuts/tasks
    
    cat > ~/.shortcuts/tasks/oasis_stats << 'EOF'
#!/bin/bash
cd ~/oasis
python oasis_client.py --stats
read -p "Press Enter to continue..."
EOF
    
    cat > ~/.shortcuts/tasks/oasis_test << 'EOF'
#!/bin/bash
cd ~/oasis
python oasis_client.py --test
read -p "Press Enter to continue..."
EOF
    
    chmod +x ~/.shortcuts/tasks/oasis_*
    
    print_success "Desktop integration ready"
}

perform_test() {
    print_step "Testing OASIS installation..."
    
    cd ~/oasis
    
    # Test Python execution
    if ! python -c "import sys; print('Python', sys.version)" > /dev/null 2>&1; then
        print_error "Python test failed"
        exit 1
    fi
    
    # Test client syntax
    if ! python -m py_compile oasis_client.py > /dev/null 2>&1; then
        print_error "Client syntax check failed"
        exit 1
    fi
    
    # Test network connectivity (basic)
    if command -v ping >/dev/null; then
        if ! ping -c 1 8.8.8.8 > /dev/null 2>&1; then
            print_error "Network connectivity test failed"
            echo "Please check your internet connection"
            exit 1
        fi
    fi
    
    print_success "Installation test passed"
}

show_completion_message() {
    echo
    echo -e "${GREEN}🎉 =================================="
    echo "     OASIS Installation Complete!"
    echo "==================================${NC}"
    echo
    echo -e "${BLUE}📱 Quick Start Commands:${NC}"
    echo "   cd ~/oasis"
    echo "   python oasis_client.py --test"
    echo "   python oasis_client.py --generate 'Hello AI'"
    echo "   python oasis_client.py --sentiment 'This is amazing!'"
    echo
    echo -e "${BLUE}🔗 Useful Aliases (restart Termux first):${NC}"
    echo "   oasis-test          # Test connection"
    echo "   oasis-stats         # Show usage stats"
    echo "   oasis-generate 'text'  # Generate text"
    echo "   oasis-sentiment 'text' # Analyze sentiment"
    echo
    echo -e "${BLUE}📂 Installation Directory:${NC}"
    echo "   ~/oasis/oasis_client.py    # Main client"
    echo "   ~/oasis/oasis_config.json  # Configuration"
    echo "   ~/oasis/oasis_aliases.sh   # Shortcuts"
    echo
    echo -e "${BLUE}📊 Revenue Tracking:${NC}"
    echo "   • Text Generation: $0.01 per request"
    echo "   • Sentiment Analysis: $0.005 per request"
    echo "   • Classification: $0.008 per request"
    echo
    echo -e "${YELLOW}🎯 Next Steps:${NC}"
    echo "   1. Restart Termux to load aliases"
    echo "   2. Run 'oasis-test' to verify connection"
    echo "   3. Start using AI: 'oasis-generate \"Your prompt\"'"
    echo "   4. Monitor costs: 'oasis-stats'"
    echo
    echo -e "${GREEN}✨ Welcome to the AI Revolution!${NC}"
}

# Main execution
main() {
    print_header
    
    check_termux
    install_dependencies
    setup_python_environment
    download_oasis_client
    create_config_file
    create_shortcuts
    create_desktop_integration
    perform_test
    
    show_completion_message
}

# Error handling
trap 'print_error "Installation failed at line $LINENO. Check the error above."' ERR

# Run main function
main "$@"