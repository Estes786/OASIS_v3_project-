#!/usr/bin/env python3
"""
OASIS Orchestra Quick Launch Script
One-click launcher for complete OASIS system
Integrates all components for seamless experience

Author: OASIS Revolution Team
License: MIT
Version: 1.0.0 - The New Civilization
"""

import os
import sys
import subprocess
import threading
import time
import json
from datetime import datetime

# Import all OASIS components
try:
    from oasis_orchestra_core import OASISOrchestra
    from hf_spaces_orchestrator import HFSpacesOrchestrator, SpaceMonitor
    from business_automation_engine import CustomerManager, RevenueEngine, BusinessIntelligence
    from termux_orchestra_commander import TermuxOrchestraCommander, MobileOrchestra
    from realtime_dashboard import DashboardServer, RealTimeMonitor
except ImportError as e:
    print(f"⚠️  Component import error: {e}")
    print("📋 Please ensure all OASIS components are installed")

class OASISLauncher:
    """
    Master Launcher for OASIS Orchestra
    Coordinates all system components
    """
    
    def __init__(self):
        self.components = {}
        self.running = False
        self.config = self.load_configuration()
        
    def load_configuration(self):
        """Load OASIS configuration"""
        config_dir = os.path.expanduser("~/.oasis_orchestra")
        config_file = os.path.join(config_dir, "config", "orchestra_config.json")
        
        default_config = {
            "hf_token": "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",
            "username": "elmatador0197",
            "dashboard_port": 8080,
            "auto_start_dashboard": True,
            "auto_start_monitoring": True,
            "launch_mode": "interactive"  # interactive, daemon, dashboard-only
        }
        
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    # Merge with defaults
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
        except Exception as e:
            print(f"⚠️  Config load error: {e}")
        
        return default_config
    
    def initialize_components(self):
        """Initialize all OASIS components"""
        print("🎼 Initializing OASIS Orchestra components...")
        
        try:
            # Core Orchestra
            self.components['orchestra'] = OASISOrchestra(self.config["hf_token"])
            print("✅ Core Orchestra initialized")
            
            # Spaces Orchestrator
            self.components['spaces_orchestrator'] = HFSpacesOrchestrator(self.config["hf_token"])
            print("✅ Spaces Orchestrator initialized")
            
            # Business Intelligence
            self.components['customer_manager'] = CustomerManager()
            self.components['revenue_engine'] = RevenueEngine()
            self.components['business_intel'] = BusinessIntelligence(
                self.components['customer_manager'],
                self.components['revenue_engine']
            )
            print("✅ Business Intelligence initialized")
            
            # Termux Commander
            self.components['termux_commander'] = TermuxOrchestraCommander()
            print("✅ Termux Commander initialized")
            
            # Dashboard Server
            self.components['dashboard_server'] = DashboardServer(
                self.components['termux_commander'],
                self.config["dashboard_port"]
            )
            print("✅ Dashboard Server initialized")
            
            # Real-time Monitor
            self.components['realtime_monitor'] = RealTimeMonitor(
                self.components['termux_commander']
            )
            print("✅ Real-time Monitor initialized")
            
            return True
            
        except Exception as e:
            print(f"❌ Component initialization error: {e}")
            return False
    
    def start_dashboard(self):
        """Start web dashboard in background"""
        if 'dashboard_server' in self.components:
            success = self.components['dashboard_server'].start_server()
            if success:
                port = self.config["dashboard_port"]
                print(f"🌐 Dashboard available at: http://localhost:{port}")
                return True
        return False
    
    def start_monitoring(self):
        """Start real-time monitoring"""
        if 'realtime_monitor' in self.components:
            self.components['realtime_monitor'].start_monitoring()
            print("📊 Real-time monitoring activated")
            return True
        return False
    
    def launch_interactive_mode(self):
        """Launch interactive Termux interface"""
        print("📱 Starting interactive mode...")
        
        try:
            mobile_app = MobileOrchestra()
            mobile_app.run()
        except Exception as e:
            print(f"❌ Interactive mode error: {e}")
    
    def launch_daemon_mode(self):
        """Launch as background daemon"""
        print("🔧 Starting daemon mode...")
        
        # Start all background services
        services_started = []
        
        if self.config.get("auto_start_dashboard", True):
            if self.start_dashboard():
                services_started.append("Dashboard")
        
        if self.config.get("auto_start_monitoring", True):
            if self.start_monitoring():
                services_started.append("Monitoring")
        
        print(f"✅ Services started: {', '.join(services_started)}")
        
        # Keep daemon running
        try:
            print("🌟 OASIS Orchestra daemon running...")
            print("💡 Press Ctrl+C to stop")
            
            while True:
                time.sleep(60)  # Check every minute
                
        except KeyboardInterrupt:
            print("\n🛑 Shutting down daemon...")
            self.shutdown()
    
    def launch_dashboard_only_mode(self):
        """Launch only web dashboard"""
        print("🌐 Starting dashboard-only mode...")
        
        if self.start_dashboard():
            port = self.config["dashboard_port"]
            print(f"✅ Dashboard running on http://localhost:{port}")
            
            try:
                print("🌟 Dashboard is ready!")
                print("💡 Press Ctrl+C to stop")
                
                while True:
                    time.sleep(30)
                    
            except KeyboardInterrupt:
                print("\n🛑 Shutting down dashboard...")
                self.shutdown()
        else:
            print("❌ Failed to start dashboard")
    
    def shutdown(self):
        """Gracefully shutdown all components"""
        print("🔄 Shutting down OASIS Orchestra...")
        
        # Stop dashboard
        if 'dashboard_server' in self.components:
            self.components['dashboard_server'].stop_server()
        
        # Stop monitoring  
        if 'realtime_monitor' in self.components:
            self.components['realtime_monitor'].stop_monitoring()
        
        # Save configurations
        try:
            self.components['termux_commander'].save_configuration()
            print("💾 Configuration saved")
        except:
            pass
        
        print("✅ Shutdown complete")
        self.running = False
    
    def run(self, mode=None):
        """Main launcher entry point"""
        print("🎼" + "="*50)
        print("🌟 OASIS Orchestra Launcher")
        print("🚀 The New Civilization - Mobile AI Revolution")
        print("="*52)
        
        # Initialize components
        if not self.initialize_components():
            print("❌ Failed to initialize components")
            return False
        
        # Determine launch mode
        launch_mode = mode or self.config.get("launch_mode", "interactive")
        
        print(f"🎯 Launch Mode: {launch_mode.title()}")
        print("🚀 Starting OASIS Orchestra...")
        time.sleep(1)
        
        self.running = True
        
        try:
            if launch_mode == "interactive":
                # Auto-start background services first
                if self.config.get("auto_start_dashboard", True):
                    self.start_dashboard()
                if self.config.get("auto_start_monitoring", True):
                    self.start_monitoring()
                
                # Then launch interactive mode
                self.launch_interactive_mode()
                
            elif launch_mode == "daemon":
                self.launch_daemon_mode()
                
            elif launch_mode == "dashboard":
                self.launch_dashboard_only_mode()
                
            else:
                print(f"❌ Unknown launch mode: {launch_mode}")
                return False
                
        except Exception as e:
            print(f"❌ Launch error: {e}")
            return False
        
        finally:
            if self.running:
                self.shutdown()
        
        return True

def show_launch_options():
    """Show available launch options"""
    print("🎼 OASIS Orchestra Launch Options:")
    print("=" * 40)
    print("1. 📱 Interactive Mode (Default)")
    print("   - Full Termux interface")
    print("   - Quick commands")
    print("   - Real-time dashboard")
    print()
    print("2. 🔧 Daemon Mode")
    print("   - Background operation")
    print("   - Web dashboard only")
    print("   - System service mode")
    print()
    print("3. 🌐 Dashboard Only")
    print("   - Web interface only")
    print("   - Lightweight mode")
    print("   - Remote access ready")
    print()

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="OASIS Orchestra Launcher - The New Civilization",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Launch Modes:
  interactive    Full Termux interface (default)
  daemon         Background service mode  
  dashboard      Web dashboard only
  
Examples:
  python3 launch_oasis.py                    # Interactive mode
  python3 launch_oasis.py --mode daemon      # Daemon mode
  python3 launch_oasis.py --mode dashboard   # Dashboard only
  python3 launch_oasis.py --help            # Show this help
        """
    )
    
    parser.add_argument(
        '--mode', '-m',
        choices=['interactive', 'daemon', 'dashboard'],
        default='interactive',
        help='Launch mode (default: interactive)'
    )
    
    parser.add_argument(
        '--port', '-p',
        type=int,
        default=8080,
        help='Dashboard port (default: 8080)'
    )
    
    parser.add_argument(
        '--options',
        action='store_true',
        help='Show launch options and exit'
    )
    
    args = parser.parse_args()
    
    # Show options if requested
    if args.options:
        show_launch_options()
        return 0
    
    # Initialize launcher
    launcher = OASISLauncher()
    
    # Override port if specified
    if args.port != 8080:
        launcher.config["dashboard_port"] = args.port
    
    # Launch OASIS Orchestra
    try:
        success = launcher.run(args.mode)
        return 0 if success else 1
        
    except KeyboardInterrupt:
        print("\n\n👋 OASIS Orchestra interrupted by user")
        return 0
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())