#!/usr/bin/env python3
"""
OASIS Termux Orchestra Commander
Ultra-Lightweight Mobile Command Center
Revolutionary AI Control from Your Mobile Device

Author: OASIS Revolution Team  
License: MIT
Version: 1.0.0 - The New Civilization
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime
from typing import Dict, List, Optional

# Import our core modules
try:
    from oasis_orchestra_core import OASISOrchestra, HFSpacesManager, BusinessAutomation, TermuxController
    from hf_spaces_orchestrator import HFSpacesOrchestrator, SpaceMonitor
    from business_automation_engine import CustomerManager, RevenueEngine, BusinessIntelligence
except ImportError as e:
    print(f"⚠️  Module import error: {e}")
    print("📋 Installing required components...")

class TermuxOrchestraCommander:
    """
    Ultra-Lightweight Termux Commander
    Mobile AI Orchestra Control Center
    """
    
    def __init__(self):
        self.config_dir = os.path.expanduser("~/.oasis_termux")
        self.ensure_setup()
        self.load_configuration()
        self.initialize_components()
        
    def ensure_setup(self):
        """Ensure Termux environment is properly configured"""
        os.makedirs(self.config_dir, exist_ok=True)
        
        # Create essential directories
        essential_dirs = [
            "logs",
            "spaces", 
            "business",
            "backups"
        ]
        
        for dirname in essential_dirs:
            os.makedirs(os.path.join(self.config_dir, dirname), exist_ok=True)
        
        print(f"📱 Termux Orchestra setup complete: {self.config_dir}")
        
    def load_configuration(self):
        """Load or create configuration"""
        config_file = os.path.join(self.config_dir, "orchestra_config.json")
        
        default_config = {
            "hf_token": "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",
            "username": "elmatador0197",
            "default_spaces": [
                "oasis-ai-chat",
                "oasis-sentiment-analyzer", 
                "oasis-text-creator"
            ],
            "business_settings": {
                "auto_billing": True,
                "analytics_enabled": True,
                "monitoring_interval": 300
            },
            "termux_optimizations": {
                "battery_optimization": True,
                "network_efficiency": True,
                "storage_management": True
            }
        }
        
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    self.config = json.load(f)
            else:
                self.config = default_config
                self.save_configuration()
        except Exception as e:
            print(f"⚠️  Config load error: {e}")
            self.config = default_config
            
    def save_configuration(self):
        """Save configuration to file"""
        try:
            config_file = os.path.join(self.config_dir, "orchestra_config.json")
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"⚠️  Config save error: {e}")
    
    def initialize_components(self):
        """Initialize all orchestra components"""
        try:
            # Core Orchestra
            self.orchestra = OASISOrchestra(self.config["hf_token"])
            
            # Spaces Management  
            self.spaces_orchestrator = HFSpacesOrchestrator(self.config["hf_token"])
            self.spaces_monitor = SpaceMonitor(self.spaces_orchestrator)
            
            # Business Intelligence
            self.customer_manager = CustomerManager()
            self.revenue_engine = RevenueEngine()  
            self.business_intel = BusinessIntelligence(
                self.customer_manager, 
                self.revenue_engine
            )
            
            print("✅ All orchestra components initialized")
            
        except Exception as e:
            print(f"❌ Component initialization error: {e}")
            self.minimal_mode = True

class TermuxUI:
    """
    Ultra-Lightweight Termux User Interface
    Optimized for mobile terminals
    """
    
    def __init__(self, commander):
        self.commander = commander
        self.screen_width = self.get_terminal_width()
        
    def get_terminal_width(self) -> int:
        """Get optimal terminal width for mobile"""
        try:
            width = os.get_terminal_size().columns
            return min(width, 80)  # Limit for mobile readability
        except:
            return 60  # Safe default for mobile
    
    def clear_screen(self):
        """Clear terminal screen efficiently"""
        os.system('clear')
    
    def print_header(self):
        """Display mobile-optimized header"""
        width = self.screen_width
        
        print("🎼" + "═" * (width - 2))
        print(f"{'🌟 OASIS ORCHESTRA 🌟':^{width}}")
        print(f"{'Mobile AI Command Center':^{width}}")
        print("═" * width)
        
        # Status indicators
        status_line = f"💰${self.commander.orchestra.business_metrics['total_revenue']:.0f} "
        status_line += f"📊{self.commander.orchestra.business_metrics['api_calls']} "
        status_line += f"🏭{len(self.commander.orchestra.spaces)}"
        print(f"{status_line:^{width}}")
        print("─" * width)
    
    def show_main_menu(self):
        """Display main menu optimized for mobile"""
        options = [
            "🚀 Quick Deploy",
            "📊 Monitor Spaces", 
            "💼 Business Dashboard",
            "🔧 Manage Spaces",
            "📈 Analytics",
            "⚙️  Settings",
            "🆘 Help",
            "👋 Exit"
        ]
        
        print("\n🎯 COMMAND CENTER:")
        for i, option in enumerate(options, 1):
            print(f"  {i}. {option}")
        
        print("\n💡 Pro Tips:")
        print("  • Use 'q' for quick commands")
        print("  • Type 'h' for help anytime")
    
    def get_user_input(self, prompt: str = "🎯 Choice") -> str:
        """Get user input with mobile-friendly prompt"""
        try:
            return input(f"\n{prompt}: ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            return "exit"
    
    def show_status_bar(self, message: str, status: str = "info"):
        """Show status message with appropriate emoji"""
        emoji_map = {
            "success": "✅",
            "error": "❌", 
            "warning": "⚠️",
            "info": "💡",
            "loading": "⏳"
        }
        
        emoji = emoji_map.get(status, "💡")
        print(f"\n{emoji} {message}")
    
    def display_spaces_summary(self):
        """Display spaces in mobile-optimized format"""
        spaces = self.commander.orchestra.spaces
        
        if not spaces:
            print("\n📭 No spaces deployed yet")
            return
        
        print(f"\n🏭 ACTIVE SPACES ({len(spaces)}):")
        print("─" * self.screen_width)
        
        for space_id, info in spaces.items():
            name = space_id.split('/')[-1][:20]  # Truncate for mobile
            status = info.get('status', 'unknown')[:10]
            calls = info.get('api_calls', 0)
            revenue = info.get('revenue', 0.0)
            
            print(f"📡 {name}")
            print(f"   Status: {status} | Calls: {calls} | Rev: ${revenue:.1f}")
    
    def display_business_summary(self):
        """Display business metrics for mobile"""
        metrics = self.commander.orchestra.business_metrics
        
        print("\n💼 BUSINESS OVERVIEW:")
        print("─" * self.screen_width)
        
        print(f"💰 Revenue: ${metrics['total_revenue']:.2f}")
        print(f"📊 API Calls: {metrics['api_calls']:,}")
        print(f"👥 Customers: {metrics['active_customers']}")
        print(f"🏭 Spaces: {metrics['spaces_deployed']}")

class QuickCommands:
    """
    Quick command system for mobile efficiency
    Single-key commands for common operations
    """
    
    def __init__(self, commander):
        self.commander = commander
        self.quick_commands = {
            'd': self.quick_deploy,
            's': self.show_status,
            'm': self.monitor_spaces,
            'b': self.business_summary,
            'h': self.show_help,
            'q': self.quit_app
        }
    
    def execute(self, command: str) -> bool:
        """Execute quick command"""
        if command in self.quick_commands:
            return self.quick_commands[command]()
        return False
    
    def quick_deploy(self) -> bool:
        """Quick deploy default spaces"""
        print("\n🚀 QUICK DEPLOY: Deploying default spaces...")
        
        result = self.commander.spaces_orchestrator.deploy_business_suite(
            self.commander.config["username"]
        )
        
        if result["success"]:
            print(f"✅ Deployed {result['total_deployed']} spaces successfully!")
        else:
            print("❌ Deployment failed!")
        
        input("\nPress Enter to continue...")
        return True
    
    def show_status(self) -> bool:
        """Show quick status overview"""
        print("\n📊 QUICK STATUS:")
        
        # System status
        print("🖥️  System: Online")
        print(f"🔗 HF Token: {'Valid' if self.commander.config['hf_token'] else 'Invalid'}")
        print(f"📱 Storage: {self.get_storage_usage()}")
        
        return True
    
    def monitor_spaces(self) -> bool:
        """Quick spaces monitoring"""
        print("\n👁️  MONITORING: Checking all spaces...")
        
        spaces = self.commander.orchestra.spaces
        if not spaces:
            print("📭 No spaces to monitor")
        else:
            for space_id in spaces.keys():
                status = "🟢 Online"  # Simplified for demo
                print(f"   {space_id.split('/')[-1]}: {status}")
        
        return True
    
    def business_summary(self) -> bool:
        """Quick business summary"""
        print("\n💼 BUSINESS QUICK VIEW:")
        
        try:
            dashboard_result = self.commander.business_intel.generate_executive_dashboard()
            
            if dashboard_result["success"]:
                summary = dashboard_result["dashboard"]["executive_summary"]
                
                print(f"💰 Revenue: {summary['total_revenue']}")
                print(f"👥 Customers: {summary['total_customers']}")
                print(f"📈 Retention: {summary['customer_retention']}")
            
        except Exception as e:
            print(f"❌ Business summary error: {e}")
        
        return True
    
    def show_help(self) -> bool:
        """Show quick help"""
        print("\n🆘 QUICK COMMANDS:")
        print("   d - Quick Deploy Spaces")
        print("   s - Show System Status") 
        print("   m - Monitor All Spaces")
        print("   b - Business Summary")
        print("   h - Show This Help")
        print("   q - Quit Application")
        
        print("\n💡 FULL MENU: Enter numbers 1-8")
        
        input("\nPress Enter to continue...")
        return True
    
    def quit_app(self) -> bool:
        """Quit application"""
        print("\n👋 Shutting down OASIS Orchestra...")
        
        # Save configuration
        self.commander.save_configuration()
        
        print("💾 Configuration saved")
        print("🌟 Thank you for using OASIS Orchestra!")
        
        return False  # Exit main loop
    
    def get_storage_usage(self) -> str:
        """Get storage usage information"""
        try:
            import shutil
            usage = shutil.disk_usage(self.commander.config_dir)
            free_gb = usage.free // (1024**3)
            return f"{free_gb}GB free"
        except:
            return "Unknown"

class MobileOrchestra:
    """
    Main Mobile Orchestra Application
    Coordinates all components for optimal mobile experience
    """
    
    def __init__(self):
        self.commander = TermuxOrchestraCommander()
        self.ui = TermuxUI(self.commander)  
        self.quick_cmd = QuickCommands(self.commander)
        
    def run(self):
        """Main application loop"""
        self.ui.show_status_bar("OASIS Orchestra starting up...", "loading")
        time.sleep(1)
        
        while True:
            try:
                self.ui.clear_screen()
                self.ui.print_header()
                self.ui.show_main_menu()
                
                choice = self.ui.get_user_input()
                
                # Check for quick commands first
                if len(choice) == 1 and choice in self.quick_cmd.quick_commands:
                    if not self.quick_cmd.execute(choice):
                        break  # Quit command
                    continue
                
                # Handle menu choices
                if choice in ['1', 'deploy', 'quick']:
                    self.handle_quick_deploy()
                elif choice in ['2', 'monitor', 'status']:
                    self.handle_monitor_spaces()
                elif choice in ['3', 'business', 'dashboard']:
                    self.handle_business_dashboard()
                elif choice in ['4', 'manage', 'spaces']:
                    self.handle_manage_spaces()
                elif choice in ['5', 'analytics', 'stats']:
                    self.handle_analytics()
                elif choice in ['6', 'settings', 'config']:
                    self.handle_settings()
                elif choice in ['7', 'help', '?']:
                    self.handle_help()
                elif choice in ['8', '0', 'exit', 'quit', 'q']:
                    if self.quick_cmd.quit_app():
                        continue
                    break
                else:
                    self.ui.show_status_bar("Invalid option! Try again or 'h' for help", "warning")
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                print("\n\n👋 Orchestra interrupted by user")
                break
            except Exception as e:
                self.ui.show_status_bar(f"Error: {e}", "error")
                time.sleep(2)
    
    def handle_quick_deploy(self):
        """Handle quick deployment"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n🚀 QUICK DEPLOY MODE")
        print("═" * self.ui.screen_width)
        
        confirm = self.ui.get_user_input("Deploy default AI spaces? (y/n)")
        
        if confirm.startswith('y'):
            self.quick_cmd.quick_deploy()
        else:
            print("❌ Deployment cancelled")
            time.sleep(1)
    
    def handle_monitor_spaces(self):
        """Handle spaces monitoring"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n📊 SPACES MONITORING")
        print("═" * self.ui.screen_width)
        
        self.ui.display_spaces_summary()
        
        print("\n🔍 Real-time Status:")
        self.quick_cmd.monitor_spaces()
        
        input("\nPress Enter to return to menu...")
    
    def handle_business_dashboard(self):
        """Handle business dashboard"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n💼 BUSINESS DASHBOARD")
        print("═" * self.ui.screen_width)
        
        self.ui.display_business_summary()
        
        print("\n📈 Detailed Analytics:")
        self.quick_cmd.business_summary()
        
        input("\nPress Enter to return to menu...")
    
    def handle_manage_spaces(self):
        """Handle space management"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n🔧 SPACE MANAGEMENT")
        print("═" * self.ui.screen_width)
        
        spaces = self.commander.orchestra.spaces
        
        if not spaces:
            print("📭 No spaces to manage")
            print("💡 Use 'Quick Deploy' to create spaces first")
        else:
            print("Available actions:")
            print("1. View space details")
            print("2. Update space configuration") 
            print("3. Scale space resources")
            print("4. Delete space")
            
            choice = self.ui.get_user_input("Select action (1-4)")
            # Implementation would go here
            
        input("\nPress Enter to return to menu...")
    
    def handle_analytics(self):
        """Handle analytics dashboard"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n📈 ANALYTICS CENTER")
        print("═" * self.ui.screen_width)
        
        try:
            # Get revenue forecast
            forecast = self.commander.revenue_engine.generate_revenue_forecast(30)
            
            if forecast["success"]:
                print("🔮 30-DAY FORECAST:")
                forecasts = forecast["forecast"]["forecasts"]
                
                for scenario, amount in forecasts.items():
                    print(f"   {scenario.title()}: {amount}")
            
            print("\n📊 GROWTH METRICS:")
            analytics = self.commander.revenue_engine.get_revenue_analytics()
            
            if analytics["success"]:
                growth = analytics["analytics"]["growth_metrics"]
                print(f"   Monthly Growth: {growth.get('month_over_month', 'N/A')}")
                print(f"   Trend: {growth.get('trend', 'N/A')}")
            
        except Exception as e:
            print(f"❌ Analytics error: {e}")
        
        input("\nPress Enter to return to menu...")
    
    def handle_settings(self):
        """Handle settings configuration"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n⚙️ ORCHESTRA SETTINGS")
        print("═" * self.ui.screen_width)
        
        print("Current Configuration:")
        print(f"🔑 HF Token: {'Set' if self.commander.config['hf_token'] else 'Not Set'}")
        print(f"👤 Username: {self.commander.config['username']}")
        print(f"🏭 Default Spaces: {len(self.commander.config['default_spaces'])}")
        
        print("\nSettings Options:")
        print("1. Update HF Token")
        print("2. Change Username")
        print("3. Configure Default Spaces")
        print("4. Business Settings")
        print("5. Termux Optimizations")
        
        choice = self.ui.get_user_input("Select option (1-5)")
        
        if choice == '1':
            new_token = input("Enter new HF token: ").strip()
            if new_token:
                self.commander.config['hf_token'] = new_token
                self.commander.save_configuration()
                print("✅ HF Token updated")
        
        # Other settings implementation would go here
        
        input("\nPress Enter to return to menu...")
    
    def handle_help(self):
        """Handle help system"""
        self.ui.clear_screen()
        self.ui.print_header()
        
        print("\n🆘 OASIS ORCHESTRA HELP")
        print("═" * self.ui.screen_width)
        
        help_sections = {
            "Quick Commands": [
                "d - Quick Deploy Spaces",
                "s - System Status",
                "m - Monitor Spaces", 
                "b - Business Summary",
                "h - Show Help",
                "q - Quit Application"
            ],
            "Main Features": [
                "Deploy AI spaces on Hugging Face",
                "Monitor space performance",
                "Track revenue and customers",
                "Scale business operations",
                "Mobile-optimized interface"
            ],
            "Getting Started": [
                "1. Set your HF token in Settings",
                "2. Use Quick Deploy to create spaces",
                "3. Monitor performance in real-time",
                "4. Track business metrics",
                "5. Scale as you grow"
            ]
        }
        
        for section, items in help_sections.items():
            print(f"\n🔹 {section.upper()}:")
            for item in items:
                print(f"   • {item}")
        
        input("\nPress Enter to return to menu...")

def main():
    """Main entry point for Termux Orchestra Commander"""
    try:
        print("🎼 Starting OASIS Termux Orchestra...")
        print("🚀 The New Civilization - Mobile AI Revolution")
        
        # Check Termux environment
        if 'com.termux' not in os.environ.get('PREFIX', ''):
            print("\n⚠️  Warning: Not detected as Termux environment")
            print("🔧 Orchestra will run in compatibility mode")
        
        # Initialize and run
        app = MobileOrchestra()
        app.run()
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        print("💡 Try running setup script first")
    
    finally:
        print("\n🌟 OASIS Orchestra shutdown complete")
        print("👋 Thank you for using The New Civilization!")

if __name__ == "__main__":
    main()