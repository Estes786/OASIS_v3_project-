# 🚀 OASIS v3 - QUICK START GUIDE

## ⚡ **30-SECOND DEPLOYMENT**

### 1. **Deploy to HF Spaces** (2 minutes)
```bash
# Make deployment script executable
chmod +x deploy.sh

# Run automated deployment
./deploy.sh

# Follow prompts:
# - Enter HF Space name: your-username/oasis-v3
# - Enter HF Token: hf_xxxxx...
# - Select visibility: 1 (public)
```

### 2. **Setup Termux Orchestrator** (1 minute)
```bash
# In Termux
pkg update && pkg install python curl
pip install requests

# Download orchestrator
curl -o termux_orchestrator.py https://your-space-name.hf.space/file/examples/termux_orchestrator.py

# Run orchestrator
python termux_orchestrator.py
```

### 3. **Test Integration** (30 seconds)
```bash
# Test sentiment analysis
curl -X POST "https://your-space-name.hf.space/api/v3/sentiment" \
     -H "Content-Type: application/json" \
     -d '{"text": "OASIS v3 is amazing!", "model": "roberta"}'
```

---

## 🎯 **INSTANT RESULTS**

After deployment, you get:

### ✅ **Working Features**
- **Multi-Modal AI Hub**: Sentiment, text generation, image analysis
- **REST API**: Production-ready endpoints with OpenAPI docs
- **Web Interface**: Beautiful Gradio interface with real-time stats
- **Termux Integration**: Ultra-lightweight orchestrator (<5MB)
- **Revenue Tracking**: Built-in monetization analytics

### 🔗 **Live URLs**
- **Main App**: `https://your-space-name.hf.space`
- **API Docs**: `https://your-space-name.hf.space/docs`
- **Stats**: `https://your-space-name.hf.space/api/v3/stats`

---

## 📱 **TERMUX ORCHESTRATOR USAGE**

### **Interactive Mode**
```python
python termux_orchestrator.py

# Menu appears:
# 1. 🎭 Sentiment Analysis
# 2. ✨ Text Generation  
# 3. 📊 Batch Processing
# 4. 📈 System Stats
# 5. 🚪 Exit
```

### **Programmatic Usage**
```python
from termux_orchestrator import OASISTermuxOrchestrator

# Initialize
orchestrator = OASISTermuxOrchestrator("https://your-space-name.hf.space")

# Analyze sentiment
result = orchestrator.analyze_sentiment("I love this system!")
print(result["sentiment"])  # POSITIVE

# Generate text
result = orchestrator.generate_text("The future of AI is")
print(result["generated_text"])
```

---

## 💰 **REVENUE GENERATION**

### **Built-in Monetization**
- ✅ **Request Tracking**: Every API call monitored
- ✅ **Revenue Calculation**: Automatic pricing per service type
- ✅ **Analytics Dashboard**: Real-time revenue metrics
- ✅ **Usage Statistics**: Detailed performance analytics

### **Pricing Structure** (customizable)
```python
RATES = {
    "sentiment_analysis": $0.01,    # per request
    "text_generation": $0.05,      # per request
    "image_analysis": $0.03,       # per request
    "batch_processing": $0.008     # per item
}
```

---

## 🧪 **API TESTING**

### **Quick Tests**
```bash
# 1. Health check
curl https://your-space-name.hf.space/

# 2. Sentiment analysis
curl -X POST "https://your-space-name.hf.space/api/v3/sentiment" \
     -H "Content-Type: application/json" \
     -d '{"text": "Amazing technology!", "model": "roberta"}'

# 3. Text generation
curl -X POST "https://your-space-name.hf.space/api/v3/generate" \
     -H "Content-Type: application/json" \
     -d '{"prompt": "The future is", "max_length": 100}'

# 4. System stats
curl https://your-space-name.hf.space/api/v3/stats
```

---

## 🔧 **TROUBLESHOOTING**

### **Common Issues & Solutions**

**1. Space Not Building**
```bash
# Check build logs in HF Spaces
# Common fix: Wait 2-3 minutes for dependencies to install
```

**2. Termux Connection Failed**
```bash
# Verify space URL
curl https://your-space-name.hf.space/

# Check internet connection
ping google.com
```

**3. API Errors**
```bash
# Check space status
curl -I https://your-space-name.hf.space/

# Test with minimal request
curl -X POST "https://your-space-name.hf.space/api/v3/sentiment" \
     -H "Content-Type: application/json" \
     -d '{"text": "test"}'
```

---

## 🌟 **ADVANCED USAGE**

### **Custom Model Configuration**
```python
# Edit app.py to add custom models
class CustomSentimentEngine(SentimentAnalysisEngine):
    def load_models(self):
        super().load_models()
        self.models['custom'] = pipeline(
            "sentiment-analysis", 
            model="your-custom-model"
        )
```

### **Batch Processing**
```python
# Process multiple texts efficiently
texts = [
    "Text 1 to analyze",
    "Text 2 to analyze", 
    "Text 3 to analyze"
]

results = orchestrator.batch_sentiment_analysis(texts)
for result in results:
    print(f"{result['sentiment']}: {result['confidence_percentage']}%")
```

### **Revenue Optimization**
```python
# Monitor high-value endpoints
stats = orchestrator.get_system_stats()
revenue = stats['revenue_stats']['revenue_generated']
print(f"Today's revenue: ${revenue:.2f}")
```

---

## 📊 **PERFORMANCE BENCHMARKS**

### **Response Times** (HF Spaces CPU-basic)
- **Sentiment Analysis**: ~200ms
- **Text Generation**: ~1.5s (150 tokens)
- **Image Classification**: ~300ms
- **API Throughput**: 100+ req/min
- **Cold Start**: ~30s initial load

### **Resource Usage**
- **Termux Footprint**: <5MB (Python + requests)
- **HF Spaces RAM**: ~2GB peak usage
- **Model Loading**: One-time 30s setup

---

## 🔄 **INTEGRATION EXAMPLES**

### **Web Application**
```javascript
// Frontend integration
async function analyzeSentiment(text) {
    const response = await fetch('https://your-space-name.hf.space/api/v3/sentiment', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({text, model: 'roberta'})
    });
    return await response.json();
}
```

### **Python Application**
```python
import requests

def analyze_text(text):
    response = requests.post(
        'https://your-space-name.hf.space/api/v3/sentiment',
        json={'text': text, 'model': 'roberta'}
    )
    return response.json()
```

### **Mobile App (React Native)**
```javascript
const analyzeText = async (text) => {
    try {
        const response = await fetch('https://your-space-name.hf.space/api/v3/sentiment', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({text, model: 'roberta'})
        });
        return await response.json();
    } catch (error) {
        console.error('Analysis failed:', error);
    }
};
```

---

## 🎯 **SUCCESS CHECKLIST**

### **After Deployment** ✅
- [ ] HF Space builds successfully (check build logs)
- [ ] Main app loads at your space URL
- [ ] API endpoints respond to test requests
- [ ] Termux orchestrator connects successfully
- [ ] Revenue tracking shows incoming requests

### **Production Ready** ✅
- [ ] Custom domain configured (optional)
- [ ] Error monitoring set up
- [ ] Rate limiting configured
- [ ] Analytics dashboard reviewed
- [ ] Backup/recovery plan implemented

---

## 🚀 **NEXT STEPS**

1. **Scale Up**: Upgrade to GPU spaces for faster processing
2. **Customize**: Add your own AI models and endpoints
3. **Monetize**: Implement subscription or pay-per-use billing
4. **Integrate**: Connect with existing applications and workflows
5. **Monitor**: Set up alerts for performance and revenue metrics

---

## 📞 **SUPPORT**

- **Documentation**: README.md for detailed information
- **Examples**: `/examples/` directory with integration samples
- **Issues**: GitHub issues for bug reports
- **Community**: HF Spaces discussions for community support

---

<div align="center">

**🎯 OASIS v3 - Ready in 3 Minutes!**

*Ultra-Lightweight AI Superintelligence Ecosystem*

[![Deploy to HF Spaces](https://img.shields.io/badge/Deploy-HF%20Spaces-orange)](https://huggingface.co/new-space)

</div>