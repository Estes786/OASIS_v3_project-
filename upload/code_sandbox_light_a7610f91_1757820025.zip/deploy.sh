#!/bin/bash

# OASIS v3 - HF Spaces Deployment Script
# Ultra-Lightweight AI Superintelligence Ecosystem
# Automated deployment to Hugging Face Spaces

set -e

echo "🎯 OASIS v3 - HUGGING FACE SPACES DEPLOYMENT"
echo "=============================================="

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if git is installed
if ! command -v git &> /dev/null; then
    print_error "Git is not installed. Please install git first."
    exit 1
fi

# Get deployment configuration
print_status "Configuring deployment parameters..."

# HF Space name
read -p "Enter your HF Space name (e.g., username/oasis-v3): " HF_SPACE_NAME
if [ -z "$HF_SPACE_NAME" ]; then
    print_error "HF Space name is required!"
    exit 1
fi

# HF Token
read -s -p "Enter your HF Token (will be hidden): " HF_TOKEN
echo ""
if [ -z "$HF_TOKEN" ]; then
    print_error "HF Token is required!"
    exit 1
fi

# Space visibility
echo "Select space visibility:"
echo "1. Public (recommended for OASIS v3)"
echo "2. Private"
read -p "Enter choice (1-2): " VISIBILITY_CHOICE

case $VISIBILITY_CHOICE in
    1) VISIBILITY="public" ;;
    2) VISIBILITY="private" ;;
    *) VISIBILITY="public" ;;
esac

print_status "Configuration complete:"
print_status "  Space: $HF_SPACE_NAME"
print_status "  Visibility: $VISIBILITY"

# Create temporary deployment directory
DEPLOY_DIR="/tmp/oasis_v3_deploy_$(date +%s)"
mkdir -p "$DEPLOY_DIR"
print_status "Created deployment directory: $DEPLOY_DIR"

# Copy files to deployment directory
print_status "Preparing deployment files..."

cp app.py "$DEPLOY_DIR/"
cp requirements.txt "$DEPLOY_DIR/"
cp README.md "$DEPLOY_DIR/"
cp packages.txt "$DEPLOY_DIR/"
cp Dockerfile "$DEPLOY_DIR/"
cp config.json "$DEPLOY_DIR/"

# Copy examples
mkdir -p "$DEPLOY_DIR/examples"
cp examples/* "$DEPLOY_DIR/examples/" 2>/dev/null || true

print_success "Files copied successfully"

# Create HF Spaces configuration
print_status "Creating HF Spaces configuration..."

cat > "$DEPLOY_DIR/.gitignore" << EOF
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Environment
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db
EOF

# Create spaces configuration from config.json
if [ -f "$DEPLOY_DIR/config.json" ]; then
    print_status "Using existing config.json for space configuration"
else
    print_warning "config.json not found, creating default configuration"
    
    cat > "$DEPLOY_DIR/config.json" << EOF
{
  "title": "OASIS v3 - AI Superintelligence Hub",
  "emoji": "🎯",
  "colorFrom": "blue",
  "colorTo": "purple",
  "sdk": "gradio",
  "sdk_version": "4.44.0",
  "app_file": "app.py",
  "pinned": false,
  "license": "mit"
}
EOF
fi

# Initialize git repository
print_status "Initializing git repository..."
cd "$DEPLOY_DIR"

git init
git config user.name "OASIS v3 Deployer"
git config user.email "deploy@oasis-v3.ai"

# Add all files
git add .
git commit -m "🎯 Initial OASIS v3 deployment

- Ultra-Lightweight AI Superintelligence Ecosystem
- Multi-modal AI capabilities (sentiment, text, image)
- API-first architecture with FastAPI
- Production-ready with comprehensive monitoring
- Termux orchestrator compatibility
- Revenue tracking and analytics

Features:
✅ Sentiment Analysis (RoBERTa, BERT, DistilBERT)
✅ Text Generation (GPT-2, T5)
✅ Image Classification (ResNet-50)
✅ Batch processing capabilities
✅ Real-time performance monitoring
✅ Comprehensive API documentation
✅ Error handling and retry logic
✅ CORS support for web integration

Architecture: Termux Command Center + HF Spaces Backend
Footprint: <5MB orchestrator + Unlimited cloud processing"

print_success "Git repository initialized and committed"

# Deploy to HF Spaces
print_status "Deploying to Hugging Face Spaces..."

# Set up HF remote
HF_REPO_URL="https://huggingface.co/spaces/$HF_SPACE_NAME"
git remote add origin "https://oauth2:$HF_TOKEN@huggingface.co/spaces/$HF_SPACE_NAME"

print_status "Remote repository configured: $HF_REPO_URL"

# Push to HF Spaces
print_status "Pushing to HF Spaces..."
if git push -u origin main; then
    print_success "Deployment successful!"
else
    print_warning "Push failed, trying to create new space..."
    
    # Try to create the space first (this requires HF CLI or API call)
    print_status "Creating new HF Space..."
    
    # Create space using git push with force (for new repos)
    git push -u origin main --force
    
    if [ $? -eq 0 ]; then
        print_success "New space created and deployed successfully!"
    else
        print_error "Deployment failed. Please check your HF token and space name."
        print_error "You may need to create the space manually at https://huggingface.co/new-space"
        exit 1
    fi
fi

# Cleanup
print_status "Cleaning up temporary files..."
cd /
rm -rf "$DEPLOY_DIR"

print_success "Cleanup completed"

# Final instructions
echo ""
echo "🎉 DEPLOYMENT COMPLETED SUCCESSFULLY!"
echo "======================================"
echo ""
print_success "Your OASIS v3 HF Space is now live at:"
print_success "$HF_REPO_URL"
echo ""
print_status "Next steps:"
echo "  1. 🔗 Visit your HF Space URL to verify deployment"
echo "  2. 📱 Configure Termux orchestrator with your space URL"
echo "  3. 🧪 Test API endpoints using examples/curl_examples.sh"
echo "  4. 🐍 Use examples/python_client.py for Python integration"
echo "  5. 💰 Monitor revenue generation in the Stats tab"
echo ""
print_status "Termux orchestrator setup:"
echo "  pkg install python"
echo "  pip install requests"
echo "  wget https://huggingface.co/spaces/$HF_SPACE_NAME/raw/main/examples/termux_orchestrator.py"
echo "  python termux_orchestrator.py"
echo ""
print_status "API Base URL: $HF_REPO_URL/api/v3"
echo ""
print_success "🎯 OASIS v3 is ready for production use!"
echo ""
print_warning "Note: It may take a few minutes for your space to build and become available."
print_warning "Check the build logs on your HF Space page if there are any issues."