#!/bin/bash

# OASIS v3 - cURL API Examples
# Ultra-Lightweight AI Superintelligence Ecosystem
# Complete API testing and integration examples

# Configuration
HF_SPACE_URL="https://your-space-name.hf.space"
API_BASE="${HF_SPACE_URL}/api/v3"

echo "🎯 OASIS v3 - cURL API Examples"
echo "================================="
echo "🔗 HF Space URL: $HF_SPACE_URL"
echo "📡 API Base: $API_BASE"
echo ""

# Function to print section headers
print_section() {
    echo ""
    echo "$(tput setaf 6)$1$(tput sgr0)"
    echo "$(printf '=%.0s' {1..50})"
}

# Function to print results
print_result() {
    echo "📊 Response:"
    echo "$1" | jq '.' 2>/dev/null || echo "$1"
    echo ""
}

# Test 1: Health Check
print_section "🔍 1. HEALTH CHECK"
echo "Testing basic connectivity..."
response=$(curl -s -w "HTTPSTATUS:%{http_code}" "$HF_SPACE_URL/")
http_code=$(echo $response | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
response_body=$(echo $response | sed -e 's/HTTPSTATUS\:.*//g')

if [ $http_code -eq 200 ]; then
    echo "✅ HF Space is ONLINE"
    print_result "$response_body"
else
    echo "❌ Health check failed (HTTP $http_code)"
    print_result "$response_body"
fi

# Test 2: Sentiment Analysis - Basic
print_section "🎭 2. SENTIMENT ANALYSIS - BASIC"
echo "Analyzing: 'I love this OASIS system!'"

response=$(curl -s -X POST "$API_BASE/sentiment" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "I love this OASIS system!",
    "model": "roberta"
  }')

print_result "$response"

# Test 3: Sentiment Analysis - Different Models
print_section "🎭 3. SENTIMENT ANALYSIS - MODEL COMPARISON"

models=("roberta" "bert" "distilbert")
test_text="This AI technology is absolutely revolutionary and game-changing!"

for model in "${models[@]}"; do
    echo "🤖 Testing with model: $model"
    
    response=$(curl -s -X POST "$API_BASE/sentiment" \
      -H "Content-Type: application/json" \
      -d "{
        \"text\": \"$test_text\",
        \"model\": \"$model\"
      }")
    
    # Extract key info
    sentiment=$(echo $response | jq -r '.sentiment // "N/A"')
    confidence=$(echo $response | jq -r '.confidence_percentage // "N/A"')
    processing_time=$(echo $response | jq -r '.processing_time // "N/A"')
    
    echo "   Sentiment: $sentiment ($confidence%) | Time: ${processing_time}s"
done
echo ""

# Test 4: Text Generation
print_section "✨ 4. TEXT GENERATION"
echo "Generating text from prompt: 'The future of artificial intelligence'"

response=$(curl -s -X POST "$API_BASE/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "The future of artificial intelligence",
    "max_length": 150,
    "model": "gpt2"
  }')

print_result "$response"

# Test 5: Text Generation - Different Lengths
print_section "✨ 5. TEXT GENERATION - LENGTH VARIATIONS"

lengths=(50 100 200)
prompt="In the year 2030, technology will"

for length in "${lengths[@]}"; do
    echo "📏 Generating with max_length: $length"
    
    response=$(curl -s -X POST "$API_BASE/generate" \
      -H "Content-Type: application/json" \
      -d "{
        \"prompt\": \"$prompt\",
        \"max_length\": $length,
        \"model\": \"gpt2\"
      }")
    
    generated_text=$(echo $response | jq -r '.generated_text // "Error"')
    word_count=$(echo $response | jq -r '.word_count // "N/A"')
    processing_time=$(echo $response | jq -r '.processing_time // "N/A"')
    
    echo "   Words: $word_count | Time: ${processing_time}s"
    echo "   Text: ${generated_text:0:100}..."
    echo ""
done

# Test 6: System Statistics
print_section "📈 6. SYSTEM STATISTICS"
echo "Fetching real-time system performance metrics..."

response=$(curl -s "$API_BASE/stats")
print_result "$response"

# Test 7: Error Handling Tests
print_section "🚨 7. ERROR HANDLING TESTS"

echo "🧪 Test 7.1: Empty text sentiment analysis"
response=$(curl -s -X POST "$API_BASE/sentiment" \
  -H "Content-Type: application/json" \
  -d '{"text": "", "model": "roberta"}')
print_result "$response"

echo "🧪 Test 7.2: Invalid model name"
response=$(curl -s -X POST "$API_BASE/sentiment" \
  -H "Content-Type: application/json" \
  -d '{"text": "Test text", "model": "invalid_model"}')
print_result "$response"

echo "🧪 Test 7.3: Missing required fields"
response=$(curl -s -X POST "$API_BASE/sentiment" \
  -H "Content-Type: application/json" \
  -d '{"model": "roberta"}')
print_result "$response"

# Test 8: Performance Benchmarking
print_section "⚡ 8. PERFORMANCE BENCHMARKING"

echo "🏃‍♂️ Running 5 consecutive sentiment analyses for latency testing..."

total_time=0
successful_requests=0

for i in {1..5}; do
    echo -n "Request $i... "
    
    start_time=$(date +%s.%N)
    
    response=$(curl -s -X POST "$API_BASE/sentiment" \
      -H "Content-Type: application/json" \
      -d '{
        "text": "Performance test request number '$i'",
        "model": "distilbert"
      }')
    
    end_time=$(date +%s.%N)
    request_time=$(echo "$end_time - $start_time" | bc)
    
    # Check if request was successful
    sentiment=$(echo $response | jq -r '.sentiment // ""')
    if [ -n "$sentiment" ]; then
        echo "✅ ${request_time}s"
        total_time=$(echo "$total_time + $request_time" | bc)
        successful_requests=$((successful_requests + 1))
    else
        echo "❌ Failed"
    fi
done

if [ $successful_requests -gt 0 ]; then
    average_time=$(echo "scale=3; $total_time / $successful_requests" | bc)
    echo ""
    echo "📊 Performance Results:"
    echo "   Successful requests: $successful_requests/5"
    echo "   Average response time: ${average_time}s"
    echo "   Total time: ${total_time}s"
fi

# Test 9: Batch Processing Simulation
print_section "📊 9. BATCH PROCESSING SIMULATION"

echo "🔄 Simulating batch sentiment analysis (5 texts)..."

texts=(
    "I absolutely love this technology!"
    "This could be better implemented."
    "Not sure what to think about this."
    "This is the most amazing AI system ever!"
    "Completely disappointed with the results."
)

echo "📝 Processing texts:"
for i in "${!texts[@]}"; do
    echo "   $((i+1)). ${texts[i]}"
done
echo ""

echo "🚀 Starting batch processing..."

for i in "${!texts[@]}"; do
    text="${texts[i]}"
    echo -n "Processing text $((i+1))... "
    
    response=$(curl -s -X POST "$API_BASE/sentiment" \
      -H "Content-Type: application/json" \
      -d "{
        \"text\": \"$text\",
        \"model\": \"distilbert\"
      }")
    
    sentiment=$(echo $response | jq -r '.sentiment // "Error"')
    confidence=$(echo $response | jq -r '.confidence_percentage // "N/A"')
    
    echo "$sentiment ($confidence%)"
    
    # Small delay to avoid overwhelming the server
    sleep 0.2
done

# Test 10: API Response Time Analysis
print_section "📊 10. API RESPONSE TIME ANALYSIS"

echo "⏱️ Measuring response times for different endpoints..."

# Sentiment Analysis
echo -n "🎭 Sentiment Analysis... "
start=$(date +%s.%N)
curl -s -X POST "$API_BASE/sentiment" \
  -H "Content-Type: application/json" \
  -d '{"text": "Response time test", "model": "roberta"}' > /dev/null
end=$(date +%s.%N)
sentiment_time=$(echo "$end - $start" | bc)
echo "${sentiment_time}s"

# Text Generation
echo -n "✨ Text Generation... "
start=$(date +%s.%N)
curl -s -X POST "$API_BASE/generate" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Speed test", "max_length": 50, "model": "gpt2"}' > /dev/null
end=$(date +%s.%N)
generation_time=$(echo "$end - $start" | bc)
echo "${generation_time}s"

# System Stats
echo -n "📈 System Stats... "
start=$(date +%s.%N)
curl -s "$API_BASE/stats" > /dev/null
end=$(date +%s.%N)
stats_time=$(echo "$end - $start" | bc)
echo "${stats_time}s"

echo ""
echo "📊 Response Time Summary:"
echo "   Sentiment Analysis: ${sentiment_time}s"
echo "   Text Generation: ${generation_time}s"
echo "   System Stats: ${stats_time}s"

# Final Summary
print_section "📋 TESTING COMPLETE"

echo "✅ All API endpoint tests completed!"
echo ""
echo "🎯 OASIS v3 API Integration Examples:"
echo ""
echo "📱 Termux Integration:"
echo "   pkg install curl jq"
echo "   bash curl_examples.sh"
echo ""
echo "🐍 Python Integration:"
echo "   pip install requests"
echo "   python python_client.py"
echo ""
echo "🌐 Web Integration:"
echo "   Use fetch() API with these same endpoints"
echo ""
echo "🚀 Production Deployment:"
echo "   - Use proper error handling"
echo "   - Implement retry logic"
echo "   - Add request timeout"
echo "   - Monitor response times"
echo ""
echo "📚 Full documentation: README.md"
echo ""
echo "🎯 OASIS v3 - Ready for production orchestration!"