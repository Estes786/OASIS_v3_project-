#!/usr/bin/env python3
"""
OASIS v3 - Python Client Library
Production-ready client for integrating with OASIS HF Spaces backend

This client can be used in any Python environment:
- Desktop applications
- Web applications  
- Mobile apps (via Kivy/BeeWare)
- IoT devices
- Jupyter notebooks
- Automation scripts

Usage:
  pip install requests
  python python_client.py
"""

import requests
import json
import time
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
import asyncio
import aiohttp
from dataclasses import dataclass


@dataclass
class OASISResponse:
    """Standardized response object for OASIS API calls"""
    success: bool
    data: Dict[str, Any]
    error: Optional[str] = None
    response_time: Optional[float] = None
    timestamp: Optional[str] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()


class OASISClient:
    """Production-ready Python client for OASIS v3 API"""
    
    def __init__(self, base_url: str, timeout: int = 30, max_retries: int = 3):
        """
        Initialize OASIS client
        
        Args:
            base_url: HF Spaces URL (e.g., "https://your-space-name.hf.space")
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts for failed requests
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Setup session with optimized settings
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "OASIS-v3-Python-Client/1.0",
            "Accept": "application/json"
        })
        
        # Client statistics
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "average_response_time": 0.0,
            "services_used": {
                "sentiment": 0,
                "generation": 0,
                "image": 0,
                "stats": 0
            }
        }
    
    def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None, 
                     service_type: str = "unknown") -> OASISResponse:
        """
        Make HTTP request with retry logic and error handling
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            data: Request payload
            service_type: Service type for statistics
            
        Returns:
            OASISResponse object
        """
        url = f"{self.base_url}{endpoint}"
        start_time = time.time()
        
        self.stats["total_requests"] += 1
        self.stats["services_used"][service_type] += 1
        
        for attempt in range(self.max_retries):
            try:
                if method.upper() == "GET":
                    response = self.session.get(url, timeout=self.timeout)
                elif method.upper() == "POST":
                    response = self.session.post(url, json=data, timeout=self.timeout)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")
                
                response.raise_for_status()
                
                # Calculate response time
                response_time = time.time() - start_time
                
                # Update statistics
                self.stats["successful_requests"] += 1
                self._update_average_response_time(response_time)
                
                # Parse response
                try:
                    result_data = response.json()
                except json.JSONDecodeError:
                    result_data = {"message": "Non-JSON response", "content": response.text}
                
                return OASISResponse(
                    success=True,
                    data=result_data,
                    response_time=response_time
                )
                
            except requests.exceptions.RequestException as e:
                if attempt == self.max_retries - 1:  # Last attempt
                    self.stats["failed_requests"] += 1
                    
                    return OASISResponse(
                        success=False,
                        data={},
                        error=f"Request failed after {self.max_retries} attempts: {str(e)}",
                        response_time=time.time() - start_time
                    )
                else:
                    # Wait before retrying (exponential backoff)
                    time.sleep(2 ** attempt)
            
            except Exception as e:
                self.stats["failed_requests"] += 1
                
                return OASISResponse(
                    success=False,
                    data={},
                    error=f"Unexpected error: {str(e)}",
                    response_time=time.time() - start_time
                )
    
    def _update_average_response_time(self, new_time: float):
        """Update average response time with new measurement"""
        total_successful = self.stats["successful_requests"]
        current_avg = self.stats["average_response_time"]
        
        # Calculate running average
        self.stats["average_response_time"] = (
            (current_avg * (total_successful - 1) + new_time) / total_successful
        )
    
    def analyze_sentiment(self, text: str, model: str = "roberta") -> OASISResponse:
        """
        Analyze sentiment of given text
        
        Args:
            text: Text to analyze
            model: Model to use (roberta, bert, distilbert)
            
        Returns:
            OASISResponse with sentiment analysis results
        """
        data = {
            "text": text,
            "model": model
        }
        
        return self._make_request("POST", "/api/v3/sentiment", data, "sentiment")
    
    def generate_text(self, prompt: str, max_length: int = 150, model: str = "gpt2") -> OASISResponse:
        """
        Generate text from prompt
        
        Args:
            prompt: Generation prompt
            max_length: Maximum length of generated text
            model: Model to use (gpt2, t5)
            
        Returns:
            OASISResponse with generated text
        """
        data = {
            "prompt": prompt,
            "max_length": max_length,
            "model": model
        }
        
        return self._make_request("POST", "/api/v3/generate", data, "generation")
    
    def get_system_stats(self) -> OASISResponse:
        """
        Get system statistics from OASIS backend
        
        Returns:
            OASISResponse with system statistics
        """
        return self._make_request("GET", "/api/v3/stats", service_type="stats")
    
    def health_check(self) -> OASISResponse:
        """
        Check if OASIS backend is healthy and responsive
        
        Returns:
            OASISResponse with health status
        """
        return self._make_request("GET", "/", service_type="health")
    
    def batch_sentiment_analysis(self, texts: List[str], model: str = "distilbert", 
                                delay: float = 0.1) -> List[OASISResponse]:
        """
        Perform batch sentiment analysis on multiple texts
        
        Args:
            texts: List of texts to analyze
            model: Model to use for analysis
            delay: Delay between requests to avoid rate limiting
            
        Returns:
            List of OASISResponse objects
        """
        results = []
        
        for text in texts:
            response = self.analyze_sentiment(text.strip(), model)
            results.append(response)
            
            if delay > 0:
                time.sleep(delay)
        
        return results
    
    def get_client_stats(self) -> Dict[str, Any]:
        """
        Get client-side statistics
        
        Returns:
            Dictionary with client statistics
        """
        success_rate = (
            (self.stats["successful_requests"] / max(self.stats["total_requests"], 1)) * 100
        )
        
        return {
            "client_info": {
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self.max_retries
            },
            "request_stats": {
                "total_requests": self.stats["total_requests"],
                "successful_requests": self.stats["successful_requests"],
                "failed_requests": self.stats["failed_requests"],
                "success_rate_percentage": round(success_rate, 2),
                "average_response_time": round(self.stats["average_response_time"], 3)
            },
            "services_used": self.stats["services_used"]
        }


class AsyncOASISClient:
    """Async version of OASIS client for high-performance applications"""
    
    def __init__(self, base_url: str, timeout: int = 30, max_retries: int = 3):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0
        }
    
    async def _make_async_request(self, method: str, endpoint: str, 
                                 data: Optional[Dict] = None) -> OASISResponse:
        """Make async HTTP request"""
        url = f"{self.base_url}{endpoint}"
        start_time = time.time()
        
        self.stats["total_requests"] += 1
        
        timeout = aiohttp.ClientTimeout(total=self.timeout)
        
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                if method.upper() == "GET":
                    async with session.get(url) as response:
                        response.raise_for_status()
                        result_data = await response.json()
                elif method.upper() == "POST":
                    async with session.post(url, json=data) as response:
                        response.raise_for_status()
                        result_data = await response.json()
                else:
                    raise ValueError(f"Unsupported method: {method}")
            
            self.stats["successful_requests"] += 1
            
            return OASISResponse(
                success=True,
                data=result_data,
                response_time=time.time() - start_time
            )
            
        except Exception as e:
            self.stats["failed_requests"] += 1
            
            return OASISResponse(
                success=False,
                data={},
                error=str(e),
                response_time=time.time() - start_time
            )
    
    async def analyze_sentiment_async(self, text: str, model: str = "roberta") -> OASISResponse:
        """Async sentiment analysis"""
        data = {"text": text, "model": model}
        return await self._make_async_request("POST", "/api/v3/sentiment", data)
    
    async def generate_text_async(self, prompt: str, max_length: int = 150, 
                                 model: str = "gpt2") -> OASISResponse:
        """Async text generation"""
        data = {"prompt": prompt, "max_length": max_length, "model": model}
        return await self._make_async_request("POST", "/api/v3/generate", data)
    
    async def batch_sentiment_analysis_async(self, texts: List[str], 
                                           model: str = "distilbert") -> List[OASISResponse]:
        """Async batch sentiment analysis"""
        tasks = []
        for text in texts:
            task = self.analyze_sentiment_async(text.strip(), model)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Convert exceptions to OASISResponse objects
        processed_results = []
        for result in results:
            if isinstance(result, Exception):
                processed_results.append(OASISResponse(
                    success=False,
                    data={},
                    error=str(result)
                ))
            else:
                processed_results.append(result)
        
        return processed_results


def demo_sync_client():
    """Demonstration of synchronous OASIS client"""
    
    print("🎯 OASIS v3 - SYNCHRONOUS CLIENT DEMO")
    print("=" * 50)
    
    # Initialize client
    client = OASISClient("https://your-space-name.hf.space")
    
    # Test connection
    print("🔄 Testing connection...")
    health = client.health_check()
    if health.success:
        print("✅ Connection successful!")
    else:
        print(f"❌ Connection failed: {health.error}")
        return
    
    # Sentiment analysis
    print("\n🎭 Testing sentiment analysis...")
    sentiment_result = client.analyze_sentiment("I love this OASIS system!")
    
    if sentiment_result.success:
        data = sentiment_result.data
        print(f"✅ Sentiment: {data.get('sentiment', 'N/A')}")
        print(f"📈 Confidence: {data.get('confidence_percentage', 'N/A')}%")
        print(f"⏱️ Response time: {sentiment_result.response_time:.3f}s")
    else:
        print(f"❌ Sentiment analysis failed: {sentiment_result.error}")
    
    # Text generation
    print("\n✨ Testing text generation...")
    generation_result = client.generate_text("The future of AI is", max_length=100)
    
    if generation_result.success:
        data = generation_result.data
        print(f"✅ Generated text: {data.get('generated_text', 'N/A')}")
        print(f"⏱️ Response time: {generation_result.response_time:.3f}s")
    else:
        print(f"❌ Text generation failed: {generation_result.error}")
    
    # Batch processing
    print("\n📊 Testing batch processing...")
    texts = [
        "I'm very happy today!",
        "This is terrible.",
        "Not sure how I feel about this.",
        "Absolutely amazing experience!"
    ]
    
    batch_results = client.batch_sentiment_analysis(texts)
    
    print("📊 Batch Results:")
    for i, result in enumerate(batch_results, 1):
        if result.success:
            data = result.data
            sentiment = data.get('sentiment', 'N/A')
            confidence = data.get('confidence_percentage', 'N/A')
            print(f"  {i}. {texts[i-1][:30]}... → {sentiment} ({confidence}%)")
        else:
            print(f"  {i}. Error: {result.error}")
    
    # Client statistics
    print("\n📈 Client Statistics:")
    stats = client.get_client_stats()
    print(json.dumps(stats, indent=2))


async def demo_async_client():
    """Demonstration of asynchronous OASIS client"""
    
    print("🎯 OASIS v3 - ASYNCHRONOUS CLIENT DEMO")
    print("=" * 50)
    
    # Initialize async client
    client = AsyncOASISClient("https://your-space-name.hf.space")
    
    # Async batch processing (much faster than sync)
    print("\n🚀 Testing async batch processing...")
    texts = [
        "Amazing AI technology!",
        "Could be better.",
        "Neutral opinion here.",
        "This is fantastic!",
        "Not impressed at all."
    ]
    
    start_time = time.time()
    results = await client.batch_sentiment_analysis_async(texts)
    end_time = time.time()
    
    print(f"⏱️ Processed {len(texts)} texts in {end_time - start_time:.3f}s")
    print("📊 Async Results:")
    
    for i, result in enumerate(results, 1):
        if result.success:
            data = result.data
            sentiment = data.get('sentiment', 'N/A')
            confidence = data.get('confidence_percentage', 'N/A')
            print(f"  {i}. {sentiment} ({confidence}%)")
        else:
            print(f"  {i}. Error: {result.error}")


def main():
    """Main demo function"""
    
    print("🎯 OASIS v3 PYTHON CLIENT LIBRARY")
    print("=" * 60)
    print("Choose demo mode:")
    print("1. Synchronous client demo")
    print("2. Asynchronous client demo")
    print("3. Both demos")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice in ["1", "3"]:
        demo_sync_client()
    
    if choice in ["2", "3"]:
        print("\n" + "="*60)
        asyncio.run(demo_async_client())
    
    if choice not in ["1", "2", "3"]:
        print("❌ Invalid choice!")


if __name__ == "__main__":
    main()