#!/usr/bin/env python3
"""
OASIS v3 - Termux Orchestrator
Ultra-Lightweight Command Center for HF Spaces Backend

This is the main orchestrator that runs on Termux with minimal dependencies:
- Only Python + urllib/requests (< 5MB total footprint)
- No heavy ML libraries required
- Controls HF Spaces backend via HTTP API calls

Usage:
  pkg install python
  pip install requests
  python termux_orchestrator.py
"""

import json
import time
import os
from datetime import datetime
from typing import Dict, Any, List, Optional

try:
    import requests
except ImportError:
    print("Installing requests...")
    os.system("pip install requests")
    import requests


class OASISTermuxOrchestrator:
    """Ultra-Lightweight Termux Orchestrator for OASIS v3"""
    
    def __init__(self, hf_space_url: str):
        self.hf_space_url = hf_space_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "OASIS-v3-Termux-Orchestrator/1.0"
        })
        
        # Local stats tracking
        self.stats = {
            "session_start": datetime.now().isoformat(),
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "services_used": {
                "sentiment": 0,
                "generation": 0,
                "image": 0,
                "stats": 0
            }
        }
        
        print("🎯 OASIS v3 Termux Orchestrator Initialized")
        print(f"🔗 Connected to: {self.hf_space_url}")
        print(f"📱 Footprint: <5MB (Python + requests only)")
        print("=" * 60)
    
    def log_activity(self, action: str, details: str = ""):
        """Simple activity logging"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] {action}")
        if details:
            print(f"    └─ {details}")
    
    def make_request(self, endpoint: str, data: Dict[str, Any], service_type: str) -> Dict[str, Any]:
        """Make HTTP request to HF Spaces backend"""
        self.stats["total_requests"] += 1
        self.stats["services_used"][service_type] += 1
        
        url = f"{self.hf_space_url}{endpoint}"
        
        try:
            self.log_activity(f"🚀 REQUESTING {service_type.upper()}", f"Endpoint: {endpoint}")
            
            response = self.session.post(url, json=data, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            self.stats["successful_requests"] += 1
            
            self.log_activity("✅ SUCCESS", f"Response received in {response.elapsed.total_seconds():.2f}s")
            
            return result
            
        except requests.exceptions.RequestException as e:
            self.stats["failed_requests"] += 1
            self.log_activity("❌ ERROR", f"Request failed: {str(e)}")
            
            return {
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
                "service_type": service_type
            }
        except json.JSONDecodeError as e:
            self.stats["failed_requests"] += 1
            self.log_activity("❌ JSON ERROR", f"Invalid response: {str(e)}")
            
            return {
                "error": f"JSON decode error: {str(e)}",
                "timestamp": datetime.now().isoformat(),
                "service_type": service_type
            }
    
    def analyze_sentiment(self, text: str, model: str = "roberta") -> Dict[str, Any]:
        """Orchestrate sentiment analysis via HF Spaces"""
        data = {"text": text, "model": model}
        return self.make_request("/api/v3/sentiment", data, "sentiment")
    
    def generate_text(self, prompt: str, max_length: int = 150, model: str = "gpt2") -> Dict[str, Any]:
        """Orchestrate text generation via HF Spaces"""
        data = {"prompt": prompt, "max_length": max_length, "model": model}
        return self.make_request("/api/v3/generate", data, "generation")
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get system statistics from HF Spaces"""
        try:
            response = self.session.get(f"{self.hf_space_url}/api/v3/stats", timeout=30)
            response.raise_for_status()
            
            self.stats["services_used"]["stats"] += 1
            return response.json()
            
        except Exception as e:
            return {"error": str(e)}
    
    def get_local_stats(self) -> Dict[str, Any]:
        """Get local orchestrator statistics"""
        uptime = (datetime.now() - datetime.fromisoformat(self.stats["session_start"])).total_seconds()
        success_rate = (self.stats["successful_requests"] / max(self.stats["total_requests"], 1)) * 100
        
        return {
            "orchestrator_stats": {
                "session_uptime_seconds": round(uptime, 2),
                "total_requests": self.stats["total_requests"],
                "successful_requests": self.stats["successful_requests"],
                "failed_requests": self.stats["failed_requests"],
                "success_rate_percentage": round(success_rate, 2),
                "requests_per_minute": round((self.stats["total_requests"] / max(uptime/60, 1)), 2)
            },
            "services_usage": self.stats["services_used"],
            "hf_space_url": self.hf_space_url,
            "footprint": "<5MB (Ultra-Lightweight)"
        }
    
    def batch_sentiment_analysis(self, texts: List[str], model: str = "distilbert") -> List[Dict[str, Any]]:
        """Batch process multiple texts for sentiment analysis"""
        results = []
        total = len(texts)
        
        self.log_activity(f"📊 BATCH PROCESSING", f"Processing {total} texts with {model}")
        
        for i, text in enumerate(texts, 1):
            print(f"    Progress: {i}/{total} ({(i/total)*100:.1f}%)")
            result = self.analyze_sentiment(text.strip(), model)
            results.append(result)
            time.sleep(0.1)  # Avoid rate limiting
        
        self.log_activity("✅ BATCH COMPLETED", f"Processed {total} texts successfully")
        return results
    
    def interactive_mode(self):
        """Interactive command-line interface"""
        
        while True:
            print("\n" + "="*60)
            print("🎯 OASIS v3 TERMUX ORCHESTRATOR - COMMAND CENTER")
            print("="*60)
            print("📋 Available Commands:")
            print("  1. 🎭 Sentiment Analysis")
            print("  2. ✨ Text Generation")
            print("  3. 📊 Batch Sentiment Analysis")
            print("  4. 📈 System Statistics")
            print("  5. 📱 Local Stats")
            print("  6. 🔄 Connection Test")
            print("  7. 🚪 Exit")
            print("="*60)
            
            try:
                choice = input("\n🎯 Enter command (1-7): ").strip()
                
                if choice == "1":
                    self._handle_sentiment_analysis()
                
                elif choice == "2":
                    self._handle_text_generation()
                
                elif choice == "3":
                    self._handle_batch_analysis()
                
                elif choice == "4":
                    self._handle_system_stats()
                
                elif choice == "5":
                    self._handle_local_stats()
                
                elif choice == "6":
                    self._handle_connection_test()
                
                elif choice == "7":
                    self.log_activity("🔚 SHUTTING DOWN", "OASIS Orchestrator terminated by user")
                    break
                
                else:
                    print("❌ Invalid choice! Please select 1-7.")
                    
            except KeyboardInterrupt:
                print("\n\n🔚 Graceful shutdown initiated...")
                break
            except Exception as e:
                print(f"❌ Unexpected error: {str(e)}")
    
    def _handle_sentiment_analysis(self):
        """Handle sentiment analysis command"""
        print("\n🎭 SENTIMENT ANALYSIS")
        print("-" * 40)
        
        text = input("📝 Enter text to analyze: ").strip()
        if not text:
            print("❌ Empty input!")
            return
        
        model = input("🤖 Model (roberta/bert/distilbert) [roberta]: ").strip() or "roberta"
        
        result = self.analyze_sentiment(text, model)
        
        print("\n📊 ANALYSIS RESULT:")
        print("-" * 30)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    def _handle_text_generation(self):
        """Handle text generation command"""
        print("\n✨ TEXT GENERATION")
        print("-" * 40)
        
        prompt = input("💭 Enter generation prompt: ").strip()
        if not prompt:
            print("❌ Empty prompt!")
            return
        
        try:
            max_length = int(input("📏 Max length [150]: ").strip() or "150")
        except ValueError:
            max_length = 150
        
        model = input("🤖 Model (gpt2/t5) [gpt2]: ").strip() or "gpt2"
        
        result = self.generate_text(prompt, max_length, model)
        
        print("\n✨ GENERATED CONTENT:")
        print("-" * 30)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    def _handle_batch_analysis(self):
        """Handle batch sentiment analysis"""
        print("\n📊 BATCH SENTIMENT ANALYSIS")
        print("-" * 40)
        print("💡 Enter multiple texts (one per line, empty line to finish):")
        
        texts = []
        while True:
            line = input(f"Text {len(texts)+1}: ").strip()
            if not line:
                break
            texts.append(line)
        
        if not texts:
            print("❌ No texts entered!")
            return
        
        model = input("🤖 Model (roberta/bert/distilbert) [distilbert]: ").strip() or "distilbert"
        
        results = self.batch_sentiment_analysis(texts, model)
        
        print("\n📊 BATCH RESULTS:")
        print("-" * 30)
        for i, result in enumerate(results, 1):
            print(f"\n📝 Text {i}: {result.get('input_text', 'N/A')[:50]}...")
            print(f"   🎭 Sentiment: {result.get('sentiment', 'Error')}")
            print(f"   📈 Confidence: {result.get('confidence_percentage', 'N/A')}%")
    
    def _handle_system_stats(self):
        """Handle system statistics display"""
        print("\n📈 SYSTEM STATISTICS")
        print("-" * 40)
        
        stats = self.get_system_stats()
        print(json.dumps(stats, indent=2, ensure_ascii=False))
    
    def _handle_local_stats(self):
        """Handle local statistics display"""
        print("\n📱 LOCAL ORCHESTRATOR STATISTICS")
        print("-" * 40)
        
        stats = self.get_local_stats()
        print(json.dumps(stats, indent=2, ensure_ascii=False))
    
    def _handle_connection_test(self):
        """Handle connection test"""
        print("\n🔄 CONNECTION TEST")
        print("-" * 40)
        
        try:
            response = self.session.get(f"{self.hf_space_url}/", timeout=10)
            if response.status_code == 200:
                print("✅ HF Space is ONLINE and accessible")
                print(f"📡 Response time: {response.elapsed.total_seconds():.2f}s")
            else:
                print(f"⚠️ HF Space returned status code: {response.status_code}")
        except Exception as e:
            print(f"❌ Connection FAILED: {str(e)}")


def main():
    """Main entry point for Termux orchestrator"""
    
    print("🚀 OASIS v3 - TERMUX ORCHESTRATOR STARTUP")
    print("=" * 60)
    
    # Get HF Space URL
    default_url = "https://your-space-name.hf.space"
    
    print(f"🔗 Default HF Space URL: {default_url}")
    hf_url = input(f"🌐 Enter your HF Space URL [{default_url}]: ").strip()
    
    if not hf_url:
        hf_url = default_url
    
    # Initialize orchestrator
    orchestrator = OASISTermuxOrchestrator(hf_url)
    
    # Test connection
    print("\n🔄 Testing connection...")
    try:
        response = orchestrator.session.get(hf_url, timeout=10)
        if response.status_code == 200:
            print("✅ Connection established successfully!")
        else:
            print(f"⚠️ Warning: Got status code {response.status_code}")
    except Exception as e:
        print(f"❌ Connection test failed: {str(e)}")
        print("🚀 Continuing anyway - will retry on actual requests")
    
    # Start interactive mode
    orchestrator.interactive_mode()


if __name__ == "__main__":
    main()