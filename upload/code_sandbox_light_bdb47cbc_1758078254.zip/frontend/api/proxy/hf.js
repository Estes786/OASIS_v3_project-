/**
 * 🚀 OASIS v3 - HuggingFace API Proxy
 * Vercel Edge Function for HuggingFace Spaces Integration
 * 
 * Lead Engineer: AI Assistant
 * Purpose: Proxy requests to HF Spaces with CORS handling
 * Features: Rate limiting, caching, error handling
 */

export const config = {
  runtime: 'edge',
  regions: ['iad1', 'sfo1', 'lhr1']
}

// 🔧 Configuration
const HF_SPACE_URL = process.env.NEXT_PUBLIC_HF_SPACE_URL || 'https://your-username-oasis-v3.hf.space'
const RATE_LIMIT = 100 // requests per minute per IP
const CACHE_TTL = 300 // 5 minutes

// 📊 In-memory rate limiting (use Redis in production)
const rateLimitMap = new Map()

// 🛡️ Rate limiting function
function checkRateLimit(ip) {
  const now = Date.now()
  const windowStart = now - 60000 // 1 minute window
  
  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, [])
  }
  
  const requests = rateLimitMap.get(ip)
  
  // Remove old requests outside window
  const validRequests = requests.filter(timestamp => timestamp > windowStart)
  rateLimitMap.set(ip, validRequests)
  
  // Check limit
  if (validRequests.length >= RATE_LIMIT) {
    return false
  }
  
  // Add current request
  validRequests.push(now)
  return true
}

// 🔍 Extract client IP
function getClientIP(request) {
  const forwarded = request.headers.get('x-forwarded-for')
  const real = request.headers.get('x-real-ip')
  const cfConnecting = request.headers.get('cf-connecting-ip')
  
  if (forwarded) {
    return forwarded.split(',')[0].trim()
  }
  
  return real || cfConnecting || 'unknown'
}

// 🚀 Main handler
export default async function handler(request) {
  const { method, url } = request
  const { searchParams, pathname } = new URL(url)
  
  // 🔍 Extract HF API path
  const hfPath = pathname.replace('/api/proxy/hf', '')
  const targetUrl = `${HF_SPACE_URL}/api/v1${hfPath}`
  
  // 📋 CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, X-API-Key',
    'Access-Control-Max-Age': '86400',
  }
  
  // ✋ Handle preflight requests
  if (method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders
    })
  }
  
  try {
    // 🛡️ Rate limiting
    const clientIP = getClientIP(request)
    if (!checkRateLimit(clientIP)) {
      return new Response(
        JSON.stringify({
          error: 'Rate limit exceeded',
          message: 'Too many requests. Please try again later.',
          limit: RATE_LIMIT,
          window: '1 minute'
        }),
        {
          status: 429,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
            'Retry-After': '60'
          }
        }
      )
    }
    
    // 📊 Request logging
    console.log(`[${new Date().toISOString()}] ${method} ${hfPath} from ${clientIP}`)
    
    // 🔄 Prepare request to HuggingFace
    const requestOptions = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'OASIS-v3-Proxy/1.0',
      }
    }
    
    // 📤 Add body for POST/PUT requests
    if (method === 'POST' || method === 'PUT') {
      try {
        const body = await request.text()
        requestOptions.body = body
        
        // 📊 Log request data (truncated for security)
        const bodyPreview = body.length > 200 ? body.substring(0, 200) + '...' : body
        console.log(`Request body: ${bodyPreview}`)
      } catch (error) {
        console.error('Error reading request body:', error)
      }
    }
    
    // 🔑 Add API key if provided
    const apiKey = request.headers.get('X-API-Key') || request.headers.get('Authorization')
    if (apiKey) {
      requestOptions.headers['Authorization'] = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`
    }
    
    // 📡 Forward request to HuggingFace Spaces
    const startTime = Date.now()
    const response = await fetch(targetUrl, requestOptions)
    const responseTime = Date.now() - startTime
    
    // 📊 Log response
    console.log(`HF Response: ${response.status} in ${responseTime}ms`)
    
    // 📥 Get response data
    const responseData = await response.text()
    
    // 🔍 Try to parse as JSON
    let jsonData
    try {
      jsonData = JSON.parse(responseData)
    } catch {
      jsonData = { raw_response: responseData }
    }
    
    // 📊 Add proxy metadata
    const enhancedResponse = {
      ...jsonData,
      _proxy_metadata: {
        proxy_version: '1.0.0',
        response_time_ms: responseTime,
        hf_status: response.status,
        cached: false,
        timestamp: new Date().toISOString(),
        client_ip: clientIP.substring(0, 8) + '...' // Partial IP for privacy
      }
    }
    
    // 🎯 Response headers
    const responseHeaders = {
      ...corsHeaders,
      'Content-Type': 'application/json',
      'X-Proxy-Response-Time': `${responseTime}ms`,
      'X-HF-Status': response.status.toString(),
      'Cache-Control': response.ok ? `public, max-age=${CACHE_TTL}` : 'no-cache'
    }
    
    // ✅ Success response
    if (response.ok) {
      return new Response(
        JSON.stringify(enhancedResponse, null, 2),
        {
          status: response.status,
          headers: responseHeaders
        }
      )
    }
    
    // ❌ Error response from HuggingFace
    return new Response(
      JSON.stringify({
        error: 'HuggingFace API Error',
        hf_status: response.status,
        hf_message: jsonData.error || 'Unknown error',
        proxy_info: 'Request forwarded to HuggingFace Spaces',
        timestamp: new Date().toISOString()
      }),
      {
        status: response.status >= 500 ? 502 : response.status,
        headers: responseHeaders
      }
    )
    
  } catch (error) {
    // 💥 Proxy error
    console.error('Proxy error:', error)
    
    return new Response(
      JSON.stringify({
        error: 'Proxy Error',
        message: 'Failed to connect to HuggingFace Spaces',
        details: error.message,
        timestamp: new Date().toISOString(),
        troubleshooting: {
          check_hf_space_url: HF_SPACE_URL,
          verify_space_running: 'Ensure HuggingFace Space is operational',
          network_issues: 'Check for network connectivity issues'
        }
      }),
      {
        status: 502,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )
  }
}

// 📚 API Documentation endpoint
export async function GET(request) {
  const { pathname } = new URL(request.url)
  
  if (pathname.endsWith('/docs') || pathname.endsWith('/info')) {
    return new Response(
      JSON.stringify({
        name: 'OASIS v3 - HuggingFace Proxy API',
        version: '1.0.0',
        description: 'Proxy service for OASIS v3 HuggingFace Spaces integration',
        endpoints: {
          '/api/proxy/hf/generate': 'Text generation',
          '/api/proxy/hf/sentiment': 'Sentiment analysis',
          '/api/proxy/hf/classify': 'Text classification',
          '/api/proxy/hf/qa': 'Question answering',
          '/api/proxy/hf/summarize': 'Text summarization',
          '/api/proxy/hf/revenue': 'Revenue statistics'
        },
        rate_limit: `${RATE_LIMIT} requests per minute per IP`,
        cache_ttl: `${CACHE_TTL} seconds`,
        cors: 'Enabled for all origins',
        authentication: 'Optional X-API-Key header',
        target: HF_SPACE_URL,
        status: 'operational'
      }, null, 2),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    )
  }
  
  // Default handler for other requests
  return handler(request)
}