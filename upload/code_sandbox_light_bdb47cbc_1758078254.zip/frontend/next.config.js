/** @type {import('next').NextConfig} */

const nextConfig = {
  // 🚀 OASIS v3 - Next.js Configuration
  // Optimized for mobile-first, ultra-fast performance
  
  reactStrictMode: true,
  swcMinify: true,
  
  // Output configuration for static export (Vercel compatibility)
  output: 'export',
  trailingSlash: true,
  skipTrailingSlashRedirect: true,
  distDir: 'out',
  
  // Image optimization (disabled for static export)
  images: {
    unoptimized: true,
    domains: [
      'your-username-oasis-v3.hf.space',
      'huggingface.co',
      'vercel.app',
      'supabase.co'
    ]
  },
  
  // Experimental features for performance
  experimental: {
    appDir: true,
    serverComponentsExternalPackages: ['axios'],
    optimizeCss: true,
    optimizePackageImports: ['lucide-react', 'framer-motion']
  },
  
  // Compiler configuration
  compiler: {
    // Remove console.log in production
    removeConsole: process.env.NODE_ENV === 'production' ? {
      exclude: ['error', 'warn']
    } : false,
  },
  
  // Environment variables
  env: {
    NEXT_PUBLIC_APP_NAME: 'OASIS v3',
    NEXT_PUBLIC_APP_VERSION: '3.0.0',
    NEXT_PUBLIC_HF_SPACE_URL: process.env.NEXT_PUBLIC_HF_SPACE_URL || 'https://your-username-oasis-v3.hf.space',
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
    NEXT_PUBLIC_VERCEL_URL: process.env.NEXT_PUBLIC_VERCEL_URL || '',
  },
  
  // Headers for security and performance
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          // Security headers
          {
            key: 'X-Frame-Options',
            value: 'DENY'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin'
          },
          // Performance headers
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          // CORS for mobile access
          {
            key: 'Access-Control-Allow-Origin',
            value: '*'
          },
          {
            key: 'Access-Control-Allow-Methods',
            value: 'GET, POST, PUT, DELETE, OPTIONS'
          },
          {
            key: 'Access-Control-Allow-Headers',
            value: 'Content-Type, Authorization'
          }
        ]
      },
      // Cache static assets
      {
        source: '/(.*)\\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable'
          }
        ]
      }
    ]
  },
  
  // Redirects
  async redirects() {
    return [
      {
        source: '/dashboard',
        destination: '/app/dashboard',
        permanent: true
      },
      {
        source: '/api-docs',
        destination: '/docs/api',
        permanent: true
      }
    ]
  },
  
  // Webpack configuration for mobile optimization
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    // Optimize bundle size for mobile
    config.optimization = {
      ...config.optimization,
      splitChunks: {
        chunks: 'all',
        minSize: 20000,
        maxSize: 244000,
        cacheGroups: {
          default: {
            minChunks: 2,
            priority: -20,
            reuseExistingChunk: true
          },
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            priority: -10,
            chunks: 'all'
          },
          // AI-specific chunks
          ai: {
            test: /[\\/]node_modules[\\/](axios|react-query)[\\/]/,
            name: 'ai-core',
            priority: 10,
            chunks: 'all'
          },
          // UI chunks  
          ui: {
            test: /[\\/]node_modules[\\/](framer-motion|lucide-react|recharts)[\\/]/,
            name: 'ui-components',
            priority: 5,
            chunks: 'all'
          }
        }
      }
    }
    
    // Add bundle analyzer in development
    if (process.env.ANALYZE === 'true') {
      const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer')
      config.plugins.push(
        new BundleAnalyzerPlugin({
          analyzerMode: 'server',
          openAnalyzer: true,
        })
      )
    }
    
    return config
  },
  
  // TypeScript configuration
  typescript: {
    // Type checking in separate process for faster builds
    ignoreBuildErrors: false
  },
  
  // ESLint configuration
  eslint: {
    ignoreDuringBuilds: false,
    dirs: ['src', 'components', 'pages', 'lib', 'hooks']
  },
  
  // PoweredByHeader
  poweredByHeader: false,
  
  // Compression
  compress: true,
  
  // Generate sitemap
  generateBuildId: async () => {
    return `oasis-v3-${Date.now()}`
  }
}

// Export configuration
module.exports = nextConfig