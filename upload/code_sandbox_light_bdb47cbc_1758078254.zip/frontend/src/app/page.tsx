'use client'

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Bot, 
  Smartphone, 
  Zap, 
  DollarSign, 
  Globe, 
  Code, 
  BarChart3,
  MessageSquare,
  Heart,
  Star,
  ArrowRight,
  Play,
  CheckCircle,
  Rocket
} from 'lucide-react'

// 🚀 OASIS v3 Homepage - Mobile-First Design
export default function OASISHomePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeDemo, setActiveDemo] = useState(0)
  const [revenueCounter, setRevenueCounter] = useState(0)

  useEffect(() => {
    setIsVisible(true)
    
    // Animate revenue counter
    const interval = setInterval(() => {
      setRevenueCounter(prev => {
        if (prev < 1247.83) {
          return prev + Math.random() * 5
        }
        return prev
      })
    }, 100)

    return () => clearInterval(interval)
  }, [])

  // Demo data
  const demoServices = [
    {
      id: 'text-generation',
      title: 'AI Text Generation',
      description: 'Create human-like content instantly',
      icon: <MessageSquare className="w-6 h-6" />,
      price: '$0.02',
      color: 'from-blue-500 to-purple-600'
    },
    {
      id: 'sentiment-analysis',
      title: 'Sentiment Analysis',
      description: 'Understand emotions in text',
      icon: <Heart className="w-6 h-6" />,
      price: '$0.005',
      color: 'from-pink-500 to-rose-600'
    },
    {
      id: 'classification',
      title: 'Text Classification',
      description: 'Categorize content automatically',
      icon: <BarChart3 className="w-6 h-6" />,
      price: '$0.01',
      color: 'from-green-500 to-emerald-600'
    }
  ]

  // Stats data
  const stats = [
    { label: 'AI Models', value: '100,000+', icon: <Bot /> },
    { label: 'Mobile Users', value: '50M+', icon: <Smartphone /> },
    { label: 'API Calls/Day', value: '1B+', icon: <Globe /> },
    { label: 'Revenue/Month', value: `$${revenueCounter.toFixed(2)}`, icon: <DollarSign /> }
  ]

  // Features data
  const features = [
    {
      title: 'Ultra-Lightweight',
      description: 'Only 5MB footprint on Android/Termux',
      icon: <Zap className="w-8 h-8 text-yellow-500" />,
      highlight: true
    },
    {
      title: 'Revenue-Ready',
      description: 'Built-in monetization from day one',
      icon: <DollarSign className="w-8 h-8 text-green-500" />,
      highlight: true
    },
    {
      title: 'Mobile-First',
      description: 'Optimized for smartphones and tablets',
      icon: <Smartphone className="w-8 h-8 text-blue-500" />,
      highlight: false
    },
    {
      title: 'Zero Dependencies',
      description: 'No heavy ML libraries on mobile',
      icon: <Code className="w-8 h-8 text-purple-500" />,
      highlight: false
    }
  ]

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* 🌟 Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-pink-500/20 to-yellow-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <AnimatePresence>
            {isVisible && (
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                {/* Logo & Badge */}
                <motion.div
                  className="flex items-center justify-center mb-6"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                >
                  <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-2xl mr-4">
                    <Rocket className="w-8 h-8 text-white" />
                  </div>
                  <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent text-sm font-semibold px-4 py-2 border border-green-400/30 rounded-full">
                    ✨ AI Superintelligence Ecosystem
                  </span>
                </motion.div>

                {/* Main Title */}
                <motion.h1
                  className="text-4xl md:text-7xl font-bold mb-6 leading-tight"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.8 }}
                >
                  <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                    OASIS v3
                  </span>
                  <br />
                  <span className="text-white text-2xl md:text-4xl">
                    The New Civilization
                  </span>
                </motion.h1>

                {/* Subtitle */}
                <motion.p
                  className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                >
                  Zero-cost, mobile-first AI superintelligence accessible from any Android device. 
                  <span className="text-blue-400 font-semibold"> 100,000+ models</span> at your fingertips.
                </motion.p>

                {/* CTA Buttons */}
                <motion.div
                  className="flex flex-col sm:flex-row gap-4 justify-center items-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8, duration: 0.8 }}
                >
                  <button className="group relative bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/25 w-full sm:w-auto">
                    <span className="flex items-center justify-center">
                      <Play className="w-5 h-5 mr-2" />
                      Launch OASIS v3
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </button>
                  
                  <button className="text-white border border-gray-600 px-8 py-4 rounded-2xl font-semibold text-lg hover:bg-white hover:text-black transition-all duration-300 w-full sm:w-auto">
                    📚 View Documentation
                  </button>
                </motion.div>

                {/* Stats Preview */}
                <motion.div
                  className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.0, duration: 0.8 }}
                >
                  {stats.map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-4 hover:bg-gray-800/50 transition-all duration-300"
                      whileHover={{ scale: 1.05 }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 1.2 + index * 0.1 }}
                    >
                      <div className="text-blue-400 mb-2 flex justify-center">
                        {stat.icon}
                      </div>
                      <div className="text-2xl font-bold text-white mb-1">
                        {stat.value}
                      </div>
                      <div className="text-gray-400 text-sm">
                        {stat.label}
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* 🚀 Features Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Revolutionary Features
              </span>
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Built for the mobile-first AI revolution with zero compromises on performance or accessibility.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className={`
                  relative p-6 rounded-2xl border transition-all duration-300 hover:scale-105
                  ${feature.highlight 
                    ? 'bg-gradient-to-br from-blue-500/10 to-purple-600/10 border-blue-500/50 hover:border-blue-400' 
                    : 'bg-gray-900/50 border-gray-800 hover:border-gray-700'
                  }
                `}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.8 }}
                whileHover={{ y: -5 }}
              >
                {feature.highlight && (
                  <div className="absolute -top-2 -right-2">
                    <Star className="w-6 h-6 text-yellow-500 fill-current" />
                  </div>
                )}
                
                <div className="mb-4">
                  {feature.icon}
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">
                  {feature.title}
                </h3>
                
                <p className="text-gray-400">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🎯 Demo Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                Live AI Services
              </span>
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Experience the power of 100,000+ AI models through our ultra-lightweight mobile interface.
            </p>
          </motion.div>

          <div className="bg-gray-900 rounded-3xl p-8 border border-gray-800">
            {/* Service Tabs */}
            <div className="flex flex-wrap gap-4 mb-8 justify-center">
              {demoServices.map((service, index) => (
                <button
                  key={service.id}
                  onClick={() => setActiveDemo(index)}
                  className={`
                    flex items-center px-6 py-3 rounded-xl font-medium transition-all duration-300
                    ${activeDemo === index
                      ? `bg-gradient-to-r ${service.color} text-white shadow-lg`
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                    }
                  `}
                >
                  {service.icon}
                  <span className="ml-2 hidden sm:inline">{service.title}</span>
                  <span className="ml-2 text-xs bg-black/30 px-2 py-1 rounded">
                    {service.price}
                  </span>
                </button>
              ))}
            </div>

            {/* Demo Content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeDemo}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-black rounded-2xl p-6 border border-gray-800"
              >
                <div className={`bg-gradient-to-r ${demoServices[activeDemo].color} bg-clip-text text-transparent font-bold text-lg mb-4 flex items-center`}>
                  {demoServices[activeDemo].icon}
                  <span className="ml-2">{demoServices[activeDemo].title}</span>
                </div>
                
                <p className="text-gray-300 mb-6">
                  {demoServices[activeDemo].description}
                </p>
                
                <div className="space-y-4">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-green-400 text-sm mb-2">✅ Request Processed</div>
                    <div className="text-gray-300">
                      Service: {demoServices[activeDemo].title} • Cost: {demoServices[activeDemo].price} • Response: 0.8s
                    </div>
                  </div>
                  
                  <button className={`w-full bg-gradient-to-r ${demoServices[activeDemo].color} text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity`}>
                    Try {demoServices[activeDemo].title} Now
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* 💰 Revenue Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Revenue-Ready from Day One
              </span>
            </h2>
            
            <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/30 rounded-3xl p-8 mb-8">
              <div className="text-6xl font-bold text-green-400 mb-2">
                ${revenueCounter.toFixed(2)}
              </div>
              <div className="text-gray-300 mb-4">Live Revenue (This Month)</div>
              
              <div className="grid md:grid-cols-3 gap-6 mt-8">
                <div className="bg-black/50 rounded-xl p-4">
                  <div className="text-blue-400 text-2xl font-bold">$500-1,500</div>
                  <div className="text-gray-400">Month 1-2 Projection</div>
                </div>
                <div className="bg-black/50 rounded-xl p-4">
                  <div className="text-purple-400 text-2xl font-bold">$7K-20K</div>
                  <div className="text-gray-400">Month 7-12 Projection</div>
                </div>
                <div className="bg-black/50 rounded-xl p-4">
                  <div className="text-green-400 text-2xl font-bold">$50K+</div>
                  <div className="text-gray-400">Enterprise Scale</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 🚀 CTA Footer */}
      <footer className="py-16 px-4 bg-black">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Join the AI Revolution?
            </h2>
            
            <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
              Deploy OASIS v3 on HuggingFace Spaces in under 5 minutes. 
              Start building the future of mobile AI today.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg hover:scale-105 transition-all duration-300 w-full sm:w-auto">
                🚀 Deploy to HuggingFace
              </button>
              
              <button className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg hover:scale-105 transition-all duration-300 w-full sm:w-auto">
                📱 Install on Termux
              </button>
            </div>
            
            <div className="text-gray-500 text-sm">
              🌟 Zero cost • ⚡ 5MB footprint • 📱 Mobile-first • 💰 Revenue-ready
            </div>
          </motion.div>
        </div>
      </footer>
    </div>
  )
}