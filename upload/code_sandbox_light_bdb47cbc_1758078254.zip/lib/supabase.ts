/**
 * 🗄️ OASIS v3 - Supabase Client Configuration
 * Lead Engineer: AI Assistant
 * Purpose: Database client with authentication and real-time features
 * Architecture: Type-safe, optimized for mobile and serverless
 */

import { createClient } from '@supabase/supabase-js'
import { Database } from '../types/database'

// 🔧 Environment Configuration
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

// 🚀 Create Supabase Client with optimized configuration
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    // Optimized for mobile and web
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    
    // Storage configuration  
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
    
    // Flow configuration
    flowType: 'pkce', // More secure for mobile apps
  },
  
  // Real-time configuration
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
  
  // Global configuration
  global: {
    headers: {
      'X-Client-Info': 'oasis-v3@3.0.0',
    },
  },
  
  // Database configuration
  db: {
    schema: 'public',
  },
})

// 🎯 Type-safe database operations
export type Tables = Database['public']['Tables']
export type UserProfile = Tables['user_profiles']['Row']
export type ApiRequest = Tables['api_requests']['Row']
export type MobileSession = Tables['mobile_sessions']['Row']
export type RevenueStats = Tables['revenue_stats']['Row']

// 📊 Revenue and Analytics Client
export class OASISAnalytics {
  private client = supabase

  // 💰 Revenue tracking
  async logApiRequest(requestData: {
    user_id?: string
    service_type: string
    endpoint: string
    request_data?: any
    response_data?: any
    cost_usd: number
    processing_time_ms: number
    success: boolean
    status_code: number
    ai_model_used?: string
    device_type?: string
    ip_address?: string
    user_agent?: string
  }) {
    try {
      const { data, error } = await this.client
        .from('api_requests')
        .insert({
          ...requestData,
          created_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) {
        console.error('Failed to log API request:', error)
        return null
      }

      return data
    } catch (err) {
      console.error('Error logging API request:', err)
      return null
    }
  }

  // 📊 Get user dashboard data
  async getUserDashboard(userId: string) {
    try {
      const { data, error } = await this.client
        .from('user_dashboard')
        .select('*')
        .eq('id', userId)
        .single()

      if (error) {
        console.error('Failed to get user dashboard:', error)
        return null
      }

      return data
    } catch (err) {
      console.error('Error getting user dashboard:', err)
      return null
    }
  }

  // 📈 Get revenue analytics
  async getRevenueAnalytics(days: number = 30) {
    try {
      const { data, error } = await this.client
        .from('revenue_analytics')
        .select('*')
        .gte('date', new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
        .order('date', { ascending: false })

      if (error) {
        console.error('Failed to get revenue analytics:', error)
        return []
      }

      return data || []
    } catch (err) {
      console.error('Error getting revenue analytics:', err)
      return []
    }
  }

  // 📱 Log mobile session
  async logMobileSession(sessionData: {
    user_id: string
    device_id: string
    device_info?: any
    termux_version?: string
    android_version?: string
    app_version?: string
    network_type?: string
    country_code?: string
  }) {
    try {
      const { data, error } = await this.client
        .from('mobile_sessions')
        .insert({
          ...sessionData,
          session_start: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) {
        console.error('Failed to log mobile session:', error)
        return null
      }

      return data
    } catch (err) {
      console.error('Error logging mobile session:', err)
      return null
    }
  }

  // ⚛️ Log quantum usage
  async logQuantumUsage(quantumData: {
    user_id: string
    quantum_backend: string
    quantum_algorithm?: string
    circuit_depth?: number
    num_qubits?: number
    quantum_processing_time_ms?: number
    classical_fallback?: boolean
    optimization_result?: any
    success: boolean
  }) {
    try {
      const { data, error } = await this.client
        .from('quantum_usage')
        .insert({
          ...quantumData,
          created_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) {
        console.error('Failed to log quantum usage:', error)
        return null
      }

      return data
    } catch (err) {
      console.error('Error logging quantum usage:', err)
      return null
    }
  }

  // 🔍 Get AI model usage statistics
  async getAIModelUsage(days: number = 7) {
    try {
      const { data, error } = await this.client
        .from('ai_model_usage')
        .select('*')
        .gte('date', new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
        .order('usage_count', { ascending: false })

      if (error) {
        console.error('Failed to get AI model usage:', error)
        return []
      }

      return data || []
    } catch (err) {
      console.error('Error getting AI model usage:', err)
      return []
    }
  }

  // ⏱️ Get real-time revenue data
  async getRealTimeRevenue(hours: number = 24) {
    try {
      const { data, error } = await this.client
        .from('revenue_real_time')
        .select('*')
        .gte('time_window', new Date(Date.now() - hours * 60 * 60 * 1000).toISOString())
        .order('time_window', { ascending: false })

      if (error) {
        console.error('Failed to get real-time revenue:', error)
        return []
      }

      return data || []
    } catch (err) {
      console.error('Error getting real-time revenue:', err)
      return []
    }
  }

  // 🔒 Log security event
  async logSecurityEvent(eventData: {
    event_type: string
    severity: 'low' | 'medium' | 'high' | 'critical'
    description: string
    user_id?: string
    ip_address?: string
    user_agent?: string
    endpoint?: string
    metadata?: any
  }) {
    try {
      const { data, error } = await this.client
        .from('security_logs')
        .insert({
          ...eventData,
          created_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) {
        console.error('Failed to log security event:', error)
        return null
      }

      return data
    } catch (err) {
      console.error('Error logging security event:', err)
      return null
    }
  }
}

// 👤 User Management Client
export class OASISUserManager {
  private client = supabase

  // 📝 Get or create user profile
  async getOrCreateProfile(userId: string, userData?: Partial<UserProfile>) {
    try {
      // Try to get existing profile
      const { data: existingProfile } = await this.client
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single()

      if (existingProfile) {
        return existingProfile
      }

      // Create new profile
      const { data, error } = await this.client
        .from('user_profiles')
        .insert({
          id: userId,
          ...userData,
        })
        .select()
        .single()

      if (error) {
        console.error('Failed to create user profile:', error)
        return null
      }

      // Log profile creation
      await analytics.logSecurityEvent({
        event_type: 'profile_created',
        severity: 'low',
        description: 'New user profile created',
        user_id: userId,
      })

      return data
    } catch (err) {
      console.error('Error managing user profile:', err)
      return null
    }
  }

  // 🔑 Generate new API key
  async generateNewApiKey(userId: string) {
    try {
      const newApiKey = Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('')

      const { data, error } = await this.client
        .from('user_profiles')
        .update({
          api_key: newApiKey,
          api_key_created_at: new Date().toISOString(),
        })
        .eq('id', userId)
        .select('api_key')
        .single()

      if (error) {
        console.error('Failed to generate new API key:', error)
        return null
      }

      // Log API key generation
      await analytics.logSecurityEvent({
        event_type: 'api_key_generated',
        severity: 'medium',
        description: 'New API key generated',
        user_id: userId,
      })

      return data.api_key
    } catch (err) {
      console.error('Error generating API key:', err)
      return null
    }
  }

  // 📊 Update user subscription
  async updateSubscription(userId: string, tier: 'free' | 'pro' | 'enterprise') {
    try {
      // Get tier configuration
      const { data: tierConfig } = await this.client
        .from('subscription_tiers')
        .select('*')
        .eq('tier_name', tier)
        .single()

      if (!tierConfig) {
        console.error('Invalid subscription tier:', tier)
        return null
      }

      // Update user profile
      const { data, error } = await this.client
        .from('user_profiles')
        .update({
          subscription_tier: tier,
          monthly_request_limit: tierConfig.monthly_request_limit,
          subscription_start: new Date().toISOString().split('T')[0],
          subscription_end: tier === 'free' ? null : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        })
        .eq('id', userId)
        .select()
        .single()

      if (error) {
        console.error('Failed to update subscription:', error)
        return null
      }

      // Log subscription change
      await analytics.logSecurityEvent({
        event_type: 'subscription_updated',
        severity: 'low',
        description: `Subscription updated to ${tier}`,
        user_id: userId,
        metadata: { new_tier: tier, tier_config: tierConfig },
      })

      return data
    } catch (err) {
      console.error('Error updating subscription:', err)
      return null
    }
  }

  // ✅ Check usage limits
  async checkUsageLimit(userId: string): Promise<{ allowed: boolean; remaining: number; limit: number }> {
    try {
      const { data } = await this.client
        .from('user_profiles')
        .select('monthly_request_limit, current_month_usage')
        .eq('id', userId)
        .single()

      if (!data) {
        return { allowed: false, remaining: 0, limit: 0 }
      }

      const remaining = Math.max(0, data.monthly_request_limit - data.current_month_usage)
      const allowed = remaining > 0

      return {
        allowed,
        remaining,
        limit: data.monthly_request_limit,
      }
    } catch (err) {
      console.error('Error checking usage limit:', err)
      return { allowed: false, remaining: 0, limit: 0 }
    }
  }
}

// 🔄 Real-time Subscriptions
export class OASISRealtime {
  private client = supabase

  // 📊 Subscribe to revenue updates
  subscribeToRevenue(callback: (payload: any) => void) {
    return this.client
      .channel('revenue_updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'revenue_real_time',
        },
        callback
      )
      .subscribe()
  }

  // 👤 Subscribe to user profile changes
  subscribeToUserProfile(userId: string, callback: (payload: any) => void) {
    return this.client
      .channel(`user_profile_${userId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_profiles',
          filter: `id=eq.${userId}`,
        },
        callback
      )
      .subscribe()
  }

  // 🚨 Subscribe to security events
  subscribeToSecurity(callback: (payload: any) => void) {
    return this.client
      .channel('security_events')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'security_logs',
          filter: 'severity=in.(high,critical)',
        },
        callback
      )
      .subscribe()
  }
}

// 🚀 Initialize clients
export const analytics = new OASISAnalytics()
export const userManager = new OASISUserManager()
export const realtime = new OASISRealtime()

// 🔧 Utility functions
export const getUser = () => supabase.auth.getUser()
export const signIn = (email: string, password: string) => 
  supabase.auth.signInWithPassword({ email, password })
export const signUp = (email: string, password: string) => 
  supabase.auth.signUp({ email, password })
export const signOut = () => supabase.auth.signOut()

// 🌐 OAuth sign-in helpers
export const signInWithGoogle = () => 
  supabase.auth.signInWithOAuth({ 
    provider: 'google',
    options: {
      redirectTo: `${window.location.origin}/auth/callback`
    }
  })

export const signInWithGitHub = () => 
  supabase.auth.signInWithOAuth({ 
    provider: 'github',
    options: {
      redirectTo: `${window.location.origin}/auth/callback`
    }
  })

// 📱 Mobile-specific utilities
export const isMobile = () => {
  if (typeof window === 'undefined') return false
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
}

export const getDeviceInfo = () => {
  if (typeof window === 'undefined') return {}
  
  return {
    user_agent: navigator.userAgent,
    screen_width: window.screen.width,
    screen_height: window.screen.height,
    device_pixel_ratio: window.devicePixelRatio,
    platform: navigator.platform,
    language: navigator.language,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  }
}

export default supabase