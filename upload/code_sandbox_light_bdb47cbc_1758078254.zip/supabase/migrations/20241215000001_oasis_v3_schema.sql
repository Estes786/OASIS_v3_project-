-- 🚀 OASIS v3 - Complete Database Schema
-- Lead Engineer: AI Assistant  
-- Purpose: User management, revenue tracking, AI processing logs
-- Architecture: Mobile-first, scalable, real-time

-- Enable necessary extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pg_stat_statements";
create extension if not exists "pgcrypto";

-- =====================================================
-- 👤 USER MANAGEMENT & AUTHENTICATION
-- =====================================================

-- Enhanced user profiles with subscription tiers
create table public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  full_name text,
  avatar_url text,
  bio text,
  website text,
  
  -- Subscription and billing
  subscription_tier text not null default 'free' check (subscription_tier in ('free', 'pro', 'enterprise')),
  subscription_start date,
  subscription_end date,
  
  -- Usage limits and tracking
  monthly_request_limit integer not null default 1000,
  current_month_usage integer not null default 0,
  total_lifetime_usage bigint not null default 0,
  
  -- API access
  api_key text unique default encode(gen_random_bytes(32), 'base64'),
  api_key_created_at timestamp with time zone default now(),
  api_key_last_used timestamp with time zone,
  
  -- Mobile/Termux specific
  termux_device_id text,
  mobile_preferences jsonb default '{}',
  
  -- Timestamps
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- User tier configurations
create table public.subscription_tiers (
  tier_name text primary key,
  monthly_request_limit integer not null,
  rate_limit_per_minute integer not null,
  features jsonb not null default '{}',
  price_usd numeric(8,2) not null default 0,
  description text,
  active boolean not null default true
);

-- Insert default tier configurations
insert into public.subscription_tiers (tier_name, monthly_request_limit, rate_limit_per_minute, features, price_usd, description) values
('free', 1000, 10, '{"basic_ai": true, "api_access": true}', 0.00, 'Free tier with basic AI access'),
('pro', 10000, 100, '{"basic_ai": true, "advanced_ai": true, "api_access": true, "priority_support": true}', 19.99, 'Professional tier with advanced features'),
('enterprise', 100000, 1000, '{"basic_ai": true, "advanced_ai": true, "api_access": true, "priority_support": true, "custom_models": true, "dedicated_support": true}', 199.99, 'Enterprise tier with unlimited features');

-- =====================================================
-- 🤖 AI PROCESSING & REQUEST TRACKING  
-- =====================================================

-- Comprehensive API request logging
create table public.api_requests (
  id uuid primary key default uuid_generate_v4(),
  
  -- User and session info
  user_id uuid references public.user_profiles(id),
  session_id text,
  
  -- Request details
  service_type text not null check (service_type in ('text_generation', 'sentiment_analysis', 'text_classification', 'question_answering', 'summarization', 'image_classification')),
  endpoint text not null,
  method text not null default 'POST',
  
  -- Request/response data
  request_data jsonb,
  response_data jsonb,
  request_size_bytes integer,
  response_size_bytes integer,
  
  -- Performance metrics
  processing_time_ms integer,
  queue_time_ms integer default 0,
  
  -- Cost and billing
  cost_usd numeric(10,4) not null,
  billing_tier text,
  
  -- Status and error handling
  status_code integer not null,
  success boolean not null,
  error_message text,
  error_code text,
  
  -- Technical details
  ai_model_used text,
  backend_used text default 'huggingface',
  
  -- Network and device info
  ip_address inet,
  user_agent text,
  device_type text, -- 'mobile', 'desktop', 'termux', 'api'
  country_code char(2),
  
  -- Timestamps
  created_at timestamp with time zone default now()
);

-- Mobile/Termux specific session tracking
create table public.mobile_sessions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.user_profiles(id),
  
  -- Device information
  device_id text not null,
  device_info jsonb,
  termux_version text,
  android_version text,
  app_version text,
  
  -- Session metrics
  session_start timestamp with time zone default now(),
  session_end timestamp with time zone,
  total_requests integer default 0,
  successful_requests integer default 0,
  total_cost_usd numeric(10,4) default 0,
  
  -- Performance data
  avg_response_time_ms numeric(8,2),
  total_data_uploaded_mb numeric(10,2) default 0,
  total_data_downloaded_mb numeric(10,2) default 0,
  
  -- Location and network
  country_code char(2),
  network_type text, -- 'wifi', 'cellular', 'unknown'
  
  unique(user_id, device_id, session_start)
);

-- =====================================================
-- 💰 REVENUE TRACKING & ANALYTICS
-- =====================================================

-- Daily revenue aggregation
create table public.revenue_stats (
  id uuid primary key default uuid_generate_v4(),
  date date not null,
  
  -- Request volume metrics
  total_requests integer default 0,
  successful_requests integer default 0,
  failed_requests integer default 0,
  unique_users integer default 0,
  new_users integer default 0,
  
  -- Revenue metrics
  total_revenue_usd numeric(12,4) default 0,
  revenue_by_tier jsonb default '{}',
  revenue_by_service jsonb default '{}',
  
  -- Performance metrics
  avg_response_time_ms numeric(8,2),
  p95_response_time_ms numeric(8,2),
  
  -- Device breakdown
  mobile_requests integer default 0,
  desktop_requests integer default 0,
  api_requests integer default 0,
  
  created_at timestamp with time zone default now(),
  
  unique(date)
);

-- Real-time revenue tracking
create table public.revenue_real_time (
  id uuid primary key default uuid_generate_v4(),
  
  -- Time window (5-minute intervals)
  time_window timestamp with time zone not null,
  
  -- Metrics for the window
  requests_count integer default 0,
  revenue_usd numeric(8,4) default 0,
  unique_users integer default 0,
  avg_response_time_ms numeric(6,2),
  
  -- Status breakdown
  success_rate numeric(5,4), -- 0.0 to 1.0
  
  created_at timestamp with time zone default now(),
  
  unique(time_window)
);

-- =====================================================
-- 🎯 AI MODEL USAGE & OPTIMIZATION
-- =====================================================

-- Track which AI models are most popular
create table public.ai_model_usage (
  id uuid primary key default uuid_generate_v4(),
  
  -- Model identification
  model_name text not null,
  model_type text not null, -- 'text', 'image', 'multimodal'
  service_type text not null,
  
  -- Usage metrics
  usage_count integer default 1,
  success_count integer default 0,
  avg_processing_time_ms numeric(8,2),
  avg_cost_usd numeric(8,4),
  
  -- User satisfaction (if available)
  avg_rating numeric(3,2), -- 1.00 to 5.00
  rating_count integer default 0,
  
  -- Date tracking
  date date not null default current_date,
  
  unique(model_name, service_type, date)
);

-- Quantum computing usage tracking
create table public.quantum_usage (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.user_profiles(id),
  
  -- Quantum processing details
  quantum_backend text not null,
  quantum_algorithm text,
  circuit_depth integer,
  num_qubits integer,
  
  -- Performance
  quantum_processing_time_ms integer,
  classical_fallback boolean default false,
  
  -- Results
  optimization_result jsonb,
  success boolean not null,
  
  created_at timestamp with time zone default now()
);

-- =====================================================
-- 🔒 SECURITY & AUDIT LOGS
-- =====================================================

-- Security and audit logging
create table public.security_logs (
  id uuid primary key default uuid_generate_v4(),
  
  -- Event details
  event_type text not null, -- 'login', 'api_key_created', 'suspicious_activity', etc.
  severity text not null check (severity in ('low', 'medium', 'high', 'critical')),
  description text not null,
  
  -- Context
  user_id uuid references public.user_profiles(id),
  ip_address inet,
  user_agent text,
  endpoint text,
  
  -- Additional data
  metadata jsonb default '{}',
  
  created_at timestamp with time zone default now()
);

-- =====================================================
-- 📊 INDEXES FOR PERFORMANCE
-- =====================================================

-- User profiles indexes
create index idx_user_profiles_username on public.user_profiles(username);
create index idx_user_profiles_subscription_tier on public.user_profiles(subscription_tier);
create index idx_user_profiles_api_key on public.user_profiles(api_key);

-- API requests indexes
create index idx_api_requests_user_id on public.api_requests(user_id);
create index idx_api_requests_created_at on public.api_requests(created_at desc);
create index idx_api_requests_service_type on public.api_requests(service_type);
create index idx_api_requests_success on public.api_requests(success);
create index idx_api_requests_cost on public.api_requests(cost_usd);
create index idx_api_requests_user_created on public.api_requests(user_id, created_at desc);

-- Mobile sessions indexes
create index idx_mobile_sessions_user_device on public.mobile_sessions(user_id, device_id);
create index idx_mobile_sessions_start on public.mobile_sessions(session_start desc);

-- Revenue stats indexes
create index idx_revenue_stats_date on public.revenue_stats(date desc);
create index idx_revenue_real_time_window on public.revenue_real_time(time_window desc);

-- AI model usage indexes
create index idx_ai_model_usage_date on public.ai_model_usage(date desc);
create index idx_ai_model_usage_model on public.ai_model_usage(model_name, service_type);

-- Security logs indexes
create index idx_security_logs_created_at on public.security_logs(created_at desc);
create index idx_security_logs_user_id on public.security_logs(user_id);
create index idx_security_logs_severity on public.security_logs(severity);

-- =====================================================
-- 🔄 FUNCTIONS & TRIGGERS
-- =====================================================

-- Function to update user profile timestamp
create or replace function public.update_updated_at_column()
returns trigger as $$
begin
    new.updated_at = now();
    return new;
end;
$$ language plpgsql;

-- Trigger for user profiles
create trigger update_user_profiles_updated_at
    before update on public.user_profiles
    for each row execute function public.update_updated_at_column();

-- Function to automatically update revenue stats
create or replace function public.update_revenue_stats()
returns trigger as $$
begin
    -- Update daily revenue stats
    insert into public.revenue_stats (date, total_requests, total_revenue_usd, successful_requests, failed_requests)
    values (
        current_date,
        1,
        case when new.success then new.cost_usd else 0 end,
        case when new.success then 1 else 0 end,
        case when not new.success then 1 else 0 end
    )
    on conflict (date) do update set
        total_requests = revenue_stats.total_requests + 1,
        total_revenue_usd = revenue_stats.total_revenue_usd + (case when new.success then new.cost_usd else 0 end),
        successful_requests = revenue_stats.successful_requests + (case when new.success then 1 else 0 end),
        failed_requests = revenue_stats.failed_requests + (case when not new.success then 1 else 0 end);
    
    -- Update real-time stats (5-minute windows)
    insert into public.revenue_real_time (time_window, requests_count, revenue_usd)
    values (
        date_trunc('hour', now()) + interval '5 minutes' * floor(extract(minute from now()) / 5),
        1,
        case when new.success then new.cost_usd else 0 end
    )
    on conflict (time_window) do update set
        requests_count = revenue_real_time.requests_count + 1,
        revenue_usd = revenue_real_time.revenue_usd + (case when new.success then new.cost_usd else 0 end);
    
    -- Update user monthly usage
    if new.user_id is not null then
        update public.user_profiles 
        set 
            current_month_usage = current_month_usage + 1,
            total_lifetime_usage = total_lifetime_usage + 1
        where id = new.user_id;
    end if;
    
    return new;
end;
$$ language plpgsql;

-- Trigger for automatic revenue tracking
create trigger update_revenue_stats_trigger
    after insert on public.api_requests
    for each row execute function public.update_revenue_stats();

-- Function to track AI model usage
create or replace function public.track_ai_model_usage()
returns trigger as $$
begin
    if new.ai_model_used is not null and new.success then
        insert into public.ai_model_usage (
            model_name, 
            model_type, 
            service_type, 
            usage_count, 
            success_count,
            avg_processing_time_ms,
            avg_cost_usd
        )
        values (
            new.ai_model_used,
            case 
                when new.service_type in ('text_generation', 'sentiment_analysis', 'text_classification', 'question_answering', 'summarization') then 'text'
                when new.service_type = 'image_classification' then 'image'
                else 'unknown'
            end,
            new.service_type,
            1,
            1,
            new.processing_time_ms,
            new.cost_usd
        )
        on conflict (model_name, service_type, date) do update set
            usage_count = ai_model_usage.usage_count + 1,
            success_count = ai_model_usage.success_count + 1,
            avg_processing_time_ms = (ai_model_usage.avg_processing_time_ms * ai_model_usage.usage_count + new.processing_time_ms) / (ai_model_usage.usage_count + 1),
            avg_cost_usd = (ai_model_usage.avg_cost_usd * ai_model_usage.usage_count + new.cost_usd) / (ai_model_usage.usage_count + 1);
    end if;
    
    return new;
end;
$$ language plpgsql;

-- Trigger for AI model usage tracking
create trigger track_ai_model_usage_trigger
    after insert on public.api_requests
    for each row execute function public.track_ai_model_usage();

-- =====================================================
-- 🔒 ROW LEVEL SECURITY (RLS)
-- =====================================================

-- Enable RLS on all tables
alter table public.user_profiles enable row level security;
alter table public.api_requests enable row level security;
alter table public.mobile_sessions enable row level security;
alter table public.quantum_usage enable row level security;

-- RLS Policies for user_profiles
create policy "Users can view own profile" on public.user_profiles
    for select using (auth.uid() = id);

create policy "Users can update own profile" on public.user_profiles
    for update using (auth.uid() = id);

create policy "Enable insert for authenticated users only" on public.user_profiles
    for insert with check (auth.role() = 'authenticated');

-- RLS Policies for api_requests
create policy "Users can view own requests" on public.api_requests
    for select using (auth.uid() = user_id);

create policy "System can insert all requests" on public.api_requests
    for insert with check (true);

-- RLS Policies for mobile_sessions
create policy "Users can view own sessions" on public.mobile_sessions
    for select using (auth.uid() = user_id);

create policy "Users can insert own sessions" on public.mobile_sessions
    for insert with check (auth.uid() = user_id);

-- RLS Policies for quantum_usage
create policy "Users can view own quantum usage" on public.quantum_usage
    for select using (auth.uid() = user_id);

-- =====================================================
-- 📈 VIEWS FOR ANALYTICS
-- =====================================================

-- User dashboard view
create view public.user_dashboard as
select 
    up.id,
    up.username,
    up.subscription_tier,
    up.monthly_request_limit,
    up.current_month_usage,
    round((up.current_month_usage::numeric / up.monthly_request_limit * 100), 2) as usage_percentage,
    up.total_lifetime_usage,
    
    -- Current month stats
    coalesce(current_month.total_requests, 0) as month_requests,
    coalesce(current_month.total_cost, 0) as month_cost_usd,
    coalesce(current_month.success_rate, 0) as month_success_rate,
    
    -- All-time stats
    coalesce(lifetime.total_requests, 0) as lifetime_requests,
    coalesce(lifetime.total_cost, 0) as lifetime_cost_usd,
    coalesce(lifetime.avg_response_time, 0) as avg_response_time_ms
    
from public.user_profiles up
left join lateral (
    select 
        count(*) as total_requests,
        sum(cost_usd) as total_cost,
        round(avg(case when success then 1.0 else 0.0 end), 4) as success_rate
    from public.api_requests ar 
    where ar.user_id = up.id 
    and ar.created_at >= date_trunc('month', current_date)
) current_month on true
left join lateral (
    select 
        count(*) as total_requests,
        sum(cost_usd) as total_cost,
        round(avg(processing_time_ms), 2) as avg_response_time
    from public.api_requests ar 
    where ar.user_id = up.id
) lifetime on true;

-- Revenue analytics view
create view public.revenue_analytics as
select 
    date,
    total_requests,
    successful_requests,
    failed_requests,
    round(successful_requests::numeric / nullif(total_requests, 0) * 100, 2) as success_rate_pct,
    total_revenue_usd,
    round(total_revenue_usd / nullif(successful_requests, 0), 6) as avg_revenue_per_request,
    unique_users,
    round(total_revenue_usd / nullif(unique_users, 0), 2) as avg_revenue_per_user,
    mobile_requests + desktop_requests + api_requests as total_device_requests,
    round(mobile_requests::numeric / nullif(mobile_requests + desktop_requests + api_requests, 0) * 100, 2) as mobile_usage_pct
from public.revenue_stats
order by date desc;

-- =====================================================
-- 🎯 INITIAL DATA & ADMIN SETUP
-- =====================================================

-- Create admin user function (call after first user signup)
create or replace function public.setup_admin_user(user_email text)
returns void as $$
begin
    update public.user_profiles 
    set 
        subscription_tier = 'enterprise',
        monthly_request_limit = 1000000
    where id = (
        select id from auth.users 
        where email = user_email 
        limit 1
    );
end;
$$ language plpgsql security definer;

-- =====================================================
-- ✅ SCHEMA CREATION COMPLETE
-- =====================================================

-- Log schema creation
insert into public.security_logs (event_type, severity, description, metadata)
values (
    'schema_creation', 
    'low', 
    'OASIS v3 database schema created successfully',
    jsonb_build_object(
        'version', '3.0.0',
        'tables_created', 10,
        'indexes_created', 15,
        'functions_created', 5,
        'triggers_created', 3,
        'views_created', 2
    )
);