#!/usr/bin/env python3
"""
🚀 OASIS v3 - Termux Orchestrator
Ultra-Lightweight AI Client for Android/Termux

Lead Engineer: AI Assistant  
Architecture: <5MB footprint, zero heavy dependencies
Dependencies: Python3 + urllib + json (built-in only)
Target: All AI processing via HuggingFace Spaces API
Business Model: Mobile-first AI superintelligence access
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import sys
import os
import time
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any
import sqlite3
import uuid

# 🔧 CONFIGURATION
class OASISConfig:
    """Ultra-lightweight configuration management"""
    
    def __init__(self):
        self.config_file = os.path.expanduser("~/.oasis_config.json")
        self.load_config()
    
    def load_config(self):
        """Load configuration from file"""
        default_config = {
            "hf_space_url": "https://your-username-oasis-v3.hf.space",
            "api_key": "",
            "user_id": str(uuid.uuid4()),
            "cache_enabled": True,
            "max_retries": 3,
            "timeout": 30,
            "revenue_tracking": True,
            "auto_update": True,
            "theme": "dark",
            "mobile_mode": True
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    loaded_config = json.load(f)
                    default_config.update(loaded_config)
        except Exception as e:
            print(f"⚠️  Config load error: {e}")
        
        self.config = default_config
        self.save_config()
    
    def save_config(self):
        """Save configuration to file"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"⚠️  Config save error: {e}")
    
    def get(self, key: str, default=None):
        """Get configuration value"""
        return self.config.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set configuration value"""
        self.config[key] = value
        self.save_config()

# 🌐 API CLIENT
class OASISAPIClient:
    """Ultra-lightweight API client using only urllib"""
    
    def __init__(self, config: OASISConfig):
        self.config = config
        self.base_url = config.get("hf_space_url")
        self.api_key = config.get("api_key")
        self.timeout = config.get("timeout", 30)
        self.max_retries = config.get("max_retries", 3)
    
    def make_request(self, endpoint: str, data: Dict = None, method: str = "GET") -> Dict:
        """Make HTTP request with retry logic"""
        url = f"{self.base_url}/api/v1/{endpoint}"
        
        # Prepare request data
        if data:
            json_data = json.dumps(data).encode('utf-8')
        else:
            json_data = None
        
        # Create request
        req = urllib.request.Request(url, data=json_data, method=method)
        req.add_header('Content-Type', 'application/json')
        
        if self.api_key:
            req.add_header('Authorization', f'Bearer {self.api_key}')
        
        # Retry logic
        for attempt in range(self.max_retries):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    result = json.loads(response.read().decode('utf-8'))
                    return result
            
            except urllib.error.HTTPError as e:
                error_msg = f"HTTP {e.code}: {e.reason}"
                if attempt == self.max_retries - 1:
                    return {"error": error_msg, "status": "failed"}
                time.sleep(1 * (attempt + 1))  # Exponential backoff
            
            except urllib.error.URLError as e:
                error_msg = f"Network error: {e.reason}"
                if attempt == self.max_retries - 1:
                    return {"error": error_msg, "status": "failed"}
                time.sleep(1 * (attempt + 1))
            
            except Exception as e:
                error_msg = f"Request error: {str(e)}"
                if attempt == self.max_retries - 1:
                    return {"error": error_msg, "status": "failed"}
                time.sleep(1 * (attempt + 1))
        
        return {"error": "Max retries exceeded", "status": "failed"}
    
    def generate_text(self, prompt: str, max_length: int = 100) -> Dict:
        """Generate text via API"""
        data = {"text": prompt, "max_length": max_length}
        return self.make_request("generate", data, "POST")
    
    def analyze_sentiment(self, text: str) -> Dict:
        """Analyze sentiment via API"""
        data = {"text": text}
        return self.make_request("sentiment", data, "POST")
    
    def classify_text(self, text: str, labels: str) -> Dict:
        """Classify text via API"""
        data = {"text": text, "labels": labels}
        return self.make_request("classify", data, "POST")
    
    def answer_question(self, context: str, question: str) -> Dict:
        """Answer question via API"""
        data = {"context": context, "question": question}
        return self.make_request("qa", data, "POST")
    
    def summarize_text(self, text: str, max_length: int = 130) -> Dict:
        """Summarize text via API"""
        data = {"text": text, "max_length": max_length}
        return self.make_request("summarize", data, "POST")
    
    def get_revenue_stats(self) -> Dict:
        """Get revenue statistics"""
        return self.make_request("revenue")
    
    def health_check(self) -> Dict:
        """Check API health"""
        try:
            return self.make_request("../health")
        except:
            return {"status": "unhealthy"}

# 💰 LOCAL REVENUE TRACKING
class MobileRevenueTracker:
    """Lightweight revenue tracking for mobile"""
    
    def __init__(self):
        self.db_path = os.path.expanduser("~/.oasis_revenue_mobile.db")
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS mobile_sessions (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT,
                    service_type TEXT,
                    estimated_cost REAL,
                    success BOOLEAN,
                    response_time REAL
                )
            ''')
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"⚠️  Database init error: {e}")
    
    def log_session(self, service_type: str, cost: float, success: bool, response_time: float):
        """Log API session"""
        try:
            session_id = str(uuid.uuid4())[:8]
            timestamp = datetime.now().isoformat()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO mobile_sessions 
                (id, timestamp, service_type, estimated_cost, success, response_time)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (session_id, timestamp, service_type, cost, success, response_time))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"⚠️  Session log error: {e}")
    
    def get_stats(self) -> Dict:
        """Get usage statistics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Total sessions and costs
            cursor.execute("SELECT COUNT(*), SUM(estimated_cost) FROM mobile_sessions")
            total_sessions, total_cost = cursor.fetchone()
            
            # Success rate
            cursor.execute("SELECT COUNT(*) FROM mobile_sessions WHERE success = 1")
            successful_sessions = cursor.fetchone()[0]
            
            # Average response time
            cursor.execute("SELECT AVG(response_time) FROM mobile_sessions")
            avg_response_time = cursor.fetchone()[0] or 0
            
            conn.close()
            
            success_rate = (successful_sessions / total_sessions * 100) if total_sessions > 0 else 0
            
            return {
                "total_sessions": total_sessions or 0,
                "total_cost": total_cost or 0,
                "success_rate": success_rate,
                "avg_response_time": avg_response_time
            }
        except Exception as e:
            print(f"⚠️  Stats error: {e}")
            return {"total_sessions": 0, "total_cost": 0, "success_rate": 0, "avg_response_time": 0}

# 🎨 CLI INTERFACE
class OASISTerminalInterface:
    """Beautiful terminal interface for mobile"""
    
    def __init__(self):
        self.config = OASISConfig()
        self.api_client = OASISAPIClient(self.config)
        self.revenue_tracker = MobileRevenueTracker()
        
        # Colors for terminal (ANSI codes)
        self.colors = {
            'HEADER': '\033[95m',
            'OKBLUE': '\033[94m',
            'OKCYAN': '\033[96m',
            'OKGREEN': '\033[92m',
            'WARNING': '\033[93m',
            'FAIL': '\033[91m',
            'ENDC': '\033[0m',
            'BOLD': '\033[1m',
            'UNDERLINE': '\033[4m',
        }
    
    def print_colored(self, text: str, color: str = 'ENDC'):
        """Print colored text"""
        print(f"{self.colors.get(color, '')}{text}{self.colors['ENDC']}")
    
    def print_banner(self):
        """Print OASIS banner"""
        banner = """
🚀════════════════════════════════════════════════════════════════════🚀
   ██████╗  █████╗ ███████╗██╗███████╗    ██╗   ██╗██████╗ 
  ██╔═══██╗██╔══██╗██╔════╝██║██╔════╝    ██║   ██║╚════██╗
  ██║   ██║███████║███████╗██║███████╗    ██║   ██║ █████╔╝
  ██║   ██║██╔══██║╚════██║██║╚════██║    ╚██╗ ██╔╝ ╚═══██╗
  ╚██████╔╝██║  ██║███████║██║███████║     ╚████╔╝ ██████╔╝
   ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝      ╚═══╝  ╚═════╝ 

🌟 AI SUPERINTELLIGENCE ECOSYSTEM • MOBILE-FIRST • ZERO-COST 🌟
⚡ Ultra-Lightweight Termux Client • <5MB Footprint • Revenue-Ready ⚡
🚀════════════════════════════════════════════════════════════════════🚀
        """
        self.print_colored(banner, 'OKBLUE')
    
    def show_main_menu(self):
        """Display main menu"""
        self.print_colored("\n📋 OASIS v3 - Main Menu", 'HEADER')
        self.print_colored("=" * 50, 'OKBLUE')
        
        menu_items = [
            "1. 💬 Text Generation",
            "2. 😊 Sentiment Analysis", 
            "3. 🏷️  Text Classification",
            "4. ❓ Question Answering",
            "5. 📝 Text Summarization",
            "6. 💰 Revenue Dashboard",
            "7. ⚙️  Settings",
            "8. 🔄 Health Check", 
            "9. 📊 Usage Statistics",
            "0. 🚪 Exit"
        ]
        
        for item in menu_items:
            self.print_colored(f"   {item}", 'OKCYAN')
        
        self.print_colored("=" * 50, 'OKBLUE')
    
    def get_user_input(self, prompt: str) -> str:
        """Get user input with colored prompt"""
        self.print_colored(f"\n{prompt}", 'OKGREEN')
        return input("👉 ").strip()
    
    def handle_text_generation(self):
        """Handle text generation"""
        self.print_colored("\n💬 Text Generation Service", 'HEADER')
        prompt = self.get_user_input("Enter your prompt:")
        
        if not prompt:
            self.print_colored("❌ Empty prompt!", 'FAIL')
            return
        
        max_length = self.get_user_input("Max length (50-200) [100]:")
        try:
            max_length = int(max_length) if max_length else 100
            max_length = max(50, min(200, max_length))
        except:
            max_length = 100
        
        self.print_colored("🔄 Generating text...", 'WARNING')
        start_time = time.time()
        
        result = self.api_client.generate_text(prompt, max_length)
        response_time = time.time() - start_time
        
        if result.get("status") == "success":
            self.print_colored("\n✅ Generation Complete!", 'OKGREEN')
            self.print_colored(f"📝 Result:\n{result.get('result', 'No result')}", 'ENDC')
            self.revenue_tracker.log_session("text_generation", result.get('cost', 0.02), True, response_time)
        else:
            self.print_colored(f"❌ Error: {result.get('error', 'Unknown error')}", 'FAIL')
            self.revenue_tracker.log_session("text_generation", 0, False, response_time)
    
    def handle_sentiment_analysis(self):
        """Handle sentiment analysis"""
        self.print_colored("\n😊 Sentiment Analysis Service", 'HEADER')
        text = self.get_user_input("Enter text to analyze:")
        
        if not text:
            self.print_colored("❌ Empty text!", 'FAIL')
            return
        
        self.print_colored("🔄 Analyzing sentiment...", 'WARNING')
        start_time = time.time()
        
        result = self.api_client.analyze_sentiment(text)
        response_time = time.time() - start_time
        
        if result.get("status") == "success":
            self.print_colored("\n✅ Analysis Complete!", 'OKGREEN')
            self.print_colored(f"📊 Result:\n{result.get('result', 'No result')}", 'ENDC')
            self.revenue_tracker.log_session("sentiment_analysis", result.get('cost', 0.005), True, response_time)
        else:
            self.print_colored(f"❌ Error: {result.get('error', 'Unknown error')}", 'FAIL')
            self.revenue_tracker.log_session("sentiment_analysis", 0, False, response_time)
    
    def handle_text_classification(self):
        """Handle text classification"""
        self.print_colored("\n🏷️ Text Classification Service", 'HEADER')
        text = self.get_user_input("Enter text to classify:")
        
        if not text:
            self.print_colored("❌ Empty text!", 'FAIL')
            return
        
        labels = self.get_user_input("Enter categories (comma-separated):")
        if not labels:
            labels = "positive,negative,neutral"
        
        self.print_colored("🔄 Classifying text...", 'WARNING')
        start_time = time.time()
        
        result = self.api_client.classify_text(text, labels)
        response_time = time.time() - start_time
        
        if result.get("status") == "success":
            self.print_colored("\n✅ Classification Complete!", 'OKGREEN')
            self.print_colored(f"🏷️ Result:\n{result.get('result', 'No result')}", 'ENDC')
            self.revenue_tracker.log_session("text_classification", result.get('cost', 0.01), True, response_time)
        else:
            self.print_colored(f"❌ Error: {result.get('error', 'Unknown error')}", 'FAIL')
            self.revenue_tracker.log_session("text_classification", 0, False, response_time)
    
    def handle_question_answering(self):
        """Handle question answering"""
        self.print_colored("\n❓ Question Answering Service", 'HEADER')
        context = self.get_user_input("Enter context:")
        
        if not context:
            self.print_colored("❌ Empty context!", 'FAIL')
            return
        
        question = self.get_user_input("Enter question:")
        if not question:
            self.print_colored("❌ Empty question!", 'FAIL')
            return
        
        self.print_colored("🔄 Finding answer...", 'WARNING')
        start_time = time.time()
        
        result = self.api_client.answer_question(context, question)
        response_time = time.time() - start_time
        
        if result.get("status") == "success":
            self.print_colored("\n✅ Answer Found!", 'OKGREEN')
            self.print_colored(f"💡 Result:\n{result.get('result', 'No result')}", 'ENDC')
            self.revenue_tracker.log_session("question_answering", result.get('cost', 0.015), True, response_time)
        else:
            self.print_colored(f"❌ Error: {result.get('error', 'Unknown error')}", 'FAIL')
            self.revenue_tracker.log_session("question_answering", 0, False, response_time)
    
    def handle_summarization(self):
        """Handle text summarization"""
        self.print_colored("\n📝 Text Summarization Service", 'HEADER')
        text = self.get_user_input("Enter text to summarize:")
        
        if not text:
            self.print_colored("❌ Empty text!", 'FAIL')
            return
        
        max_length = self.get_user_input("Summary length (50-200) [130]:")
        try:
            max_length = int(max_length) if max_length else 130
            max_length = max(50, min(200, max_length))
        except:
            max_length = 130
        
        self.print_colored("🔄 Summarizing text...", 'WARNING')
        start_time = time.time()
        
        result = self.api_client.summarize_text(text, max_length)
        response_time = time.time() - start_time
        
        if result.get("status") == "success":
            self.print_colored("\n✅ Summarization Complete!", 'OKGREEN')
            self.print_colored(f"📋 Result:\n{result.get('result', 'No result')}", 'ENDC')
            self.revenue_tracker.log_session("summarization", result.get('cost', 0.02), True, response_time)
        else:
            self.print_colored(f"❌ Error: {result.get('error', 'Unknown error')}", 'FAIL')
            self.revenue_tracker.log_session("summarization", 0, False, response_time)
    
    def show_revenue_dashboard(self):
        """Show revenue dashboard"""
        self.print_colored("\n💰 Revenue Dashboard", 'HEADER')
        self.print_colored("=" * 50, 'OKBLUE')
        
        # Remote revenue stats
        self.print_colored("🔄 Fetching remote revenue data...", 'WARNING')
        remote_stats = self.api_client.get_revenue_stats()
        
        if remote_stats.get("status") == "success":
            stats = remote_stats.get("revenue_stats", {})
            self.print_colored(f"💰 Total Revenue: ${stats.get('total_revenue', 0):.3f}", 'OKGREEN')
            self.print_colored(f"📈 Today's Revenue: ${stats.get('today_revenue', 0):.3f}", 'OKGREEN')
            self.print_colored(f"🎯 Monthly Projection: ${stats.get('projected_monthly', 0):.2f}", 'OKGREEN')
        else:
            self.print_colored("⚠️ Remote revenue data unavailable", 'WARNING')
        
        # Local usage stats  
        local_stats = self.revenue_tracker.get_stats()
        self.print_colored("\n📱 Mobile Usage Statistics:", 'OKCYAN')
        self.print_colored(f"📊 Total Sessions: {local_stats['total_sessions']}", 'ENDC')
        self.print_colored(f"💸 Estimated Costs: ${local_stats['total_cost']:.3f}", 'ENDC')
        self.print_colored(f"✅ Success Rate: {local_stats['success_rate']:.1f}%", 'ENDC')
        self.print_colored(f"⚡ Avg Response: {local_stats['avg_response_time']:.2f}s", 'ENDC')
    
    def show_settings(self):
        """Show settings menu"""
        self.print_colored("\n⚙️ Settings", 'HEADER')
        self.print_colored("=" * 50, 'OKBLUE')
        
        current_url = self.config.get("hf_space_url")
        self.print_colored(f"🌐 HF Space URL: {current_url}", 'ENDC')
        
        if self.get_user_input("Update HF Space URL? (y/n)").lower() == 'y':
            new_url = self.get_user_input("Enter new URL:")
            if new_url:
                self.config.set("hf_space_url", new_url)
                self.api_client.base_url = new_url
                self.print_colored("✅ URL updated!", 'OKGREEN')
        
        # API Key setup
        if self.get_user_input("Setup API Key? (y/n)").lower() == 'y':
            api_key = self.get_user_input("Enter API Key:")
            self.config.set("api_key", api_key)
            self.api_client.api_key = api_key
            self.print_colored("✅ API Key saved!", 'OKGREEN')
        
        # Theme toggle
        current_theme = self.config.get("theme", "dark")
        if self.get_user_input(f"Toggle theme? Current: {current_theme} (y/n)").lower() == 'y':
            new_theme = "light" if current_theme == "dark" else "dark"
            self.config.set("theme", new_theme)
            self.print_colored(f"✅ Theme set to {new_theme}!", 'OKGREEN')
    
    def health_check(self):
        """Perform health check"""
        self.print_colored("\n🔄 Performing Health Check...", 'HEADER')
        
        result = self.api_client.health_check()
        
        if result.get("status") == "healthy":
            self.print_colored("✅ OASIS v3 is HEALTHY and OPERATIONAL!", 'OKGREEN')
            self.print_colored(f"🌟 Service: {result.get('service', 'Unknown')}", 'OKCYAN')
        else:
            self.print_colored("❌ OASIS v3 is UNHEALTHY", 'FAIL')
            self.print_colored("🔧 Check your internet connection and HF Space URL", 'WARNING')
    
    def show_usage_statistics(self):
        """Show detailed usage statistics"""
        self.print_colored("\n📊 Detailed Usage Statistics", 'HEADER')
        self.print_colored("=" * 50, 'OKBLUE')
        
        stats = self.revenue_tracker.get_stats()
        
        self.print_colored("📱 Mobile Session Analytics:", 'OKCYAN')
        self.print_colored(f"   Total API Calls: {stats['total_sessions']}", 'ENDC')
        self.print_colored(f"   Success Rate: {stats['success_rate']:.1f}%", 'ENDC')
        self.print_colored(f"   Average Response Time: {stats['avg_response_time']:.2f} seconds", 'ENDC')
        self.print_colored(f"   Total Estimated Cost: ${stats['total_cost']:.3f}", 'ENDC')
        
        if stats['total_sessions'] > 0:
            avg_cost = stats['total_cost'] / stats['total_sessions']
            self.print_colored(f"   Average Cost per Request: ${avg_cost:.4f}", 'ENDC')
            
            # Projection
            daily_projection = stats['total_cost'] * (24 / (stats['avg_response_time'] / 3600))
            self.print_colored(f"   Daily Cost Projection: ${daily_projection:.2f}", 'WARNING')
    
    def run(self):
        """Main application loop"""
        try:
            self.print_banner()
            
            while True:
                self.show_main_menu()
                choice = self.get_user_input("Select option (0-9):")
                
                if choice == "1":
                    self.handle_text_generation()
                elif choice == "2":
                    self.handle_sentiment_analysis()
                elif choice == "3":
                    self.handle_text_classification()
                elif choice == "4":
                    self.handle_question_answering()
                elif choice == "5":
                    self.handle_summarization()
                elif choice == "6":
                    self.show_revenue_dashboard()
                elif choice == "7":
                    self.show_settings()
                elif choice == "8":
                    self.health_check()
                elif choice == "9":
                    self.show_usage_statistics()
                elif choice == "0":
                    self.print_colored("\n👋 Exiting OASIS v3. Thank you!", 'OKGREEN')
                    break
                else:
                    self.print_colored("❌ Invalid option! Please try again.", 'FAIL')
                
                # Pause before next menu
                input("\nPress Enter to continue...")
                
        except KeyboardInterrupt:
            self.print_colored("\n\n👋 OASIS v3 terminated by user. Goodbye!", 'WARNING')
        except Exception as e:
            self.print_colored(f"\n💥 Fatal error: {str(e)}", 'FAIL')
            sys.exit(1)

# 🚀 MAIN ENTRY POINT
def main():
    """Main entry point for OASIS Termux Orchestrator"""
    
    # Check Python version
    if sys.version_info < (3, 6):
        print("❌ Python 3.6+ required!")
        sys.exit(1)
    
    # Welcome message
    print("🚀 Starting OASIS v3 Termux Orchestrator...")
    
    try:
        # Initialize and run interface
        interface = OASISTerminalInterface()
        interface.run()
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Install missing dependencies: pip install requests")
        sys.exit(1)
    except Exception as e:
        print(f"💥 Startup error: {e}")
        sys.exit(1)

# CLI Entry Points for direct usage
if __name__ == "__main__":
    main()

# 🔧 UTILITY FUNCTIONS FOR DIRECT USAGE
def quick_generate(prompt: str, hf_url: str = None) -> str:
    """Quick text generation without full interface"""
    config = OASISConfig()
    if hf_url:
        config.set("hf_space_url", hf_url)
    
    client = OASISAPIClient(config)
    result = client.generate_text(prompt)
    
    if result.get("status") == "success":
        return result.get("result", "No result")
    else:
        return f"Error: {result.get('error', 'Unknown error')}"

def quick_sentiment(text: str, hf_url: str = None) -> str:
    """Quick sentiment analysis without full interface"""
    config = OASISConfig()
    if hf_url:
        config.set("hf_space_url", hf_url)
    
    client = OASISAPIClient(config)
    result = client.analyze_sentiment(text)
    
    if result.get("status") == "success":
        return result.get("result", "No result")
    else:
        return f"Error: {result.get('error', 'Unknown error')}"

# 📱 ALIASES FOR TERMUX
def oasis():
    """Alias for main function"""
    main()

def oasis_generate(prompt):
    """Alias for quick generation"""
    return quick_generate(prompt)

def oasis_sentiment(text):
    """Alias for quick sentiment"""
    return quick_sentiment(text)