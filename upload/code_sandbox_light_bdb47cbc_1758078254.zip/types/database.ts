/**
 * 🗄️ OASIS v3 - Database Types
 * Auto-generated from Supabase schema
 * Lead Engineer: AI Assistant
 */

export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string
          username: string | null
          full_name: string | null
          avatar_url: string | null
          bio: string | null
          website: string | null
          subscription_tier: 'free' | 'pro' | 'enterprise'
          subscription_start: string | null
          subscription_end: string | null
          monthly_request_limit: number
          current_month_usage: number
          total_lifetime_usage: number
          api_key: string | null
          api_key_created_at: string | null
          api_key_last_used: string | null
          termux_device_id: string | null
          mobile_preferences: any | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          website?: string | null
          subscription_tier?: 'free' | 'pro' | 'enterprise'
          subscription_start?: string | null
          subscription_end?: string | null
          monthly_request_limit?: number
          current_month_usage?: number
          total_lifetime_usage?: number
          api_key?: string | null
          api_key_created_at?: string | null
          api_key_last_used?: string | null
          termux_device_id?: string | null
          mobile_preferences?: any | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          website?: string | null
          subscription_tier?: 'free' | 'pro' | 'enterprise'
          subscription_start?: string | null
          subscription_end?: string | null
          monthly_request_limit?: number
          current_month_usage?: number
          total_lifetime_usage?: number
          api_key?: string | null
          api_key_created_at?: string | null
          api_key_last_used?: string | null
          termux_device_id?: string | null
          mobile_preferences?: any | null
          created_at?: string
          updated_at?: string
        }
      }
      subscription_tiers: {
        Row: {
          tier_name: string
          monthly_request_limit: number
          rate_limit_per_minute: number
          features: any
          price_usd: number
          description: string | null
          active: boolean
        }
        Insert: {
          tier_name: string
          monthly_request_limit: number
          rate_limit_per_minute: number
          features?: any
          price_usd?: number
          description?: string | null
          active?: boolean
        }
        Update: {
          tier_name?: string
          monthly_request_limit?: number
          rate_limit_per_minute?: number
          features?: any
          price_usd?: number
          description?: string | null
          active?: boolean
        }
      }
      api_requests: {
        Row: {
          id: string
          user_id: string | null
          session_id: string | null
          service_type: 'text_generation' | 'sentiment_analysis' | 'text_classification' | 'question_answering' | 'summarization' | 'image_classification'
          endpoint: string
          method: string
          request_data: any | null
          response_data: any | null
          request_size_bytes: number | null
          response_size_bytes: number | null
          processing_time_ms: number | null
          queue_time_ms: number | null
          cost_usd: number
          billing_tier: string | null
          status_code: number
          success: boolean
          error_message: string | null
          error_code: string | null
          ai_model_used: string | null
          backend_used: string | null
          ip_address: string | null
          user_agent: string | null
          device_type: string | null
          country_code: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          session_id?: string | null
          service_type: 'text_generation' | 'sentiment_analysis' | 'text_classification' | 'question_answering' | 'summarization' | 'image_classification'
          endpoint: string
          method?: string
          request_data?: any | null
          response_data?: any | null
          request_size_bytes?: number | null
          response_size_bytes?: number | null
          processing_time_ms?: number | null
          queue_time_ms?: number | null
          cost_usd: number
          billing_tier?: string | null
          status_code: number
          success: boolean
          error_message?: string | null
          error_code?: string | null
          ai_model_used?: string | null
          backend_used?: string | null
          ip_address?: string | null
          user_agent?: string | null
          device_type?: string | null
          country_code?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          session_id?: string | null
          service_type?: 'text_generation' | 'sentiment_analysis' | 'text_classification' | 'question_answering' | 'summarization' | 'image_classification'
          endpoint?: string
          method?: string
          request_data?: any | null
          response_data?: any | null
          request_size_bytes?: number | null
          response_size_bytes?: number | null
          processing_time_ms?: number | null
          queue_time_ms?: number | null
          cost_usd?: number
          billing_tier?: string | null
          status_code?: number
          success?: boolean
          error_message?: string | null
          error_code?: string | null
          ai_model_used?: string | null
          backend_used?: string | null
          ip_address?: string | null
          user_agent?: string | null
          device_type?: string | null
          country_code?: string | null
          created_at?: string
        }
      }
      mobile_sessions: {
        Row: {
          id: string
          user_id: string | null
          device_id: string
          device_info: any | null
          termux_version: string | null
          android_version: string | null
          app_version: string | null
          session_start: string
          session_end: string | null
          total_requests: number | null
          successful_requests: number | null
          total_cost_usd: number | null
          avg_response_time_ms: number | null
          total_data_uploaded_mb: number | null
          total_data_downloaded_mb: number | null
          country_code: string | null
          network_type: string | null
        }
        Insert: {
          id?: string
          user_id?: string | null
          device_id: string
          device_info?: any | null
          termux_version?: string | null
          android_version?: string | null
          app_version?: string | null
          session_start?: string
          session_end?: string | null
          total_requests?: number | null
          successful_requests?: number | null
          total_cost_usd?: number | null
          avg_response_time_ms?: number | null
          total_data_uploaded_mb?: number | null
          total_data_downloaded_mb?: number | null
          country_code?: string | null
          network_type?: string | null
        }
        Update: {
          id?: string
          user_id?: string | null
          device_id?: string
          device_info?: any | null
          termux_version?: string | null
          android_version?: string | null
          app_version?: string | null
          session_start?: string
          session_end?: string | null
          total_requests?: number | null
          successful_requests?: number | null
          total_cost_usd?: number | null
          avg_response_time_ms?: number | null
          total_data_uploaded_mb?: number | null
          total_data_downloaded_mb?: number | null
          country_code?: string | null
          network_type?: string | null
        }
      }
      revenue_stats: {
        Row: {
          id: string
          date: string
          total_requests: number | null
          successful_requests: number | null
          failed_requests: number | null
          unique_users: number | null
          new_users: number | null
          total_revenue_usd: number | null
          revenue_by_tier: any | null
          revenue_by_service: any | null
          avg_response_time_ms: number | null
          p95_response_time_ms: number | null
          mobile_requests: number | null
          desktop_requests: number | null
          api_requests: number | null
          created_at: string
        }
        Insert: {
          id?: string
          date?: string
          total_requests?: number | null
          successful_requests?: number | null
          failed_requests?: number | null
          unique_users?: number | null
          new_users?: number | null
          total_revenue_usd?: number | null
          revenue_by_tier?: any | null
          revenue_by_service?: any | null
          avg_response_time_ms?: number | null
          p95_response_time_ms?: number | null
          mobile_requests?: number | null
          desktop_requests?: number | null
          api_requests?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          date?: string
          total_requests?: number | null
          successful_requests?: number | null
          failed_requests?: number | null
          unique_users?: number | null
          new_users?: number | null
          total_revenue_usd?: number | null
          revenue_by_tier?: any | null
          revenue_by_service?: any | null
          avg_response_time_ms?: number | null
          p95_response_time_ms?: number | null
          mobile_requests?: number | null
          desktop_requests?: number | null
          api_requests?: number | null
          created_at?: string
        }
      }
      revenue_real_time: {
        Row: {
          id: string
          time_window: string
          requests_count: number | null
          revenue_usd: number | null
          unique_users: number | null
          avg_response_time_ms: number | null
          success_rate: number | null
          created_at: string
        }
        Insert: {
          id?: string
          time_window: string
          requests_count?: number | null
          revenue_usd?: number | null
          unique_users?: number | null
          avg_response_time_ms?: number | null
          success_rate?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          time_window?: string
          requests_count?: number | null
          revenue_usd?: number | null
          unique_users?: number | null
          avg_response_time_ms?: number | null
          success_rate?: number | null
          created_at?: string
        }
      }
      ai_model_usage: {
        Row: {
          id: string
          model_name: string
          model_type: string
          service_type: string
          usage_count: number | null
          success_count: number | null
          avg_processing_time_ms: number | null
          avg_cost_usd: number | null
          avg_rating: number | null
          rating_count: number | null
          date: string
        }
        Insert: {
          id?: string
          model_name: string
          model_type: string
          service_type: string
          usage_count?: number | null
          success_count?: number | null
          avg_processing_time_ms?: number | null
          avg_cost_usd?: number | null
          avg_rating?: number | null
          rating_count?: number | null
          date?: string
        }
        Update: {
          id?: string
          model_name?: string
          model_type?: string
          service_type?: string
          usage_count?: number | null
          success_count?: number | null
          avg_processing_time_ms?: number | null
          avg_cost_usd?: number | null
          avg_rating?: number | null
          rating_count?: number | null
          date?: string
        }
      }
      quantum_usage: {
        Row: {
          id: string
          user_id: string | null
          quantum_backend: string
          quantum_algorithm: string | null
          circuit_depth: number | null
          num_qubits: number | null
          quantum_processing_time_ms: number | null
          classical_fallback: boolean | null
          optimization_result: any | null
          success: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          quantum_backend: string
          quantum_algorithm?: string | null
          circuit_depth?: number | null
          num_qubits?: number | null
          quantum_processing_time_ms?: number | null
          classical_fallback?: boolean | null
          optimization_result?: any | null
          success: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          quantum_backend?: string
          quantum_algorithm?: string | null
          circuit_depth?: number | null
          num_qubits?: number | null
          quantum_processing_time_ms?: number | null
          classical_fallback?: boolean | null
          optimization_result?: any | null
          success?: boolean
          created_at?: string
        }
      }
      security_logs: {
        Row: {
          id: string
          event_type: string
          severity: 'low' | 'medium' | 'high' | 'critical'
          description: string
          user_id: string | null
          ip_address: string | null
          user_agent: string | null
          endpoint: string | null
          metadata: any | null
          created_at: string
        }
        Insert: {
          id?: string
          event_type: string
          severity: 'low' | 'medium' | 'high' | 'critical'
          description: string
          user_id?: string | null
          ip_address?: string | null
          user_agent?: string | null
          endpoint?: string | null
          metadata?: any | null
          created_at?: string
        }
        Update: {
          id?: string
          event_type?: string
          severity?: 'low' | 'medium' | 'high' | 'critical'
          description?: string
          user_id?: string | null
          ip_address?: string | null
          user_agent?: string | null
          endpoint?: string | null
          metadata?: any | null
          created_at?: string
        }
      }
    }
    Views: {
      user_dashboard: {
        Row: {
          id: string
          username: string | null
          subscription_tier: 'free' | 'pro' | 'enterprise'
          monthly_request_limit: number
          current_month_usage: number
          usage_percentage: number | null
          total_lifetime_usage: number
          month_requests: number | null
          month_cost_usd: number | null
          month_success_rate: number | null
          lifetime_requests: number | null
          lifetime_cost_usd: number | null
          avg_response_time_ms: number | null
        }
      }
      revenue_analytics: {
        Row: {
          date: string
          total_requests: number | null
          successful_requests: number | null
          failed_requests: number | null
          success_rate_pct: number | null
          total_revenue_usd: number | null
          avg_revenue_per_request: number | null
          unique_users: number | null
          avg_revenue_per_user: number | null
          total_device_requests: number | null
          mobile_usage_pct: number | null
        }
      }
    }
    Functions: {
      update_revenue_stats: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      update_updated_at_column: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      track_ai_model_usage: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      setup_admin_user: {
        Args: {
          user_email: string
        }
        Returns: undefined
      }
    }
    Enums: {
      subscription_tier: 'free' | 'pro' | 'enterprise'
      service_type: 'text_generation' | 'sentiment_analysis' | 'text_classification' | 'question_answering' | 'summarization' | 'image_classification'
      severity_level: 'low' | 'medium' | 'high' | 'critical'
    }
  }
}

// 🎯 Type helpers for better developer experience
export type SubscriptionTier = Database['public']['Enums']['subscription_tier']
export type ServiceType = Database['public']['Enums']['service_type']
export type SeverityLevel = Database['public']['Enums']['severity_level']

// 📊 Analytics types
export type UserDashboard = Database['public']['Views']['user_dashboard']['Row']
export type RevenueAnalytics = Database['public']['Views']['revenue_analytics']['Row']

// 🔄 Helper types for API responses
export interface APIResponse<T> {
  data: T | null
  error: string | null
  success: boolean
  timestamp: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  has_more: boolean
}

// 📱 Mobile-specific types
export interface DeviceInfo {
  user_agent?: string
  screen_width?: number
  screen_height?: number
  device_pixel_ratio?: number
  platform?: string
  language?: string
  timezone?: string
}

export interface MobileSessionMetrics {
  session_duration_minutes: number
  requests_per_minute: number
  data_efficiency_score: number
  battery_impact_estimate: string
}

// 💰 Revenue-specific types
export interface RevenueBreakdown {
  by_service: Record<ServiceType, number>
  by_tier: Record<SubscriptionTier, number>
  by_device: Record<'mobile' | 'desktop' | 'api', number>
  by_hour: Record<string, number>
}

export interface UsageQuota {
  current: number
  limit: number
  percentage: number
  resets_at: string
  overage_cost_per_request: number
}

// ⚛️ Quantum-specific types
export interface QuantumResult {
  backend_used: string
  algorithm: string
  execution_time_ms: number
  classical_fallback: boolean
  optimization_score?: number
  quantum_advantage?: boolean
}

// 🔒 Security types
export interface SecurityEvent {
  type: string
  severity: SeverityLevel
  description: string
  metadata?: Record<string, any>
  automated_response?: string
}