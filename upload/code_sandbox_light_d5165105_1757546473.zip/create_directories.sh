#!/bin/bash
# 🌟 OASIS Revolution - Directory Structure Creator
# Create the complete OASIS ecosystem structure

echo "🏗️ Creating OASIS Revolution directory structure..."

# Create main directories
directories=(
    # Core directories
    "config"
    "logs"
    "data"
    "cache"
    
    # Business directories
    "business"
    "business/customers"
    "business/customers/free"
    "business/customers/premium"
    "business/customers/enterprise"
    "business/revenue"
    "business/revenue/daily"
    "business/revenue/monthly"
    "business/revenue/yearly"
    "business/analytics"
    "business/analytics/usage"
    "business/analytics/performance"
    "business/analytics/growth"
    "business/contracts"
    "business/invoices"
    "business/reports"
    "business/marketing"
    "business/automation"
    
    # Monitoring directories
    "monitoring"
    "monitoring/system"
    "monitoring/performance"
    "monitoring/api"
    "monitoring/business"
    "monitoring/alerts"
    "monitoring/logs"
    "monitoring/reports"
    "monitoring/dashboards"
    "monitoring/realtime"
    
    # Documentation
    "docs"
    "docs/api"
    "docs/guides"
    "docs/tutorials"
    "docs/examples"
    
    # Tests
    "tests"
    "tests/unit"
    "tests/integration"
    "tests/performance"
    "tests/mobile"
    
    # Models and assets
    "models"
    "assets"
    "assets/images"
    "assets/icons"
)

# Create directories
for dir in "${directories[@]}"; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        echo "✅ Created: $dir"
    else
        echo "📁 Exists: $dir"
    fi
done

# Create .gitkeep files for empty directories
for dir in "${directories[@]}"; do
    if [ -z "$(ls -A "$dir" 2>/dev/null)" ]; then
        touch "$dir/.gitkeep"
    fi
done

# Create initial config file if it doesn't exist
if [ ! -f "config/oasis_config.json" ]; then
    cat > config/oasis_config.json << 'EOF'
{
    "version": "2.0.0",
    "name": "OASIS Revolution",
    "description": "Ultra-Lightweight AI System for Termux",
    "api_endpoint": "https://api-inference.huggingface.co/models",
    "models": {
        "chat": "microsoft/DialoGPT-medium",
        "sentiment": "cardiffnlp/twitter-roberta-base-sentiment-latest",
        "qa": "deepset/roberta-base-squad2",
        "summarization": "facebook/bart-large-cnn",
        "translation": "Helsinki-NLP/opus-mt-en-id"
    },
    "limits": {
        "max_tokens": 1000,
        "timeout": 30,
        "retry_attempts": 3
    },
    "business": {
        "free_tier_limit": 100,
        "premium_multiplier": 10,
        "enterprise_multiplier": 100
    },
    "monitoring": {
        "collection_interval": 60,
        "retention_days": 30,
        "dashboard_refresh": 30
    }
}
EOF
    echo "✅ Created initial configuration"
fi

# Make main scripts executable
chmod +x oasis
chmod +x termux_setup.sh
chmod +x scripts/quick_install.sh
chmod +x oasis_core.py
chmod +x hf_controller.py
chmod +x business_engine.py
chmod +x monitoring_dashboard.py

echo ""
echo "🎉 OASIS Revolution directory structure created successfully!"
echo ""
echo "📁 Directory Summary:"
echo "   📊 Business: $(find business -type d | wc -l) directories"
echo "   📈 Monitoring: $(find monitoring -type d | wc -l) directories"  
echo "   📚 Documentation: $(find docs -type d | wc -l) directories"
echo "   🧪 Tests: $(find tests -type d | wc -l) directories"
echo ""
echo "🚀 Ready to launch OASIS Revolution!"
echo "   Run: ./oasis"