#!/usr/bin/env python3
"""
🚀 OASIS HF Controller - Advanced Hugging Face API Management
Ultra-Lightweight Business-Ready Controller
Zero Heavy Dependencies - Maximum Performance

The Revolution's Brain Center!
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import time
import os
from datetime import datetime, timedelta
import hashlib
import threading
from typing import Dict, List, Any, Optional

class HFApiController:
    """
    Advanced Hugging Face API Controller
    Business-grade features with ultra-lightweight architecture
    """
    
    def __init__(self, token: str = "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"):
        self.token = token
        self.base_url = "https://api-inference.huggingface.co/models"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "OASIS-Revolution/2.0",
            "X-Wait-For-Model": "true"
        }
        
        # Business tracking
        self.request_count = 0
        self.total_tokens = 0
        self.revenue_generated = 0.0
        self.start_time = time.time()
        
        # Rate limiting
        self.rate_limits = {
            "free_tier": {"requests_per_hour": 1000, "requests_per_day": 10000},
            "premium": {"requests_per_hour": 10000, "requests_per_day": 100000},
            "enterprise": {"requests_per_hour": 50000, "requests_per_day": 1000000}
        }
        
        # Model optimization
        self.model_cache = {}
        self.model_performance = {}
        
        # Initialize business tracking
        self._init_business_tracking()
        
    def _init_business_tracking(self):
        """Initialize business analytics tracking"""
        os.makedirs("business/analytics", exist_ok=True)
        os.makedirs("business/revenue", exist_ok=True)
        os.makedirs("business/customers", exist_ok=True)
        
        # Load existing business data
        self._load_business_data()
    
    def _load_business_data(self):
        """Load existing business analytics"""
        try:
            business_file = "business/analytics/daily_stats.json"
            if os.path.exists(business_file):
                with open(business_file, 'r') as f:
                    data = json.load(f)
                    self.revenue_generated = data.get("total_revenue", 0.0)
                    self.request_count = data.get("total_requests", 0)
        except:
            pass
    
    def query_model_advanced(self, model_name: str, payload: Dict, 
                           tier: str = "free", user_id: str = None) -> Dict:
        """
        Advanced model querying with business features
        """
        # Check rate limits
        if not self._check_rate_limit(tier, user_id):
            return {"error": "Rate limit exceeded", "tier": tier}
        
        # Pre-process payload for optimization
        optimized_payload = self._optimize_payload(payload, model_name)
        
        # Execute request with retry logic
        result = self._execute_request(model_name, optimized_payload)
        
        # Post-process and track business metrics
        self._track_business_metrics(model_name, result, tier, user_id)
        
        return result
    
    def _check_rate_limit(self, tier: str, user_id: str = None) -> bool:
        """Check if request is within rate limits"""
        current_hour = datetime.now().hour
        rate_file = f"business/analytics/rate_limits_{current_hour}.json"
        
        try:
            if os.path.exists(rate_file):
                with open(rate_file, 'r') as f:
                    rates = json.load(f)
            else:
                rates = {}
            
            user_key = user_id or "anonymous"
            current_requests = rates.get(user_key, 0)
            max_requests = self.rate_limits.get(tier, {}).get("requests_per_hour", 100)
            
            if current_requests >= max_requests:
                return False
            
            # Update rate tracking
            rates[user_key] = current_requests + 1
            with open(rate_file, 'w') as f:
                json.dump(rates, f)
                
            return True
            
        except:
            return True  # Allow on error
    
    def _optimize_payload(self, payload: Dict, model_name: str) -> Dict:
        """Optimize payload based on model type and performance data"""
        optimized = payload.copy()
        
        # Model-specific optimizations
        if "gpt" in model_name.lower() or "dialo" in model_name.lower():
            # Chat models
            if "parameters" not in optimized:
                optimized["parameters"] = {}
            optimized["parameters"].update({
                "max_length": min(optimized["parameters"].get("max_length", 512), 512),
                "temperature": optimized["parameters"].get("temperature", 0.7),
                "pad_token_id": 50256
            })
        
        elif "sentiment" in model_name.lower() or "emotion" in model_name.lower():
            # Classification models
            if isinstance(optimized.get("inputs"), str):
                # Truncate long texts for better performance
                optimized["inputs"] = optimized["inputs"][:512]
        
        elif "summarization" in model_name.lower() or "bart" in model_name.lower():
            # Summarization models
            if "parameters" not in optimized:
                optimized["parameters"] = {}
            optimized["parameters"].update({
                "max_length": optimized["parameters"].get("max_length", 150),
                "min_length": optimized["parameters"].get("min_length", 30)
            })
        
        return optimized
    
    def _execute_request(self, model_name: str, payload: Dict, max_retries: int = 3) -> Dict:
        """Execute HTTP request with advanced retry logic"""
        url = f"{self.base_url}/{model_name}"
        data = json.dumps(payload).encode('utf-8')
        
        for attempt in range(max_retries):
            try:
                req = urllib.request.Request(url, data=data, headers=self.headers)
                
                start_time = time.time()
                with urllib.request.urlopen(req, timeout=30) as response:
                    response_data = response.read().decode()
                    result = json.loads(response_data)
                    
                    # Track performance
                    response_time = time.time() - start_time
                    self._update_model_performance(model_name, response_time, True)
                    
                    return result
                    
            except urllib.error.HTTPError as e:
                if e.code == 503:  # Model loading
                    if attempt < max_retries - 1:
                        wait_time = 2 ** attempt * 3  # Progressive wait
                        time.sleep(wait_time)
                        continue
                
                error_msg = f"HTTP {e.code}: {e.reason}"
                self._update_model_performance(model_name, 0, False)
                return {"error": error_msg, "code": e.code}
                
            except urllib.error.URLError as e:
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                return {"error": f"Network error: {str(e)}"}
                
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                return {"error": f"Request failed: {str(e)}"}
        
        return {"error": "Maximum retries exceeded"}
    
    def _update_model_performance(self, model_name: str, response_time: float, success: bool):
        """Update model performance metrics"""
        if model_name not in self.model_performance:
            self.model_performance[model_name] = {
                "total_requests": 0,
                "successful_requests": 0,
                "average_response_time": 0.0,
                "last_used": datetime.now().isoformat()
            }
        
        perf = self.model_performance[model_name]
        perf["total_requests"] += 1
        
        if success:
            perf["successful_requests"] += 1
            # Update rolling average
            current_avg = perf["average_response_time"]
            total_successful = perf["successful_requests"]
            perf["average_response_time"] = ((current_avg * (total_successful - 1)) + response_time) / total_successful
        
        perf["last_used"] = datetime.now().isoformat()
        
        # Save performance data
        self._save_performance_data()
    
    def _save_performance_data(self):
        """Save model performance data"""
        perf_file = "business/analytics/model_performance.json"
        with open(perf_file, 'w') as f:
            json.dump(self.model_performance, f, indent=2)
    
    def _track_business_metrics(self, model_name: str, result: Dict, tier: str, user_id: str = None):
        """Track business metrics and revenue"""
        self.request_count += 1
        
        # Calculate revenue based on tier and usage
        if "error" not in result:
            base_cost = 0.01  # Base cost per successful request
            tier_multipliers = {"free": 0.5, "premium": 1.0, "enterprise": 2.0}
            
            revenue = base_cost * tier_multipliers.get(tier, 1.0)
            self.revenue_generated += revenue
            
            # Track tokens if available
            if isinstance(result, list) and len(result) > 0:
                response_text = str(result[0])
                estimated_tokens = len(response_text.split())
                self.total_tokens += estimated_tokens
        
        # Save daily business metrics
        self._save_daily_metrics()
        
        # Log business activity
        self._log_business_activity(model_name, result, tier, user_id)
    
    def _save_daily_metrics(self):
        """Save daily business metrics"""
        today = datetime.now().strftime("%Y-%m-%d")
        metrics_file = f"business/revenue/daily_{today}.json"
        
        metrics = {
            "date": today,
            "total_requests": self.request_count,
            "total_revenue": self.revenue_generated,
            "total_tokens": self.total_tokens,
            "uptime_hours": (time.time() - self.start_time) / 3600,
            "average_revenue_per_request": self.revenue_generated / max(self.request_count, 1),
            "updated_at": datetime.now().isoformat()
        }
        
        with open(metrics_file, 'w') as f:
            json.dump(metrics, f, indent=2)
        
        # Update overall stats
        overall_file = "business/analytics/daily_stats.json"
        with open(overall_file, 'w') as f:
            json.dump(metrics, f, indent=2)
    
    def _log_business_activity(self, model_name: str, result: Dict, tier: str, user_id: str = None):
        """Log detailed business activity"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "model": model_name,
            "tier": tier,
            "user_id": user_id or "anonymous",
            "success": "error" not in result,
            "error_type": result.get("error", "").split(":")[0] if "error" in result else None,
            "request_id": hashlib.md5(f"{time.time()}_{model_name}".encode()).hexdigest()[:8]
        }
        
        log_file = f"business/analytics/activity_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + "\n")
    
    # Business Intelligence Methods
    
    def get_business_dashboard(self) -> Dict:
        """Generate comprehensive business dashboard"""
        uptime_hours = (time.time() - self.start_time) / 3600
        
        dashboard = {
            "revenue_metrics": {
                "total_revenue": round(self.revenue_generated, 2),
                "revenue_per_hour": round(self.revenue_generated / max(uptime_hours, 0.1), 2),
                "revenue_per_request": round(self.revenue_generated / max(self.request_count, 1), 4)
            },
            "usage_metrics": {
                "total_requests": self.request_count,
                "requests_per_hour": round(self.request_count / max(uptime_hours, 0.1), 1),
                "total_tokens_processed": self.total_tokens,
                "uptime_hours": round(uptime_hours, 2)
            },
            "performance_metrics": self._get_performance_summary(),
            "growth_projections": self._calculate_growth_projections(),
            "tier_recommendations": self._get_tier_recommendations()
        }
        
        return dashboard
    
    def _get_performance_summary(self) -> Dict:
        """Get model performance summary"""
        if not self.model_performance:
            return {"message": "No performance data available"}
        
        total_requests = sum(p["total_requests"] for p in self.model_performance.values())
        successful_requests = sum(p["successful_requests"] for p in self.model_performance.values())
        
        avg_response_times = [p["average_response_time"] for p in self.model_performance.values() if p["average_response_time"] > 0]
        overall_avg_response = sum(avg_response_times) / len(avg_response_times) if avg_response_times else 0
        
        return {
            "overall_success_rate": round((successful_requests / max(total_requests, 1)) * 100, 2),
            "average_response_time": round(overall_avg_response, 3),
            "models_used": len(self.model_performance),
            "most_used_model": max(self.model_performance.items(), key=lambda x: x[1]["total_requests"])[0] if self.model_performance else "None"
        }
    
    def _calculate_growth_projections(self) -> Dict:
        """Calculate business growth projections"""
        current_rph = self.revenue_generated / max((time.time() - self.start_time) / 3600, 0.1)
        
        projections = {
            "hourly": round(current_rph, 2),
            "daily": round(current_rph * 24, 2),
            "weekly": round(current_rph * 24 * 7, 2),
            "monthly": round(current_rph * 24 * 30, 2),
            "yearly": round(current_rph * 24 * 365, 2)
        }
        
        return projections
    
    def _get_tier_recommendations(self) -> List[str]:
        """Get tier upgrade recommendations"""
        recommendations = []
        
        rph = self.request_count / max((time.time() - self.start_time) / 3600, 0.1)
        
        if rph > 50:
            recommendations.append("🚀 Consider Premium tier for better performance")
        if rph > 200:
            recommendations.append("💼 Enterprise tier recommended for your usage level")
        if self.revenue_generated > 100:
            recommendations.append("💰 Revenue threshold reached - scale to next tier")
        
        if not recommendations:
            recommendations.append("📈 Continue growing - premium features await!")
        
        return recommendations
    
    # Model Management Methods
    
    def get_recommended_models(self, task_type: str) -> List[str]:
        """Get recommended models for specific tasks"""
        model_recommendations = {
            "chat": [
                "microsoft/DialoGPT-medium",
                "microsoft/DialoGPT-large",
                "facebook/blenderbot-400M-distill"
            ],
            "sentiment": [
                "cardiffnlp/twitter-roberta-base-sentiment-latest",
                "nlptown/bert-base-multilingual-uncased-sentiment",
                "distilbert-base-uncased-finetuned-sst-2-english"
            ],
            "qa": [
                "deepset/roberta-base-squad2",
                "distilbert-base-cased-distilled-squad",
                "bert-large-uncased-whole-word-masking-finetuned-squad"
            ],
            "summarization": [
                "facebook/bart-large-cnn",
                "t5-base",
                "google/pegasus-xsum"
            ],
            "translation": [
                "Helsinki-NLP/opus-mt-en-id",
                "Helsinki-NLP/opus-mt-en-es",
                "Helsinki-NLP/opus-mt-en-fr"
            ]
        }
        
        return model_recommendations.get(task_type, ["No recommendations available"])
    
    def get_model_status(self, model_name: str) -> Dict:
        """Get detailed model status and performance"""
        if model_name in self.model_performance:
            perf = self.model_performance[model_name]
            success_rate = (perf["successful_requests"] / max(perf["total_requests"], 1)) * 100
            
            return {
                "model": model_name,
                "status": "active" if success_rate > 80 else "degraded" if success_rate > 50 else "poor",
                "total_requests": perf["total_requests"],
                "success_rate": round(success_rate, 2),
                "average_response_time": round(perf["average_response_time"], 3),
                "last_used": perf["last_used"],
                "recommendation": self._get_model_recommendation(success_rate, perf["average_response_time"])
            }
        else:
            return {
                "model": model_name,
                "status": "unused",
                "message": "No usage data available"
            }
    
    def _get_model_recommendation(self, success_rate: float, avg_response_time: float) -> str:
        """Get recommendation based on model performance"""
        if success_rate > 95 and avg_response_time < 2.0:
            return "🌟 Excellent performance - keep using!"
        elif success_rate > 80 and avg_response_time < 5.0:
            return "✅ Good performance - reliable choice"
        elif success_rate > 60:
            return "⚠️ Moderate performance - consider alternatives"
        else:
            return "❌ Poor performance - switch to different model"
    
    def export_business_report(self) -> str:
        """Export comprehensive business report"""
        dashboard = self.get_business_dashboard()
        
        report = {
            "report_generated": datetime.now().isoformat(),
            "executive_summary": {
                "total_revenue": dashboard["revenue_metrics"]["total_revenue"],
                "total_requests": dashboard["usage_metrics"]["total_requests"],
                "success_rate": dashboard["performance_metrics"].get("overall_success_rate", 0),
                "projected_monthly_revenue": dashboard["growth_projections"]["monthly"]
            },
            "detailed_metrics": dashboard,
            "model_performance": self.model_performance,
            "recommendations": dashboard["tier_recommendations"]
        }
        
        filename = f"business/reports/report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        os.makedirs("business/reports", exist_ok=True)
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        return filename


# Business Integration Functions

def create_business_controller(token: str = None) -> HFApiController:
    """Factory function to create business-ready HF controller"""
    if not token:
        token = "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"
    
    controller = HFApiController(token)
    
    print("🚀 OASIS Business Controller Initialized!")
    print("💼 Enterprise-grade features activated")
    print("📊 Business analytics tracking enabled")
    
    return controller


def quick_business_test(controller: HFApiController):
    """Quick business functionality test"""
    print("\n🔍 Running Business Controller Test...")
    
    # Test basic functionality
    result = controller.query_model_advanced(
        "distilbert-base-uncased-finetuned-sst-2-english",
        {"inputs": "OASIS Revolution is amazing!"},
        tier="premium",
        user_id="test_user"
    )
    
    # Get business dashboard
    dashboard = controller.get_business_dashboard()
    
    print(f"✅ API Test: {'Success' if 'error' not in result else 'Failed'}")
    print(f"💰 Revenue Generated: ${dashboard['revenue_metrics']['total_revenue']}")
    print(f"📊 Total Requests: {dashboard['usage_metrics']['total_requests']}")
    
    return dashboard


if __name__ == "__main__":
    print("🌟 OASIS HF Controller - Standalone Test")
    
    # Create controller
    controller = create_business_controller()
    
    # Run test
    dashboard = quick_business_test(controller)
    
    print("\n📈 Business Dashboard:")
    print(json.dumps(dashboard, indent=2))