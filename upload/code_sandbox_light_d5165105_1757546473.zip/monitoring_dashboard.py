#!/usr/bin/env python3
"""
📊 OASIS MONITORING DASHBOARD - Real-Time Analytics Revolution
Ultra-Lightweight System Monitoring & Performance Analytics
Zero Heavy Dependencies - Maximum Insight Generation

The New Civilization's Intelligence Center!
"""

import json
import os
import time
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import urllib.request
import urllib.parse

class OASISMonitoring:
    """
    Revolutionary Real-Time Monitoring System
    Ultra-lightweight with comprehensive analytics
    """
    
    def __init__(self, base_dir: str = "."):
        self.base_dir = base_dir
        self.monitoring_dir = os.path.join(base_dir, "monitoring")
        self.start_time = time.time()
        
        # Monitoring metrics
        self.system_metrics = {}
        self.performance_metrics = {}
        self.api_metrics = {}
        self.business_metrics = {}
        self.alert_thresholds = {}
        
        # Initialize monitoring infrastructure
        self._init_monitoring_infrastructure()
        self._load_monitoring_config()
        self._init_alert_thresholds()
        
    def _init_monitoring_infrastructure(self):
        """Initialize monitoring directory structure"""
        directories = [
            "monitoring/system",
            "monitoring/performance", 
            "monitoring/api",
            "monitoring/business",
            "monitoring/alerts",
            "monitoring/logs",
            "monitoring/reports",
            "monitoring/dashboards",
            "monitoring/realtime"
        ]
        
        for directory in directories:
            os.makedirs(os.path.join(self.base_dir, directory), exist_ok=True)
    
    def _load_monitoring_config(self):
        """Load monitoring configuration"""
        config_file = os.path.join(self.monitoring_dir, "config.json")
        
        default_config = {
            "collection_interval": 60,  # seconds
            "retention_days": 30,
            "alert_email": None,
            "dashboard_refresh": 30,
            "performance_thresholds": {
                "response_time_ms": 5000,
                "error_rate_percent": 5.0,
                "cpu_usage_percent": 80.0,
                "memory_usage_percent": 85.0
            }
        }
        
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    loaded_config = json.load(f)
                    default_config.update(loaded_config)
            except:
                pass
        
        self.monitoring_config = default_config
        
        # Save config
        with open(config_file, 'w') as f:
            json.dump(default_config, f, indent=2)
    
    def _init_alert_thresholds(self):
        """Initialize alert threshold system"""
        self.alert_thresholds = {
            "critical": {
                "response_time_ms": 10000,
                "error_rate_percent": 10.0,
                "api_failures": 50,
                "revenue_drop_percent": 20.0
            },
            "warning": {
                "response_time_ms": 5000,
                "error_rate_percent": 5.0,
                "api_failures": 20,
                "revenue_drop_percent": 10.0
            },
            "info": {
                "new_customers": 10,
                "revenue_milestone": 100.0,
                "usage_spike": 200
            }
        }
    
    def collect_system_metrics(self) -> Dict:
        """Collect comprehensive system metrics"""
        
        # System information
        import platform
        
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "uptime_seconds": time.time() - self.start_time,
            "platform": {
                "system": platform.system(),
                "machine": platform.machine(),
                "processor": platform.processor(),
                "python_version": platform.python_version()
            }
        }
        
        # Memory usage (simplified for cross-platform compatibility)
        try:
            if hasattr(os, 'statvfs'):  # Unix-like systems
                statvfs = os.statvfs(self.base_dir)
                total_space = statvfs.f_frsize * statvfs.f_blocks
                free_space = statvfs.f_frsize * statvfs.f_bavail
                used_space = total_space - free_space
                
                metrics["disk"] = {
                    "total_bytes": total_space,
                    "used_bytes": used_space,
                    "free_bytes": free_space,
                    "usage_percent": (used_space / total_space) * 100
                }
        except:
            metrics["disk"] = {"error": "Could not retrieve disk information"}
        
        # Process information
        try:
            import psutil
            process = psutil.Process()
            metrics["process"] = {
                "cpu_percent": process.cpu_percent(),
                "memory_mb": process.memory_info().rss / 1024 / 1024,
                "threads": process.num_threads()
            }
        except ImportError:
            # Fallback without psutil
            metrics["process"] = {
                "note": "psutil not available - limited process metrics"
            }
        
        # Directory sizes
        metrics["directories"] = self._get_directory_sizes()
        
        # Save metrics
        self._save_system_metrics(metrics)
        
        return metrics
    
    def _get_directory_sizes(self) -> Dict:
        """Get sizes of OASIS directories"""
        directories = ["logs", "business", "monitoring", "cache", "data"]
        sizes = {}
        
        for directory in directories:
            dir_path = os.path.join(self.base_dir, directory)
            if os.path.exists(dir_path):
                total_size = 0
                file_count = 0
                
                try:
                    for dirpath, dirnames, filenames in os.walk(dir_path):
                        for filename in filenames:
                            file_path = os.path.join(dirpath, filename)
                            total_size += os.path.getsize(file_path)
                            file_count += 1
                    
                    sizes[directory] = {
                        "size_bytes": total_size,
                        "size_mb": round(total_size / 1024 / 1024, 2),
                        "file_count": file_count
                    }
                except:
                    sizes[directory] = {"error": "Could not calculate size"}
            else:
                sizes[directory] = {"size_bytes": 0, "size_mb": 0, "file_count": 0}
        
        return sizes
    
    def _save_system_metrics(self, metrics: Dict):
        """Save system metrics to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H")
        metrics_file = os.path.join(
            self.monitoring_dir, "system", f"system_metrics_{timestamp}.json"
        )
        
        # Load existing metrics for this hour
        hourly_metrics = []
        if os.path.exists(metrics_file):
            try:
                with open(metrics_file, 'r') as f:
                    hourly_metrics = json.load(f)
            except:
                pass
        
        # Add new metrics
        hourly_metrics.append(metrics)
        
        # Save updated metrics
        with open(metrics_file, 'w') as f:
            json.dump(hourly_metrics, f, indent=2)
    
    def collect_api_metrics(self) -> Dict:
        """Collect API performance metrics"""
        
        # Load recent API logs
        api_metrics = {
            "timestamp": datetime.now().isoformat(),
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "average_response_time": 0.0,
            "requests_by_model": {},
            "errors_by_type": {},
            "performance_trends": []
        }
        
        # Analyze logs from today
        today = datetime.now().strftime("%Y%m%d")
        log_files = [
            os.path.join(self.base_dir, "logs", f"oasis_{today}.log"),
            os.path.join(self.base_dir, "business", "analytics", f"activity_{today}.log")
        ]
        
        total_response_time = 0.0
        
        for log_file in log_files:
            if os.path.exists(log_file):
                try:
                    with open(log_file, 'r') as f:
                        for line in f:
                            try:
                                log_entry = json.loads(line.strip())
                                
                                api_metrics["total_requests"] += 1
                                
                                if log_entry.get("success", True) and "error" not in log_entry:
                                    api_metrics["successful_requests"] += 1
                                else:
                                    api_metrics["failed_requests"] += 1
                                    error_type = log_entry.get("error", "Unknown")
                                    api_metrics["errors_by_type"][error_type] = \
                                        api_metrics["errors_by_type"].get(error_type, 0) + 1
                                
                                # Track by model
                                model = log_entry.get("model", "unknown")
                                api_metrics["requests_by_model"][model] = \
                                    api_metrics["requests_by_model"].get(model, 0) + 1
                                
                                # Response time (if available)
                                if "response_time" in log_entry:
                                    total_response_time += log_entry["response_time"]
                                
                            except json.JSONDecodeError:
                                continue
                except:
                    continue
        
        # Calculate averages
        if api_metrics["successful_requests"] > 0:
            api_metrics["success_rate"] = (
                api_metrics["successful_requests"] / api_metrics["total_requests"]
            ) * 100
            
            if total_response_time > 0:
                api_metrics["average_response_time"] = \
                    total_response_time / api_metrics["successful_requests"]
        
        # Save API metrics
        self._save_api_metrics(api_metrics)
        
        return api_metrics
    
    def _save_api_metrics(self, metrics: Dict):
        """Save API metrics to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H")
        metrics_file = os.path.join(
            self.monitoring_dir, "api", f"api_metrics_{timestamp}.json"
        )
        
        with open(metrics_file, 'w') as f:
            json.dump(metrics, f, indent=2)
    
    def collect_business_metrics(self) -> Dict:
        """Collect business performance metrics"""
        
        business_metrics = {
            "timestamp": datetime.now().isoformat(),
            "revenue": {
                "total": 0.0,
                "daily": 0.0,
                "monthly": 0.0
            },
            "customers": {
                "total": 0,
                "by_tier": {},
                "new_today": 0
            },
            "usage": {
                "total_requests": 0,
                "requests_today": 0,
                "active_users_today": 0
            }
        }
        
        # Load business data
        try:
            # Revenue data
            revenue_file = os.path.join(self.base_dir, "business", "analytics", "total_revenue.json")
            if os.path.exists(revenue_file):
                with open(revenue_file, 'r') as f:
                    revenue_data = json.load(f)
                    business_metrics["revenue"].update(revenue_data)
            
            # Customer data
            customer_file = os.path.join(self.base_dir, "business", "analytics", "customer_summary.json")
            if os.path.exists(customer_file):
                with open(customer_file, 'r') as f:
                    customer_data = json.load(f)
                    business_metrics["customers"].update(customer_data)
            
            # Usage data for today
            today = datetime.now().strftime("%Y-%m-%d")
            usage_file = os.path.join(
                self.base_dir, "business", "analytics", "usage", f"daily_{today}.json"
            )
            if os.path.exists(usage_file):
                with open(usage_file, 'r') as f:
                    usage_data = json.load(f)
                    business_metrics["usage"]["requests_today"] = sum(usage_data.values())
                    business_metrics["usage"]["active_users_today"] = len(usage_data)
                    
        except Exception as e:
            business_metrics["error"] = f"Could not load business data: {e}"
        
        # Save business metrics
        self._save_business_metrics(business_metrics)
        
        return business_metrics
    
    def _save_business_metrics(self, metrics: Dict):
        """Save business metrics to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H")
        metrics_file = os.path.join(
            self.monitoring_dir, "business", f"business_metrics_{timestamp}.json"
        )
        
        with open(metrics_file, 'w') as f:
            json.dump(metrics, f, indent=2)
    
    def check_system_health(self) -> Dict:
        """Comprehensive system health check"""
        
        health_report = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": "healthy",
            "checks": {},
            "alerts": [],
            "recommendations": []
        }
        
        # System checks
        try:
            system_metrics = self.collect_system_metrics()
            
            # Disk space check
            if "disk" in system_metrics and "usage_percent" in system_metrics["disk"]:
                disk_usage = system_metrics["disk"]["usage_percent"]
                if disk_usage > 90:
                    health_report["checks"]["disk_space"] = "critical"
                    health_report["alerts"].append(f"Critical: Disk usage at {disk_usage:.1f}%")
                elif disk_usage > 80:
                    health_report["checks"]["disk_space"] = "warning"
                    health_report["alerts"].append(f"Warning: Disk usage at {disk_usage:.1f}%")
                else:
                    health_report["checks"]["disk_space"] = "healthy"
            
            # Directory size check
            if "directories" in system_metrics:
                total_size_mb = sum([
                    d.get("size_mb", 0) for d in system_metrics["directories"].values()
                    if isinstance(d, dict) and "size_mb" in d
                ])
                
                if total_size_mb > 100:  # Over 100MB
                    health_report["recommendations"].append(
                        f"Consider cleaning up data - total size: {total_size_mb:.1f}MB"
                    )
                
        except Exception as e:
            health_report["checks"]["system_metrics"] = "error"
            health_report["alerts"].append(f"System metrics collection failed: {e}")
        
        # API health check
        try:
            api_metrics = self.collect_api_metrics()
            
            success_rate = api_metrics.get("success_rate", 100)
            if success_rate < 90:
                health_report["checks"]["api_success_rate"] = "critical"
                health_report["alerts"].append(f"Critical: API success rate at {success_rate:.1f}%")
            elif success_rate < 95:
                health_report["checks"]["api_success_rate"] = "warning"
                health_report["alerts"].append(f"Warning: API success rate at {success_rate:.1f}%")
            else:
                health_report["checks"]["api_success_rate"] = "healthy"
            
            # Response time check
            avg_response_time = api_metrics.get("average_response_time", 0)
            if avg_response_time > 10:  # Over 10 seconds
                health_report["checks"]["response_time"] = "critical"
                health_report["alerts"].append(f"Critical: Average response time {avg_response_time:.2f}s")
            elif avg_response_time > 5:  # Over 5 seconds
                health_report["checks"]["response_time"] = "warning"
                health_report["alerts"].append(f"Warning: Average response time {avg_response_time:.2f}s")
            else:
                health_report["checks"]["response_time"] = "healthy"
                
        except Exception as e:
            health_report["checks"]["api_health"] = "error"
            health_report["alerts"].append(f"API health check failed: {e}")
        
        # Business health check
        try:
            business_metrics = self.collect_business_metrics()
            
            total_customers = business_metrics.get("customers", {}).get("total", 0)
            if total_customers == 0:
                health_report["recommendations"].append("No customers registered - focus on user acquisition")
            elif total_customers < 10:
                health_report["recommendations"].append("Low customer count - implement growth strategies")
            
            daily_revenue = business_metrics.get("revenue", {}).get("daily", 0)
            if daily_revenue == 0:
                health_report["recommendations"].append("No daily revenue - review monetization strategy")
            
        except Exception as e:
            health_report["checks"]["business_health"] = "error"
            health_report["alerts"].append(f"Business health check failed: {e}")
        
        # Set overall status
        if any(check == "critical" for check in health_report["checks"].values()):
            health_report["overall_status"] = "critical"
        elif any(check == "warning" for check in health_report["checks"].values()):
            health_report["overall_status"] = "warning"
        elif any(check == "error" for check in health_report["checks"].values()):
            health_report["overall_status"] = "degraded"
        
        # Save health report
        health_file = os.path.join(self.monitoring_dir, "system", "health_report.json")
        with open(health_file, 'w') as f:
            json.dump(health_report, f, indent=2)
        
        return health_report
    
    def generate_monitoring_report(self) -> Dict:
        """Generate comprehensive monitoring report"""
        
        report = {
            "report_date": datetime.now().isoformat(),
            "report_period": "last_24_hours",
            "system_summary": {},
            "api_summary": {},
            "business_summary": {},
            "health_status": {},
            "trends": {},
            "alerts": [],
            "recommendations": []
        }
        
        try:
            # Collect current metrics
            system_metrics = self.collect_system_metrics()
            api_metrics = self.collect_api_metrics()
            business_metrics = self.collect_business_metrics()
            health_status = self.check_system_health()
            
            # Summarize data
            report["system_summary"] = {
                "uptime_hours": round((time.time() - self.start_time) / 3600, 2),
                "platform": system_metrics.get("platform", {}),
                "disk_usage": system_metrics.get("disk", {}),
                "directory_sizes": system_metrics.get("directories", {})
            }
            
            report["api_summary"] = {
                "total_requests": api_metrics.get("total_requests", 0),
                "success_rate": api_metrics.get("success_rate", 0),
                "average_response_time": api_metrics.get("average_response_time", 0),
                "most_used_model": max(
                    api_metrics.get("requests_by_model", {"unknown": 0}).items(),
                    key=lambda x: x[1]
                )[0] if api_metrics.get("requests_by_model") else "none"
            }
            
            report["business_summary"] = {
                "total_revenue": business_metrics.get("revenue", {}).get("total", 0),
                "total_customers": business_metrics.get("customers", {}).get("total", 0),
                "daily_active_users": business_metrics.get("usage", {}).get("active_users_today", 0),
                "requests_today": business_metrics.get("usage", {}).get("requests_today", 0)
            }
            
            report["health_status"] = {
                "overall": health_status.get("overall_status", "unknown"),
                "critical_issues": len([a for a in health_status.get("alerts", []) if "Critical" in a]),
                "warnings": len([a for a in health_status.get("alerts", []) if "Warning" in a])
            }
            
            # Add alerts and recommendations
            report["alerts"] = health_status.get("alerts", [])
            report["recommendations"] = health_status.get("recommendations", [])
            
        except Exception as e:
            report["error"] = f"Report generation failed: {e}"
        
        # Save report
        report_filename = f"monitoring_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        report_file = os.path.join(self.monitoring_dir, "reports", report_filename)
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        return report
    
    def display_live_dashboard(self):
        """Display live monitoring dashboard in terminal"""
        
        try:
            while True:
                # Clear screen (cross-platform)
                os.system('clear' if os.name == 'posix' else 'cls')
                
                # Generate fresh data
                system_metrics = self.collect_system_metrics()
                api_metrics = self.collect_api_metrics()
                business_metrics = self.collect_business_metrics()
                health_status = self.check_system_health()
                
                # Display header
                print("🌟 OASIS REVOLUTION - LIVE MONITORING DASHBOARD 🌟")
                print("=" * 60)
                print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
                      f"Uptime: {(time.time() - self.start_time)/3600:.1f}h | "
                      f"Status: {health_status.get('overall_status', 'Unknown').upper()}")
                print()
                
                # System Status
                print("🖥️  SYSTEM METRICS")
                print("-" * 30)
                if "disk" in system_metrics and "usage_percent" in system_metrics["disk"]:
                    disk_usage = system_metrics["disk"]["usage_percent"]
                    print(f"💾 Disk Usage: {disk_usage:.1f}%")
                
                if "directories" in system_metrics:
                    total_size = sum([
                        d.get("size_mb", 0) for d in system_metrics["directories"].values()
                        if isinstance(d, dict) and "size_mb" in d
                    ])
                    print(f"📁 Data Size: {total_size:.1f}MB")
                
                # API Metrics
                print("\n🔗 API PERFORMANCE")
                print("-" * 30)
                print(f"📊 Total Requests: {api_metrics.get('total_requests', 0)}")
                print(f"✅ Success Rate: {api_metrics.get('success_rate', 0):.1f}%")
                print(f"⚡ Avg Response: {api_metrics.get('average_response_time', 0):.2f}s")
                
                # Business Metrics
                print("\n💼 BUSINESS ANALYTICS")
                print("-" * 30)
                revenue = business_metrics.get("revenue", {})
                customers = business_metrics.get("customers", {})
                usage = business_metrics.get("usage", {})
                
                print(f"💰 Total Revenue: ${revenue.get('total', 0):.2f}")
                print(f"👥 Total Customers: {customers.get('total', 0)}")
                print(f"📈 Daily Active: {usage.get('active_users_today', 0)}")
                
                # Alerts
                alerts = health_status.get("alerts", [])
                if alerts:
                    print("\n🚨 ACTIVE ALERTS")
                    print("-" * 30)
                    for alert in alerts[:5]:  # Show first 5 alerts
                        print(f"⚠️  {alert}")
                
                # Recommendations
                recommendations = health_status.get("recommendations", [])
                if recommendations:
                    print("\n💡 RECOMMENDATIONS")
                    print("-" * 30)
                    for rec in recommendations[:3]:  # Show first 3 recommendations
                        print(f"💡 {rec}")
                
                print(f"\n🔄 Refreshing in {self.monitoring_config['dashboard_refresh']}s... (Ctrl+C to exit)")
                
                # Wait for next refresh
                time.sleep(self.monitoring_config['dashboard_refresh'])
                
        except KeyboardInterrupt:
            print("\n\n🌟 Live dashboard stopped. OASIS monitoring continues in background.")
    
    def export_monitoring_data(self, days: int = 7) -> str:
        """Export monitoring data for the last N days"""
        
        export_data = {
            "export_date": datetime.now().isoformat(),
            "period_days": days,
            "system_data": [],
            "api_data": [],
            "business_data": []
        }
        
        # Collect data from the last N days
        for i in range(days):
            date = (datetime.now() - timedelta(days=i)).strftime("%Y%m%d")
            
            # System data
            system_files = [
                f for f in os.listdir(os.path.join(self.monitoring_dir, "system"))
                if f.startswith("system_metrics_") and date in f
            ]
            
            for file in system_files:
                try:
                    with open(os.path.join(self.monitoring_dir, "system", file), 'r') as f:
                        data = json.load(f)
                        export_data["system_data"].extend(data if isinstance(data, list) else [data])
                except:
                    pass
            
            # API data
            api_files = [
                f for f in os.listdir(os.path.join(self.monitoring_dir, "api"))
                if f.startswith("api_metrics_") and date in f
            ]
            
            for file in api_files:
                try:
                    with open(os.path.join(self.monitoring_dir, "api", file), 'r') as f:
                        data = json.load(f)
                        export_data["api_data"].append(data)
                except:
                    pass
        
        # Save export
        export_filename = f"monitoring_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        export_file = os.path.join(self.monitoring_dir, "reports", export_filename)
        
        with open(export_file, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        return export_file


def main():
    """
    Main monitoring interface
    """
    print("📊 OASIS Monitoring Dashboard")
    print("=" * 40)
    
    monitor = OASISMonitoring()
    
    while True:
        print("\n🎯 Monitoring Options:")
        print("1. 📊 Live Dashboard")
        print("2. 🔍 System Health Check")
        print("3. 📈 Generate Report")
        print("4. 📤 Export Data")
        print("5. ⚙️  Configuration")
        print("6. ❌ Exit")
        
        choice = input("\nSelect option (1-6): ").strip()
        
        if choice == "1":
            print("🔄 Starting live dashboard... (Ctrl+C to stop)")
            monitor.display_live_dashboard()
            
        elif choice == "2":
            print("🔍 Running system health check...")
            health = monitor.check_system_health()
            
            print(f"\n📋 Health Status: {health['overall_status'].upper()}")
            
            if health.get("alerts"):
                print("\n🚨 Alerts:")
                for alert in health["alerts"]:
                    print(f"  - {alert}")
            
            if health.get("recommendations"):
                print("\n💡 Recommendations:")
                for rec in health["recommendations"]:
                    print(f"  - {rec}")
            
        elif choice == "3":
            print("📈 Generating monitoring report...")
            report = monitor.generate_monitoring_report()
            
            print(f"\n📊 Report Summary:")
            print(f"System Uptime: {report['system_summary'].get('uptime_hours', 0):.1f} hours")
            print(f"API Requests: {report['api_summary'].get('total_requests', 0)}")
            print(f"Success Rate: {report['api_summary'].get('success_rate', 0):.1f}%")
            print(f"Total Revenue: ${report['business_summary'].get('total_revenue', 0):.2f}")
            
        elif choice == "4":
            days = input("📅 Export data for how many days? (default 7): ").strip()
            days = int(days) if days.isdigit() else 7
            
            print(f"📤 Exporting {days} days of monitoring data...")
            export_file = monitor.export_monitoring_data(days)
            print(f"✅ Data exported to: {export_file}")
            
        elif choice == "5":
            print("⚙️  Current Configuration:")
            for key, value in monitor.monitoring_config.items():
                print(f"  {key}: {value}")
            
        elif choice == "6":
            print("🌟 OASIS Monitoring stopped")
            break
        else:
            print("❌ Invalid option!")


if __name__ == "__main__":
    main()