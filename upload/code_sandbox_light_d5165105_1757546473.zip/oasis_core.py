#!/usr/bin/env python3
"""
🌟 OASIS REVOLUTION - CORE ENGINE 🌟
Ultra-Lightweight AI Command Center for Termux
ZERO Heavy Dependencies - Pure Hugging Face API

The New Civilization begins here!
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import sys
import os
import time
from datetime import datetime
import hashlib
import random
import base64

class OASISCore:
    """
    Ultra-Lightweight OASIS Engine
    Pure Python implementation with ZERO heavy dependencies
    """
    
    def __init__(self, token="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"):
        self.token = token
        self.base_url = "https://api-inference.huggingface.co/models"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "OASIS-Revolution/1.0"
        }
        self.session_id = self._generate_session_id()
        self.request_count = 0
        self.start_time = time.time()
        
        # Initialize directories
        self._init_directories()
        
        # Load configuration
        self.config = self._load_config()
        
    def _generate_session_id(self):
        """Generate unique session ID"""
        timestamp = str(int(time.time()))
        random_str = str(random.randint(1000, 9999))
        return hashlib.md5((timestamp + random_str).encode()).hexdigest()[:8]
    
    def _init_directories(self):
        """Initialize OASIS directory structure"""
        dirs = ["logs", "cache", "config", "data", "models", "business"]
        for directory in dirs:
            os.makedirs(directory, exist_ok=True)
    
    def _load_config(self):
        """Load configuration with defaults"""
        default_config = {
            "models": {
                "chat": "microsoft/DialoGPT-medium",
                "sentiment": "cardiffnlp/twitter-roberta-base-sentiment-latest",
                "qa": "deepset/roberta-base-squad2",
                "summarization": "facebook/bart-large-cnn",
                "translation": "Helsinki-NLP/opus-mt-en-id"
            },
            "limits": {
                "max_tokens": 1000,
                "timeout": 30,
                "retry_attempts": 3
            },
            "business": {
                "free_tier_limit": 100,
                "premium_multiplier": 10,
                "enterprise_multiplier": 100
            }
        }
        
        config_path = "config/oasis_config.json"
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    loaded_config = json.load(f)
                    default_config.update(loaded_config)
            except:
                pass
        
        return default_config
    
    def query_model(self, model_name, payload, timeout=None):
        """
        Pure API call to Hugging Face - Zero dependencies
        Ultra-lightweight with error handling and retries
        """
        if timeout is None:
            timeout = self.config["limits"]["timeout"]
            
        url = f"{self.base_url}/{model_name}"
        data = json.dumps(payload).encode('utf-8')
        
        for attempt in range(self.config["limits"]["retry_attempts"]):
            try:
                req = urllib.request.Request(url, data=data, headers=self.headers)
                
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    result = json.loads(response.read().decode())
                    self.request_count += 1
                    self._log_request(model_name, payload, result, "success")
                    return result
                    
            except urllib.error.HTTPError as e:
                error_msg = f"HTTP {e.code}: {e.reason}"
                if attempt == self.config["limits"]["retry_attempts"] - 1:
                    self._log_request(model_name, payload, {"error": error_msg}, "error")
                    return {"error": error_msg}
                time.sleep(2 ** attempt)  # Exponential backoff
                
            except Exception as e:
                error_msg = str(e)
                if attempt == self.config["limits"]["retry_attempts"] - 1:
                    self._log_request(model_name, payload, {"error": error_msg}, "error")
                    return {"error": error_msg}
                time.sleep(2 ** attempt)
    
    def chat(self, message, model=None):
        """Ultra-lightweight chat functionality"""
        if model is None:
            model = self.config["models"]["chat"]
            
        payload = {
            "inputs": message,
            "parameters": {
                "max_length": min(self.config["limits"]["max_tokens"], 512),
                "temperature": 0.7,
                "return_full_text": False
            }
        }
        
        result = self.query_model(model, payload)
        if "error" not in result and result:
            if isinstance(result, list) and len(result) > 0:
                return result[0].get("generated_text", message)
        return f"Error: {result.get('error', 'Unknown error')}"
    
    def analyze_sentiment(self, text):
        """Sentiment analysis via API"""
        payload = {"inputs": text}
        result = self.query_model(self.config["models"]["sentiment"], payload)
        
        if "error" not in result and result:
            if isinstance(result, list) and len(result) > 0:
                sentiment_data = result[0]
                return {
                    "label": sentiment_data.get("label", "UNKNOWN"),
                    "score": round(sentiment_data.get("score", 0), 3)
                }
        return {"label": "ERROR", "score": 0, "error": result.get("error", "Unknown error")}
    
    def answer_question(self, question, context):
        """Question answering system"""
        payload = {
            "inputs": {
                "question": question,
                "context": context
            }
        }
        
        result = self.query_model(self.config["models"]["qa"], payload)
        if "error" not in result and result:
            return {
                "answer": result.get("answer", "No answer found"),
                "score": round(result.get("score", 0), 3)
            }
        return {"answer": "Error occurred", "score": 0, "error": result.get("error", "Unknown error")}
    
    def summarize_text(self, text, max_length=100):
        """Text summarization"""
        payload = {
            "inputs": text,
            "parameters": {
                "max_length": max_length,
                "min_length": 30
            }
        }
        
        result = self.query_model(self.config["models"]["summarization"], payload)
        if "error" not in result and result:
            if isinstance(result, list) and len(result) > 0:
                return result[0].get("summary_text", "No summary generated")
        return f"Error: {result.get('error', 'Unknown error')}"
    
    def translate_text(self, text, target_lang="id"):
        """Text translation (English to Indonesian by default)"""
        if target_lang == "id":
            model = "Helsinki-NLP/opus-mt-en-id"
        else:
            model = f"Helsinki-NLP/opus-mt-en-{target_lang}"
            
        payload = {"inputs": text}
        result = self.query_model(model, payload)
        
        if "error" not in result and result:
            if isinstance(result, list) and len(result) > 0:
                return result[0].get("translation_text", text)
        return f"Error: {result.get('error', 'Unknown error')}"
    
    def _log_request(self, model, payload, result, status):
        """Log API requests for monitoring"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "session_id": self.session_id,
            "model": model,
            "status": status,
            "request_count": self.request_count,
            "payload_size": len(json.dumps(payload)),
            "has_error": "error" in result
        }
        
        log_path = f"logs/oasis_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
    
    def get_stats(self):
        """Get system statistics"""
        uptime = time.time() - self.start_time
        return {
            "session_id": self.session_id,
            "uptime_seconds": round(uptime, 2),
            "total_requests": self.request_count,
            "requests_per_minute": round((self.request_count / uptime) * 60, 2) if uptime > 0 else 0,
            "api_token": self.token[:8] + "..." if self.token else "Not set",
            "directories_initialized": len([d for d in ["logs", "cache", "config", "data", "models", "business"] if os.path.exists(d)])
        }
    
    def health_check(self):
        """System health check"""
        try:
            # Quick API test
            test_result = self.query_model("distilbert-base-uncased-finetuned-sst-2-english", 
                                         {"inputs": "OASIS Revolution test"})
            
            if "error" in test_result:
                return {"status": "error", "message": "API connection failed", "details": test_result}
            
            return {"status": "healthy", "message": "All systems operational", "api_responsive": True}
            
        except Exception as e:
            return {"status": "error", "message": f"Health check failed: {str(e)}"}


class OASISInterface:
    """
    Command-line interface for OASIS Revolution
    Ultra-lightweight with beautiful ASCII art
    """
    
    def __init__(self):
        self.core = OASISCore()
        self.running = True
        
    def display_banner(self):
        """Revolutionary ASCII banner"""
        banner = """
╔══════════════════════════════════════════════════════════════╗
║                    🌟 OASIS REVOLUTION 🌟                    ║
║                  The New Civilization Begins                 ║
║                                                              ║
║  ⚡ Ultra-Lightweight AI Command Center                      ║
║  🚀 Zero Heavy Dependencies                                  ║
║  🔗 Pure Hugging Face API Integration                        ║
║  📱 Termux-Optimized Architecture                           ║
║                                                              ║
║           "Where AI Dreams Become Reality"                   ║
╚══════════════════════════════════════════════════════════════╝
        """
        print(banner)
        
        # Show system stats
        stats = self.core.get_stats()
        print(f"🔧 Session: {stats['session_id']} | Uptime: {stats['uptime_seconds']}s")
        print(f"📊 Requests: {stats['total_requests']} | Rate: {stats['requests_per_minute']}/min")
        print(f"🔑 Token: {stats['api_token']}")
        print("─" * 62)
    
    def main_menu(self):
        """Revolutionary main interface"""
        while self.running:
            print(f"\n🌟 OASIS Command Center - The Future is NOW!")
            print("┌─────────────────────────────────────────────┐")
            print("│  1. 💬 AI Chat (Revolutionary Conversation) │")
            print("│  2. 📊 Sentiment Analysis (Emotion Reader)  │")
            print("│  3. ❓ Smart Q&A (Knowledge Oracle)        │")
            print("│  4. 📝 Text Summarizer (Wisdom Extractor)  │")
            print("│  5. 🌐 Language Translator (World Bridge)   │")
            print("│  6. 📈 Business Dashboard (Revenue Engine)  │")
            print("│  7. 🔧 System Status (Health Monitor)       │")
            print("│  8. 🚀 Advanced Features (Power Tools)     │")
            print("│  9. ❌ Exit Revolution                      │")
            print("└─────────────────────────────────────────────┘")
            
            choice = input("\n🎯 Select your destiny (1-9): ").strip()
            
            if choice == "1":
                self.chat_mode()
            elif choice == "2":
                self.sentiment_mode()
            elif choice == "3":
                self.qa_mode()
            elif choice == "4":
                self.summarize_mode()
            elif choice == "5":
                self.translate_mode()
            elif choice == "6":
                self.business_dashboard()
            elif choice == "7":
                self.system_status()
            elif choice == "8":
                self.advanced_features()
            elif choice == "9":
                print("\n🌟 OASIS Revolution continues in the background...")
                print("💫 The New Civilization awaits your return!")
                self.running = False
            else:
                print("❌ Invalid choice! Choose wisely, revolutionary!")
    
    def chat_mode(self):
        """Revolutionary chat interface"""
        print("\n🤖 OASIS AI Chat - Revolutionary Conversation Engine")
        print("💡 Type 'exit' to return to command center")
        print("🌟 Enter your thoughts and watch the magic happen!")
        print("─" * 60)
        
        while True:
            user_input = input("\n🎤 You: ").strip()
            if user_input.lower() in ['exit', 'quit', 'back']:
                break
            
            if not user_input:
                continue
                
            print("🔄 OASIS is thinking...")
            response = self.core.chat(user_input)
            print(f"🤖 OASIS: {response}")
    
    def sentiment_mode(self):
        """Emotion analysis interface"""
        print("\n📊 OASIS Sentiment Analyzer - Read the Emotional Universe")
        text = input("💭 Enter text to analyze emotions: ").strip()
        
        if text:
            print("🔍 Analyzing emotional patterns...")
            result = self.core.analyze_sentiment(text)
            
            if "error" not in result:
                emotion_emoji = {"POSITIVE": "😊", "NEGATIVE": "😞", "NEUTRAL": "😐"}.get(result["label"], "🤔")
                confidence = result["score"] * 100
                
                print(f"\n🎭 Emotional Analysis Results:")
                print(f"   └── Emotion: {emotion_emoji} {result['label']}")
                print(f"   └── Confidence: {confidence:.1f}%")
                
                if confidence > 90:
                    print("   └── 🎯 High confidence - Crystal clear emotion!")
                elif confidence > 70:
                    print("   └── ✅ Good confidence - Reliable reading")
                else:
                    print("   └── ⚠️  Moderate confidence - Mixed signals")
            else:
                print(f"❌ Analysis failed: {result.get('error', 'Unknown error')}")
        else:
            print("❌ Please enter some text to analyze!")
    
    def qa_mode(self):
        """Knowledge oracle interface"""
        print("\n❓ OASIS Knowledge Oracle - Ask and You Shall Receive")
        context = input("📖 Enter context/background information: ").strip()
        question = input("🔍 Ask your question: ").strip()
        
        if context and question:
            print("🧠 Consulting the knowledge oracle...")
            result = self.core.answer_question(question, context)
            
            if "error" not in result:
                confidence = result["score"] * 100
                
                print(f"\n💡 Oracle's Answer:")
                print(f"   └── 📝 {result['answer']}")
                print(f"   └── 🎯 Confidence: {confidence:.1f}%")
                
                if confidence > 80:
                    print("   └── 🌟 Highly confident answer!")
                elif confidence > 50:
                    print("   └── ✅ Reasonably confident")
                else:
                    print("   └── ⚠️  Low confidence - take with caution")
            else:
                print(f"❌ Oracle consultation failed: {result.get('error', 'Unknown error')}")
        else:
            print("❌ Please provide both context and question!")
    
    def summarize_mode(self):
        """Wisdom extractor interface"""
        print("\n📝 OASIS Wisdom Extractor - Distill Knowledge to Essence")
        text = input("📄 Enter text to summarize: ").strip()
        
        if text:
            if len(text) < 100:
                print("⚠️  Text is quite short, but I'll extract what I can...")
            
            print("🔄 Extracting core wisdom...")
            summary = self.core.summarize_text(text)
            
            print(f"\n✨ Extracted Wisdom:")
            print(f"   └── {summary}")
            print(f"   └── Compression ratio: {len(text)} → {len(summary)} chars")
        else:
            print("❌ Please enter text to summarize!")
    
    def translate_mode(self):
        """Universal translator interface"""
        print("\n🌐 OASIS Universal Translator - Bridge All Languages")
        text = input("💬 Enter English text to translate: ").strip()
        
        if text:
            print("🔄 Bridging language barriers...")
            translation = self.core.translate_text(text, "id")  # Indonesian
            
            print(f"\n🌍 Translation Results:")
            print(f"   🇺🇸 English: {text}")
            print(f"   🇮🇩 Indonesian: {translation}")
        else:
            print("❌ Please enter text to translate!")
    
    def business_dashboard(self):
        """Business intelligence dashboard"""
        print("\n📈 OASIS Business Intelligence - Revenue Revolution")
        stats = self.core.get_stats()
        
        # Simulate business metrics based on usage
        requests = stats["total_requests"]
        revenue_estimate = requests * 0.01  # $0.01 per request estimate
        
        print("┌─ Business Metrics ─────────────────────────────┐")
        print(f"│ 💰 Estimated Revenue: ${revenue_estimate:.2f}     │")
        print(f"│ 📊 API Calls: {requests} requests               │")
        print(f"│ ⚡ Request Rate: {stats['requests_per_minute']:.1f}/min        │")
        print(f"│ ⏱️  Uptime: {stats['uptime_seconds']:.0f} seconds            │")
        print("└─────────────────────────────────────────────────┘")
        
        if requests > 50:
            print("🎉 Congratulations! You're ready for Premium tier!")
        elif requests > 20:
            print("📈 Great progress! Premium features coming soon!")
        else:
            print("🌱 Growing strong! Keep building your AI empire!")
    
    def system_status(self):
        """System health and diagnostics"""
        print("\n🔧 OASIS System Diagnostics - Health Monitor")
        print("🔍 Running comprehensive system check...")
        
        health = self.core.health_check()
        stats = self.core.get_stats()
        
        print("\n📊 System Status Report:")
        print(f"   🟢 Status: {health['status'].upper()}")
        print(f"   💌 Message: {health['message']}")
        print(f"   🔗 API Connection: {'✅ Active' if health.get('api_responsive') else '❌ Failed'}")
        print(f"   📁 Directories: {stats['directories_initialized']}/6 initialized")
        print(f"   🆔 Session ID: {stats['session_id']}")
        
        # Check disk usage (simple check)
        try:
            log_files = [f for f in os.listdir("logs") if f.endswith(".log")]
            print(f"   📋 Log Files: {len(log_files)} active")
        except:
            print("   📋 Log Files: Unable to check")
    
    def advanced_features(self):
        """Advanced power tools"""
        print("\n🚀 OASIS Advanced Features - Power Tools")
        print("┌─────────────────────────────────────────────┐")
        print("│  1. 🔧 Configuration Manager               │")
        print("│  2. 📋 Request History Viewer              │")
        print("│  3. 💾 Export Session Data                 │")
        print("│  4. 🧹 Clean Cache & Logs                  │")
        print("│  5. 🔄 Reset System                        │")
        print("│  6. ⬅️  Back to Main Menu                   │")
        print("└─────────────────────────────────────────────┘")
        
        choice = input("\n🎯 Select advanced feature (1-6): ").strip()
        
        if choice == "1":
            self._config_manager()
        elif choice == "2":
            self._view_history()
        elif choice == "3":
            self._export_data()
        elif choice == "4":
            self._clean_system()
        elif choice == "5":
            self._reset_system()
        elif choice == "6":
            return
        else:
            print("❌ Invalid choice!")
    
    def _config_manager(self):
        """Configuration management"""
        print("\n🔧 Configuration Manager")
        print(f"Current models:")
        for key, model in self.core.config["models"].items():
            print(f"   {key}: {model}")
        print("\nConfiguration loaded successfully! ✅")
    
    def _view_history(self):
        """View request history"""
        print("\n📋 Request History Viewer")
        try:
            today = datetime.now().strftime('%Y%m%d')
            log_file = f"logs/oasis_{today}.log"
            
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    lines = f.readlines()
                    
                print(f"📊 Found {len(lines)} requests today")
                if lines:
                    print("Recent requests:")
                    for line in lines[-5:]:  # Show last 5
                        try:
                            data = json.loads(line)
                            print(f"   {data['timestamp'][:19]} - {data['model']} ({data['status']})")
                        except:
                            pass
            else:
                print("📂 No history file found for today")
        except Exception as e:
            print(f"❌ Error reading history: {e}")
    
    def _export_data(self):
        """Export session data"""
        stats = self.core.get_stats()
        export_data = {
            "export_time": datetime.now().isoformat(),
            "session_stats": stats,
            "config": self.core.config
        }
        
        filename = f"data/export_{stats['session_id']}.json"
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"📤 Session data exported to: {filename}")
    
    def _clean_system(self):
        """Clean cache and old logs"""
        print("\n🧹 System Cleanup")
        confirm = input("⚠️  This will clean logs and cache. Continue? (y/N): ").strip().lower()
        
        if confirm == 'y':
            # Clean old logs (keep today's)
            try:
                today = datetime.now().strftime('%Y%m%d')
                for file in os.listdir("logs"):
                    if file.endswith(".log") and today not in file:
                        os.remove(f"logs/{file}")
                        print(f"🗑️  Removed old log: {file}")
                
                print("✅ System cleanup completed!")
            except Exception as e:
                print(f"❌ Cleanup error: {e}")
        else:
            print("🔄 Cleanup cancelled")
    
    def _reset_system(self):
        """Reset system to defaults"""
        print("\n🔄 System Reset")
        confirm = input("⚠️  This will reset all settings. Continue? (y/N): ").strip().lower()
        
        if confirm == 'y':
            print("🔄 Resetting OASIS to factory defaults...")
            self.core = OASISCore()  # Reinitialize
            print("✅ System reset completed!")
        else:
            print("🔄 Reset cancelled")


def main():
    """
    OASIS Revolution Entry Point
    The New Civilization starts here!
    """
    try:
        interface = OASISInterface()
        interface.display_banner()
        
        # Quick health check
        health = interface.core.health_check()
        if health["status"] == "error":
            print(f"⚠️  Warning: {health['message']}")
            print("🔧 System may have limited functionality")
        
        interface.main_menu()
        
    except KeyboardInterrupt:
        print("\n\n🌟 OASIS Revolution paused by user")
        print("💫 The New Civilization will return!")
    except Exception as e:
        print(f"\n❌ OASIS encountered an error: {e}")
        print("🔧 Please check your system and try again")


if __name__ == "__main__":
    main()