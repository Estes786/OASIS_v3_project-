#!/bin/bash
# 🌟 OASIS Revolution - One-Command Installer
# Ultra-Fast Setup for The New Civilization

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Configuration
REPO_URL="https://github.com/your-username/oasis-revolution.git"
INSTALL_DIR="$HOME/oasis_revolution"
BRANCH="main"

print_banner() {
    echo -e "${PURPLE}"
    cat << 'EOF'
╔══════════════════════════════════════════════════════════════╗
║                🌟 OASIS REVOLUTION 🌟                        ║
║              One-Command Installation                        ║
║                                                              ║
║         "The New Civilization Starts Here"                  ║
╚══════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
}

print_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Detect environment
detect_environment() {
    if [ -n "$PREFIX" ]; then
        ENV_TYPE="termux"
        PACKAGE_MANAGER="pkg"
    elif command -v apt >/dev/null 2>&1; then
        ENV_TYPE="debian"
        PACKAGE_MANAGER="apt"
    elif command -v yum >/dev/null 2>&1; then
        ENV_TYPE="redhat"
        PACKAGE_MANAGER="yum"
    elif command -v apk >/dev/null 2>&1; then
        ENV_TYPE="alpine"
        PACKAGE_MANAGER="apk"
    else
        ENV_TYPE="unknown"
        PACKAGE_MANAGER="unknown"
    fi
    
    print_step "Detected environment: $ENV_TYPE"
}

# Check prerequisites
check_prerequisites() {
    print_step "Checking system prerequisites..."
    
    # Check for required commands
    local missing_commands=()
    
    for cmd in curl git python3; do
        if ! command -v $cmd >/dev/null 2>&1; then
            missing_commands+=($cmd)
        fi
    done
    
    if [ ${#missing_commands[@]} -ne 0 ]; then
        print_warning "Missing required commands: ${missing_commands[*]}"
        install_prerequisites "${missing_commands[@]}"
    else
        print_success "All prerequisites found"
    fi
}

# Install prerequisites
install_prerequisites() {
    local commands=("$@")
    
    print_step "Installing prerequisites: ${commands[*]}"
    
    case $ENV_TYPE in
        "termux")
            pkg update -y
            pkg install -y "${commands[@]}"
            ;;
        "debian")
            sudo apt update
            sudo apt install -y "${commands[@]}"
            ;;
        "redhat")
            sudo yum install -y "${commands[@]}"
            ;;
        "alpine")
            sudo apk add "${commands[@]}"
            ;;
        *)
            print_error "Unknown package manager. Please install manually: ${commands[*]}"
            exit 1
            ;;
    esac
    
    print_success "Prerequisites installed"
}

# Download OASIS
download_oasis() {
    print_step "Downloading OASIS Revolution..."
    
    if [ -d "$INSTALL_DIR" ]; then
        print_warning "OASIS directory exists. Updating..."
        cd "$INSTALL_DIR"
        git pull origin $BRANCH
    else
        git clone -b $BRANCH "$REPO_URL" "$INSTALL_DIR"
        cd "$INSTALL_DIR"
    fi
    
    print_success "OASIS downloaded successfully"
}

# Run setup
run_setup() {
    print_step "Running OASIS setup..."
    
    chmod +x termux_setup.sh
    
    # Choose installation mode based on environment
    if [ "$ENV_TYPE" = "termux" ]; then
        ./termux_setup.sh --full
    else
        ./termux_setup.sh --quick
    fi
    
    print_success "OASIS setup completed"
}

# Test installation
test_installation() {
    print_step "Testing OASIS installation..."
    
    if python3 oasis_core.py >/dev/null 2>&1; then
        print_success "OASIS core engine test passed"
    else
        print_error "OASIS core engine test failed"
        return 1
    fi
    
    # Test quick command
    if ./oasis status >/dev/null 2>&1; then
        print_success "OASIS command interface working"
    else
        print_warning "OASIS command interface needs configuration"
    fi
    
    print_success "Installation test completed"
}

# Add to PATH
setup_path() {
    print_step "Setting up PATH access..."
    
    local shell_rc=""
    
    if [ -n "$BASH_VERSION" ]; then
        shell_rc="$HOME/.bashrc"
    elif [ -n "$ZSH_VERSION" ]; then
        shell_rc="$HOME/.zshrc"
    else
        shell_rc="$HOME/.profile"
    fi
    
    if [ -f "$shell_rc" ] && ! grep -q "oasis_revolution" "$shell_rc"; then
        echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> "$shell_rc"
        print_success "Added OASIS to PATH in $shell_rc"
    fi
    
    # Immediate PATH setup
    export PATH="$INSTALL_DIR:$PATH"
}

# Show completion message
show_completion() {
    echo
    echo -e "${GREEN}🎉 OASIS REVOLUTION INSTALLED SUCCESSFULLY! 🎉${NC}"
    echo
    echo -e "${PURPLE}🚀 Quick Start Commands:${NC}"
    echo -e "   ${BLUE}cd $INSTALL_DIR${NC}"
    echo -e "   ${BLUE}./oasis${NC}                 # Start OASIS Revolution"
    echo -e "   ${BLUE}./oasis chat${NC}            # AI Chat Interface"
    echo -e "   ${BLUE}./oasis business${NC}        # Business Dashboard"
    echo -e "   ${BLUE}./oasis monitor${NC}         # System Monitoring"
    echo
    echo -e "${YELLOW}💡 Next Steps:${NC}"
    echo "   1. Restart your terminal to use 'oasis' command globally"
    echo "   2. Run 'oasis test' to verify everything works"
    echo "   3. Check out README.md for full documentation"
    echo "   4. Join our Discord community for support"
    echo
    echo -e "${PURPLE}🌟 Welcome to The New Civilization! 🌟${NC}"
    
    # Offer immediate start
    echo
    read -p "🚀 Start OASIS Revolution now? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        python3 oasis_launcher.py
    fi
}

# Handle script arguments
case "${1:-}" in
    "--help"|"-h")
        echo "🌟 OASIS Revolution Quick Installer"
        echo
        echo "Usage: $0 [options]"
        echo
        echo "Options:"
        echo "  --fast      Skip confirmations (CI/automation)"
        echo "  --dev       Install development version"  
        echo "  --path DIR  Install to custom directory"
        echo "  --help      Show this help"
        echo
        exit 0
        ;;
    "--fast")
        FAST_MODE=true
        ;;
    "--dev")
        BRANCH="develop"
        ;;
    "--path")
        INSTALL_DIR="$2"
        shift
        ;;
esac

# Main installation flow
main() {
    print_banner
    
    # Environment detection
    detect_environment
    
    # Prerequisites
    check_prerequisites
    
    # Download and setup
    download_oasis
    run_setup
    
    # Testing
    test_installation
    
    # PATH setup
    setup_path
    
    # Completion
    show_completion
}

# Error handling
trap 'print_error "Installation failed on line $LINENO. Check the error above."' ERR

# Run main installation
main "$@"