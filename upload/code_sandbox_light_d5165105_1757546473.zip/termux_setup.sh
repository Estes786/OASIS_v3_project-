#!/bin/bash
# 🌟 OASIS REVOLUTION - TERMUX SETUP SCRIPT 🌟
# Ultra-Lightweight AI Revolution Installer
# Zero Heavy Dependencies - Maximum Performance
# 
# The New Civilization Deployment System
# 
# Usage: bash termux_setup.sh [--quick|--full|--business]

set -e  # Exit on any error

# Colors for beautiful output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# OASIS Configuration
OASIS_VERSION="2.0.0"
OASIS_DIR="$HOME/oasis_revolution"
HF_TOKEN="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"
GITHUB_REPO="https://github.com/your-username/oasis-revolution"

# Installation mode
INSTALL_MODE="${1:-full}"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[OASIS]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_banner() {
    echo -e "${PURPLE}"
    cat << 'EOF'
╔══════════════════════════════════════════════════════════════╗
║                    🌟 OASIS REVOLUTION 🌟                    ║
║                  The New Civilization Installer             ║
║                                                              ║
║  🚀 Ultra-Lightweight AI System for Termux                  ║
║  ⚡ Zero Heavy Dependencies                                  ║
║  🔗 Pure Hugging Face API Integration                        ║
║  💼 Business-Ready Architecture                              ║
║                                                              ║
║           "Where Dreams Become Digital Reality"              ║
╚══════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo -e "${CYAN}Version: $OASIS_VERSION${NC}"
    echo -e "${CYAN}Mode: $INSTALL_MODE${NC}"
    echo ""
}

# System Requirements Check
check_system() {
    print_status "Checking system requirements..."
    
    # Check if running in Termux
    if [ -z "$PREFIX" ]; then
        print_warning "Not running in Termux environment"
        print_status "Assuming regular Linux environment"
        TERMUX_ENV=false
    else
        print_success "Termux environment detected"
        TERMUX_ENV=true
    fi
    
    # Check available space
    AVAILABLE_SPACE=$(df -h . | awk 'NR==2{print $4}' | sed 's/[^0-9]*//g')
    if [ "$AVAILABLE_SPACE" -lt 100 ]; then
        print_warning "Low disk space detected. OASIS needs ~50MB minimum."
    else
        print_success "Sufficient disk space available"
    fi
    
    # Check Python availability
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python $PYTHON_VERSION found"
    else
        print_status "Python3 not found - will install"
        NEED_PYTHON=true
    fi
    
    # Check network connectivity
    if ping -c 1 huggingface.co &> /dev/null; then
        print_success "Network connectivity confirmed"
    else
        print_warning "Network connectivity issue - may affect installation"
    fi
}

# Package Installation
install_packages() {
    print_status "Installing essential packages..."
    
    if [ "$TERMUX_ENV" = true ]; then
        # Termux package installation
        print_status "Updating Termux packages..."
        pkg update -y || print_warning "Package update had issues"
        
        print_status "Installing core packages..."
        pkg install -y python git curl wget openssh || {
            print_error "Failed to install core packages"
            exit 1
        }
        
        if [ "$INSTALL_MODE" = "full" ] || [ "$INSTALL_MODE" = "business" ]; then
            print_status "Installing additional tools..."
            pkg install -y nano vim htop tree jq || print_warning "Some optional packages failed"
        fi
    else
        # Regular Linux installation
        print_status "Installing packages for Linux..."
        if command -v apt &> /dev/null; then
            sudo apt update
            sudo apt install -y python3 python3-pip git curl wget nano
        elif command -v yum &> /dev/null; then
            sudo yum install -y python3 python3-pip git curl wget nano
        else
            print_warning "Unknown package manager - manual installation may be required"
        fi
    fi
    
    print_success "Package installation completed"
}

# OASIS Directory Structure Setup
create_directory_structure() {
    print_status "Creating OASIS directory structure..."
    
    # Remove existing installation if present
    if [ -d "$OASIS_DIR" ]; then
        print_warning "Existing OASIS installation found"
        read -p "Do you want to remove it and install fresh? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$OASIS_DIR"
            print_status "Removed existing installation"
        else
            print_status "Backing up existing installation..."
            mv "$OASIS_DIR" "${OASIS_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
        fi
    fi
    
    # Create main directory
    mkdir -p "$OASIS_DIR"
    cd "$OASIS_DIR"
    
    # Create subdirectories
    directories=(
        "core"
        "config" 
        "logs"
        "data"
        "cache"
        "business/analytics"
        "business/revenue" 
        "business/reports"
        "business/customers"
        "models"
        "scripts"
        "docs"
        "tests"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
    done
    
    print_success "Directory structure created at $OASIS_DIR"
}

# Download OASIS Core Files
download_core_files() {
    print_status "Installing OASIS core engine..."
    
    # Create main OASIS engine
    cat > core/oasis_engine.py << 'CORE_ENGINE_EOF'
#!/usr/bin/env python3
"""
🌟 OASIS REVOLUTION - CORE ENGINE 🌟
Ultra-Lightweight AI Command Center for Termux
ZERO Heavy Dependencies - Pure Hugging Face API Integration
"""

import json
import urllib.request
import urllib.parse
import sys
import os
import time
from datetime import datetime

class OASISCore:
    def __init__(self, token="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"):
        self.token = token
        self.base_url = "https://api-inference.huggingface.co/models"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        self.request_count = 0
        
    def query_model(self, model_name, payload):
        url = f"{self.base_url}/{model_name}"
        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(url, data=data, headers=self.headers)
        
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode())
                self.request_count += 1
                return result
        except Exception as e:
            return {"error": str(e)}
    
    def chat(self, message):
        payload = {"inputs": message, "parameters": {"max_length": 100}}
        result = self.query_model("microsoft/DialoGPT-medium", payload)
        
        if "error" not in result and result:
            return result[0].get("generated_text", message) if isinstance(result, list) else "Response generated"
        return f"Error: {result.get('error', 'Unknown error')}"
    
    def analyze_sentiment(self, text):
        payload = {"inputs": text}
        result = self.query_model("cardiffnlp/twitter-roberta-base-sentiment-latest", payload)
        
        if "error" not in result and result and isinstance(result, list):
            return result[0]
        return {"label": "ERROR", "score": 0}

if __name__ == "__main__":
    core = OASISCore()
    print("🌟 OASIS Core Engine - Quick Test")
    
    # Test sentiment analysis
    test_result = core.analyze_sentiment("I love OASIS Revolution!")
    print(f"Sentiment: {test_result}")
    
    # Test chat
    chat_result = core.chat("Hello OASIS!")
    print(f"Chat: {chat_result}")
    
    print(f"Total requests: {core.request_count}")
CORE_ENGINE_EOF
    
    # Create launcher script
    cat > oasis_launcher.py << 'LAUNCHER_EOF'
#!/usr/bin/env python3
"""
🚀 OASIS Revolution Launcher
Simple command-line interface
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))

from oasis_engine import OASISCore

def main():
    print("🌟 OASIS Revolution - Quick Launcher")
    print("━" * 50)
    
    core = OASISCore()
    
    while True:
        print("\n🎯 OASIS Menu:")
        print("1. 💬 Chat")
        print("2. 📊 Sentiment Analysis") 
        print("3. 📈 Stats")
        print("4. ❌ Exit")
        
        choice = input("\nSelect (1-4): ").strip()
        
        if choice == "1":
            message = input("💭 Your message: ")
            result = core.chat(message)
            print(f"🤖 OASIS: {result}")
            
        elif choice == "2":
            text = input("📝 Text to analyze: ")
            result = core.analyze_sentiment(text)
            print(f"📊 Sentiment: {result.get('label', 'Unknown')} ({result.get('score', 0):.2f})")
            
        elif choice == "3":
            print(f"📊 Total API calls: {core.request_count}")
            
        elif choice == "4":
            print("🌟 OASIS Revolution continues...")
            break
        else:
            print("❌ Invalid choice!")

if __name__ == "__main__":
    main()
LAUNCHER_EOF
    
    # Create configuration file
    cat > config/oasis_config.json << 'CONFIG_EOF'
{
    "version": "2.0.0",
    "name": "OASIS Revolution",
    "description": "Ultra-Lightweight AI System for Termux",
    "api_endpoint": "https://api-inference.huggingface.co/models",
    "models": {
        "chat": "microsoft/DialoGPT-medium",
        "sentiment": "cardiffnlp/twitter-roberta-base-sentiment-latest",
        "qa": "deepset/roberta-base-squad2",
        "summarization": "facebook/bart-large-cnn"
    },
    "limits": {
        "max_tokens": 1000,
        "timeout": 30,
        "retry_attempts": 3
    },
    "business": {
        "free_tier_limit": 100,
        "premium_multiplier": 10,
        "enterprise_multiplier": 100
    },
    "installation": {
        "date": "$(date -Iseconds)",
        "mode": "INSTALL_MODE",
        "termux": "TERMUX_ENV"
    }
}
CONFIG_EOF
    
    # Make scripts executable
    chmod +x core/oasis_engine.py
    chmod +x oasis_launcher.py
    
    print_success "OASIS core files installed"
}

# Business Tools Installation
install_business_tools() {
    if [ "$INSTALL_MODE" = "business" ] || [ "$INSTALL_MODE" = "full" ]; then
        print_status "Installing business analytics tools..."
        
        # Business dashboard script
        cat > scripts/business_dashboard.py << 'BUSINESS_EOF'
#!/usr/bin/env python3
"""
📈 OASIS Business Dashboard
Revenue tracking and analytics
"""

import json
import os
from datetime import datetime

def get_business_metrics():
    """Get current business metrics"""
    try:
        with open("business/analytics/daily_stats.json", 'r') as f:
            return json.load(f)
    except:
        return {
            "total_revenue": 0.0,
            "total_requests": 0,
            "date": datetime.now().strftime("%Y-%m-%d")
        }

def display_dashboard():
    """Display business dashboard"""
    metrics = get_business_metrics()
    
    print("📈 OASIS Business Dashboard")
    print("=" * 40)
    print(f"💰 Revenue: ${metrics.get('total_revenue', 0):.2f}")
    print(f"📊 Requests: {metrics.get('total_requests', 0)}")
    print(f"📅 Date: {metrics.get('date', 'Unknown')}")
    
    # Revenue projections
    daily_revenue = metrics.get('total_revenue', 0)
    print(f"\n📊 Projections:")
    print(f"   Weekly: ${daily_revenue * 7:.2f}")
    print(f"   Monthly: ${daily_revenue * 30:.2f}")
    print(f"   Yearly: ${daily_revenue * 365:.2f}")

if __name__ == "__main__":
    display_dashboard()
BUSINESS_EOF
        
        chmod +x scripts/business_dashboard.py
        print_success "Business tools installed"
    fi
}

# Create Quick Commands
create_commands() {
    print_status "Creating quick command shortcuts..."
    
    # Create main launcher script
    cat > oasis << 'MAIN_LAUNCHER_EOF'
#!/bin/bash
# OASIS Revolution Quick Launcher

OASIS_DIR="$HOME/oasis_revolution"

if [ ! -d "$OASIS_DIR" ]; then
    echo "❌ OASIS not found. Run installation script first."
    exit 1
fi

cd "$OASIS_DIR"

case "$1" in
    "chat"|"c")
        echo "🚀 Starting OASIS Chat..."
        python3 oasis_launcher.py
        ;;
    "business"|"b")
        echo "📈 Opening Business Dashboard..."
        python3 scripts/business_dashboard.py
        ;;
    "test"|"t")
        echo "🔍 Running OASIS Test..."
        python3 core/oasis_engine.py
        ;;
    "status"|"s")
        echo "📊 OASIS Status:"
        echo "   Directory: $OASIS_DIR"
        echo "   Core Engine: $([ -f core/oasis_engine.py ] && echo '✅ Present' || echo '❌ Missing')"
        echo "   Config: $([ -f config/oasis_config.json ] && echo '✅ Present' || echo '❌ Missing')"
        ;;
    "update"|"u")
        echo "🔄 Updating OASIS..."
        # Future: git pull or download updates
        echo "Update feature coming soon!"
        ;;
    *)
        echo "🌟 OASIS Revolution Quick Commands:"
        echo "   oasis chat     (c) - Start AI chat interface"
        echo "   oasis business (b) - Open business dashboard" 
        echo "   oasis test     (t) - Run system test"
        echo "   oasis status   (s) - Show system status"
        echo "   oasis update   (u) - Update OASIS"
        echo ""
        echo "🚀 Default: Starting main interface..."
        python3 oasis_launcher.py
        ;;
esac
MAIN_LAUNCHER_EOF
    
    chmod +x oasis
    
    # Add to PATH if possible
    if [ "$TERMUX_ENV" = true ]; then
        # Termux: add to ~/.bashrc
        if ! grep -q "export PATH.*oasis_revolution" ~/.bashrc 2>/dev/null; then
            echo "export PATH=\"$OASIS_DIR:\$PATH\"" >> ~/.bashrc
            print_success "Added OASIS to PATH (restart shell to use 'oasis' command)"
        fi
    else
        # Regular Linux: suggest manual PATH addition
        print_status "To use 'oasis' command globally, add this to your ~/.bashrc:"
        echo "export PATH=\"$OASIS_DIR:\$PATH\""
    fi
    
    print_success "Quick commands created"
}

# Performance Optimization
optimize_performance() {
    print_status "Optimizing system performance..."
    
    # Create optimized Python startup
    export PYTHONDONTWRITEBYTECODE=1
    export PYTHONUNBUFFERED=1
    
    # Set optimal Python flags for Termux
    if [ "$TERMUX_ENV" = true ]; then
        cat > scripts/optimize_termux.sh << 'OPTIMIZE_EOF'
#!/bin/bash
# Termux Performance Optimization
echo "⚡ Optimizing Termux for OASIS..."

# Python optimizations
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUNBUFFERED=1

# Memory optimization
if command -v termux-wake-lock &> /dev/null; then
    termux-wake-lock
    echo "🔋 Wake lock enabled"
fi

echo "✅ Termux optimizations applied"
OPTIMIZE_EOF
        chmod +x scripts/optimize_termux.sh
    fi
    
    print_success "Performance optimizations applied"
}

# Installation Testing
test_installation() {
    print_status "Testing OASIS installation..."
    
    cd "$OASIS_DIR"
    
    # Test core engine
    if python3 core/oasis_engine.py > /dev/null 2>&1; then
        print_success "Core engine test passed"
    else
        print_error "Core engine test failed"
        return 1
    fi
    
    # Test configuration loading
    if python3 -c "import json; json.load(open('config/oasis_config.json'))" 2>/dev/null; then
        print_success "Configuration test passed"
    else
        print_error "Configuration test failed"
        return 1
    fi
    
    # Test directory structure
    required_dirs=("core" "config" "logs" "business")
    for dir in "${required_dirs[@]}"; do
        if [ -d "$dir" ]; then
            print_success "Directory $dir: ✅"
        else
            print_error "Directory $dir: ❌ Missing"
            return 1
        fi
    done
    
    print_success "All tests passed!"
    return 0
}

# Create Documentation
create_documentation() {
    print_status "Creating documentation..."
    
    cat > README.md << 'README_EOF'
# 🌟 OASIS Revolution - Ultra-Lightweight AI System

## The New Civilization in Your Pocket

OASIS (Open AI System Infrastructure Simplified) is an ultra-lightweight AI system designed specifically for Termux and mobile environments.

### ✨ Features
- 🚀 **Ultra-Lightweight**: <5MB total footprint
- ⚡ **Zero Heavy Dependencies**: Pure Python + urllib only
- 🔗 **API-First Architecture**: Powered by Hugging Face
- 📱 **Termux-Optimized**: Perfect for mobile AI
- 💼 **Business-Ready**: Revenue tracking and analytics
- 🌍 **Open Source**: MIT Licensed

### 🎯 Quick Start

```bash
# Launch OASIS
./oasis

# Or use specific commands
./oasis chat      # Start AI chat
./oasis business  # View analytics
./oasis test      # Run system test
./oasis status    # Check status
```

### 🏗️ Architecture

```
oasis_revolution/
├── core/                 # Core AI engine
├── config/              # Configuration files
├── business/            # Business analytics
├── scripts/             # Utility scripts
└── logs/               # System logs
```

### 📊 Business Model

- **Phase 1**: Open Source Foundation ($50K-200K)
- **Phase 2**: Premium Services ($1M-5M) 
- **Phase 3**: Enterprise Platform ($100M+)

### 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Submit pull request
4. Join the revolution!

### 📧 Contact

- GitHub: [Your GitHub Username]
- Email: your-email@example.com
- Discord: OASIS Revolution Community

---

**"The New Civilization Begins with OASIS"**
README_EOF
    
    # Create quick reference
    cat > docs/QUICK_REFERENCE.md << 'QUICKREF_EOF'
# 📚 OASIS Quick Reference

## Essential Commands

### Main Interface
```bash
./oasis           # Main menu
./oasis chat      # AI Chat mode
./oasis business  # Business dashboard
```

### System Management
```bash
./oasis status    # System status
./oasis test      # Run tests
./oasis update    # Update system
```

## Python API Examples

### Basic Usage
```python
from core.oasis_engine import OASISCore

# Initialize
core = OASISCore()

# Chat
response = core.chat("Hello AI!")

# Sentiment Analysis
sentiment = core.analyze_sentiment("I love this!")
```

### Business Analytics
```python
from hf_controller import HFApiController

# Initialize with business features
controller = HFApiController()

# Get dashboard
dashboard = controller.get_business_dashboard()
print(dashboard['revenue_metrics'])
```

## Configuration

Edit `config/oasis_config.json` to customize:
- Model endpoints
- Rate limits  
- Business settings
- API tokens

## Troubleshooting

### Common Issues
1. **Network Error**: Check internet connection
2. **API Error**: Verify HF token validity
3. **Permission Error**: Check file permissions
4. **Import Error**: Ensure Python 3.6+

### Getting Help
- Check logs in `logs/` directory
- Run `./oasis test` for diagnostics
- Join our Discord community
QUICKREF_EOF
    
    print_success "Documentation created"
}

# Final Setup and Summary
finalize_installation() {
    print_status "Finalizing installation..."
    
    # Set proper permissions
    find "$OASIS_DIR" -name "*.py" -exec chmod +x {} \;
    find "$OASIS_DIR" -name "*.sh" -exec chmod +x {} \;
    
    # Create initial log entry
    mkdir -p logs
    echo "$(date -Iseconds): OASIS Revolution installed successfully" > logs/install.log
    
    # Update config with installation details
    sed -i "s/INSTALL_MODE/$INSTALL_MODE/g" config/oasis_config.json
    sed -i "s/TERMUX_ENV/$TERMUX_ENV/g" config/oasis_config.json
    
    print_success "Installation finalized"
}

# Installation Summary
show_summary() {
    echo ""
    echo -e "${GREEN}🎉 OASIS REVOLUTION INSTALLATION COMPLETE! 🎉${NC}"
    echo ""
    echo -e "${CYAN}📍 Installation Directory: $OASIS_DIR${NC}"
    echo -e "${CYAN}📦 Installation Mode: $INSTALL_MODE${NC}"
    echo -e "${CYAN}🔧 Environment: $([ "$TERMUX_ENV" = true ] && echo "Termux" || echo "Linux")${NC}"
    echo ""
    echo -e "${YELLOW}🚀 Quick Start Commands:${NC}"
    echo -e "   ${BLUE}cd $OASIS_DIR${NC}"
    echo -e "   ${BLUE}./oasis${NC}                 # Start OASIS"
    echo -e "   ${BLUE}./oasis chat${NC}            # AI Chat"
    echo -e "   ${BLUE}./oasis business${NC}        # Business Dashboard"
    echo ""
    echo -e "${PURPLE}💡 What's Next:${NC}"
    echo "   1. 🔥 Run './oasis test' to verify everything works"
    echo "   2. 🚀 Start with './oasis chat' for AI conversations"
    echo "   3. 📊 Check './oasis business' for revenue tracking"
    echo "   4. 📚 Read docs/QUICK_REFERENCE.md for advanced usage"
    echo ""
    echo -e "${GREEN}🌟 Welcome to The New Civilization! 🌟${NC}"
}

# Main Installation Flow
main() {
    print_banner
    
    # Pre-installation checks
    check_system
    
    # Core installation
    install_packages
    create_directory_structure
    download_core_files
    
    # Optional components based on mode
    if [ "$INSTALL_MODE" = "full" ] || [ "$INSTALL_MODE" = "business" ]; then
        install_business_tools
    fi
    
    # System setup
    create_commands
    optimize_performance
    create_documentation
    finalize_installation
    
    # Post-installation
    if test_installation; then
        show_summary
        
        # Offer to start OASIS
        echo ""
        read -p "🚀 Would you like to start OASIS now? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            cd "$OASIS_DIR"
            python3 oasis_launcher.py
        fi
    else
        print_error "Installation completed with errors. Check the logs."
        exit 1
    fi
}

# Handle script arguments
case "$1" in
    "--help"|"-h")
        echo "🌟 OASIS Revolution Installer"
        echo ""
        echo "Usage: $0 [mode]"
        echo ""
        echo "Modes:"
        echo "  --quick    Minimal installation (core only)"
        echo "  --full     Complete installation (recommended)"
        echo "  --business Business features + analytics"
        echo "  --help     Show this help"
        echo ""
        echo "Default: full installation"
        exit 0
        ;;
    "--quick")
        INSTALL_MODE="quick"
        ;;
    "--business")
        INSTALL_MODE="business"
        ;;
    "--full"|"")
        INSTALL_MODE="full"
        ;;
    *)
        print_error "Unknown option: $1"
        echo "Use --help for usage information"
        exit 1
        ;;
esac

# Run main installation
main