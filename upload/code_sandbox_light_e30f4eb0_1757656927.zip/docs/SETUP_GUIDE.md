# 🚀 OASIS 2.0 Setup Guide

> **Complete Installation Guide for Ultra-Lightweight AI Superintelligence**

## 📋 **Table of Contents**
- [Quick Start](#quick-start)
- [Termux Setup](#termux-setup)  
- [HuggingFace Configuration](#huggingface-configuration)
- [Dashboard Deployment](#dashboard-deployment)
- [Business Configuration](#business-configuration)
- [Troubleshooting](#troubleshooting)

---

## 🚀 **Quick Start**

### **1-Minute Launch (Web Dashboard)**
```bash
# Clone or download the dashboard
git clone https://github.com/oasis-revolution/dashboard.git
cd dashboard

# Launch locally
python -m http.server 8000

# Open in browser
open http://localhost:8000
```

### **5-Minute Termux Setup**
```bash
# Download and run setup
curl -fsSL https://raw.githubusercontent.com/oasis-revolution/dashboard/main/termux/setup.sh | bash

# Launch OASIS
~/oasis_revolution/launch.sh
```

---

## 📱 **Termux Setup (Android)**

### **Prerequisites** 
- Android device (6.0+)
- Termux app from F-Droid or Google Play
- 50MB free storage minimum
- Internet connection for initial setup

### **Step 1: Install Termux**
```bash
# Download Termux from F-Droid (recommended)
# Or Google Play Store
```

### **Step 2: Run OASIS Setup**
```bash
# Update Termux packages
pkg update && pkg upgrade -y

# Download OASIS setup script
curl -fsSL https://raw.githubusercontent.com/oasis-revolution/dashboard/main/termux/setup.sh -o oasis_setup.sh

# Make executable and run
chmod +x oasis_setup.sh
./oasis_setup.sh
```

### **Step 3: Verify Installation**
```bash
# Check OASIS status
~/oasis_revolution/monitor.sh

# Expected output:
# ✅ OASIS footprint: <5MB
# ✅ Zero heavy dependencies confirmed
# ✅ Business services ready
```

---

## 🤖 **HuggingFace Configuration**

### **Get API Token**
1. Visit [HuggingFace Settings](https://huggingface.co/settings/tokens)
2. Create new token with `read` permissions
3. Copy the token

### **Configure OASIS**
```bash
# Edit configuration
nano ~/oasis_revolution/.env

# Add your token:
HUGGINGFACE_API_KEY=hf_your_token_here
```

### **Test Integration**
```bash
# Run test command
cd ~/oasis_revolution
python oasis_commander.py status

# Should show:
# 🤖 HuggingFace Integration: CONNECTED
```

---

## 🖥️ **Dashboard Deployment**

### **Local Development**
```bash
# Navigate to dashboard directory
cd /path/to/oasis-dashboard

# Start development server
python -m http.server 3000

# Access dashboard
# http://localhost:3000
```

### **Static Hosting (GitHub Pages)**
```bash
# Fork the repository
# Enable GitHub Pages in settings
# Access at: https://yourusername.github.io/dashboard
```

### **Custom Domain Deployment**
```bash
# Build optimized version
npm run build

# Deploy to your hosting service
# (Netlify, Vercel, Firebase, etc.)
```

---

## 💼 **Business Configuration**

### **Revenue Targets**
```bash
# Edit business configuration
nano ~/oasis_revolution/.env

# Set targets:
REVENUE_TARGET=5000
CONTENT_PRICING_MIN=50
CONTENT_PRICING_MAX=200
API_PRICING_MIN=0.01
API_PRICING_MAX=0.10
```

### **Service Activation**
```bash
# Start revenue generation
~/oasis_revolution/demo_revenue.sh

# Monitor earnings
tail -f ~/oasis_revolution/logs/oasis_*.log
```

### **Automation Setup**
```bash
# Enable auto-start (optional)
echo "~/oasis_revolution/launch.sh" >> ~/.bashrc

# Schedule revenue automation (cron)
crontab -e
# Add: 0 */6 * * * ~/oasis_revolution/demo_revenue.sh
```

---

## 🔧 **Troubleshooting**

### **Common Issues**

#### **"Permission Denied" Error**
```bash
# Fix permissions
chmod +x ~/oasis_revolution/*.sh
chmod +x ~/oasis_revolution/*.py
```

#### **"Module Not Found" Error** 
```bash
# Reinstall Python dependencies
pip install requests python-dotenv aiohttp flask --no-cache-dir
```

#### **"API Token Invalid" Error**
```bash
# Check token configuration
cat ~/oasis_revolution/.env | grep HUGGINGFACE_API_KEY

# Regenerate token at HuggingFace
# Update .env file with new token
```

#### **High Memory Usage**
```bash
# Check for forbidden packages
pip list | grep -E "(numpy|torch|pytorch|pandas)"

# Remove if found
pip uninstall numpy torch pytorch pandas scikit-learn transformers -y
```

### **Performance Optimization**

#### **Reduce Footprint**
```bash
# Clean pip cache
pip cache purge

# Remove unused packages
pip freeze | grep -v -E "(requests|python-dotenv|aiohttp|flask)" | xargs pip uninstall -y
```

#### **Speed Up Startup**
```bash
# Preload modules
echo "python -c 'import requests, json, time'" >> ~/.bashrc
```

### **Debug Mode**
```bash
# Enable debug logging
echo "DEBUG_MODE=true" >> ~/oasis_revolution/.env

# View detailed logs
tail -f ~/oasis_revolution/logs/oasis_*.log
```

---

## 📊 **System Requirements**

### **Minimum Requirements**
- **Storage**: 50MB free space
- **RAM**: 512MB available
- **Network**: Internet connection for API calls
- **OS**: Android 6.0+ (Termux) or any modern OS (Dashboard)

### **Recommended Setup**
- **Storage**: 200MB+ for logs and data
- **RAM**: 1GB+ for smooth operation
- **Network**: Stable broadband connection
- **Device**: Modern Android phone or tablet

---

## 🚀 **Next Steps After Setup**

### **Immediate Actions**
1. **Test All Services**: Verify content generation, API calls, custom solutions
2. **Configure Business Settings**: Set pricing, targets, automation preferences  
3. **Generate First Revenue**: Run demo workflows and monitor earnings
4. **Customize Dashboard**: Adjust colors, metrics, and display preferences

### **Week 1 Goals**
- [ ] Complete setup verification
- [ ] Generate first $100 in simulated revenue
- [ ] Optimize system performance
- [ ] Set up monitoring and alerts

### **Month 1 Goals**  
- [ ] Real HuggingFace API integration
- [ ] First actual client and revenue
- [ ] Performance benchmarking
- [ ] Business process optimization

---

## 🆘 **Support & Community**

### **Get Help**
- 📧 Email: support@oasis-revolution.ai
- 💬 Discord: [OASIS Community](https://discord.gg/oasis)
- 📖 Documentation: [docs.oasis-revolution.ai](https://docs.oasis-revolution.ai)
- 🐛 Issues: [GitHub Issues](https://github.com/oasis-revolution/dashboard/issues)

### **Contributing**
- 🔧 Development: See [CONTRIBUTING.md](CONTRIBUTING.md)
- 💡 Feature Requests: [GitHub Discussions](https://github.com/oasis-revolution/dashboard/discussions)
- 📝 Documentation: Help improve this guide

---

**🌟 Ready to revolutionize your AI business? The setup is complete - now let's generate some revenue! 💰**