/**
 * OASIS 2.0 Revolutionary Dashboard Controller
 * Ultra-Lightweight AI Superintelligence Business Management
 */

class OasisDashboard {
    constructor() {
        this.revenue = {
            monthly: 0,
            daily: 0,
            total: 0
        };
        this.services = [];
        this.apiCalls = 0;
        this.logs = [];
        
        this.init();
    }

    init() {
        this.setupCharts();
        this.startSimulation();
        this.initializeSystem();
        this.setupEventListeners();
    }

    setupCharts() {
        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        this.revenueChart = new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Month 1', 'Month 2', 'Month 3', 'Month 4', 'Month 5', 'Month 6'],
                datasets: [{
                    label: 'Revenue Projection ($)',
                    data: [500, 1200, 2800, 4500, 7200, 12000],
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: 'white' }
                    }
                },
                scales: {
                    x: { 
                        ticks: { color: 'white' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y: { 
                        ticks: { color: 'white' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    }
                }
            }
        });

        // Service Performance Chart
        const serviceCtx = document.getElementById('serviceChart').getContext('2d');
        this.serviceChart = new Chart(serviceCtx, {
            type: 'doughnut',
            data: {
                labels: ['Content Generation', 'API Reseller', 'Custom Solutions'],
                datasets: [{
                    data: [45, 30, 25],
                    backgroundColor: [
                        'rgb(59, 130, 246)',
                        'rgb(147, 51, 234)',
                        'rgb(249, 115, 22)'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { 
                            color: 'white',
                            padding: 20
                        }
                    }
                }
            }
        });
    }

    startSimulation() {
        // Simulate real-time revenue generation
        setInterval(() => {
            this.simulateRevenue();
            this.updateDashboard();
        }, 3000);

        // Simulate API calls
        setInterval(() => {
            this.apiCalls += Math.floor(Math.random() * 5) + 1;
            this.updateApiCalls();
        }, 2000);

        // Add system logs
        setInterval(() => {
            this.addSystemLog();
        }, 4000);
    }

    simulateRevenue() {
        const services = [
            { name: 'Content Generation', min: 50, max: 200 },
            { name: 'API Reseller', min: 1, max: 10 },
            { name: 'Custom Solutions', min: 500, max: 2000 }
        ];

        if (Math.random() < 0.3) { // 30% chance of new revenue
            const service = services[Math.floor(Math.random() * services.length)];
            const amount = Math.floor(Math.random() * (service.max - service.min + 1)) + service.min;
            
            this.revenue.monthly += amount;
            this.revenue.total += amount;
            
            this.addLog(`💰 Revenue: +$${amount} from ${service.name}`, 'success');
        }
    }

    initializeSystem() {
        this.addLog('🚀 OASIS 2.0 Revolution Starting...', 'info');
        this.addLog('📱 Termux Command Center: Initializing...', 'info');
        
        setTimeout(() => {
            this.addLog('✅ Ultra-lightweight environment loaded (<5MB)', 'success');
            this.addLog('🤖 HuggingFace API: Connected', 'success');
            this.addLog('💼 Business modules: Ready', 'success');
            this.addLog('🎯 Revenue streams: ACTIVE', 'success');
        }, 2000);

        // Initialize live commands
        this.updateLiveCommands();
    }

    updateLiveCommands() {
        const commands = [
            '> python oasis_commander.py --start',
            '> curl -X POST https://api-inference.huggingface.co/models/...',
            '> ./revenue_automation.py --monitor',
            '> git push origin oasis-revolution',
            '> python business_ai_services.py --status'
        ];

        const commandsEl = document.getElementById('live-commands');
        
        setInterval(() => {
            const randomCommand = commands[Math.floor(Math.random() * commands.length)];
            const timestamp = new Date().toLocaleTimeString();
            
            const newCommand = document.createElement('div');
            newCommand.innerHTML = `<span class="text-gray-500">[${timestamp}]</span> ${randomCommand}`;
            
            commandsEl.appendChild(newCommand);
            
            // Keep only last 5 commands
            while (commandsEl.children.length > 5) {
                commandsEl.removeChild(commandsEl.firstChild);
            }
            
            // Scroll to bottom
            commandsEl.scrollTop = commandsEl.scrollHeight;
        }, 5000);
    }

    updateDashboard() {
        document.getElementById('monthly-revenue').textContent = `$${this.revenue.monthly.toLocaleString()}`;
        document.getElementById('active-services').textContent = this.services.length;
        
        // Animate numbers
        this.animateNumber('monthly-revenue', this.revenue.monthly);
    }

    updateApiCalls() {
        document.getElementById('api-calls').textContent = this.apiCalls.toLocaleString();
        this.animateNumber('api-calls', this.apiCalls);
    }

    animateNumber(elementId, targetValue) {
        const element = document.getElementById(elementId);
        element.classList.add('pulse-animation');
        setTimeout(() => {
            element.classList.remove('pulse-animation');
        }, 1000);
    }

    addLog(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const log = {
            time: timestamp,
            message: message,
            type: type
        };
        
        this.logs.unshift(log);
        
        // Keep only last 50 logs
        if (this.logs.length > 50) {
            this.logs.pop();
        }
        
        this.updateSystemLogs();
    }

    addSystemLog() {
        const systemMessages = [
            { msg: '🔄 Processing HuggingFace API request...', type: 'info' },
            { msg: '📊 Analytics data updated', type: 'info' },
            { msg: '🛡️ Security scan completed', type: 'success' },
            { msg: '⚡ Performance optimization applied', type: 'success' },
            { msg: '🌐 Network connection stable', type: 'info' },
            { msg: '💾 Data backup completed', type: 'success' },
            { msg: '🔧 System maintenance routine', type: 'info' }
        ];

        const randomMsg = systemMessages[Math.floor(Math.random() * systemMessages.length)];
        this.addLog(randomMsg.msg, randomMsg.type);
    }

    updateSystemLogs() {
        const logsContainer = document.getElementById('system-logs');
        
        logsContainer.innerHTML = this.logs.map(log => {
            const colorClass = {
                'info': 'text-cyan-400',
                'success': 'text-green-400',
                'warning': 'text-yellow-400',
                'error': 'text-red-400'
            }[log.type] || 'text-gray-400';
            
            return `<div class="${colorClass}">[${log.time}] ${log.message}</div>`;
        }).join('');
        
        // Auto-scroll to top to show latest logs
        logsContainer.scrollTop = 0;
    }

    setupEventListeners() {
        // Service buttons will be handled by global functions
        // for simplicity in the HTML onclick handlers
    }
}

// Global functions for button actions
function startService(type) {
    const serviceNames = {
        'content': 'Content Generation',
        'api': 'API Reseller',
        'custom': 'Custom Solutions'
    };
    
    const serviceName = serviceNames[type];
    dashboard.services.push({
        type: type,
        name: serviceName,
        status: 'active',
        startTime: new Date()
    });
    
    dashboard.addLog(`🚀 ${serviceName} service launched!`, 'success');
    dashboard.updateDashboard();
    
    // Show success animation
    showNotification(`${serviceName} service is now ACTIVE! 🎉`);
}

function deployOasis() {
    dashboard.addLog('🚀 Deploying OASIS Revolution...', 'info');
    
    setTimeout(() => {
        dashboard.addLog('✅ OASIS deployment successful!', 'success');
        dashboard.addLog('🌟 The New Civilization is LIVE!', 'success');
    }, 2000);
    
    showNotification('OASIS Revolution Deployed! 🚀');
}

function startRevenue() {
    dashboard.addLog('💰 Starting revenue generation...', 'info');
    dashboard.addLog('📈 All business services activated', 'success');
    
    // Boost revenue simulation
    for (let i = 0; i < 3; i++) {
        setTimeout(() => {
            dashboard.simulateRevenue();
        }, i * 1000);
    }
    
    showNotification('Revenue streams activated! 💰');
}

function monitorSystem() {
    dashboard.addLog('👁️ System monitoring initiated...', 'info');
    dashboard.addLog('📊 All systems operational', 'success');
    dashboard.addLog('🔋 Resource usage: Optimal', 'success');
    
    showNotification('System monitoring active! 👁️');
}

function viewLogs() {
    const logsContainer = document.getElementById('system-logs');
    logsContainer.scrollIntoView({ behavior: 'smooth' });
    
    showNotification('System logs displayed! 📋');
}

function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Initialize dashboard when page loads
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new OasisDashboard();
});

// Revenue calculator functionality
function calculateRevenue() {
    const services = parseInt(document.getElementById('services')?.value || 3);
    const clients = parseInt(document.getElementById('clients')?.value || 10);
    const pricing = parseInt(document.getElementById('pricing')?.value || 150);
    
    const monthlyRevenue = services * clients * pricing;
    const yearlyRevenue = monthlyRevenue * 12;
    
    if (document.getElementById('monthly-result')) {
        document.getElementById('monthly-result').textContent = `$${monthlyRevenue.toLocaleString()}`;
        document.getElementById('yearly-result').textContent = `$${yearlyRevenue.toLocaleString()}`;
    }
    
    return { monthly: monthlyRevenue, yearly: yearlyRevenue };
}

// Export functionality for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { OasisDashboard, calculateRevenue };
}