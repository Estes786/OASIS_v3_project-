# OASIS v3 Termux Orchestrator

**Ultra-lightweight AI orchestration system for mobile devices**

## Overview

The OASIS v3 Termux Orchestrator transforms your Android device into a powerful AI command center. With a footprint of less than 50MB, it provides access to cutting-edge AI capabilities through Hugging Face's cloud infrastructure while maintaining the "Zero-Cost & Zero-Burden" philosophy.

## Features

- 🚀 **Ultra-lightweight**: < 50MB total footprint
- 🤖 **AI Services**: Text generation, sentiment analysis, summarization, translation, Q&A
- 💰 **Revenue Engine**: Built-in freemium model and usage tracking
- ⚙️ **Configuration Management**: Flexible configuration system
- 📊 **Analytics**: Comprehensive usage and revenue analytics
- 🔒 **Secure**: Token-based authentication with Hugging Face
- 📱 **Mobile-first**: Optimized for Termux on Android

## Quick Start

### 1. Installation

```bash
# Download and run the setup script
curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/termux-orchestrator/termux_setup.sh | bash

# Or manual installation:
pkg update && pkg upgrade
pkg install python git curl nano
pip install requests flask flask-cors python-dotenv
```

### 2. Configuration

```bash
# Navigate to OASIS directory
cd ~/oasis-v3

# Set your Hugging Face API key
nano config/.env
# Add: HUGGING_FACE_API_KEY=your_token_here
```

### 3. Quick Test

```bash
# Run quick start
./quick_start.sh

# Or test manually
python3 oasis_orchestrator.py status
```

## Usage

### Command Line Interface

```bash
# Get system status
python3 oasis_orchestrator.py status

# Run diagnostics
python3 oasis_orchestrator.py diagnostics

# Generate text
python3 oasis_orchestrator.py generate --text "The future of AI is"

# Analyze sentiment
python3 oasis_orchestrator.py sentiment --text "I love this AI system!"

# Interactive mode
python3 oasis_orchestrator.py --interactive
```

### Interactive Mode

```bash
python3 oasis_orchestrator.py -i

# Available commands in interactive mode:
oasis> generate Hello world
oasis> sentiment I'm feeling great today!
oasis> summarize [long text here]
oasis> translate Hello world
oasis> status
oasis> help
oasis> exit
```

### Python API

```python
from oasis_orchestrator import OASISOrchestrator

# Initialize orchestrator
orchestrator = OASISOrchestrator()

# Generate text
result = orchestrator.generate_text("The future of AI is", max_length=100)
print(result["generated_text"])

# Analyze sentiment
result = orchestrator.analyze_sentiment("I love this new technology!")
print(result["sentiment"])

# Get system status
status = orchestrator.get_status()
print(status)
```

## Services

### Text Generation
- **Model**: GPT-2 (default)
- **Usage**: Creative writing, content generation, code completion
- **Rate Limit**: 100 requests/hour (free tier)

### Sentiment Analysis
- **Model**: RoBERTa-base-sentiment
- **Usage**: Social media monitoring, customer feedback analysis
- **Rate Limit**: 200 requests/hour (free tier)

### Text Summarization
- **Model**: BART-large-CNN
- **Usage**: Document summarization, news briefing
- **Rate Limit**: 50 requests/hour (free tier)

### Translation
- **Models**: Helsinki-NLP OPUS models
- **Languages**: EN↔FR, EN↔DE, EN↔ES, FR↔EN
- **Rate Limit**: 100 requests/hour (free tier)

### Question Answering
- **Model**: RoBERTa-base-squad2
- **Usage**: Information extraction, chatbots
- **Rate Limit**: 100 requests/hour (free tier)

## Configuration

### Environment Variables

```bash
# Required
HUGGING_FACE_API_KEY=your_token_here

# Optional
OASIS_VERSION=3.0
OASIS_PLATFORM=termux
LOG_LEVEL=INFO
DEBUG_MODE=false
```

### Service Configuration

```python
from config_manager import ConfigManager

config = ConfigManager()

# Enable/disable services
config.enable_service("text_generation")
config.disable_service("translation")

# Update service settings
config.update_service_config("text_generation", {
    "default_model": "gpt2",
    "max_length": 150,
    "rate_limit": 200
})
```

## Revenue Model

### Freemium Tiers

| Tier | Monthly Cost | Daily Requests | Hourly Requests | Features |
|------|-------------|----------------|-----------------|----------|
| Free | $0 | 100 | 20 | Basic AI services |
| Premium | $9.99 | 1,000 | 200 | Advanced models, priority |
| Enterprise | $99.99 | 10,000 | 2,000 | Custom models, support |

### Usage Tracking

```python
from revenue_engine import RevenueEngine

revenue = RevenueEngine()

# Register user
revenue.register_user("user123", "free")

# Check limits
limits = revenue.check_usage_limits("user123", "text_generation")
if limits["can_proceed"]:
    # Process request
    revenue.record_usage("user123", "text_generation", tokens_used=10)

# Get user stats
stats = revenue.get_user_stats("user123")
print(f"Usage: {stats['usage']['daily_requests']}/{stats['limits']['daily']}")
```

## Architecture

```
┌─────────────────────────────────────────┐
│ TERMUX COMMAND CENTER (<50MB)          │
├─────────────────────────────────────────┤
│ ┌─────────────┐ ┌─────────────────────┐ │
│ │ Orchestrator│ │ Configuration       │ │
│ │ Engine      │ │ Manager             │ │
│ └─────────────┘ └─────────────────────┘ │
│ ┌─────────────┐ ┌─────────────────────┐ │
│ │ HF Client   │ │ Revenue Engine      │ │
│ │ (API)       │ │ (Monetization)      │ │
│ └─────────────┘ └─────────────────────┘ │
└─────────────────────────────────────────┘
                    │ HTTPS API
                    ▼
┌─────────────────────────────────────────┐
│ HUGGING FACE CLOUD (Unlimited Scale)   │
│ ┌─────────┐ ┌─────────┐ ┌─────────────┐ │
│ │ Text    │ │ Vision  │ │ Audio       │ │
│ │ Models  │ │ Models  │ │ Models      │ │
│ └─────────┘ └─────────┘ └─────────────┘ │
└─────────────────────────────────────────┘
```

## File Structure

```
oasis-v3/termux-orchestrator/
├── oasis_orchestrator.py      # Main orchestrator
├── hf_client.py               # Hugging Face API client
├── config_manager.py          # Configuration management
├── revenue_engine.py          # Monetization engine
├── termux_setup.sh           # Installation script
├── requirements.txt          # Python dependencies
└── README.md                 # This file

~/oasis-v3/                   # Runtime directory
├── config/
│   ├── .env                  # Environment variables
│   └── oasis_config.json     # Configuration file
├── logs/
│   └── orchestrator.log      # Application logs
└── data/
    ├── usage_records.json    # Usage tracking
    ├── user_tiers.json       # User subscriptions
    └── revenue_stats.json    # Revenue statistics
```

## Troubleshooting

### Common Issues

1. **API Key Not Set**
   ```bash
   # Check environment
   echo $HUGGING_FACE_API_KEY
   
   # Set in .env file
   nano ~/oasis-v3/config/.env
   ```

2. **Model Loading Errors**
   ```bash
   # Check internet connection
   curl -I https://api-inference.huggingface.co
   
   # Run diagnostics
   python3 oasis_orchestrator.py diagnostics
   ```

3. **Rate Limit Exceeded**
   ```bash
   # Check usage
   python3 -c "from revenue_engine import RevenueEngine; r=RevenueEngine(); print(r.get_user_stats('your_user_id'))"
   ```

### Performance Optimization

1. **Memory Usage**
   - Monitor with `top` or `htop`
   - Adjust cache settings in config
   - Use lightweight models for frequent tasks

2. **Network Optimization**
   - Use WiFi when possible
   - Cache responses for repeated queries
   - Batch requests when applicable

3. **Battery Optimization**
   - Reduce logging level in production
   - Use sleep modes between requests
   - Optimize request frequency

## Development

### Adding New Services

1. **Extend HF Client**
   ```python
   def new_service(self, input_data, model="model-name"):
       payload = {"inputs": input_data}
       result = self._make_request(model, payload)
       return self._format_response(result)
   ```

2. **Update Orchestrator**
   ```python
   def new_service_endpoint(self, data):
       return self.hf_client.new_service(data)
   ```

3. **Add Configuration**
   ```json
   "new_service": {
       "enabled": true,
       "default_model": "model-name",
       "rate_limit": 100
   }
   ```

### Testing

```bash
# Run all tests
python3 -m pytest tests/

# Test specific component
python3 hf_client.py test
python3 oasis_orchestrator.py diagnostics

# Load testing
python3 tests/load_test.py
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

- 📧 Email: support@oasis-ai.org
- 💬 Discord: [OASIS Community](https://discord.gg/oasis)
- 📖 Documentation: [docs.oasis-ai.org](https://docs.oasis-ai.org)
- 🐛 Issues: [GitHub Issues](https://github.com/your-repo/oasis-v3/issues)

## Roadmap

- [ ] Voice interface integration
- [ ] Image generation services
- [ ] Custom model fine-tuning
- [ ] Blockchain integration
- [ ] Quantum computing support
- [ ] Multi-language UI
- [ ] Desktop companion app

---

**OASIS v3 - Democratizing AI, One Mobile Device at a Time** 🚀

