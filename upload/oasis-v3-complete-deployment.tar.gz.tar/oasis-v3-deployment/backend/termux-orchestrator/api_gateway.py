#!/usr/bin/env python3
"""
OASIS v3 API Gateway
Ultra-lightweight API gateway for unified access to all OASIS services.
Handles authentication, rate limiting, and service orchestration.
"""

import json
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
import hashlib
import secrets

logger = logging.getLogger(__name__)

@dataclass
class APIKey:
    """API key configuration"""
    key_id: str
    key_hash: str
    user_id: str
    tier: str
    created_at: str
    last_used: str
    is_active: bool
    permissions: List[str]

@dataclass
class RateLimitConfig:
    """Rate limiting configuration"""
    requests_per_minute: int
    requests_per_hour: int
    requests_per_day: int
    burst_limit: int

@dataclass
class ServiceEndpoint:
    """Service endpoint configuration"""
    service_id: str
    name: str
    url: str
    health_check_url: str
    is_active: bool
    required_tier: str
    rate_limits: RateLimitConfig

class OASISAPIGateway:
    """
    Comprehensive API Gateway for OASIS v3.
    Handles authentication, rate limiting, and service routing.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / "oasis-v3" / "data" / "gateway"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Data files
        self.api_keys_file = self.data_dir / "api_keys.json"
        self.rate_limits_file = self.data_dir / "rate_limits.json"
        self.services_file = self.data_dir / "services.json"
        self.access_logs_file = self.data_dir / "access_logs.json"
        
        # Initialize data
        self.api_keys = self._load_api_keys()
        self.rate_limits = self._load_rate_limits()
        self.services = self._load_services()
        self.access_logs = self._load_access_logs()
        
        # Rate limiting tracking
        self.request_counts = {}  # In-memory rate limit tracking
        
        logger.info("🚪 API Gateway initialized")

    def _load_api_keys(self) -> Dict[str, APIKey]:
        """Load API keys from file"""
        if not self.api_keys_file.exists():
            return self._generate_demo_api_keys()
        
        try:
            with open(self.api_keys_file, 'r') as f:
                data = json.load(f)
                return {
                    key_id: APIKey(**key_data)
                    for key_id, key_data in data.items()
                }
        except Exception as e:
            logger.warning(f"Failed to load API keys: {e}")
            return self._generate_demo_api_keys()

    def _generate_demo_api_keys(self) -> Dict[str, APIKey]:
        """Generate demo API keys for testing"""
        demo_keys = {}
        
        # Generate keys for different tiers
        tiers = ["free", "starter", "professional", "enterprise"]
        
        for tier in tiers:
            key = f"oasis-{tier}-{secrets.token_hex(16)}"
            key_hash = hashlib.sha256(key.encode()).hexdigest()
            
            api_key = APIKey(
                key_id=f"key_{tier}_{int(datetime.now().timestamp())}",
                key_hash=key_hash,
                user_id=f"demo_user_{tier}",
                tier=tier,
                created_at=datetime.now().isoformat(),
                last_used=datetime.now().isoformat(),
                is_active=True,
                permissions=self._get_tier_permissions(tier)
            )
            
            demo_keys[key] = api_key
            
        self._save_api_keys()
        return demo_keys

    def _get_tier_permissions(self, tier: str) -> List[str]:
        """Get permissions for a tier"""
        permissions_map = {
            "free": ["text_generation", "sentiment_analysis"],
            "starter": ["text_generation", "sentiment_analysis", "text_summarization"],
            "professional": ["text_generation", "sentiment_analysis", "text_summarization", "translation"],
            "enterprise": ["all_services", "custom_models", "priority_support"]
        }
        
        return permissions_map.get(tier, ["text_generation"])

    def _save_api_keys(self):
        """Save API keys to file"""
        try:
            data = {
                key: asdict(api_key)
                for key, api_key in self.api_keys.items()
            }
            
            with open(self.api_keys_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save API keys: {e}")

    def _load_rate_limits(self) -> Dict[str, RateLimitConfig]:
        """Load rate limit configurations"""
        if self.rate_limits_file.exists():
            try:
                with open(self.rate_limits_file, 'r') as f:
                    data = json.load(f)
                    return {
                        tier: RateLimitConfig(**config)
                        for tier, config in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load rate limits: {e}")
        
        # Initialize default rate limits
        return self._initialize_rate_limits()

    def _initialize_rate_limits(self) -> Dict[str, RateLimitConfig]:
        """Initialize default rate limit configurations"""
        rate_limits = {
            "free": RateLimitConfig(
                requests_per_minute=5,
                requests_per_hour=50,
                requests_per_day=200,
                burst_limit=10
            ),
            "starter": RateLimitConfig(
                requests_per_minute=20,
                requests_per_hour=500,
                requests_per_day=2000,
                burst_limit=50
            ),
            "professional": RateLimitConfig(
                requests_per_minute=100,
                requests_per_hour=2500,
                requests_per_day=10000,
                burst_limit=200
            ),
            "enterprise": RateLimitConfig(
                requests_per_minute=500,
                requests_per_hour=15000,
                requests_per_day=100000,
                burst_limit=1000
            )
        }
        
        self._save_rate_limits()
        return rate_limits

    def _save_rate_limits(self):
        """Save rate limit configurations"""
        try:
            data = {
                tier: asdict(config)
                for tier, config in self.rate_limits.items()
            }
            
            with open(self.rate_limits_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save rate limits: {e}")

    def _load_services(self) -> Dict[str, ServiceEndpoint]:
        """Load service endpoint configurations"""
        if self.services_file.exists():
            try:
                with open(self.services_file, 'r') as f:
                    data = json.load(f)
                    return {
                        service_id: ServiceEndpoint(**service_data)
                        for service_id, service_data in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load services: {e}")
        
        # Initialize default services
        return self._initialize_services()

    def _initialize_services(self) -> Dict[str, ServiceEndpoint]:
        """Initialize default service endpoints"""
        services = {
            "text_generation": ServiceEndpoint(
                service_id="text_generation",
                name="Text Generation",
                url="https://api-inference.huggingface.co/models/gpt2",
                health_check_url="https://api-inference.huggingface.co/models/gpt2",
                is_active=True,
                required_tier="free",
                rate_limits=RateLimitConfig(10, 100, 500, 20)
            ),
            "sentiment_analysis": ServiceEndpoint(
                service_id="sentiment_analysis",
                name="Sentiment Analysis",
                url="https://api-inference.huggingface.co/models/cardiffnlp/twitter-roberta-base-sentiment-latest",
                health_check_url="https://api-inference.huggingface.co/models/cardiffnlp/twitter-roberta-base-sentiment-latest",
                is_active=True,
                required_tier="free",
                rate_limits=RateLimitConfig(15, 150, 750, 30)
            ),
            "text_summarization": ServiceEndpoint(
                service_id="text_summarization",
                name="Text Summarization",
                url="https://api-inference.huggingface.co/models/facebook/bart-large-cnn",
                health_check_url="https://api-inference.huggingface.co/models/facebook/bart-large-cnn",
                is_active=True,
                required_tier="starter",
                rate_limits=RateLimitConfig(8, 80, 400, 15)
            ),
            "translation": ServiceEndpoint(
                service_id="translation",
                name="Translation",
                url="https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-en-fr",
                health_check_url="https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-en-fr",
                is_active=True,
                required_tier="professional",
                rate_limits=RateLimitConfig(12, 120, 600, 25)
            ),
            "question_answering": ServiceEndpoint(
                service_id="question_answering",
                name="Question Answering",
                url="https://api-inference.huggingface.co/models/deepset/roberta-base-squad2",
                health_check_url="https://api-inference.huggingface.co/models/deepset/roberta-base-squad2",
                is_active=True,
                required_tier="professional",
                rate_limits=RateLimitConfig(10, 100, 500, 20)
            )
        }
        
        self._save_services()
        return services

    def _save_services(self):
        """Save service configurations"""
        try:
            data = {
                service_id: asdict(service)
                for service_id, service in self.services.items()
            }
            
            with open(self.services_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save services: {e}")

    def _load_access_logs(self) -> List[Dict[str, Any]]:
        """Load access logs"""
        if not self.access_logs_file.exists():
            return []
        
        try:
            with open(self.access_logs_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load access logs: {e}")
            return []

    def _save_access_logs(self):
        """Save access logs"""
        try:
            # Keep only last 1000 logs to prevent file from growing too large
            logs_to_save = self.access_logs[-1000:] if len(self.access_logs) > 1000 else self.access_logs
            
            with open(self.access_logs_file, 'w') as f:
                json.dump(logs_to_save, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save access logs: {e}")

    def authenticate_request(self, api_key: str) -> Tuple[bool, Optional[APIKey], str]:
        """Authenticate API request"""
        if not api_key:
            return False, None, "Missing API key"
        
        # Hash the provided key to compare with stored hash
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        # Find matching API key
        for stored_key, api_key_obj in self.api_keys.items():
            if api_key_obj.key_hash == key_hash:
                if not api_key_obj.is_active:
                    return False, None, "API key is inactive"
                
                # Update last used timestamp
                api_key_obj.last_used = datetime.now().isoformat()
                self._save_api_keys()
                
                return True, api_key_obj, "Authentication successful"
        
        return False, None, "Invalid API key"

    def check_rate_limits(self, api_key_obj: APIKey, service_id: str) -> Tuple[bool, str, Dict[str, Any]]:
        """Check rate limits for the request"""
        user_id = api_key_obj.user_id
        tier = api_key_obj.tier
        
        if tier not in self.rate_limits:
            return False, "Invalid tier configuration", {}
        
        rate_config = self.rate_limits[tier]
        current_time = datetime.now()
        
        # Initialize tracking for user if not exists
        if user_id not in self.request_counts:
            self.request_counts[user_id] = {
                "minute": {"count": 0, "reset_time": current_time + timedelta(minutes=1)},
                "hour": {"count": 0, "reset_time": current_time + timedelta(hours=1)},
                "day": {"count": 0, "reset_time": current_time + timedelta(days=1)}
            }
        
        user_counts = self.request_counts[user_id]
        
        # Reset counters if time windows have passed
        for window in ["minute", "hour", "day"]:
            if current_time >= user_counts[window]["reset_time"]:
                user_counts[window]["count"] = 0
                if window == "minute":
                    user_counts[window]["reset_time"] = current_time + timedelta(minutes=1)
                elif window == "hour":
                    user_counts[window]["reset_time"] = current_time + timedelta(hours=1)
                else:  # day
                    user_counts[window]["reset_time"] = current_time + timedelta(days=1)
        
        # Check limits
        limits = {
            "minute": rate_config.requests_per_minute,
            "hour": rate_config.requests_per_hour,
            "day": rate_config.requests_per_day
        }
        
        for window, limit in limits.items():
            if user_counts[window]["count"] >= limit:
                reset_time = user_counts[window]["reset_time"]
                return False, f"Rate limit exceeded for {window}", {
                    "limit": limit,
                    "reset_time": reset_time.isoformat(),
                    "retry_after": int((reset_time - current_time).total_seconds())
                }
        
        # Increment counters
        for window in ["minute", "hour", "day"]:
            user_counts[window]["count"] += 1
        
        # Return current usage info
        usage_info = {
            "tier": tier,
            "limits": {
                "minute": {"used": user_counts["minute"]["count"], "limit": limits["minute"]},
                "hour": {"used": user_counts["hour"]["count"], "limit": limits["hour"]},
                "day": {"used": user_counts["day"]["count"], "limit": limits["day"]}
            }
        }
        
        return True, "Rate limit check passed", usage_info

    def check_service_access(self, api_key_obj: APIKey, service_id: str) -> Tuple[bool, str]:
        """Check if user has access to the requested service"""
        if service_id not in self.services:
            return False, "Service not found"
        
        service = self.services[service_id]
        
        if not service.is_active:
            return False, "Service is currently unavailable"
        
        # Check tier requirements
        tier_hierarchy = ["free", "starter", "professional", "enterprise"]
        
        try:
            user_tier_level = tier_hierarchy.index(api_key_obj.tier)
            required_tier_level = tier_hierarchy.index(service.required_tier)
            
            if user_tier_level < required_tier_level:
                return False, f"Service requires {service.required_tier} tier or higher"
        except ValueError:
            return False, "Invalid tier configuration"
        
        # Check permissions
        if "all_services" not in api_key_obj.permissions and service_id not in api_key_obj.permissions:
            return False, "Insufficient permissions for this service"
        
        return True, "Access granted"

    def log_request(self, api_key_obj: APIKey, service_id: str, request_data: Dict[str, Any], 
                   response_data: Dict[str, Any], success: bool, error_message: Optional[str] = None):
        """Log API request for analytics"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "user_id": api_key_obj.user_id,
            "tier": api_key_obj.tier,
            "service_id": service_id,
            "success": success,
            "error_message": error_message,
            "request_size": len(json.dumps(request_data)),
            "response_size": len(json.dumps(response_data)),
            "processing_time": response_data.get("processing_time", 0)
        }
        
        self.access_logs.append(log_entry)
        self._save_access_logs()

    def process_request(self, api_key: str, service_id: str, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming API request through the gateway"""
        start_time = time.time()
        
        # Authenticate
        auth_success, api_key_obj, auth_message = self.authenticate_request(api_key)
        if not auth_success:
            return {
                "success": False,
                "error": auth_message,
                "error_code": "AUTH_FAILED",
                "timestamp": datetime.now().isoformat()
            }
        
        # Check rate limits
        rate_ok, rate_message, rate_info = self.check_rate_limits(api_key_obj, service_id)
        if not rate_ok:
            return {
                "success": False,
                "error": rate_message,
                "error_code": "RATE_LIMIT_EXCEEDED",
                "rate_limit_info": rate_info,
                "timestamp": datetime.now().isoformat()
            }
        
        # Check service access
        access_ok, access_message = self.check_service_access(api_key_obj, service_id)
        if not access_ok:
            return {
                "success": False,
                "error": access_message,
                "error_code": "ACCESS_DENIED",
                "timestamp": datetime.now().isoformat()
            }
        
        # Process request (mock implementation)
        try:
            # In a real implementation, this would route to the actual service
            service = self.services[service_id]
            
            # Mock response based on service type
            if service_id == "text_generation":
                response = {
                    "success": True,
                    "service": service_id,
                    "result": {
                        "generated_text": f"Mock generated text for: {request_data.get('prompt', 'No prompt')}"
                    }
                }
            elif service_id == "sentiment_analysis":
                response = {
                    "success": True,
                    "service": service_id,
                    "result": {
                        "sentiment": "positive",
                        "confidence": 0.85,
                        "text": request_data.get('text', 'No text')
                    }
                }
            else:
                response = {
                    "success": True,
                    "service": service_id,
                    "result": {
                        "message": f"Mock response from {service.name}",
                        "input": request_data
                    }
                }
            
            processing_time = time.time() - start_time
            response.update({
                "processing_time": processing_time,
                "rate_limit_info": rate_info,
                "timestamp": datetime.now().isoformat()
            })
            
            # Log successful request
            self.log_request(api_key_obj, service_id, request_data, response, True)
            
            return response
            
        except Exception as e:
            error_response = {
                "success": False,
                "error": f"Service error: {str(e)}",
                "error_code": "SERVICE_ERROR",
                "timestamp": datetime.now().isoformat()
            }
            
            # Log failed request
            self.log_request(api_key_obj, service_id, request_data, error_response, False, str(e))
            
            return error_response

    def get_gateway_stats(self) -> Dict[str, Any]:
        """Get comprehensive gateway statistics"""
        # Analyze access logs
        total_requests = len(self.access_logs)
        successful_requests = len([log for log in self.access_logs if log["success"]])
        
        # Recent activity (last 24 hours)
        twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
        recent_logs = [
            log for log in self.access_logs
            if datetime.fromisoformat(log["timestamp"]) > twenty_four_hours_ago
        ]
        
        # Service usage statistics
        service_usage = {}
        for log in recent_logs:
            service_id = log["service_id"]
            service_usage[service_id] = service_usage.get(service_id, 0) + 1
        
        # Tier usage statistics
        tier_usage = {}
        for log in recent_logs:
            tier = log["tier"]
            tier_usage[tier] = tier_usage.get(tier, 0) + 1
        
        # Error analysis
        error_logs = [log for log in recent_logs if not log["success"]]
        error_types = {}
        for log in error_logs:
            error_msg = log.get("error_message", "Unknown error")
            error_types[error_msg] = error_types.get(error_msg, 0) + 1
        
        return {
            "timestamp": datetime.now().isoformat(),
            "overview": {
                "total_requests": total_requests,
                "successful_requests": successful_requests,
                "success_rate": (successful_requests / total_requests * 100) if total_requests > 0 else 0,
                "requests_24h": len(recent_logs),
                "active_api_keys": len([key for key in self.api_keys.values() if key.is_active])
            },
            "service_usage_24h": service_usage,
            "tier_usage_24h": tier_usage,
            "error_analysis": {
                "total_errors_24h": len(error_logs),
                "error_types": error_types
            },
            "service_status": {
                service_id: {
                    "name": service.name,
                    "is_active": service.is_active,
                    "required_tier": service.required_tier
                }
                for service_id, service in self.services.items()
            }
        }

# Example usage and testing
if __name__ == "__main__":
    gateway = OASISAPIGateway()
    
    print("🚪 OASIS v3 API Gateway")
    print("=" * 50)
    
    # Get a demo API key
    demo_key = list(gateway.api_keys.keys())[0]  # Get first demo key
    print(f"🔑 Using demo API key: {demo_key[:20]}...")
    
    # Test request
    response = gateway.process_request(
        api_key=demo_key,
        service_id="text_generation",
        request_data={"prompt": "Hello, world!"}
    )
    
    print(f"📤 Request result: {response['success']}")
    
    # Get gateway stats
    stats = gateway.get_gateway_stats()
    print(f"📊 Gateway stats: {stats['overview']['total_requests']} total requests, {stats['overview']['success_rate']:.1f}% success rate")

