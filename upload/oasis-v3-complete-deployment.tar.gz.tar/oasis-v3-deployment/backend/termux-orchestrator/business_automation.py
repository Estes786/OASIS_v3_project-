#!/usr/bin/env python3
"""
OASIS v3 Business Automation Engine
Ultra-lightweight workflow automation for client management and business operations.
Enhanced with AI-driven insights and automated workflows.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum

logger = logging.getLogger(__name__)

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress" 
    COMPLETED = "completed"
    FAILED = "failed"

class TaskPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

@dataclass
class AutomationTask:
    """Automation task definition"""
    task_id: str
    title: str
    description: str
    task_type: str
    priority: TaskPriority
    status: TaskStatus
    created_at: str
    due_date: str
    assigned_to: str
    metadata: Dict[str, Any]

@dataclass
class ClientTicket:
    """Support ticket for client issues"""
    ticket_id: str
    client_id: str
    subject: str
    priority: str
    status: str
    created_at: str
    last_updated: str
    messages: List[Dict[str, str]]

@dataclass
class BusinessWorkflow:
    """Business process workflow definition"""
    workflow_id: str
    name: str
    description: str
    steps: List[Dict[str, Any]]
    triggers: List[str]
    is_active: bool

class OASISBusinessAutomation:
    """
    Comprehensive business automation engine for OASIS v3.
    Handles client lifecycle, support workflows, and operational tasks.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / "oasis-v3" / "data" / "automation"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.tasks_file = self.data_dir / "tasks.json"
        self.tickets_file = self.data_dir / "tickets.json"
        self.workflows_file = self.data_dir / "workflows.json"
        self.interactions_file = self.data_dir / "interactions.json"
        
        self.tasks = self._load_tasks()
        self.tickets = self._load_tickets()
        self.workflows = self._load_workflows()
        self.client_interactions = self._load_interactions()
        
        logger.info("🤖 Business Automation Engine initialized")

    def _load_tasks(self) -> Dict[str, AutomationTask]:
        """Load tasks from file"""
        if not self.tasks_file.exists():
            return {}
        
        try:
            with open(self.tasks_file, 'r') as f:
                data = json.load(f)
                return {
                    task_id: AutomationTask(
                        task_id=task_data["task_id"],
                        title=task_data["title"],
                        description=task_data["description"],
                        task_type=task_data["task_type"],
                        priority=TaskPriority(task_data["priority"]),
                        status=TaskStatus(task_data["status"]),
                        created_at=task_data["created_at"],
                        due_date=task_data["due_date"],
                        assigned_to=task_data["assigned_to"],
                        metadata=task_data["metadata"]
                    )
                    for task_id, task_data in data.items()
                }
        except Exception as e:
            logger.warning(f"Failed to load tasks: {e}")
            return {}

    def _save_tasks(self):
        """Save tasks to file"""
        try:
            data = {
                task_id: {
                    "task_id": task.task_id,
                    "title": task.title,
                    "description": task.description,
                    "task_type": task.task_type,
                    "priority": task.priority.value,
                    "status": task.status.value,
                    "created_at": task.created_at,
                    "due_date": task.due_date,
                    "assigned_to": task.assigned_to,
                    "metadata": task.metadata
                }
                for task_id, task in self.tasks.items()
            }
            
            with open(self.tasks_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save tasks: {e}")

    def _load_tickets(self) -> Dict[str, ClientTicket]:
        """Load tickets from file"""
        if not self.tickets_file.exists():
            return {}
        
        try:
            with open(self.tickets_file, 'r') as f:
                data = json.load(f)
                return {
                    ticket_id: ClientTicket(**ticket_data)
                    for ticket_id, ticket_data in data.items()
                }
        except Exception as e:
            logger.warning(f"Failed to load tickets: {e}")
            return {}

    def _save_tickets(self):
        """Save tickets to file"""
        try:
            data = {
                ticket_id: asdict(ticket)
                for ticket_id, ticket in self.tickets.items()
            }
            
            with open(self.tickets_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save tickets: {e}")

    def _load_workflows(self) -> Dict[str, BusinessWorkflow]:
        """Load workflows from file or initialize defaults"""
        if self.workflows_file.exists():
            try:
                with open(self.workflows_file, 'r') as f:
                    data = json.load(f)
                    return {
                        workflow_id: BusinessWorkflow(**workflow_data)
                        for workflow_id, workflow_data in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load workflows: {e}")
        
        # Initialize default workflows
        return self._initialize_default_workflows()

    def _initialize_default_workflows(self) -> Dict[str, BusinessWorkflow]:
        """Initialize predefined business workflows"""
        workflows = {
            "onboarding": BusinessWorkflow(
                workflow_id="onboarding",
                name="Client Onboarding",
                description="Automated client onboarding process",
                steps=[
                    {"step": "send_welcome_email", "delay_hours": 0},
                    {"step": "create_api_credentials", "delay_hours": 1},
                    {"step": "schedule_demo_call", "delay_hours": 24},
                    {"step": "send_getting_started_guide", "delay_hours": 48}
                ],
                triggers=["new_client_signup"],
                is_active=True
            ),
            "churn_prevention": BusinessWorkflow(
                workflow_id="churn_prevention", 
                name="Churn Prevention",
                description="Automated actions to prevent client churn",
                steps=[
                    {"step": "send_check_in_email", "delay_hours": 0},
                    {"step": "offer_support_call", "delay_hours": 24},
                    {"step": "provide_usage_insights", "delay_hours": 72},
                    {"step": "escalate_to_account_manager", "delay_hours": 168}
                ],
                triggers=["low_usage_detected", "support_ticket_created"],
                is_active=True
            ),
            "upsell_campaign": BusinessWorkflow(
                workflow_id="upsell_campaign",
                name="Upsell Opportunity",
                description="Automated upselling based on usage patterns",
                steps=[
                    {"step": "analyze_usage_pattern", "delay_hours": 0},
                    {"step": "send_upgrade_recommendation", "delay_hours": 1},
                    {"step": "schedule_consultation", "delay_hours": 72},
                    {"step": "send_limited_time_offer", "delay_hours": 168}
                ],
                triggers=["usage_threshold_exceeded", "tier_limit_reached"],
                is_active=True
            ),
            "revenue_optimization": BusinessWorkflow(
                workflow_id="revenue_optimization",
                name="Revenue Optimization",
                description="Automated revenue optimization tasks",
                steps=[
                    {"step": "analyze_pricing_efficiency", "delay_hours": 0},
                    {"step": "identify_upsell_opportunities", "delay_hours": 2},
                    {"step": "optimize_tier_recommendations", "delay_hours": 4},
                    {"step": "generate_revenue_report", "delay_hours": 24}
                ],
                triggers=["monthly_revenue_review", "pricing_analysis_needed"],
                is_active=True
            )
        }
        
        self._save_workflows()
        return workflows

    def _save_workflows(self):
        """Save workflows to file"""
        try:
            data = {
                workflow_id: asdict(workflow)
                for workflow_id, workflow in self.workflows.items()
            }
            
            with open(self.workflows_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save workflows: {e}")

    def _load_interactions(self) -> Dict[str, List[Dict[str, Any]]]:
        """Load client interactions from file"""
        if not self.interactions_file.exists():
            return {}
        
        try:
            with open(self.interactions_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load interactions: {e}")
            return {}

    def _save_interactions(self):
        """Save client interactions to file"""
        try:
            with open(self.interactions_file, 'w') as f:
                json.dump(self.client_interactions, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save interactions: {e}")

    def create_task(self, title: str, description: str, task_type: str, 
                   priority: TaskPriority, assigned_to: str, 
                   due_hours: int = 24, **metadata) -> str:
        """Create a new automation task"""
        task_id = f"task_{len(self.tasks) + 1}_{int(datetime.now().timestamp())}"
        due_date = (datetime.now() + timedelta(hours=due_hours)).isoformat()

        task = AutomationTask(
            task_id=task_id,
            title=title,
            description=description,
            task_type=task_type,
            priority=priority,
            status=TaskStatus.PENDING,
            created_at=datetime.now().isoformat(),
            due_date=due_date,
            assigned_to=assigned_to,
            metadata=metadata
        )

        self.tasks[task_id] = task
        self._save_tasks()
        
        logger.info(f"📋 Task created: {title} ({task_id})")
        return task_id

    def update_task_status(self, task_id: str, status: TaskStatus, 
                          notes: Optional[str] = None) -> bool:
        """Update task status"""
        if task_id not in self.tasks:
            return False

        self.tasks[task_id].status = status
        if notes:
            self.tasks[task_id].metadata["status_notes"] = notes

        self._save_tasks()
        logger.info(f"📋 Task updated: {task_id} -> {status.value}")
        return True

    def create_support_ticket(self, client_id: str, subject: str, 
                            priority: str, initial_message: str) -> str:
        """Create a new support ticket"""
        ticket_id = f"ticket_{len(self.tickets) + 1}_{int(datetime.now().timestamp())}"

        ticket = ClientTicket(
            ticket_id=ticket_id,
            client_id=client_id,
            subject=subject,
            priority=priority,
            status="open",
            created_at=datetime.now().isoformat(),
            last_updated=datetime.now().isoformat(),
            messages=[{
                "sender": "client",
                "message": initial_message,
                "timestamp": datetime.now().isoformat()
            }]
        )

        self.tickets[ticket_id] = ticket
        self._save_tickets()

        # Trigger churn prevention workflow if high priority
        if priority in ["high", "urgent"]:
            self.trigger_workflow("churn_prevention", {"client_id": client_id, "ticket_id": ticket_id})

        logger.info(f"🎫 Support ticket created: {subject} ({ticket_id})")
        return ticket_id

    def trigger_workflow(self, workflow_id: str, context: Dict[str, Any]) -> List[str]:
        """Trigger a business workflow"""
        if workflow_id not in self.workflows:
            logger.warning(f"Workflow not found: {workflow_id}")
            return []

        workflow = self.workflows[workflow_id]
        if not workflow.is_active:
            logger.info(f"Workflow inactive: {workflow_id}")
            return []

        created_tasks = []

        for i, step in enumerate(workflow.steps):
            task_id = self.create_task(
                title=f"{workflow.name} - Step {i+1}",
                description=f"Execute {step['step']} for {workflow_id}",
                task_type=f"workflow_{workflow_id}",
                priority=TaskPriority.MEDIUM,
                assigned_to="automation_system",
                due_hours=step.get("delay_hours", 24),
                workflow_step=step["step"],
                workflow_context=context
            )
            created_tasks.append(task_id)

        logger.info(f"🔄 Workflow triggered: {workflow_id} ({len(created_tasks)} tasks)")
        return created_tasks

    def process_client_interaction(self, client_id: str, interaction_type: str, 
                                 data: Dict[str, Any]) -> Dict[str, Any]:
        """Process and analyze client interactions"""
        timestamp = datetime.now().isoformat()

        if client_id not in self.client_interactions:
            self.client_interactions[client_id] = []

        interaction = {
            "timestamp": timestamp,
            "type": interaction_type,
            "data": data
        }

        self.client_interactions[client_id].append(interaction)
        self._save_interactions()

        # Analyze interaction patterns and trigger workflows
        analysis = self._analyze_interaction_patterns(client_id)

        # Auto-trigger workflows based on patterns
        triggered_workflows = []

        if analysis["usage_trend"] == "declining":
            workflows = self.trigger_workflow("churn_prevention", {"client_id": client_id})
            triggered_workflows.extend(workflows)

        if analysis["usage_level"] == "high" and analysis["tier_utilization"] > 0.8:
            workflows = self.trigger_workflow("upsell_campaign", {"client_id": client_id})
            triggered_workflows.extend(workflows)

        logger.info(f"📊 Client interaction processed: {client_id} - {interaction_type}")
        
        return {
            "interaction_logged": True,
            "analysis": analysis,
            "triggered_workflows": triggered_workflows
        }

    def _analyze_interaction_patterns(self, client_id: str) -> Dict[str, Any]:
        """Analyze client interaction patterns"""
        interactions = self.client_interactions.get(client_id, [])

        if not interactions:
            return {"status": "insufficient_data"}

        # Analyze recent interactions (last 30 days)
        recent_interactions = [
            i for i in interactions 
            if datetime.fromisoformat(i["timestamp"]) > datetime.now() - timedelta(days=30)
        ]

        usage_count = len([i for i in recent_interactions if i["type"] == "api_usage"])
        support_count = len([i for i in recent_interactions if i["type"] == "support_request"])
        
        # Calculate trends
        if len(interactions) > 1:
            mid_point = len(interactions) // 2
            recent_usage = len([i for i in interactions[mid_point:] if i["type"] == "api_usage"])
            older_usage = len([i for i in interactions[:mid_point] if i["type"] == "api_usage"])
            
            if recent_usage < older_usage * 0.7:
                usage_trend = "declining"
            elif recent_usage > older_usage * 1.3:
                usage_trend = "growing"
            else:
                usage_trend = "stable"
        else:
            usage_trend = "new"

        return {
            "total_interactions": len(interactions),
            "recent_interactions": len(recent_interactions),
            "usage_frequency": usage_count,
            "support_requests": support_count,
            "usage_trend": usage_trend,
            "usage_level": "high" if usage_count > 50 else "medium" if usage_count > 10 else "low",
            "tier_utilization": min(usage_count / 100, 1.0),  # Normalized utilization
            "satisfaction_indicator": "positive" if support_count < 2 else "needs_attention",
            "last_activity": interactions[-1]["timestamp"] if interactions else None
        }

    def get_automation_dashboard(self) -> Dict[str, Any]:
        """Get comprehensive automation dashboard data"""
        # Task statistics
        total_tasks = len(self.tasks)
        completed_tasks = len([t for t in self.tasks.values() if t.status == TaskStatus.COMPLETED])
        pending_tasks = len([t for t in self.tasks.values() if t.status == TaskStatus.PENDING])
        overdue_tasks = len([
            t for t in self.tasks.values() 
            if t.status == TaskStatus.PENDING and datetime.fromisoformat(t.due_date) < datetime.now()
        ])

        # Ticket statistics
        open_tickets = len([t for t in self.tickets.values() if t.status == "open"])
        high_priority_tickets = len([
            t for t in self.tickets.values() 
            if t.status == "open" and t.priority in ["high", "urgent"]
        ])

        # Workflow statistics
        active_workflows = len([w for w in self.workflows.values() if w.is_active])

        # Client interaction statistics
        total_clients = len(self.client_interactions)
        today = datetime.now().date()
        interactions_today = sum(
            len([
                i for i in interactions 
                if datetime.fromisoformat(i["timestamp"]).date() == today
            ])
            for interactions in self.client_interactions.values()
        )

        return {
            "timestamp": datetime.now().isoformat(),
            "task_summary": {
                "total_tasks": total_tasks,
                "completed_tasks": completed_tasks,
                "pending_tasks": pending_tasks,
                "overdue_tasks": overdue_tasks,
                "completion_rate": (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
            },
            "ticket_summary": {
                "open_tickets": open_tickets,
                "high_priority_tickets": high_priority_tickets,
                "total_tickets": len(self.tickets)
            },
            "workflow_summary": {
                "active_workflows": active_workflows,
                "total_workflows": len(self.workflows)
            },
            "client_summary": {
                "total_clients": total_clients,
                "interactions_today": interactions_today,
                "active_clients": len([
                    client_id for client_id, interactions in self.client_interactions.items()
                    if any(
                        datetime.fromisoformat(i["timestamp"]) > datetime.now() - timedelta(days=7)
                        for i in interactions
                    )
                ])
            }
        }

# Example usage and testing
if __name__ == "__main__":
    automation = OASISBusinessAutomation()
    
    print("🤖 OASIS v3 Business Automation Engine")
    print("=" * 50)
    
    # Demo operations
    task_id = automation.create_task(
        title="Follow up with enterprise client",
        description="Check on integration progress",
        task_type="client_management",
        priority=TaskPriority.HIGH,
        assigned_to="account_manager"
    )
    
    ticket_id = automation.create_support_ticket(
        client_id="client_001",
        subject="API Integration Issue",
        priority="high",
        initial_message="Having trouble with authentication flow"
    )
    
    # Process client interaction
    result = automation.process_client_interaction(
        client_id="client_001",
        interaction_type="api_usage",
        data={"requests": 150, "errors": 2}
    )
    
    # Get dashboard
    dashboard = automation.get_automation_dashboard()
    
    print(f"✅ Created task: {task_id}")
    print(f"✅ Created ticket: {ticket_id}")
    print(f"✅ Triggered workflows: {len(result['triggered_workflows'])}")
    print(f"📊 Dashboard: {dashboard['task_summary']['total_tasks']} tasks, {dashboard['ticket_summary']['open_tickets']} tickets")

