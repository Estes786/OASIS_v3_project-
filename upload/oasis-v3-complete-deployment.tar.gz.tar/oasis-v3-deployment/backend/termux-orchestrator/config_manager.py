#!/usr/bin/env python3
"""
OASIS v3 Configuration Manager
Handles all configuration and environment management
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class ConfigManager:
    """Manages OASIS v3 configuration and environment"""
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path.home() / "oasis-v3" / "config"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.config_dir / "oasis_config.json"
        self.env_file = self.config_dir / ".env"
        
        self.config = self._load_config()
        self._ensure_env_file()
        
        logger.info("⚙️ Configuration Manager initialized")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        default_config = {
            "version": "3.0",
            "platform": "termux",
            "philosophy": "Zero-Cost & Zero-Burden",
            "services": {
                "text_generation": {
                    "enabled": True,
                    "default_model": "gpt2",
                    "max_length": 100,
                    "rate_limit": 100  # requests per hour
                },
                "sentiment_analysis": {
                    "enabled": True,
                    "default_model": "cardiffnlp/twitter-roberta-base-sentiment-latest",
                    "rate_limit": 200
                },
                "text_summarization": {
                    "enabled": True,
                    "default_model": "facebook/bart-large-cnn",
                    "rate_limit": 50
                },
                "translation": {
                    "enabled": True,
                    "default_model": "Helsinki-NLP/opus-mt-en-fr",
                    "rate_limit": 100
                },
                "question_answering": {
                    "enabled": True,
                    "default_model": "deepset/roberta-base-squad2",
                    "rate_limit": 100
                }
            },
            "huggingface": {
                "api_base": "https://api-inference.huggingface.co/models",
                "timeout": 30,
                "max_retries": 3,
                "retry_delay": 2
            },
            "logging": {
                "level": "INFO",
                "max_log_size": "10MB",
                "backup_count": 5
            },
            "performance": {
                "memory_limit": "50MB",
                "cpu_limit": "80%",
                "cache_size": "10MB"
            },
            "revenue": {
                "freemium_enabled": True,
                "free_tier_limits": {
                    "requests_per_day": 100,
                    "requests_per_hour": 20
                },
                "premium_tier_limits": {
                    "requests_per_day": 1000,
                    "requests_per_hour": 200
                }
            }
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    loaded_config = json.load(f)
                    # Merge with defaults
                    default_config.update(loaded_config)
            except Exception as e:
                logger.warning(f"Failed to load config file: {e}, using defaults")
        
        return default_config
    
    def _ensure_env_file(self):
        """Ensure .env file exists with required variables"""
        if not self.env_file.exists():
            env_content = """# OASIS v3 Environment Configuration
# Hugging Face API Key (required for AI services)
HUGGING_FACE_API_KEY=your_hf_token_here

# OASIS Configuration
OASIS_VERSION=3.0
OASIS_PLATFORM=termux
OASIS_MODE=orchestrator

# Logging Configuration
LOG_LEVEL=INFO
LOG_DIR=~/oasis-v3/logs

# Performance Configuration
MEMORY_LIMIT=50MB
CPU_LIMIT=80%

# Revenue Configuration
FREEMIUM_ENABLED=true
PREMIUM_ENABLED=false

# Development Configuration
DEBUG_MODE=false
VERBOSE_LOGGING=false
"""
            with open(self.env_file, 'w') as f:
                f.write(env_content)
            
            logger.info(f"📝 Created environment file: {self.env_file}")
    
    def save_config(self):
        """Save current configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info("💾 Configuration saved")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        self.save_config()
    
    def get_env(self, key: str, default: str = "") -> str:
        """Get environment variable"""
        return os.getenv(key, default)
    
    def is_service_enabled(self, service: str) -> bool:
        """Check if a service is enabled"""
        return self.get(f"services.{service}.enabled", False)
    
    def get_service_config(self, service: str) -> Dict[str, Any]:
        """Get configuration for a specific service"""
        return self.get(f"services.{service}", {})
    
    def get_rate_limit(self, service: str) -> int:
        """Get rate limit for a service"""
        return self.get(f"services.{service}.rate_limit", 100)
    
    def get_huggingface_config(self) -> Dict[str, Any]:
        """Get Hugging Face configuration"""
        return self.get("huggingface", {})
    
    def get_revenue_config(self) -> Dict[str, Any]:
        """Get revenue configuration"""
        return self.get("revenue", {})
    
    def update_service_config(self, service: str, config: Dict[str, Any]):
        """Update configuration for a specific service"""
        current_config = self.get_service_config(service)
        current_config.update(config)
        self.set(f"services.{service}", current_config)
    
    def enable_service(self, service: str):
        """Enable a service"""
        self.set(f"services.{service}.enabled", True)
        logger.info(f"✅ Service enabled: {service}")
    
    def disable_service(self, service: str):
        """Disable a service"""
        self.set(f"services.{service}.enabled", False)
        logger.info(f"❌ Service disabled: {service}")
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information"""
        return {
            "version": self.get("version"),
            "platform": self.get("platform"),
            "philosophy": self.get("philosophy"),
            "config_dir": str(self.config_dir),
            "config_file": str(self.config_file),
            "env_file": str(self.env_file),
            "services_enabled": [
                service for service in self.get("services", {}).keys()
                if self.is_service_enabled(service)
            ],
            "timestamp": datetime.now().isoformat()
        }
    
    def validate_config(self) -> Dict[str, Any]:
        """Validate current configuration"""
        validation_result = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "recommendations": []
        }
        
        # Check required environment variables
        hf_api_key = self.get_env("HUGGING_FACE_API_KEY")
        if not hf_api_key or hf_api_key == "your_hf_token_here":
            validation_result["errors"].append("Hugging Face API key not set")
            validation_result["valid"] = False
        
        # Check service configurations
        services = self.get("services", {})
        for service_name, service_config in services.items():
            if not isinstance(service_config, dict):
                validation_result["errors"].append(f"Invalid configuration for service: {service_name}")
                validation_result["valid"] = False
            
            if "enabled" not in service_config:
                validation_result["warnings"].append(f"Service {service_name} missing 'enabled' flag")
        
        # Check performance limits
        memory_limit = self.get("performance.memory_limit")
        if memory_limit and not memory_limit.endswith("MB"):
            validation_result["warnings"].append("Memory limit should be specified in MB")
        
        # Recommendations
        if validation_result["valid"]:
            validation_result["recommendations"].append("Configuration is valid and ready for use")
        else:
            validation_result["recommendations"].append("Fix configuration errors before running OASIS")
        
        return validation_result

# Example usage
if __name__ == "__main__":
    config = ConfigManager()
    
    print("OASIS v3 Configuration Manager")
    print("=" * 40)
    
    # Show system info
    system_info = config.get_system_info()
    print("System Info:")
    print(json.dumps(system_info, indent=2))
    
    print("\nValidation:")
    validation = config.validate_config()
    print(json.dumps(validation, indent=2))
    
    print("\nService Status:")
    services = config.get("services", {})
    for service_name in services.keys():
        enabled = config.is_service_enabled(service_name)
        rate_limit = config.get_rate_limit(service_name)
        print(f"  {service_name}: {'✅' if enabled else '❌'} (Rate limit: {rate_limit}/hour)")

