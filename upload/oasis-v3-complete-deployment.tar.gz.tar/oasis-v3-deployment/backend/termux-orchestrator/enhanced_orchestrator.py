#!/usr/bin/env python3
"""
OASIS v3 Enhanced Main Orchestrator
Ultra-lightweight AI superintelligence orchestration system.
Enhanced with business automation, advanced revenue engine, and API gateway.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

# Import enhanced components
from hf_client import HuggingFaceClient
from config_manager import ConfigManager
from enhanced_revenue_engine import EnhancedRevenueEngine
from business_automation import OASISBusinessAutomation
from api_gateway import OASISAPIGateway

logger = logging.getLogger(__name__)

class OASISEnhancedOrchestrator:
    """
    Enhanced OASIS v3 Main Orchestrator
    Coordinates all system components for AI superintelligence operations.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / "oasis-v3"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize core components
        self.config = ConfigManager()
        self.hf_client = HuggingFaceClient()
        self.revenue_engine = EnhancedRevenueEngine(self.data_dir / "revenue")
        self.business_automation = OASISBusinessAutomation(self.data_dir / "automation")
        self.api_gateway = OASISAPIGateway(self.data_dir / "gateway")
        
        # System state
        self.is_running = False
        self.start_time = None
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "revenue_generated": 0.0
        }
        
        logger.info("🚀 OASIS v3 Enhanced Orchestrator initialized")

    def start_system(self) -> Dict[str, Any]:
        """Start the OASIS system"""
        try:
            self.is_running = True
            self.start_time = datetime.now()
            
            # Initialize all components
            logger.info("🔧 Initializing system components...")
            
            # Check HuggingFace connectivity
            hf_health = self.hf_client.health_check()
            
            # Initialize business workflows
            self.business_automation.trigger_workflow("revenue_optimization", {
                "trigger": "system_startup",
                "timestamp": datetime.now().isoformat()
            })
            
            # Log system startup
            startup_log = {
                "event": "system_startup",
                "timestamp": self.start_time.isoformat(),
                "components": {
                    "config_manager": True,
                    "hf_client": hf_health.get("status") == "healthy",
                    "revenue_engine": True,
                    "business_automation": True,
                    "api_gateway": True
                }
            }
            
            logger.info("✅ OASIS v3 system started successfully")
            
            return {
                "success": True,
                "message": "OASIS v3 system started successfully",
                "startup_time": self.start_time.isoformat(),
                "components_status": startup_log["components"],
                "system_info": self.get_system_info()
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to start system: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def stop_system(self) -> Dict[str, Any]:
        """Stop the OASIS system"""
        try:
            self.is_running = False
            stop_time = datetime.now()
            
            # Calculate uptime
            uptime = stop_time - self.start_time if self.start_time else timedelta(0)
            
            # Generate final reports
            final_stats = self.get_comprehensive_stats()
            
            logger.info("🛑 OASIS v3 system stopped")
            
            return {
                "success": True,
                "message": "OASIS v3 system stopped successfully",
                "stop_time": stop_time.isoformat(),
                "uptime_seconds": uptime.total_seconds(),
                "final_stats": final_stats
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to stop system: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def process_ai_request(self, user_id: str, service_type: str, request_data: Dict[str, Any], 
                          api_key: Optional[str] = None) -> Dict[str, Any]:
        """Process AI request through the enhanced pipeline"""
        try:
            # Use API gateway for authentication and rate limiting
            if api_key:
                gateway_response = self.api_gateway.process_request(api_key, service_type, request_data)
                if not gateway_response.get("success"):
                    return gateway_response
            
            # Record usage for revenue tracking
            usage_record = self.revenue_engine.record_usage(
                user_id=user_id,
                service_type=service_type,
                tokens_used=request_data.get("tokens", 1),
                model_used=request_data.get("model", "gpt2"),
                success=True
            )
            
            # Process through HuggingFace client
            if service_type == "text_generation":
                result = self.hf_client.generate_text(
                    prompt=request_data.get("prompt", ""),
                    model=request_data.get("model", "gpt2"),
                    max_length=request_data.get("max_length", 100)
                )
            elif service_type == "sentiment_analysis":
                result = self.hf_client.analyze_sentiment(
                    text=request_data.get("text", ""),
                    model=request_data.get("model", "cardiffnlp/twitter-roberta-base-sentiment-latest")
                )
            elif service_type == "text_summarization":
                result = self.hf_client.summarize_text(
                    text=request_data.get("text", ""),
                    model=request_data.get("model", "facebook/bart-large-cnn")
                )
            elif service_type == "translation":
                result = self.hf_client.translate_text(
                    text=request_data.get("text", ""),
                    source_lang=request_data.get("source_lang", "en"),
                    target_lang=request_data.get("target_lang", "fr")
                )
            elif service_type == "question_answering":
                result = self.hf_client.answer_question(
                    question=request_data.get("question", ""),
                    context=request_data.get("context", "")
                )
            else:
                result = {"success": False, "error": f"Unsupported service type: {service_type}"}
            
            # Update stats
            if result.get("success"):
                self.stats["successful_requests"] += 1
                if usage_record:
                    self.stats["revenue_generated"] += usage_record.cost
            else:
                self.stats["failed_requests"] += 1
            
            self.stats["total_requests"] += 1
            
            # Process client interaction for business automation
            self.business_automation.process_client_interaction(
                client_id=user_id,
                interaction_type="api_usage",
                data={
                    "service_type": service_type,
                    "success": result.get("success", False),
                    "tokens_used": request_data.get("tokens", 1)
                }
            )
            
            # Add orchestrator metadata
            result.update({
                "orchestrator_info": {
                    "processed_by": "oasis_v3_enhanced_orchestrator",
                    "timestamp": datetime.now().isoformat(),
                    "user_id": user_id,
                    "usage_record_id": usage_record.record_id if usage_record else None
                }
            })
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to process AI request: {e}")
            self.stats["failed_requests"] += 1
            self.stats["total_requests"] += 1
            
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information"""
        return {
            "oasis_version": "3.0-enhanced",
            "system_name": "OASIS Enhanced Superintelligence Orchestrator",
            "is_running": self.is_running,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "uptime_seconds": (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
            "components": {
                "config_manager": "active",
                "hf_client": "active",
                "enhanced_revenue_engine": "active",
                "business_automation": "active",
                "api_gateway": "active"
            },
            "capabilities": [
                "text_generation",
                "sentiment_analysis", 
                "text_summarization",
                "translation",
                "question_answering",
                "business_automation",
                "revenue_optimization",
                "api_gateway"
            ],
            "philosophy": "Zero-Cost & Zero-Burden AI Superintelligence",
            "architecture": "Termux-HuggingFace Enhanced Orchestration"
        }

    def get_comprehensive_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics"""
        # Get stats from all components
        revenue_analytics = self.revenue_engine.generate_revenue_analytics()
        business_dashboard = self.business_automation.get_automation_dashboard()
        gateway_stats = self.api_gateway.get_gateway_stats()
        
        return {
            "timestamp": datetime.now().isoformat(),
            "orchestrator_stats": self.stats,
            "revenue_analytics": revenue_analytics,
            "business_automation": business_dashboard,
            "api_gateway": gateway_stats,
            "system_health": {
                "is_running": self.is_running,
                "uptime_seconds": (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
                "success_rate": (self.stats["successful_requests"] / self.stats["total_requests"] * 100) if self.stats["total_requests"] > 0 else 0
            }
        }

    def run_diagnostics(self) -> Dict[str, Any]:
        """Run comprehensive system diagnostics"""
        logger.info("🔍 Running enhanced system diagnostics...")
        
        diagnostics = {
            "timestamp": datetime.now().isoformat(),
            "system_status": "healthy",
            "component_health": {},
            "performance_metrics": {},
            "recommendations": []
        }
        
        try:
            # Test HuggingFace connectivity
            hf_health = self.hf_client.health_check()
            diagnostics["component_health"]["hf_client"] = hf_health
            
            # Test revenue engine
            revenue_test = self.revenue_engine.generate_revenue_analytics()
            diagnostics["component_health"]["revenue_engine"] = {
                "status": "healthy",
                "total_clients": revenue_test["overview"]["total_clients"],
                "total_revenue": revenue_test["overview"]["total_revenue"]
            }
            
            # Test business automation
            automation_dashboard = self.business_automation.get_automation_dashboard()
            diagnostics["component_health"]["business_automation"] = {
                "status": "healthy",
                "total_tasks": automation_dashboard["task_summary"]["total_tasks"],
                "pending_tasks": automation_dashboard["task_summary"]["pending_tasks"]
            }
            
            # Test API gateway
            gateway_stats = self.api_gateway.get_gateway_stats()
            diagnostics["component_health"]["api_gateway"] = {
                "status": "healthy",
                "total_requests": gateway_stats["overview"]["total_requests"],
                "success_rate": gateway_stats["overview"]["success_rate"]
            }
            
            # Performance metrics
            diagnostics["performance_metrics"] = {
                "total_requests": self.stats["total_requests"],
                "success_rate": (self.stats["successful_requests"] / self.stats["total_requests"] * 100) if self.stats["total_requests"] > 0 else 0,
                "revenue_generated": self.stats["revenue_generated"],
                "uptime_hours": (datetime.now() - self.start_time).total_seconds() / 3600 if self.start_time else 0
            }
            
            # Generate recommendations
            if self.stats["total_requests"] > 0:
                success_rate = (self.stats["successful_requests"] / self.stats["total_requests"]) * 100
                if success_rate < 95:
                    diagnostics["recommendations"].append("Consider investigating failed requests to improve success rate")
                
                if self.stats["revenue_generated"] < 10:
                    diagnostics["recommendations"].append("Consider implementing upselling strategies to increase revenue")
            
            if not diagnostics["recommendations"]:
                diagnostics["recommendations"].append("System is performing optimally")
            
            logger.info("✅ Enhanced diagnostics complete")
            
        except Exception as e:
            logger.error(f"❌ Diagnostics failed: {e}")
            diagnostics["system_status"] = "error"
            diagnostics["error"] = str(e)
        
        return diagnostics

    def get_business_insights(self) -> Dict[str, Any]:
        """Get AI-driven business insights"""
        try:
            # Get data from all components
            revenue_analytics = self.revenue_engine.generate_revenue_analytics()
            optimization = self.revenue_engine.optimize_pricing()
            automation_dashboard = self.business_automation.get_automation_dashboard()
            gateway_stats = self.api_gateway.get_gateway_stats()
            
            # Generate insights
            insights = {
                "timestamp": datetime.now().isoformat(),
                "revenue_insights": {
                    "total_revenue": revenue_analytics["overview"]["total_revenue"],
                    "monthly_growth": revenue_analytics["overview"]["growth_rate"],
                    "arpu": revenue_analytics["overview"]["arpu"],
                    "top_tier": max(revenue_analytics["tier_analytics"]["distribution"].items(), key=lambda x: x[1])[0] if revenue_analytics["tier_analytics"]["distribution"] else "none"
                },
                "operational_insights": {
                    "total_clients": revenue_analytics["overview"]["total_clients"],
                    "active_clients": revenue_analytics["overview"]["active_clients"],
                    "success_rate": gateway_stats["overview"]["success_rate"],
                    "pending_tasks": automation_dashboard["task_summary"]["pending_tasks"]
                },
                "optimization_opportunities": optimization["optimization_recommendations"][:5],  # Top 5
                "risk_factors": {
                    "high_risk_clients": revenue_analytics["risk_analytics"]["high_risk_clients"],
                    "churn_risk": "low" if revenue_analytics["risk_analytics"]["high_risk_clients"] < 2 else "medium",
                    "satisfaction_score": revenue_analytics["risk_analytics"]["satisfaction_avg"]
                },
                "growth_recommendations": [
                    "Focus on converting free tier users to paid tiers",
                    "Implement automated upselling workflows",
                    "Enhance customer success programs",
                    "Expand AI model offerings",
                    "Develop enterprise partnerships"
                ]
            }
            
            return insights
            
        except Exception as e:
            logger.error(f"❌ Failed to generate business insights: {e}")
            return {
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def execute_command(self, command: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute orchestrator commands"""
        params = params or {}
        
        try:
            if command == "start":
                return self.start_system()
            
            elif command == "stop":
                return self.stop_system()
            
            elif command == "status":
                return self.get_system_info()
            
            elif command == "stats":
                return self.get_comprehensive_stats()
            
            elif command == "diagnostics":
                return self.run_diagnostics()
            
            elif command == "insights":
                return self.get_business_insights()
            
            elif command == "process_request":
                return self.process_ai_request(
                    user_id=params.get("user_id", "anonymous"),
                    service_type=params.get("service_type", "text_generation"),
                    request_data=params.get("request_data", {}),
                    api_key=params.get("api_key")
                )
            
            elif command == "revenue_report":
                return self.revenue_engine.generate_revenue_analytics()
            
            elif command == "automation_dashboard":
                return self.business_automation.get_automation_dashboard()
            
            elif command == "gateway_stats":
                return self.api_gateway.get_gateway_stats()
            
            else:
                return {
                    "success": False,
                    "error": f"Unknown command: {command}",
                    "available_commands": [
                        "start", "stop", "status", "stats", "diagnostics", 
                        "insights", "process_request", "revenue_report", 
                        "automation_dashboard", "gateway_stats"
                    ]
                }
                
        except Exception as e:
            logger.error(f"❌ Command execution failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "command": command,
                "timestamp": datetime.now().isoformat()
            }

# Example usage and testing
if __name__ == "__main__":
    orchestrator = OASISEnhancedOrchestrator()
    
    print("🚀 OASIS v3 Enhanced Orchestrator")
    print("=" * 50)
    
    # Start system
    start_result = orchestrator.execute_command("start")
    print(f"🔧 System start: {start_result['success']}")
    
    # Run diagnostics
    diagnostics = orchestrator.execute_command("diagnostics")
    print(f"🔍 Diagnostics: {diagnostics['system_status']}")
    
    # Process a test request
    test_request = orchestrator.execute_command("process_request", {
        "user_id": "test_user",
        "service_type": "text_generation",
        "request_data": {"prompt": "Hello, OASIS v3!"}
    })
    print(f"🤖 Test request: {test_request.get('success', False)}")
    
    # Get business insights
    insights = orchestrator.execute_command("insights")
    print(f"📊 Business insights: {len(insights.get('optimization_opportunities', []))} opportunities")
    
    # Get comprehensive stats
    stats = orchestrator.execute_command("stats")
    print(f"📈 System stats: {stats['orchestrator_stats']['total_requests']} total requests")

