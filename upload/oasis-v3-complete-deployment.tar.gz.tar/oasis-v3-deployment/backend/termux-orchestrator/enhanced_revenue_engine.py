#!/usr/bin/env python3
"""
OASIS v3 Enhanced Revenue Engine
Ultra-lightweight business intelligence with automated pricing and revenue optimization.
Enhanced with AI-driven insights and dynamic pricing strategies.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)

@dataclass
class PricingTier:
    """Enhanced pricing tier configuration"""
    name: str
    base_price: float
    requests_limit: int
    features: List[str]
    overage_rate: float
    ai_models_included: List[str]
    support_level: str
    sla_guarantee: Optional[str] = None

@dataclass
class ClientProfile:
    """Enhanced client profile with usage and billing data"""
    client_id: str
    tier: str
    total_spent: float
    requests_count: int
    last_activity: str
    satisfaction_score: float
    churn_risk: str
    preferred_models: List[str]
    usage_patterns: Dict[str, Any]
    billing_history: List[Dict[str, Any]]

@dataclass
class RevenueMetrics:
    """Comprehensive revenue metrics for analytics"""
    total_revenue: float
    monthly_revenue: float
    avg_transaction: float
    client_count: int
    growth_rate: float
    churn_rate: float
    ltv: float  # Lifetime Value
    arpu: float  # Average Revenue Per User

@dataclass
class UsageRecord:
    """Individual usage record for tracking"""
    record_id: str
    user_id: str
    service_type: str
    tokens_used: int
    cost: float
    timestamp: str
    model_used: str
    success: bool

class EnhancedRevenueEngine:
    """
    Enhanced automated revenue optimization and pricing engine.
    Zero dependencies, pure Python implementation with advanced analytics.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / "oasis-v3" / "data" / "revenue"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Data files
        self.clients_file = self.data_dir / "clients.json"
        self.usage_file = self.data_dir / "usage_records.json"
        self.pricing_file = self.data_dir / "pricing_tiers.json"
        
        # Initialize data
        self.pricing_tiers = self._load_pricing_tiers()
        self.clients = self._load_clients()
        self.usage_records = self._load_usage_records()
        
        logger.info("💰 Enhanced Revenue Engine initialized")

    def _load_pricing_tiers(self) -> Dict[str, PricingTier]:
        """Load pricing tiers from file or initialize defaults"""
        if self.pricing_file.exists():
            try:
                with open(self.pricing_file, 'r') as f:
                    data = json.load(f)
                    return {
                        tier_id: PricingTier(**tier_data)
                        for tier_id, tier_data in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load pricing tiers: {e}")
        
        # Initialize enhanced default pricing tiers
        return self._initialize_enhanced_pricing_tiers()

    def _initialize_enhanced_pricing_tiers(self) -> Dict[str, PricingTier]:
        """Initialize enhanced pricing tiers with AI model access"""
        tiers = {
            "free": PricingTier(
                name="Free Tier",
                base_price=0.0,
                requests_limit=50,
                features=["Basic API", "Community Support"],
                overage_rate=0.20,
                ai_models_included=["gpt2"],
                support_level="community"
            ),
            "starter": PricingTier(
                name="Starter",
                base_price=9.99,
                requests_limit=500,
                features=["Basic API", "Email Support", "Analytics Dashboard"],
                overage_rate=0.10,
                ai_models_included=["gpt2", "distilbert-base-uncased"],
                support_level="email"
            ),
            "professional": PricingTier(
                name="Professional", 
                base_price=29.99,
                requests_limit=2500,
                features=["Advanced API", "Priority Support", "Advanced Analytics", "Custom Models"],
                overage_rate=0.05,
                ai_models_included=["gpt2", "distilbert-base-uncased", "facebook/bart-large-cnn"],
                support_level="priority",
                sla_guarantee="99.5%"
            ),
            "enterprise": PricingTier(
                name="Enterprise",
                base_price=99.99,
                requests_limit=15000,
                features=["Full API", "24/7 Support", "Custom Models", "SLA", "Dedicated Account Manager"],
                overage_rate=0.02,
                ai_models_included=["all_models"],
                support_level="24/7",
                sla_guarantee="99.9%"
            ),
            "enterprise_plus": PricingTier(
                name="Enterprise Plus",
                base_price=299.99,
                requests_limit=50000,
                features=["Unlimited API", "White-label", "Custom Infrastructure", "Dedicated Support"],
                overage_rate=0.01,
                ai_models_included=["all_models", "custom_models"],
                support_level="dedicated",
                sla_guarantee="99.95%"
            )
        }
        
        self._save_pricing_tiers()
        return tiers

    def _save_pricing_tiers(self):
        """Save pricing tiers to file"""
        try:
            data = {
                tier_id: asdict(tier)
                for tier_id, tier in self.pricing_tiers.items()
            }
            
            with open(self.pricing_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save pricing tiers: {e}")

    def _load_clients(self) -> Dict[str, ClientProfile]:
        """Load client profiles from file"""
        if not self.clients_file.exists():
            return self._generate_demo_clients()
        
        try:
            with open(self.clients_file, 'r') as f:
                data = json.load(f)
                return {
                    client_id: ClientProfile(**client_data)
                    for client_id, client_data in data.items()
                }
        except Exception as e:
            logger.warning(f"Failed to load clients: {e}")
            return self._generate_demo_clients()

    def _generate_demo_clients(self) -> Dict[str, ClientProfile]:
        """Generate demo client data for demonstration"""
        return {
            "startup_001": ClientProfile(
                client_id="startup_001",
                tier="starter", 
                total_spent=89.91,
                requests_count=1450,
                last_activity=(datetime.now() - timedelta(hours=2)).isoformat(),
                satisfaction_score=4.2,
                churn_risk="low",
                preferred_models=["gpt2", "distilbert-base-uncased"],
                usage_patterns={"peak_hours": [9, 14, 18], "avg_daily_requests": 48},
                billing_history=[
                    {"date": "2024-01-01", "amount": 9.99, "tier": "starter"},
                    {"date": "2024-02-01", "amount": 19.98, "tier": "starter"},
                    {"date": "2024-03-01", "amount": 29.99, "tier": "professional"}
                ]
            ),
            "corp_002": ClientProfile(
                client_id="corp_002",
                tier="enterprise",
                total_spent=2899.73,
                requests_count=67000,
                last_activity=(datetime.now() - timedelta(minutes=15)).isoformat(),
                satisfaction_score=4.8,
                churn_risk="low",
                preferred_models=["facebook/bart-large-cnn", "all_models"],
                usage_patterns={"peak_hours": [8, 9, 10, 14, 15, 16], "avg_daily_requests": 2234},
                billing_history=[
                    {"date": "2024-01-01", "amount": 99.99, "tier": "enterprise"},
                    {"date": "2024-02-01", "amount": 199.98, "tier": "enterprise"},
                    {"date": "2024-03-01", "amount": 299.99, "tier": "enterprise_plus"}
                ]
            ),
            "agency_003": ClientProfile(
                client_id="agency_003",
                tier="professional",
                total_spent=449.73,
                requests_count=18500,
                last_activity=(datetime.now() - timedelta(days=1)).isoformat(),
                satisfaction_score=3.9,
                churn_risk="medium",
                preferred_models=["gpt2", "facebook/bart-large-cnn"],
                usage_patterns={"peak_hours": [10, 11, 15, 16], "avg_daily_requests": 617},
                billing_history=[
                    {"date": "2024-01-01", "amount": 29.99, "tier": "professional"},
                    {"date": "2024-02-01", "amount": 59.98, "tier": "professional"},
                    {"date": "2024-03-01", "amount": 89.97, "tier": "professional"}
                ]
            )
        }

    def _save_clients(self):
        """Save client profiles to file"""
        try:
            data = {
                client_id: asdict(client)
                for client_id, client in self.clients.items()
            }
            
            with open(self.clients_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save clients: {e}")

    def _load_usage_records(self) -> List[UsageRecord]:
        """Load usage records from file"""
        if not self.usage_file.exists():
            return []
        
        try:
            with open(self.usage_file, 'r') as f:
                data = json.load(f)
                return [UsageRecord(**record) for record in data]
        except Exception as e:
            logger.warning(f"Failed to load usage records: {e}")
            return []

    def _save_usage_records(self):
        """Save usage records to file"""
        try:
            data = [asdict(record) for record in self.usage_records]
            
            with open(self.usage_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save usage records: {e}")

    def register_user(self, user_id: str, tier: str = "free", 
                     metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Register a new user with enhanced profile"""
        if user_id in self.clients:
            logger.warning(f"User already exists: {user_id}")
            return False

        if tier not in self.pricing_tiers:
            logger.error(f"Invalid tier: {tier}")
            return False

        client = ClientProfile(
            client_id=user_id,
            tier=tier,
            total_spent=0.0,
            requests_count=0,
            last_activity=datetime.now().isoformat(),
            satisfaction_score=5.0,  # Start with perfect score
            churn_risk="low",
            preferred_models=[],
            usage_patterns={},
            billing_history=[]
        )

        self.clients[user_id] = client
        self._save_clients()
        
        logger.info(f"👤 User registered: {user_id} ({tier})")
        return True

    def record_usage(self, user_id: str, service_type: str, tokens_used: int = 1, 
                    model_used: str = "gpt2", success: bool = True) -> Optional[UsageRecord]:
        """Record usage with enhanced tracking"""
        if user_id not in self.clients:
            logger.error(f"User not found: {user_id}")
            return None

        client = self.clients[user_id]
        tier = self.pricing_tiers[client.tier]

        # Calculate cost based on tier and usage
        if client.requests_count < tier.requests_limit:
            cost = 0.0  # Within limit
        else:
            overage = tokens_used
            cost = overage * tier.overage_rate

        # Create usage record
        record = UsageRecord(
            record_id=f"usage_{len(self.usage_records) + 1}_{int(datetime.now().timestamp())}",
            user_id=user_id,
            service_type=service_type,
            tokens_used=tokens_used,
            cost=cost,
            timestamp=datetime.now().isoformat(),
            model_used=model_used,
            success=success
        )

        self.usage_records.append(record)

        # Update client profile
        client.requests_count += tokens_used
        client.total_spent += cost
        client.last_activity = datetime.now().isoformat()

        # Update preferred models
        if model_used not in client.preferred_models:
            client.preferred_models.append(model_used)

        self._save_usage_records()
        self._save_clients()

        logger.info(f"📊 Usage recorded: {user_id} - {service_type} (${cost:.4f})")
        return record

    def generate_revenue_analytics(self) -> Dict[str, Any]:
        """Generate comprehensive revenue analytics"""
        # Basic metrics
        total_clients = len(self.clients)
        total_revenue = sum(client.total_spent for client in self.clients.values())
        
        # Tier distribution
        tier_distribution = {}
        tier_revenue = {}
        
        for client in self.clients.values():
            tier_distribution[client.tier] = tier_distribution.get(client.tier, 0) + 1
            tier_revenue[client.tier] = tier_revenue.get(client.tier, 0) + client.total_spent

        # Calculate ARPU (Average Revenue Per User)
        arpu = total_revenue / total_clients if total_clients > 0 else 0

        # Calculate churn risk distribution
        churn_distribution = {}
        for client in self.clients.values():
            churn_distribution[client.churn_risk] = churn_distribution.get(client.churn_risk, 0) + 1

        # Recent activity analysis
        thirty_days_ago = datetime.now() - timedelta(days=30)
        active_clients = len([
            client for client in self.clients.values()
            if datetime.fromisoformat(client.last_activity) > thirty_days_ago
        ])

        # Usage analytics
        total_requests = sum(client.requests_count for client in self.clients.values())
        recent_usage_records = [
            r for r in self.usage_records
            if datetime.fromisoformat(r.timestamp) > thirty_days_ago
        ]
        
        monthly_revenue = sum(r.cost for r in recent_usage_records)

        # Growth calculation (mock for demo)
        growth_rate = 15.7  # Mock growth rate

        return {
            "timestamp": datetime.now().isoformat(),
            "overview": {
                "total_revenue": total_revenue,
                "monthly_revenue": monthly_revenue,
                "total_clients": total_clients,
                "active_clients": active_clients,
                "arpu": arpu,
                "total_requests": total_requests,
                "growth_rate": growth_rate
            },
            "tier_analytics": {
                "distribution": tier_distribution,
                "revenue_by_tier": tier_revenue,
                "tier_performance": {
                    tier_id: {
                        "clients": tier_distribution.get(tier_id, 0),
                        "revenue": tier_revenue.get(tier_id, 0),
                        "avg_revenue_per_client": tier_revenue.get(tier_id, 0) / tier_distribution.get(tier_id, 1)
                    }
                    for tier_id in self.pricing_tiers.keys()
                }
            },
            "risk_analytics": {
                "churn_distribution": churn_distribution,
                "high_risk_clients": len([c for c in self.clients.values() if c.churn_risk == "high"]),
                "satisfaction_avg": sum(c.satisfaction_score for c in self.clients.values()) / total_clients if total_clients > 0 else 0
            },
            "usage_analytics": {
                "total_requests_30_days": len(recent_usage_records),
                "avg_requests_per_client": len(recent_usage_records) / active_clients if active_clients > 0 else 0,
                "success_rate": (sum(1 for r in recent_usage_records if r.success) / len(recent_usage_records) * 100) if recent_usage_records else 100
            }
        }

    def optimize_pricing(self) -> Dict[str, Any]:
        """AI-driven pricing optimization recommendations"""
        analytics = self.generate_revenue_analytics()
        
        recommendations = []
        
        # Analyze tier performance
        tier_performance = analytics["tier_analytics"]["tier_performance"]
        
        for tier_id, performance in tier_performance.items():
            if performance["clients"] > 0:
                avg_revenue = performance["avg_revenue_per_client"]
                tier = self.pricing_tiers[tier_id]
                
                # Low revenue per client - suggest price increase
                if avg_revenue < tier.base_price * 1.5:
                    recommendations.append({
                        "type": "price_increase",
                        "tier": tier_id,
                        "current_price": tier.base_price,
                        "suggested_price": tier.base_price * 1.2,
                        "reason": "Low revenue per client ratio"
                    })
                
                # High revenue per client - suggest new tier
                if avg_revenue > tier.base_price * 3:
                    recommendations.append({
                        "type": "new_tier",
                        "tier": tier_id,
                        "reason": "High revenue potential - consider premium tier"
                    })

        # Churn risk analysis
        high_risk_count = analytics["risk_analytics"]["high_risk_clients"]
        if high_risk_count > analytics["overview"]["total_clients"] * 0.1:
            recommendations.append({
                "type": "retention_program",
                "reason": f"High churn risk detected ({high_risk_count} clients)",
                "suggestion": "Implement retention discounts or loyalty program"
            })

        return {
            "timestamp": datetime.now().isoformat(),
            "current_performance": analytics["overview"],
            "optimization_recommendations": recommendations,
            "projected_impact": {
                "revenue_increase": "15-25%",
                "churn_reduction": "10-15%",
                "client_satisfaction": "+0.3 points"
            }
        }

    def get_business_dashboard(self) -> Dict[str, Any]:
        """Get comprehensive business dashboard data"""
        analytics = self.generate_revenue_analytics()
        optimization = self.optimize_pricing()
        
        # Calculate key metrics
        total_clients = analytics["overview"]["total_clients"]
        monthly_revenue = analytics["overview"]["monthly_revenue"]
        growth_rate = analytics["overview"]["growth_rate"]
        
        # Top performing clients
        top_clients = sorted(
            self.clients.values(),
            key=lambda c: c.total_spent,
            reverse=True
        )[:5]
        
        # Recent activity
        recent_records = [
            r for r in self.usage_records
            if datetime.fromisoformat(r.timestamp) > datetime.now() - timedelta(days=7)
        ]
        
        return {
            "timestamp": datetime.now().isoformat(),
            "kpi_summary": {
                "total_revenue": analytics["overview"]["total_revenue"],
                "monthly_revenue": monthly_revenue,
                "total_clients": total_clients,
                "active_clients": analytics["overview"]["active_clients"],
                "growth_rate": growth_rate,
                "arpu": analytics["overview"]["arpu"]
            },
            "tier_breakdown": analytics["tier_analytics"]["distribution"],
            "top_clients": [
                {
                    "client_id": client.client_id,
                    "tier": client.tier,
                    "total_spent": client.total_spent,
                    "satisfaction_score": client.satisfaction_score
                }
                for client in top_clients
            ],
            "recent_activity": {
                "requests_this_week": len(recent_records),
                "revenue_this_week": sum(r.cost for r in recent_records),
                "success_rate": (sum(1 for r in recent_records if r.success) / len(recent_records) * 100) if recent_records else 100
            },
            "optimization_alerts": optimization["optimization_recommendations"][:3],  # Top 3 recommendations
            "churn_risk": {
                "high_risk_clients": analytics["risk_analytics"]["high_risk_clients"],
                "satisfaction_avg": analytics["risk_analytics"]["satisfaction_avg"]
            }
        }

# Example usage and testing
if __name__ == "__main__":
    revenue = EnhancedRevenueEngine()
    
    print("💰 OASIS v3 Enhanced Revenue Engine")
    print("=" * 50)
    
    # Demo operations
    revenue.register_user("demo_user", "starter")
    
    # Record some usage
    for i in range(5):
        revenue.record_usage("demo_user", "text_generation", tokens_used=10, model_used="gpt2")
    
    # Generate analytics
    analytics = revenue.generate_revenue_analytics()
    print(f"📈 Revenue analytics: ${analytics['overview']['total_revenue']:.2f} total, {analytics['overview']['total_clients']} clients")
    
    # Get optimization recommendations
    optimization = revenue.optimize_pricing()
    print(f"🎯 Optimization: {len(optimization['optimization_recommendations'])} recommendations")
    
    # Get business dashboard
    dashboard = revenue.get_business_dashboard()
    print(f"📊 Dashboard: ${dashboard['kpi_summary']['monthly_revenue']:.2f} monthly revenue, {dashboard['kpi_summary']['active_clients']} active clients")

