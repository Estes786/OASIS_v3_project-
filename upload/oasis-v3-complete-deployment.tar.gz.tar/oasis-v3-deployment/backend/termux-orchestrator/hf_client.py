#!/usr/bin/env python3
"""
OASIS v3 Hugging Face API Client
Ultra-lightweight client for Hugging Face Inference API
"""

import os
import json
import time
import logging
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class HuggingFaceClient:
    """Ultra-lightweight Hugging Face API client for OASIS v3"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv('HUGGING_FACE_API_KEY')
        self.base_url = "https://api-inference.huggingface.co/models"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}" if self.api_key else "",
            "Content-Type": "application/json"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        logger.info("🤗 Hugging Face Client initialized")
    
    def _make_request(self, model_name: str, payload: Dict[str, Any], 
                     max_retries: int = 3) -> Dict[str, Any]:
        """Make API request with retry logic"""
        url = f"{self.base_url}/{model_name}"
        
        for attempt in range(max_retries):
            try:
                response = self.session.post(url, json=payload, timeout=30)
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 503:
                    # Model is loading, wait and retry
                    wait_time = 2 ** attempt
                    logger.info(f"Model loading, waiting {wait_time}s...")
                    time.sleep(wait_time)
                    continue
                else:
                    logger.error(f"API error: {response.status_code} - {response.text}")
                    return {"error": f"API error: {response.status_code}"}
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Request failed: {e}")
                if attempt == max_retries - 1:
                    return {"error": f"Request failed: {e}"}
                time.sleep(1)
        
        return {"error": "Max retries exceeded"}
    
    def generate_text(self, prompt: str, model: str = "gpt2", 
                     max_length: int = 100, temperature: float = 0.7) -> Dict[str, Any]:
        """Generate text using language models"""
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_length": max_length,
                "temperature": temperature,
                "return_full_text": False
            }
        }
        
        logger.info(f"🔤 Generating text with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result and isinstance(result, list) and len(result) > 0:
            generated_text = result[0].get("generated_text", "")
            return {
                "success": True,
                "generated_text": generated_text,
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def analyze_sentiment(self, text: str, 
                         model: str = "cardiffnlp/twitter-roberta-base-sentiment-latest") -> Dict[str, Any]:
        """Analyze sentiment of text"""
        payload = {"inputs": text}
        
        logger.info(f"😊 Analyzing sentiment with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result and isinstance(result, list):
            return {
                "success": True,
                "sentiment": result[0] if result else [],
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def summarize_text(self, text: str, 
                      model: str = "facebook/bart-large-cnn") -> Dict[str, Any]:
        """Summarize text"""
        payload = {"inputs": text}
        
        logger.info(f"📝 Summarizing text with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result and isinstance(result, list) and len(result) > 0:
            summary = result[0].get("summary_text", "")
            return {
                "success": True,
                "summary": summary,
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def classify_text(self, text: str, 
                     model: str = "facebook/bart-large-mnli") -> Dict[str, Any]:
        """Classify text"""
        payload = {"inputs": text}
        
        logger.info(f"🏷️ Classifying text with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result:
            return {
                "success": True,
                "classification": result,
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def translate_text(self, text: str, source_lang: str = "en", target_lang: str = "fr",
                      model: str = "Helsinki-NLP/opus-mt-en-fr") -> Dict[str, Any]:
        """Translate text"""
        payload = {"inputs": text}
        
        logger.info(f"🌐 Translating {source_lang} -> {target_lang} with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result and isinstance(result, list) and len(result) > 0:
            translation = result[0].get("translation_text", "")
            return {
                "success": True,
                "translation": translation,
                "source_lang": source_lang,
                "target_lang": target_lang,
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def question_answering(self, question: str, context: str,
                          model: str = "deepset/roberta-base-squad2") -> Dict[str, Any]:
        """Answer questions based on context"""
        payload = {
            "inputs": {
                "question": question,
                "context": context
            }
        }
        
        logger.info(f"❓ Answering question with {model}")
        result = self._make_request(model, payload)
        
        if "error" not in result and "answer" in result:
            return {
                "success": True,
                "answer": result["answer"],
                "score": result.get("score", 0),
                "model": model,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": False,
            "error": result.get("error", "Unknown error"),
            "model": model
        }
    
    def get_available_models(self) -> List[str]:
        """Get list of commonly used models for OASIS v3"""
        return [
            "gpt2",
            "microsoft/DialoGPT-medium",
            "cardiffnlp/twitter-roberta-base-sentiment-latest",
            "facebook/bart-large-cnn",
            "facebook/bart-large-mnli",
            "Helsinki-NLP/opus-mt-en-fr",
            "deepset/roberta-base-squad2",
            "sentence-transformers/all-MiniLM-L6-v2"
        ]
    
    def health_check(self) -> Dict[str, Any]:
        """Check if the client is working properly"""
        try:
            # Simple test with a lightweight model
            result = self.generate_text("Hello", model="gpt2", max_length=10)
            return {
                "status": "healthy" if result["success"] else "unhealthy",
                "api_key_set": bool(self.api_key),
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

# Example usage and testing
if __name__ == "__main__":
    import sys
    
    # Initialize client
    client = HuggingFaceClient()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "health":
            result = client.health_check()
            print(json.dumps(result, indent=2))
        
        elif command == "models":
            models = client.get_available_models()
            print("Available models:")
            for model in models:
                print(f"  - {model}")
        
        elif command == "test":
            print("Testing Hugging Face Client...")
            
            # Test text generation
            result = client.generate_text("The future of AI is", max_length=50)
            print("Text Generation:", json.dumps(result, indent=2))
            
            # Test sentiment analysis
            result = client.analyze_sentiment("I love this new AI system!")
            print("Sentiment Analysis:", json.dumps(result, indent=2))
        
        else:
            print(f"Unknown command: {command}")
            print("Available commands: health, models, test")
    
    else:
        print("OASIS v3 Hugging Face Client")
        print("Usage: python3 hf_client.py <command>")
        print("Commands: health, models, test")

