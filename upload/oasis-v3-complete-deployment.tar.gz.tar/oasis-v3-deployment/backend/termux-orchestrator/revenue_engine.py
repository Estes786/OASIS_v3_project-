#!/usr/bin/env python3
"""
OASIS v3 Revenue Engine
Handles monetization, usage tracking, and freemium model
"""

import os
import json
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)

@dataclass
class UsageRecord:
    """Record of API usage"""
    user_id: str
    service: str
    timestamp: datetime
    tokens_used: int = 0
    cost: float = 0.0
    tier: str = "free"
    success: bool = True

@dataclass
class UserTier:
    """User subscription tier"""
    user_id: str
    tier: str  # free, premium, enterprise
    start_date: datetime
    end_date: Optional[datetime] = None
    monthly_limit: int = 1000
    daily_limit: int = 100
    hourly_limit: int = 20

class RevenueEngine:
    """Manages revenue generation and usage tracking"""
    
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / "oasis-v3" / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.usage_file = self.data_dir / "usage_records.json"
        self.users_file = self.data_dir / "user_tiers.json"
        self.revenue_file = self.data_dir / "revenue_stats.json"
        
        self.usage_records: List[UsageRecord] = []
        self.user_tiers: Dict[str, UserTier] = {}
        self.revenue_stats = self._load_revenue_stats()
        
        self._load_data()
        
        # Pricing configuration
        self.pricing = {
            "free": {
                "daily_limit": 100,
                "hourly_limit": 20,
                "monthly_cost": 0.0,
                "cost_per_request": 0.0
            },
            "premium": {
                "daily_limit": 1000,
                "hourly_limit": 200,
                "monthly_cost": 9.99,
                "cost_per_request": 0.01
            },
            "enterprise": {
                "daily_limit": 10000,
                "hourly_limit": 2000,
                "monthly_cost": 99.99,
                "cost_per_request": 0.005
            }
        }
        
        logger.info("💰 Revenue Engine initialized")
    
    def _load_data(self):
        """Load usage records and user tiers from files"""
        # Load usage records
        if self.usage_file.exists():
            try:
                with open(self.usage_file, 'r') as f:
                    data = json.load(f)
                    self.usage_records = [
                        UsageRecord(
                            user_id=record["user_id"],
                            service=record["service"],
                            timestamp=datetime.fromisoformat(record["timestamp"]),
                            tokens_used=record.get("tokens_used", 0),
                            cost=record.get("cost", 0.0),
                            tier=record.get("tier", "free"),
                            success=record.get("success", True)
                        )
                        for record in data
                    ]
            except Exception as e:
                logger.warning(f"Failed to load usage records: {e}")
        
        # Load user tiers
        if self.users_file.exists():
            try:
                with open(self.users_file, 'r') as f:
                    data = json.load(f)
                    self.user_tiers = {
                        user_id: UserTier(
                            user_id=user_data["user_id"],
                            tier=user_data["tier"],
                            start_date=datetime.fromisoformat(user_data["start_date"]),
                            end_date=datetime.fromisoformat(user_data["end_date"]) if user_data.get("end_date") else None,
                            monthly_limit=user_data.get("monthly_limit", 1000),
                            daily_limit=user_data.get("daily_limit", 100),
                            hourly_limit=user_data.get("hourly_limit", 20)
                        )
                        for user_id, user_data in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load user tiers: {e}")
    
    def _save_data(self):
        """Save usage records and user tiers to files"""
        try:
            # Save usage records
            with open(self.usage_file, 'w') as f:
                json.dump([
                    {
                        "user_id": record.user_id,
                        "service": record.service,
                        "timestamp": record.timestamp.isoformat(),
                        "tokens_used": record.tokens_used,
                        "cost": record.cost,
                        "tier": record.tier,
                        "success": record.success
                    }
                    for record in self.usage_records
                ], f, indent=2)
            
            # Save user tiers
            with open(self.users_file, 'w') as f:
                json.dump({
                    user_id: {
                        "user_id": user_tier.user_id,
                        "tier": user_tier.tier,
                        "start_date": user_tier.start_date.isoformat(),
                        "end_date": user_tier.end_date.isoformat() if user_tier.end_date else None,
                        "monthly_limit": user_tier.monthly_limit,
                        "daily_limit": user_tier.daily_limit,
                        "hourly_limit": user_tier.hourly_limit
                    }
                    for user_id, user_tier in self.user_tiers.items()
                }, f, indent=2)
            
        except Exception as e:
            logger.error(f"Failed to save data: {e}")
    
    def _load_revenue_stats(self) -> Dict[str, Any]:
        """Load revenue statistics"""
        default_stats = {
            "total_revenue": 0.0,
            "monthly_revenue": 0.0,
            "total_users": 0,
            "premium_users": 0,
            "enterprise_users": 0,
            "total_requests": 0,
            "successful_requests": 0,
            "last_updated": datetime.now().isoformat()
        }
        
        if self.revenue_file.exists():
            try:
                with open(self.revenue_file, 'r') as f:
                    stats = json.load(f)
                    default_stats.update(stats)
            except Exception as e:
                logger.warning(f"Failed to load revenue stats: {e}")
        
        return default_stats
    
    def _save_revenue_stats(self):
        """Save revenue statistics"""
        try:
            self.revenue_stats["last_updated"] = datetime.now().isoformat()
            with open(self.revenue_file, 'w') as f:
                json.dump(self.revenue_stats, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save revenue stats: {e}")
    
    def register_user(self, user_id: str, tier: str = "free") -> bool:
        """Register a new user"""
        if user_id in self.user_tiers:
            logger.warning(f"User {user_id} already registered")
            return False
        
        pricing = self.pricing.get(tier, self.pricing["free"])
        
        user_tier = UserTier(
            user_id=user_id,
            tier=tier,
            start_date=datetime.now(),
            monthly_limit=pricing["daily_limit"] * 30,
            daily_limit=pricing["daily_limit"],
            hourly_limit=pricing["hourly_limit"]
        )
        
        self.user_tiers[user_id] = user_tier
        self._save_data()
        
        # Update stats
        self.revenue_stats["total_users"] += 1
        if tier == "premium":
            self.revenue_stats["premium_users"] += 1
        elif tier == "enterprise":
            self.revenue_stats["enterprise_users"] += 1
        
        self._save_revenue_stats()
        
        logger.info(f"👤 User registered: {user_id} ({tier})")
        return True
    
    def upgrade_user(self, user_id: str, new_tier: str) -> bool:
        """Upgrade user to a new tier"""
        if user_id not in self.user_tiers:
            logger.error(f"User {user_id} not found")
            return False
        
        old_tier = self.user_tiers[user_id].tier
        pricing = self.pricing.get(new_tier, self.pricing["free"])
        
        self.user_tiers[user_id].tier = new_tier
        self.user_tiers[user_id].monthly_limit = pricing["daily_limit"] * 30
        self.user_tiers[user_id].daily_limit = pricing["daily_limit"]
        self.user_tiers[user_id].hourly_limit = pricing["hourly_limit"]
        
        self._save_data()
        
        # Update stats
        if old_tier == "free" and new_tier == "premium":
            self.revenue_stats["premium_users"] += 1
        elif old_tier == "free" and new_tier == "enterprise":
            self.revenue_stats["enterprise_users"] += 1
        elif old_tier == "premium" and new_tier == "enterprise":
            self.revenue_stats["premium_users"] -= 1
            self.revenue_stats["enterprise_users"] += 1
        
        self._save_revenue_stats()
        
        logger.info(f"⬆️ User upgraded: {user_id} ({old_tier} -> {new_tier})")
        return True
    
    def check_usage_limits(self, user_id: str, service: str) -> Dict[str, Any]:
        """Check if user can make a request based on usage limits"""
        # Get or create user
        if user_id not in self.user_tiers:
            self.register_user(user_id, "free")
        
        user_tier = self.user_tiers[user_id]
        now = datetime.now()
        
        # Count recent usage
        hour_ago = now - timedelta(hours=1)
        day_ago = now - timedelta(days=1)
        month_ago = now - timedelta(days=30)
        
        hourly_usage = len([
            r for r in self.usage_records
            if r.user_id == user_id and r.timestamp >= hour_ago and r.success
        ])
        
        daily_usage = len([
            r for r in self.usage_records
            if r.user_id == user_id and r.timestamp >= day_ago and r.success
        ])
        
        monthly_usage = len([
            r for r in self.usage_records
            if r.user_id == user_id and r.timestamp >= month_ago and r.success
        ])
        
        # Check limits
        can_proceed = (
            hourly_usage < user_tier.hourly_limit and
            daily_usage < user_tier.daily_limit and
            monthly_usage < user_tier.monthly_limit
        )
        
        return {
            "can_proceed": can_proceed,
            "user_tier": user_tier.tier,
            "usage": {
                "hourly": {"used": hourly_usage, "limit": user_tier.hourly_limit},
                "daily": {"used": daily_usage, "limit": user_tier.daily_limit},
                "monthly": {"used": monthly_usage, "limit": user_tier.monthly_limit}
            },
            "limits_exceeded": {
                "hourly": hourly_usage >= user_tier.hourly_limit,
                "daily": daily_usage >= user_tier.daily_limit,
                "monthly": monthly_usage >= user_tier.monthly_limit
            }
        }
    
    def record_usage(self, user_id: str, service: str, tokens_used: int = 1, 
                    success: bool = True) -> UsageRecord:
        """Record API usage"""
        user_tier = self.user_tiers.get(user_id)
        tier = user_tier.tier if user_tier else "free"
        
        # Calculate cost
        pricing = self.pricing.get(tier, self.pricing["free"])
        cost = tokens_used * pricing["cost_per_request"]
        
        record = UsageRecord(
            user_id=user_id,
            service=service,
            timestamp=datetime.now(),
            tokens_used=tokens_used,
            cost=cost,
            tier=tier,
            success=success
        )
        
        self.usage_records.append(record)
        
        # Update revenue stats
        self.revenue_stats["total_requests"] += 1
        if success:
            self.revenue_stats["successful_requests"] += 1
            self.revenue_stats["total_revenue"] += cost
        
        # Clean old records (keep last 30 days)
        cutoff = datetime.now() - timedelta(days=30)
        self.usage_records = [r for r in self.usage_records if r.timestamp >= cutoff]
        
        self._save_data()
        self._save_revenue_stats()
        
        logger.info(f"📊 Usage recorded: {user_id} - {service} (${cost:.4f})")
        return record
    
    def get_user_stats(self, user_id: str) -> Dict[str, Any]:
        """Get usage statistics for a user"""
        if user_id not in self.user_tiers:
            return {"error": "User not found"}
        
        user_tier = self.user_tiers[user_id]
        user_records = [r for r in self.usage_records if r.user_id == user_id]
        
        now = datetime.now()
        day_ago = now - timedelta(days=1)
        month_ago = now - timedelta(days=30)
        
        daily_records = [r for r in user_records if r.timestamp >= day_ago]
        monthly_records = [r for r in user_records if r.timestamp >= month_ago]
        
        return {
            "user_id": user_id,
            "tier": user_tier.tier,
            "registration_date": user_tier.start_date.isoformat(),
            "limits": {
                "hourly": user_tier.hourly_limit,
                "daily": user_tier.daily_limit,
                "monthly": user_tier.monthly_limit
            },
            "usage": {
                "total_requests": len(user_records),
                "daily_requests": len(daily_records),
                "monthly_requests": len(monthly_records),
                "total_cost": sum(r.cost for r in user_records),
                "monthly_cost": sum(r.cost for r in monthly_records)
            },
            "services_used": list(set(r.service for r in user_records)),
            "success_rate": len([r for r in user_records if r.success]) / max(len(user_records), 1)
        }
    
    def get_revenue_stats(self) -> Dict[str, Any]:
        """Get comprehensive revenue statistics"""
        now = datetime.now()
        month_ago = now - timedelta(days=30)
        
        # Calculate monthly revenue
        monthly_records = [r for r in self.usage_records if r.timestamp >= month_ago]
        monthly_revenue = sum(r.cost for r in monthly_records)
        
        # Calculate subscription revenue
        subscription_revenue = (
            self.revenue_stats["premium_users"] * self.pricing["premium"]["monthly_cost"] +
            self.revenue_stats["enterprise_users"] * self.pricing["enterprise"]["monthly_cost"]
        )
        
        # Service usage breakdown
        service_stats = {}
        for record in self.usage_records:
            if record.service not in service_stats:
                service_stats[record.service] = {"requests": 0, "revenue": 0.0}
            service_stats[record.service]["requests"] += 1
            service_stats[record.service]["revenue"] += record.cost
        
        return {
            "total_revenue": self.revenue_stats["total_revenue"],
            "monthly_revenue": monthly_revenue,
            "subscription_revenue": subscription_revenue,
            "api_revenue": self.revenue_stats["total_revenue"] - subscription_revenue,
            "users": {
                "total": self.revenue_stats["total_users"],
                "free": self.revenue_stats["total_users"] - self.revenue_stats["premium_users"] - self.revenue_stats["enterprise_users"],
                "premium": self.revenue_stats["premium_users"],
                "enterprise": self.revenue_stats["enterprise_users"]
            },
            "requests": {
                "total": self.revenue_stats["total_requests"],
                "successful": self.revenue_stats["successful_requests"],
                "success_rate": self.revenue_stats["successful_requests"] / max(self.revenue_stats["total_requests"], 1)
            },
            "service_breakdown": service_stats,
            "projections": {
                "monthly_recurring_revenue": subscription_revenue,
                "annual_recurring_revenue": subscription_revenue * 12,
                "average_revenue_per_user": self.revenue_stats["total_revenue"] / max(self.revenue_stats["total_users"], 1)
            },
            "last_updated": self.revenue_stats["last_updated"]
        }
    
    def generate_revenue_report(self) -> str:
        """Generate a formatted revenue report"""
        stats = self.get_revenue_stats()
        
        report = f"""
OASIS v3 Revenue Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'=' * 50}

💰 REVENUE OVERVIEW
Total Revenue: ${stats['total_revenue']:.2f}
Monthly Revenue: ${stats['monthly_revenue']:.2f}
Subscription Revenue: ${stats['subscription_revenue']:.2f}
API Revenue: ${stats['api_revenue']:.2f}

👥 USER METRICS
Total Users: {stats['users']['total']}
Free Users: {stats['users']['free']}
Premium Users: {stats['users']['premium']}
Enterprise Users: {stats['users']['enterprise']}

📊 REQUEST METRICS
Total Requests: {stats['requests']['total']}
Successful Requests: {stats['requests']['successful']}
Success Rate: {stats['requests']['success_rate']:.1%}

🔮 PROJECTIONS
Monthly Recurring Revenue: ${stats['projections']['monthly_recurring_revenue']:.2f}
Annual Recurring Revenue: ${stats['projections']['annual_recurring_revenue']:.2f}
Average Revenue Per User: ${stats['projections']['average_revenue_per_user']:.2f}

🎯 SERVICE BREAKDOWN
"""
        
        for service, data in stats['service_breakdown'].items():
            report += f"{service}: {data['requests']} requests, ${data['revenue']:.2f}\n"
        
        return report

# Example usage
if __name__ == "__main__":
    revenue = RevenueEngine()
    
    print("OASIS v3 Revenue Engine")
    print("=" * 40)
    
    # Demo usage
    revenue.register_user("demo_user", "free")
    revenue.register_user("premium_user", "premium")
    
    # Record some usage
    revenue.record_usage("demo_user", "text_generation", tokens_used=10)
    revenue.record_usage("premium_user", "sentiment_analysis", tokens_used=5)
    
    # Show stats
    print("\nRevenue Report:")
    print(revenue.generate_revenue_report())
    
    print("\nUser Stats:")
    user_stats = revenue.get_user_stats("demo_user")
    print(json.dumps(user_stats, indent=2))

