#!/usr/bin/env python3
"""
OASIS v3 Orchestrator Test Suite
Comprehensive testing for all components
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from pathlib import Path

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from hf_client import HuggingFaceClient
    from config_manager import ConfigManager
    from revenue_engine import RevenueEngine
    from oasis_orchestrator import OASISOrchestrator
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Make sure all OASIS v3 modules are in the same directory")
    sys.exit(1)

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class OASISTestSuite:
    """Comprehensive test suite for OASIS v3 components"""
    
    def __init__(self):
        self.test_results = {
            "total_tests": 0,
            "passed": 0,
            "failed": 0,
            "errors": [],
            "start_time": datetime.now()
        }
        
        print("🧪 OASIS v3 Test Suite")
        print("=" * 50)
    
    def run_test(self, test_name: str, test_func):
        """Run a single test and record results"""
        self.test_results["total_tests"] += 1
        
        try:
            print(f"\n🔍 Testing: {test_name}")
            start_time = time.time()
            
            result = test_func()
            
            end_time = time.time()
            duration = end_time - start_time
            
            if result:
                print(f"✅ PASS: {test_name} ({duration:.2f}s)")
                self.test_results["passed"] += 1
            else:
                print(f"❌ FAIL: {test_name} ({duration:.2f}s)")
                self.test_results["failed"] += 1
                self.test_results["errors"].append(f"{test_name}: Test returned False")
            
        except Exception as e:
            print(f"💥 ERROR: {test_name} - {e}")
            self.test_results["failed"] += 1
            self.test_results["errors"].append(f"{test_name}: {str(e)}")
    
    def test_imports(self):
        """Test that all modules can be imported"""
        try:
            # Test imports
            from hf_client import HuggingFaceClient
            from config_manager import ConfigManager
            from revenue_engine import RevenueEngine
            from oasis_orchestrator import OASISOrchestrator
            
            print("  ✓ All modules imported successfully")
            return True
        except Exception as e:
            print(f"  ✗ Import failed: {e}")
            return False
    
    def test_config_manager(self):
        """Test configuration manager functionality"""
        try:
            config = ConfigManager()
            
            # Test basic operations
            config.set("test.value", "hello")
            value = config.get("test.value")
            
            if value != "hello":
                print(f"  ✗ Config set/get failed: expected 'hello', got '{value}'")
                return False
            
            # Test service operations
            config.enable_service("test_service")
            if not config.is_service_enabled("test_service"):
                print("  ✗ Service enable/check failed")
                return False
            
            # Test validation
            validation = config.validate_config()
            if not isinstance(validation, dict):
                print("  ✗ Config validation failed")
                return False
            
            print("  ✓ Configuration manager working correctly")
            return True
            
        except Exception as e:
            print(f"  ✗ Config manager error: {e}")
            return False
    
    def test_revenue_engine(self):
        """Test revenue engine functionality"""
        try:
            revenue = RevenueEngine()
            
            # Test user registration
            test_user = f"test_user_{int(time.time())}"
            if not revenue.register_user(test_user, "free"):
                print("  ✗ User registration failed")
                return False
            
            # Test usage recording
            record = revenue.record_usage(test_user, "test_service", tokens_used=5)
            if not record or record.user_id != test_user:
                print("  ✗ Usage recording failed")
                return False
            
            # Test usage limits
            limits = revenue.check_usage_limits(test_user, "test_service")
            if not limits or "can_proceed" not in limits:
                print("  ✗ Usage limit check failed")
                return False
            
            # Test stats
            stats = revenue.get_user_stats(test_user)
            if not stats or "user_id" not in stats:
                print("  ✗ User stats failed")
                return False
            
            print("  ✓ Revenue engine working correctly")
            return True
            
        except Exception as e:
            print(f"  ✗ Revenue engine error: {e}")
            return False
    
    def test_hf_client(self):
        """Test Hugging Face client functionality"""
        try:
            client = HuggingFaceClient()
            
            # Test health check
            health = client.health_check()
            if not health or "status" not in health:
                print("  ✗ Health check failed")
                return False
            
            # Test model list
            models = client.get_available_models()
            if not models or len(models) == 0:
                print("  ✗ Model list failed")
                return False
            
            print("  ✓ Hugging Face client initialized correctly")
            
            # Test API call (only if API key is set)
            api_key = os.getenv('HUGGING_FACE_API_KEY')
            if api_key and api_key != "your_hf_token_here":
                print("  🔑 API key found, testing API call...")
                result = client.generate_text("Hello", model="gpt2", max_length=10)
                
                if result and "success" in result:
                    if result["success"]:
                        print("  ✓ API call successful")
                    else:
                        print(f"  ⚠️ API call failed: {result.get('error', 'Unknown error')}")
                else:
                    print("  ⚠️ API call returned unexpected format")
            else:
                print("  ⚠️ No API key set, skipping API test")
            
            return True
            
        except Exception as e:
            print(f"  ✗ HF client error: {e}")
            return False
    
    def test_orchestrator(self):
        """Test main orchestrator functionality"""
        try:
            orchestrator = OASISOrchestrator()
            
            # Test status
            status = orchestrator.get_status()
            if not status or "oasis_version" not in status:
                print("  ✗ Status check failed")
                return False
            
            # Test diagnostics
            diagnostics = orchestrator.run_diagnostics()
            if not diagnostics or "system_status" not in diagnostics:
                print("  ✗ Diagnostics failed")
                return False
            
            print("  ✓ Orchestrator working correctly")
            return True
            
        except Exception as e:
            print(f"  ✗ Orchestrator error: {e}")
            return False
    
    def test_file_structure(self):
        """Test that required files and directories exist"""
        try:
            current_dir = Path(__file__).parent
            
            required_files = [
                "oasis_orchestrator.py",
                "hf_client.py",
                "config_manager.py",
                "revenue_engine.py",
                "requirements.txt",
                "README.md"
            ]
            
            for file_name in required_files:
                file_path = current_dir / file_name
                if not file_path.exists():
                    print(f"  ✗ Missing required file: {file_name}")
                    return False
            
            print("  ✓ All required files present")
            return True
            
        except Exception as e:
            print(f"  ✗ File structure error: {e}")
            return False
    
    def test_environment(self):
        """Test environment and dependencies"""
        try:
            import sys
            import json
            import time
            import logging
            import requests
            from datetime import datetime
            from pathlib import Path
            from typing import Dict, List, Optional, Any
            from dataclasses import dataclass
            
            print(f"  ✓ Python version: {sys.version}")
            print("  ✓ All required modules available")
            return True
            
        except ImportError as e:
            print(f"  ✗ Missing dependency: {e}")
            return False
        except Exception as e:
            print(f"  ✗ Environment error: {e}")
            return False
    
    def run_all_tests(self):
        """Run all tests and generate report"""
        print(f"🚀 Starting OASIS v3 Test Suite at {self.test_results['start_time']}")
        
        # Run all tests
        self.run_test("Environment Check", self.test_environment)
        self.run_test("File Structure", self.test_file_structure)
        self.run_test("Module Imports", self.test_imports)
        self.run_test("Configuration Manager", self.test_config_manager)
        self.run_test("Revenue Engine", self.test_revenue_engine)
        self.run_test("Hugging Face Client", self.test_hf_client)
        self.run_test("Main Orchestrator", self.test_orchestrator)
        
        # Generate report
        self.generate_report()
    
    def generate_report(self):
        """Generate final test report"""
        end_time = datetime.now()
        duration = end_time - self.test_results["start_time"]
        
        print("\n" + "=" * 50)
        print("📊 TEST RESULTS")
        print("=" * 50)
        
        print(f"Total Tests: {self.test_results['total_tests']}")
        print(f"Passed: {self.test_results['passed']} ✅")
        print(f"Failed: {self.test_results['failed']} ❌")
        print(f"Success Rate: {(self.test_results['passed'] / self.test_results['total_tests']) * 100:.1f}%")
        print(f"Duration: {duration.total_seconds():.2f} seconds")
        
        if self.test_results["errors"]:
            print("\n🐛 ERRORS:")
            for error in self.test_results["errors"]:
                print(f"  - {error}")
        
        if self.test_results["failed"] == 0:
            print("\n🎉 ALL TESTS PASSED! OASIS v3 is ready for deployment!")
        else:
            print(f"\n⚠️ {self.test_results['failed']} test(s) failed. Please review and fix issues.")
        
        # Save report to file
        report_data = {
            **self.test_results,
            "end_time": end_time.isoformat(),
            "duration_seconds": duration.total_seconds()
        }
        
        try:
            report_file = Path.home() / "oasis-v3" / "logs" / "test_report.json"
            report_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(report_file, 'w') as f:
                json.dump(report_data, f, indent=2, default=str)
            
            print(f"\n📄 Test report saved to: {report_file}")
        except Exception as e:
            print(f"\n⚠️ Could not save test report: {e}")

def main():
    """Main entry point"""
    test_suite = OASISTestSuite()
    test_suite.run_all_tests()

if __name__ == "__main__":
    main()

