#!/bin/bash

# OASIS v3 Vercel Deployment Script
# Deploy the frontend to Vercel for global access

echo "🚀 OASIS v3 Vercel Deployment"
echo "================================"

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel
fi

# Navigate to frontend directory
cd ../frontend

# Create vercel.json configuration
cat > vercel.json << EOF
{
  "version": 2,
  "name": "oasis-v3-frontend",
  "builds": [
    {
      "src": "index.html",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  },
  "functions": {
    "app/api/**/*.js": {
      "runtime": "nodejs18.x"
    }
  }
}
EOF

# Create package.json for Vercel
cat > package.json << EOF
{
  "name": "oasis-v3-frontend",
  "version": "3.0.0",
  "description": "OASIS v3 - AI Superintelligence Platform Frontend",
  "main": "index.html",
  "scripts": {
    "start": "serve -s .",
    "build": "echo 'Already built'"
  },
  "keywords": ["ai", "superintelligence", "oasis", "termux", "huggingface"],
  "author": "OASIS Team",
  "license": "MIT",
  "dependencies": {
    "serve": "^14.0.0"
  }
}
EOF

echo "📋 Deploying to Vercel..."
vercel --prod

echo "✅ OASIS v3 Frontend deployed successfully!"
echo "🌐 Your application is now live on Vercel"
echo ""
echo "Next steps:"
echo "1. Configure your custom domain (optional)"
echo "2. Set up environment variables for API endpoints"
echo "3. Connect to Supabase backend"
echo ""
echo "🎉 OASIS v3 is ready for global access!"

