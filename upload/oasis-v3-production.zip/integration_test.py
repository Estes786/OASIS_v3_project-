#!/usr/bin/env python3
"""
OASIS v3 End-to-End Integration Test Suite
Comprehensive testing across all ecosystem components

Test Coverage:
- HuggingFace Spaces API endpoints
- Termux orchestrator functionality  
- Frontend-backend integration
- Supabase database operations
- Revenue tracking accuracy
- Performance benchmarks

Author: OASIS Team
Version: 3.0.0-production
"""

import json
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime
from typing import Dict, List, Any, Optional

class OASISIntegrationTester:
    """Comprehensive integration testing for OASIS v3 ecosystem"""

    def __init__(self, config_path: str = "test_config.json"):
        self.version = "3.0.0-integration-test"
        self.test_start = datetime.now()
        self.config = self._load_test_config(config_path)

        # Test endpoints
        self.hf_spaces_url = self.config.get("hf_spaces_url", "https://elmatador0197-oasis-v3.hf.space")
        self.frontend_url = self.config.get("frontend_url", "https://oasis-v3.vercel.app")
        self.supabase_url = self.config.get("supabase_url", "")

        # Test results
        self.test_results = []
        self.passed_tests = 0
        self.failed_tests = 0

        print(f"🧪 OASIS v3 Integration Test Suite v{self.version}")
        print(f"🎯 Testing endpoints:")
        print(f"   🤗 HF Spaces: {self.hf_spaces_url}")
        print(f"   🌐 Frontend: {self.frontend_url}")
        print(f"   🗄️  Supabase: {'Configured' if self.supabase_url else 'Not configured'}")
        print("-" * 60)

    def _load_test_config(self, config_path: str) -> Dict[str, Any]:
        """Load test configuration with defaults"""
        default_config = {
            "hf_spaces_url": "https://elmatador0197-oasis-v3.hf.space",
            "frontend_url": "https://oasis-v3.vercel.app",
            "supabase_url": "",
            "test_timeout": 30,
            "test_data": {
                "sentiment_texts": [
                    "OASIS v3 is revolutionary and amazing!",
                    "This AI system is terrible and broken.",
                    "The weather is okay today."
                ],
                "generation_prompts": [
                    "The future of AI is",
                    "Mobile computing will",
                    "Revenue optimization through"
                ],
                "translation_texts": [
                    "Hello world, this is OASIS v3!",
                    "Artificial intelligence is transforming technology.",
                    "Mobile-first development is essential."
                ]
            }
        }

        try:
            with open(config_path, "r") as f:
                user_config = json.load(f)
                default_config.update(user_config)
        except FileNotFoundError:
            print(f"⚠️  Config file not found, using defaults")

        return default_config

    def _make_request(self, url: str, method: str = "GET", data: Dict = None) -> Dict[str, Any]:
        """Make HTTP request with error handling"""
        try:
            if method == "POST" and data:
                json_data = json.dumps(data).encode('utf-8')
                req = urllib.request.Request(
                    url,
                    data=json_data,
                    headers={'Content-Type': 'application/json'}
                )
            else:
                req = urllib.request.Request(url)

            with urllib.request.urlopen(req, timeout=self.config["test_timeout"]) as response:
                response_data = response.read().decode('utf-8')
                return {
                    "success": True,
                    "status_code": response.getcode(),
                    "data": json.loads(response_data) if response_data else {}
                }

        except urllib.error.HTTPError as e:
            return {
                "success": False,
                "status_code": e.code,
                "error": f"HTTP {e.code}: {e.reason}"
            }
        except Exception as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e)
            }

    def _log_test(self, test_name: str, passed: bool, details: str = "", duration: float = 0):
        """Log test result"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name} ({duration:.3f}s)")
        if details:
            print(f"      {details}")

        self.test_results.append({
            "test_name": test_name,
            "passed": passed,
            "details": details,
            "duration": duration,
            "timestamp": datetime.now().isoformat()
        })

        if passed:
            self.passed_tests += 1
        else:
            self.failed_tests += 1

    def test_hf_spaces_health(self) -> bool:
        """Test HuggingFace Spaces health endpoint"""
        start_time = time.time()

        result = self._make_request(f"{self.hf_spaces_url}/health")
        duration = time.time() - start_time

        if result["success"] and result["status_code"] == 200:
            data = result["data"]
            version = data.get("version", "unknown")
            status = data.get("status", "unknown")

            passed = status == "healthy"
            details = f"Version: {version}, Status: {status}"
            self._log_test("HF Spaces Health Check", passed, details, duration)
            return passed
        else:
            self._log_test("HF Spaces Health Check", False, result["error"], duration)
            return False

    def test_hf_spaces_sentiment_api(self) -> bool:
        """Test sentiment analysis API"""
        start_time = time.time()

        test_texts = self.config["test_data"]["sentiment_texts"]
        all_passed = True

        for i, text in enumerate(test_texts):
            result = self._make_request(
                f"{self.hf_spaces_url}/api/v3/sentiment",
                "POST",
                {"text": text, "user_id": f"test_user_{i}"}
            )

            if result["success"] and result["status_code"] == 200:
                data = result["data"]
                if data.get("success") and "sentiment" in data.get("data", {}):
                    sentiment = data["data"]["sentiment"]
                    confidence = data["data"]["confidence"]
                    revenue = data.get("revenue_generated", 0)

                    details = f"Text: '{text[:30]}...' → {sentiment} ({confidence:.2f}) +${revenue:.3f}"
                else:
                    all_passed = False
                    details = f"Invalid response format for text {i+1}"
            else:
                all_passed = False
                details = f"API error for text {i+1}: {result['error']}"

        duration = time.time() - start_time
        self._log_test("HF Spaces Sentiment API", all_passed, details, duration)
        return all_passed

    def test_hf_spaces_generation_api(self) -> bool:
        """Test text generation API"""
        start_time = time.time()

        test_prompts = self.config["test_data"]["generation_prompts"]
        all_passed = True

        for i, prompt in enumerate(test_prompts):
            result = self._make_request(
                f"{self.hf_spaces_url}/api/v3/generate",
                "POST",
                {"prompt": prompt, "user_id": f"test_user_{i}"}
            )

            if result["success"] and result["status_code"] == 200:
                data = result["data"]
                if data.get("success") and "generated_text" in data.get("data", {}):
                    generated = data["data"]["generated_text"]
                    revenue = data.get("revenue_generated", 0)

                    details = f"Prompt: '{prompt[:20]}...' → Generated {len(generated)} chars, +${revenue:.3f}"
                else:
                    all_passed = False
                    details = f"Invalid response format for prompt {i+1}"
            else:
                all_passed = False
                details = f"API error for prompt {i+1}: {result['error']}"

        duration = time.time() - start_time
        self._log_test("HF Spaces Generation API", all_passed, details, duration)
        return all_passed

    def test_hf_spaces_batch_api(self) -> bool:
        """Test batch processing API"""
        start_time = time.time()

        batch_requests = [
            {"id": "1", "type": "sentiment", "input": "Great day for testing!"},
            {"id": "2", "type": "emotion", "input": "I am excited about OASIS v3!"},
            {"id": "3", "type": "sentiment", "input": "This is a neutral statement."}
        ]

        result = self._make_request(
            f"{self.hf_spaces_url}/api/v3/batch",
            "POST",
            {"requests": batch_requests, "user_id": "test_batch_user"}
        )

        duration = time.time() - start_time

        if result["success"] and result["status_code"] == 200:
            data = result["data"]
            if data.get("batch_results") and len(data["batch_results"]) == len(batch_requests):
                processed_count = len(data["batch_results"])
                total_revenue = sum(
                    r.get("result", {}).get("revenue_generated", 0) 
                    for r in data["batch_results"]
                )

                details = f"Processed {processed_count} requests, Total revenue: ${total_revenue:.3f}"
                self._log_test("HF Spaces Batch API", True, details, duration)
                return True
            else:
                self._log_test("HF Spaces Batch API", False, "Invalid batch response", duration)
                return False
        else:
            self._log_test("HF Spaces Batch API", False, result["error"], duration)
            return False

    def test_hf_spaces_analytics(self) -> bool:
        """Test analytics endpoint"""
        start_time = time.time()

        result = self._make_request(f"{self.hf_spaces_url}/analytics")
        duration = time.time() - start_time

        if result["success"] and result["status_code"] == 200:
            data = result["data"]
            required_fields = ["version", "total_requests", "success_rate", "revenue_today", "monthly_projection"]

            if all(field in data for field in required_fields):
                revenue_today = data["revenue_today"]
                monthly_proj = data["monthly_projection"]
                success_rate = data["success_rate"]

                details = f"Revenue today: ${revenue_today:.2f}, Monthly: ${monthly_proj:.2f}, Success: {success_rate:.1f}%"
                self._log_test("HF Spaces Analytics", True, details, duration)
                return True
            else:
                self._log_test("HF Spaces Analytics", False, "Missing required fields", duration)
                return False
        else:
            self._log_test("HF Spaces Analytics", False, result["error"], duration)
            return False

    def test_termux_orchestrator_simulation(self) -> bool:
        """Simulate Termux orchestrator functionality"""
        start_time = time.time()

        # Simulate orchestrator configuration
        config_simulation = {
            "hf_spaces_url": self.hf_spaces_url,
            "api_timeout": 30,
            "retry_attempts": 3
        }

        # Test configuration validity
        required_config = ["hf_spaces_url", "api_timeout", "retry_attempts"]
        config_valid = all(key in config_simulation for key in required_config)

        # Simulate session creation
        import hashlib
        session_id = hashlib.md5(str(time.time()).encode()).hexdigest()[:16]

        # Test basic API connectivity (simulate orchestrator request)
        health_check = self._make_request(f"{self.hf_spaces_url}/health")
        api_connected = health_check["success"]

        duration = time.time() - start_time

        passed = config_valid and api_connected
        details = f"Session: {session_id}, Config: {'✓' if config_valid else '✗'}, API: {'✓' if api_connected else '✗'}"

        self._log_test("Termux Orchestrator Simulation", passed, details, duration)
        return passed

    def test_performance_benchmarks(self) -> bool:
        """Test performance benchmarks"""
        start_time = time.time()

        # Test response time requirements
        sentiment_start = time.time()
        sentiment_result = self._make_request(
            f"{self.hf_spaces_url}/api/v3/sentiment",
            "POST",
            {"text": "Performance test message", "user_id": "perf_test"}
        )
        sentiment_time = time.time() - sentiment_start

        # Check if response time meets mobile requirements (<500ms target)
        target_response_time = 0.5  # 500ms
        performance_acceptable = sentiment_time < target_response_time

        # Test concurrent request handling (simulate)
        concurrent_tests = []
        for i in range(3):  # Simulate 3 concurrent requests
            test_start = time.time()
            result = self._make_request(
                f"{self.hf_spaces_url}/api/v3/sentiment",
                "POST",
                {"text": f"Concurrent test {i+1}", "user_id": f"concurrent_{i}"}
            )
            test_time = time.time() - test_start
            concurrent_tests.append({
                "success": result["success"],
                "time": test_time
            })

        avg_concurrent_time = sum(t["time"] for t in concurrent_tests) / len(concurrent_tests)
        concurrent_success_rate = sum(1 for t in concurrent_tests if t["success"]) / len(concurrent_tests)

        duration = time.time() - start_time

        passed = (
            performance_acceptable and 
            concurrent_success_rate >= 0.8 and  # 80% success rate minimum
            avg_concurrent_time < 1.0  # 1 second max for concurrent
        )

        details = f"Single: {sentiment_time:.3f}s, Concurrent avg: {avg_concurrent_time:.3f}s, Success: {concurrent_success_rate:.1%}"
        self._log_test("Performance Benchmarks", passed, details, duration)
        return passed

    def test_revenue_tracking_accuracy(self) -> bool:
        """Test revenue tracking accuracy"""
        start_time = time.time()

        # Get initial analytics
        initial_analytics = self._make_request(f"{self.hf_spaces_url}/analytics")

        if not initial_analytics["success"]:
            self._log_test("Revenue Tracking Accuracy", False, "Cannot fetch initial analytics", 0)
            return False

        initial_revenue = initial_analytics["data"].get("revenue_today", 0)

        # Make a tracked request
        tracked_request = self._make_request(
            f"{self.hf_spaces_url}/api/v3/sentiment",
            "POST",
            {"text": "Revenue tracking test", "user_id": "revenue_test"}
        )

        if not tracked_request["success"]:
            self._log_test("Revenue Tracking Accuracy", False, "Tracked request failed", 0)
            return False

        expected_revenue = tracked_request["data"].get("revenue_generated", 0)

        # Wait a moment for analytics to update
        time.sleep(1)

        # Get updated analytics
        updated_analytics = self._make_request(f"{self.hf_spaces_url}/analytics")

        if not updated_analytics["success"]:
            self._log_test("Revenue Tracking Accuracy", False, "Cannot fetch updated analytics", 0)
            return False

        updated_revenue = updated_analytics["data"].get("revenue_today", 0)
        revenue_increase = updated_revenue - initial_revenue

        duration = time.time() - start_time

        # Check if revenue tracking is accurate (within small tolerance)
        tolerance = 0.001  # $0.001 tolerance
        tracking_accurate = abs(revenue_increase - expected_revenue) <= tolerance

        details = f"Expected: ${expected_revenue:.3f}, Actual: ${revenue_increase:.3f}, Accurate: {'✓' if tracking_accurate else '✗'}"
        self._log_test("Revenue Tracking Accuracy", tracking_accurate, details, duration)
        return tracking_accurate

    def run_full_test_suite(self) -> Dict[str, Any]:
        """Run complete integration test suite"""
        print("🚀 Starting OASIS v3 Full Integration Test Suite")
        print("=" * 60)

        test_methods = [
            self.test_hf_spaces_health,
            self.test_hf_spaces_sentiment_api,
            self.test_hf_spaces_generation_api,
            self.test_hf_spaces_batch_api,
            self.test_hf_spaces_analytics,
            self.test_termux_orchestrator_simulation,
            self.test_performance_benchmarks,
            self.test_revenue_tracking_accuracy
        ]

        overall_start = time.time()

        for test_method in test_methods:
            try:
                test_method()
            except Exception as e:
                test_name = test_method.__name__.replace("test_", "").replace("_", " ").title()
                self._log_test(test_name, False, f"Exception: {str(e)}", 0)

        total_duration = time.time() - overall_start

        # Generate test report
        print("
" + "=" * 60)
        print("🏁 OASIS v3 Integration Test Results")
        print("=" * 60)

        total_tests = self.passed_tests + self.failed_tests
        success_rate = (self.passed_tests / total_tests * 100) if total_tests > 0 else 0

        print(f"📊 Test Summary:")
        print(f"   Total Tests: {total_tests}")
        print(f"   Passed: {self.passed_tests}")
        print(f"   Failed: {self.failed_tests}")
        print(f"   Success Rate: {success_rate:.1f}%")
        print(f"   Total Duration: {total_duration:.3f}s")

        # Determine overall status
        if success_rate >= 90:
            status = "🎉 EXCELLENT"
            status_color = "green"
        elif success_rate >= 80:
            status = "✅ GOOD"
            status_color = "yellow"
        elif success_rate >= 60:
            status = "⚠️  ACCEPTABLE"
            status_color = "orange"
        else:
            status = "❌ NEEDS ATTENTION"
            status_color = "red"

        print(f"
🎯 Overall Status: {status}")

        # Production readiness assessment
        production_ready = (
            success_rate >= 80 and
            self.passed_tests >= 6 and  # Minimum critical tests
            self.failed_tests <= 2  # Maximum acceptable failures
        )

        print(f"🚀 Production Ready: {'YES ✅' if production_ready else 'NO ❌'}")

        if production_ready:
            print("
💰 Revenue Generation Status: READY")
            print("📱 Termux Integration: OPERATIONAL") 
            print("🤗 HuggingFace Spaces: HEALTHY")
            print("📊 Analytics Tracking: FUNCTIONAL")
        else:
            print("
⚠️  Issues detected that may impact production deployment")
            print("   Please review failed tests before proceeding")

        return {
            "total_tests": total_tests,
            "passed_tests": self.passed_tests,
            "failed_tests": self.failed_tests,
            "success_rate": success_rate,
            "duration": total_duration,
            "production_ready": production_ready,
            "status": status,
            "test_results": self.test_results,
            "timestamp": datetime.now().isoformat()
        }

def main():
    """Main test execution"""
    tester = OASISIntegrationTester()
    results = tester.run_full_test_suite()

    # Save test results
    with open("integration_test_results.json", "w") as f:
        json.dump(results, f, indent=2)

    print(f"
📄 Detailed results saved to: integration_test_results.json")

    # Exit with appropriate code
    exit_code = 0 if results["production_ready"] else 1
    return exit_code

if __name__ == "__main__":
    exit(main())
