#!/usr/bin/env python3
"""
OASIS 2.0 - Simple Demo
Non-interactive demo of all features
"""

import os
import requests
from pathlib import Path

class OASISDemo:
    def __init__(self):
        self.token = self._get_token()
        if not self.token:
            print("❌ No HF_TOKEN found!")
            print("Please run: python set_token.py YOUR_TOKEN")
            exit(1)
        
        self.api_base = "https://api-inference.huggingface.co/models"
        print(f"✅ OASIS Demo initialized with token: {self.token[:10]}...")
    
    def _get_token(self):
        """Get HF token from config"""
        config_file = Path("config/.env")
        if config_file.exists():
            with open(config_file, 'r') as f:
                for line in f:
                    if line.startswith("HF_TOKEN="):
                        token = line.split("=", 1)[1].strip()
                        if token and token != "your_hugging_face_token_here":
                            return token
        return None
    
    def call_api(self, model, prompt):
        """Make API call"""
        url = f"{self.api_base}/{model}"
        headers = {"Authorization": f"Bearer {self.token}"}
        payload = {"inputs": prompt}
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}
    
    def demo_text_generation(self):
        """Demo text generation"""
        print("\n🤖 TEXT GENERATION DEMO")
        print("-" * 30)
        prompt = "The future of AI is"
        print(f"📝 Prompt: {prompt}")
        
        result = self.call_api("microsoft/DialoGPT-medium", prompt)
        if "error" not in result:
            try:
                generated = result[0]["generated_text"]
                print(f"✨ Generated: {generated}")
            except:
                print(f"📄 Raw result: {result}")
        else:
            print(f"❌ Error: {result['error']}")
    
    def demo_text_classification(self):
        """Demo text classification"""
        print("\n📊 TEXT CLASSIFICATION DEMO")
        print("-" * 35)
        text = "This product is amazing!"
        print(f"📝 Text: {text}")
        
        result = self.call_api("cardiffnlp/twitter-roberta-base-sentiment-latest", text)
        if "error" not in result:
            print(f"📊 Classification: {result}")
        else:
            print(f"❌ Error: {result['error']}")
    
    def demo_summarization(self):
        """Demo text summarization"""
        print("\n📋 TEXT SUMMARIZATION DEMO")
        print("-" * 32)
        text = "The tower is 324 metres (1,063 ft) tall, about the same height as an 81-storey building, and the tallest structure in Paris. Its base is square, measuring 125 metres (410 ft) on each side."
        print(f"📝 Text: {text}")
        
        result = self.call_api("facebook/bart-large-cnn", text)
        if "error" not in result:
            try:
                summary = result[0]["summary_text"]
                print(f"📋 Summary: {summary}")
            except:
                print(f"📄 Raw result: {result}")
        else:
            print(f"❌ Error: {result['error']}")
    
    def run_all_demos(self):
        """Run all demos"""
        print("🌟 OASIS 2.0 - COMPREHENSIVE DEMO")
        print("=" * 40)
        print("🚀 Pure API-First Architecture")
        print("💡 Zero Heavy Dependencies")
        print("📱 Ultra-Lightweight (<5MB)")
        
        self.demo_text_generation()
        self.demo_text_classification()  
        self.demo_summarization()
        
        print("\n✅ Demo complete!")
        print("🎉 OASIS 2.0 is working perfectly!")

def main():
    demo = OASISDemo()
    demo.run_all_demos()

if __name__ == "__main__":
    main()
