#!/usr/bin/env python3
"""
OASIS 2.0 - Termux Test Script
Comprehensive testing for Termux environment
"""

import os
import requests
import sys
from pathlib import Path

def test_banner():
    """Show test banner"""
    print("=" * 60)
    print("🧪 OASIS 2.0 - TERMUX COMPATIBILITY TEST 🧪")
    print("=" * 60)
    print("Testing all system components for Termux compatibility...")
    print()

def test_dependencies():
    """Test if all required dependencies are available"""
    print("🔍 TESTING DEPENDENCIES")
    print("-" * 30)
    
    dependencies = ['os', 'json', 'time', 'pathlib', 'datetime', 'requests']
    failed = []
    
    for dep in dependencies:
        try:
            if dep == 'requests':
                import requests
            elif dep == 'pathlib':
                from pathlib import Path
            elif dep == 'datetime':
                from datetime import datetime
            elif dep == 'json':
                import json
            elif dep == 'time':
                import time
            elif dep == 'os':
                import os
            print(f"✅ {dep}: OK")
        except ImportError:
            print(f"❌ {dep}: MISSING")
            failed.append(dep)
    
    if failed:
        print(f"\n❌ Missing dependencies: {', '.join(failed)}")
        print("Install with: pip install " + " ".join(failed))
        return False
    
    print("\n✅ All dependencies available!")
    return True

def test_file_structure():
    """Test file and directory structure"""
    print("\n📁 TESTING FILE STRUCTURE")
    print("-" * 30)
    
    base_dir = Path(__file__).parent
    required_items = [
        ("config/", "directory"),
        ("scripts/", "directory"),
        ("data/", "directory"),
        ("logs/", "directory"),
        ("business/", "directory"),
        ("termux_launcher.py", "file"),
        ("set_token.py", "file")
    ]
    
    missing = []
    for item, item_type in required_items:
        path = base_dir / item
        if item_type == "directory":
            if path.exists() and path.is_dir():
                print(f"✅ {item}: OK")
            else:
                print(f"❌ {item}: MISSING")
                missing.append(item)
        else:  # file
            if path.exists() and path.is_file():
                print(f"✅ {item}: OK")
            else:
                print(f"❌ {item}: MISSING")
                missing.append(item)
    
    if missing:
        print(f"\n⚠️ Missing items: {', '.join(missing)}")
        # Create missing directories
        for item in missing:
            if item.endswith("/"):
                (base_dir / item).mkdir(exist_ok=True)
                print(f"✅ Created {item}")
    
    return len(missing) == 0

def test_token_configuration():
    """Test token configuration"""
    print("\n🔑 TESTING TOKEN CONFIGURATION")
    print("-" * 35)
    
    # Test environment variable
    env_token = os.getenv("HF_TOKEN", "").strip()
    if env_token and env_token != "your_hugging_face_token_here":
        print(f"✅ Environment HF_TOKEN found: {env_token[:10]}...")
        return env_token
    else:
        print("⚠️ No environment HF_TOKEN found")
    
    # Test config file
    config_file = Path(__file__).parent / "config" / ".env"
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                for line in f:
                    if line.startswith("HF_TOKEN="):
                        token = line.split("=", 1)[1].strip()
                        if token != "your_hugging_face_token_here":
                            print(f"✅ Config file HF_TOKEN found: {token[:10]}...")
                            return token
            print("⚠️ Config file exists but no valid HF_TOKEN found")
        except Exception as e:
            print(f"❌ Error reading config file: {e}")
    else:
        print("⚠️ Config file not found")
    
    print("❌ No valid HF_TOKEN configured!")
    print("Please run: python set_token.py YOUR_TOKEN")
    return None

def test_api_connection(token):
    """Test API connection"""
    if not token:
        print("\n❌ Cannot test API without token")
        return False
    
    print("\n🌐 TESTING API CONNECTION")
    print("-" * 28)
    
    try:
        url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"inputs": "Hello"}
        
        print("📡 Making test API call...")
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ API connection successful!")
            print(f"📄 Response: {result}")
            return True
        else:
            print(f"⚠️ API returned status {response.status_code}")
            print(f"Response: {response.text}")
            return False
    
    except requests.exceptions.RequestException as e:
        print(f"❌ API connection failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def test_termux_launcher():
    """Test termux launcher import"""
    print("\n🚀 TESTING TERMUX LAUNCHER")
    print("-" * 30)
    
    try:
        # Test if we can import the termux launcher
        sys.path.insert(0, str(Path(__file__).parent))
        
        # Try to import the launcher
        print("📥 Testing termux_launcher import...")
        import termux_launcher
        print("✅ termux_launcher imported successfully!")
        
        # Test instantiation without token (should not crash)
        print("🔧 Testing TermuxOASIS instantiation...")
        
        # Temporarily remove token to test fallback
        old_token = os.environ.get("HF_TOKEN")
        if old_token:
            del os.environ["HF_TOKEN"]
        
        try:
            oasis = termux_launcher.TermuxOASIS()
            print("✅ TermuxOASIS created successfully!")
            has_token = oasis.hf_token is not None
            print(f"🔑 Token detected: {'Yes' if has_token else 'No'}")
        except Exception as e:
            print(f"❌ Failed to create TermuxOASIS: {e}")
            return False
        finally:
            # Restore token
            if old_token:
                os.environ["HF_TOKEN"] = old_token
        
        return True
    
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def run_comprehensive_test():
    """Run all tests"""
    test_banner()
    
    # Test results
    results = {}
    
    # Test 1: Dependencies
    results['dependencies'] = test_dependencies()
    
    # Test 2: File structure
    results['file_structure'] = test_file_structure()
    
    # Test 3: Token configuration
    token = test_token_configuration()
    results['token'] = token is not None
    
    # Test 4: API connection (only if token exists)
    if token:
        results['api'] = test_api_connection(token)
    else:
        results['api'] = False
    
    # Test 5: Termux launcher
    results['launcher'] = test_termux_launcher()
    
    # Final results
    print("\n" + "="*60)
    print("📊 FINAL TEST RESULTS")
    print("="*60)
    
    total_tests = len(results)
    passed_tests = sum(results.values())
    
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{test_name.upper():.<30} {status}")
    
    print(f"\nTests passed: {passed_tests}/{total_tests}")
    success_rate = (passed_tests / total_tests) * 100
    print(f"Success rate: {success_rate:.1f}%")
    
    if passed_tests == total_tests:
        print("\n🎉 ALL TESTS PASSED! OASIS 2.0 is ready for Termux!")
        print("▶️ Run: python termux_launcher.py")
    else:
        print(f"\n⚠️ {total_tests - passed_tests} test(s) failed. Please fix issues before using.")
        
        if not results['token']:
            print("💡 Next step: Set up your HF token")
            print("   python set_token.py YOUR_TOKEN_HERE")
    
    print("="*60)

if __name__ == "__main__":
    run_comprehensive_test()
