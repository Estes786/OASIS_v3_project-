#!/usr/bin/env python3
"""
OASIS 2.0 - Test API
Quick API test without interactive input
"""

import os
import requests
from pathlib import Path

def get_token():
    """Get HF token from config"""
    config_file = Path("config/.env")
    if config_file.exists():
        with open(config_file, 'r') as f:
            for line in f:
                if line.startswith("HF_TOKEN="):
                    token = line.split("=", 1)[1].strip()
                    if token and token != "your_hugging_face_token_here":
                        return token
    return None

def test_text_generation():
    """Test text generation API"""
    token = get_token()
    if not token:
        print("❌ No HF_TOKEN found! Run: python set_token.py YOUR_TOKEN")
        return
    
    print(f"🔑 Using token: {token[:10]}...")
    print("🤖 Testing text generation...")
    
    try:
        url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"inputs": "Hello, how are you?"}
        
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        
        print(f"📡 API Response Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ API call successful!")
            print(f"📝 Generated text: {result}")
        else:
            print(f"❌ API call failed: {response.status_code}")
            print(f"Response: {response.text}")
    
    except Exception as e:
        print(f"❌ Test failed: {e}")

def main():
    """Main test function"""
    print("🧪 OASIS 2.0 - API Test")
    print("=" * 25)
    test_text_generation()

if __name__ == "__main__":
    main()
