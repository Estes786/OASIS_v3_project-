from flask import Blueprint, request, jsonify
import os
import requests
import subprocess
import json
from datetime import datetime

oasis_bp = Blueprint('oasis', __name__)

# Hugging Face API configuration
HF_API_URL = "https://api-inference.huggingface.co/models/"
HF_API_KEY = os.getenv("HUGGING_FACE_API_KEY", "")
HF_HEADERS = {"Authorization": f"Bearer {HF_API_KEY}"}

def query_hf_model(payload, model_id):
    """Query Hugging Face model API"""
    try:
        response = requests.post(HF_API_URL + model_id, headers=HF_HEADERS, json=payload, timeout=30)
        return response.json()
    except Exception as e:
        return {"error": str(e)}

@oasis_bp.route('/status', methods=['GET'])
def get_status():
    """Get system status"""
    return jsonify({
        "status": "Online",
        "termux": "Ready",
        "huggingface": "Connected" if HF_API_KEY else "No API Key",
        "timestamp": datetime.now().isoformat()
    })

@oasis_bp.route('/generate-text', methods=['POST'])
def generate_text():
    """Generate text using Hugging Face models"""
    try:
        data = request.get_json()
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({"error": "Prompt is required"}), 400
        
        # Use GPT-2 for text generation
        payload = {"inputs": prompt, "parameters": {"max_length": 200, "temperature": 0.7}}
        result = query_hf_model(payload, "gpt2")
        
        if "error" in result:
            return jsonify({"error": "Failed to generate text", "details": result["error"]}), 500
        
        # Extract generated text
        if isinstance(result, list) and len(result) > 0 and "generated_text" in result[0]:
            generated_text = result[0]["generated_text"]
        else:
            generated_text = str(result)
        
        return jsonify({
            "success": True,
            "prompt": prompt,
            "generated_text": generated_text,
            "model": "gpt2"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@oasis_bp.route('/analyze-sentiment', methods=['POST'])
def analyze_sentiment():
    """Analyze sentiment using Hugging Face models"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text:
            return jsonify({"error": "Text is required"}), 400
        
        # Use DistilBERT for sentiment analysis
        payload = {"inputs": text}
        result = query_hf_model(payload, "distilbert-base-uncased-finetuned-sst-2-english")
        
        if "error" in result:
            return jsonify({"error": "Failed to analyze sentiment", "details": result["error"]}), 500
        
        return jsonify({
            "success": True,
            "text": text,
            "sentiment": result,
            "model": "distilbert-base-uncased-finetuned-sst-2-english"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@oasis_bp.route('/generate-content', methods=['POST'])
def generate_content():
    """Generate content based on topic and type"""
    try:
        data = request.get_json()
        topic = data.get('topic', '')
        content_type = data.get('type', 'blog')
        
        if not topic:
            return jsonify({"error": "Topic is required"}), 400
        
        # Create appropriate prompt based on content type
        prompts = {
            'blog': f"Write a comprehensive blog post about {topic}. Include an introduction, main points, and conclusion:",
            'social': f"Write a engaging social media post about {topic}:",
            'email': f"Write a professional email campaign about {topic}:"
        }
        
        prompt = prompts.get(content_type, prompts['blog'])
        
        # Generate content using GPT-2
        payload = {"inputs": prompt, "parameters": {"max_length": 300, "temperature": 0.8}}
        result = query_hf_model(payload, "gpt2")
        
        if "error" in result:
            return jsonify({"error": "Failed to generate content", "details": result["error"]}), 500
        
        # Extract generated text
        if isinstance(result, list) and len(result) > 0 and "generated_text" in result[0]:
            generated_content = result[0]["generated_text"]
        else:
            generated_content = str(result)
        
        return jsonify({
            "success": True,
            "topic": topic,
            "type": content_type,
            "content": generated_content,
            "model": "gpt2"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@oasis_bp.route('/analyze-image', methods=['POST'])
def analyze_image():
    """Analyze uploaded image"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({"error": "No image file selected"}), 400
        
        # Read image data
        image_data = file.read()
        
        # Use image-to-text model
        headers = {"Authorization": f"Bearer {HF_API_KEY}"}
        response = requests.post(
            HF_API_URL + "nlpconnect/vit-gpt2-image-captioning",
            headers=headers,
            data=image_data,
            timeout=30
        )
        
        result = response.json()
        
        if "error" in result:
            return jsonify({"error": "Failed to analyze image", "details": result["error"]}), 500
        
        return jsonify({
            "success": True,
            "filename": file.filename,
            "analysis": result,
            "model": "vit-gpt2-image-captioning"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@oasis_bp.route('/termux-command', methods=['POST'])
def execute_termux_command():
    """Execute Termux command (simulated)"""
    try:
        data = request.get_json()
        command = data.get('command', '')
        
        if not command:
            return jsonify({"error": "Command is required"}), 400
        
        # For security, we'll simulate command execution
        # In a real Termux environment, you would use subprocess carefully
        simulated_commands = {
            'pwd': '/data/data/com.termux/files/home',
            'ls': 'oasis_controller.py\nrequirements.txt\nconfig.json',
            'whoami': 'termux',
            'uname -a': 'Linux localhost 4.14.0+ #1 SMP PREEMPT aarch64 Android',
            'python --version': 'Python 3.11.0',
            'pip list': 'requests==2.31.0\nhuggingface-hub==0.16.4\nflask==2.3.3'
        }
        
        output = simulated_commands.get(command, f"Command '{command}' executed successfully (simulated)")
        
        return jsonify({
            "success": True,
            "command": command,
            "output": output,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@oasis_bp.route('/revenue-stats', methods=['GET'])
def get_revenue_stats():
    """Get revenue statistics"""
    try:
        # Simulated revenue data for MVP demonstration
        stats = {
            "total_revenue": 2500.00,
            "monthly_revenue": 850.00,
            "active_clients": 12,
            "services_used": {
                "text_generation": 145,
                "sentiment_analysis": 89,
                "content_generation": 67,
                "image_analysis": 23
            },
            "revenue_breakdown": {
                "content_generation": 1200.00,
                "sentiment_analysis": 800.00,
                "consulting": 500.00
            },
            "growth_rate": "15%",
            "last_updated": datetime.now().isoformat()
        }
        
        return jsonify({
            "success": True,
            "stats": stats
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

