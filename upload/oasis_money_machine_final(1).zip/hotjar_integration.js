// OASIS v3 Money Making Machine - Hotjar Integration
// User Analytics & Behavior Tracking for Solo Founder

// Hotjar Configuration for OASIS
const HOTJAR_CONFIG = {
  site_id: process.env.NEXT_PUBLIC_HOTJAR_SITE_ID || 'your-hotjar-site-id',
  version: 6,
  tracking_code: `
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:${process.env.NEXT_PUBLIC_HOTJAR_SITE_ID},hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
  `
};

// Hotjar Integration Class for OASIS Money Machine
export class OASISHotjarIntegration {
  constructor() {
    this.isInitialized = false;
    this.userId = null;
    this.userAttributes = {};
  }

  // Initialize Hotjar tracking
  init() {
    if (typeof window === 'undefined' || this.isInitialized) {
      return;
    }

    try {
      // Inject Hotjar tracking code
      const script = document.createElement('script');
      script.innerHTML = HOTJAR_CONFIG.tracking_code;
      document.head.appendChild(script);

      this.isInitialized = true;
      console.log('Hotjar initialized for OASIS v3 Money Machine');

      // Track initialization event
      this.trackEvent('oasis_hotjar_initialized', {
        timestamp: new Date().toISOString(),
        version: '3.0.0-money-machine'
      });

    } catch (error) {
      console.error('Error initializing Hotjar:', error);
    }
  }

  // Identify user for personalized tracking
  identify(userId, attributes = {}) {
    if (typeof window === 'undefined' || !window.hj) {
      return;
    }

    try {
      this.userId = userId;
      this.userAttributes = {
        ...attributes,
        identified_at: new Date().toISOString(),
        platform: 'oasis_v3'
      };

      // Hotjar identify call
      window.hj('identify', userId, this.userAttributes);

      console.log('User identified in Hotjar:', userId);
    } catch (error) {
      console.error('Error identifying user in Hotjar:', error);
    }
  }

  // Track custom events
  trackEvent(eventName, properties = {}) {
    if (typeof window === 'undefined' || !window.hj) {
      return;
    }

    try {
      const eventData = {
        ...properties,
        user_id: this.userId,
        timestamp: new Date().toISOString(),
        source: 'oasis_v3_money_machine'
      };

      // Hotjar event tracking
      window.hj('event', eventName);

      // Also track in console for debugging
      console.log('Hotjar Event:', eventName, eventData);

      // Store event for later analysis
      this.storeEventLocally(eventName, eventData);

    } catch (error) {
      console.error('Error tracking event in Hotjar:', error);
    }
  }

  // Track revenue-related events
  trackRevenue(eventType, amount, metadata = {}) {
    const revenueEvent = {
      event_type: eventType,
      amount: amount,
      currency: 'usd',
      ...metadata
    };

    this.trackEvent('oasis_revenue_event', revenueEvent);
  }

  // Track API usage
  trackAPIUsage(endpoint, responseTime, success = true) {
    const apiEvent = {
      endpoint: endpoint,
      response_time_ms: responseTime,
      success: success,
      user_tier: this.userAttributes.subscription_tier || 'free'
    };

    this.trackEvent('oasis_api_usage', apiEvent);
  }

  // Track user journey through money-making funnel
  trackFunnelStep(step, metadata = {}) {
    const funnelSteps = [
      'landing_page_view',
      'signup_started',
      'signup_completed',
      'first_api_call',
      'upgrade_prompt_shown',
      'upgrade_started',
      'upgrade_completed',
      'enterprise_inquiry'
    ];

    if (funnelSteps.includes(step)) {
      this.trackEvent('oasis_funnel_step', {
        step: step,
        step_index: funnelSteps.indexOf(step),
        ...metadata
      });
    }
  }

  // Track subscription events
  trackSubscription(action, tier, metadata = {}) {
    const subscriptionEvent = {
      action: action, // 'started', 'completed', 'canceled', 'upgraded'
      tier: tier, // 'premium', 'enterprise'
      ...metadata
    };

    this.trackEvent('oasis_subscription', subscriptionEvent);
  }

  // Track feature usage
  trackFeatureUsage(feature, metadata = {}) {
    const featureEvent = {
      feature: feature,
      user_tier: this.userAttributes.subscription_tier || 'free',
      ...metadata
    };

    this.trackEvent('oasis_feature_usage', featureEvent);
  }

  // Start recording session (for specific user flows)
  startRecording(tags = []) {
    if (typeof window === 'undefined' || !window.hj) {
      return;
    }

    try {
      window.hj('trigger', 'oasis_session_recording');
      
      // Add tags for easier filtering
      tags.forEach(tag => {
        window.hj('tagRecording', [tag]);
      });

      console.log('Hotjar recording started with tags:', tags);
    } catch (error) {
      console.error('Error starting Hotjar recording:', error);
    }
  }

  // Stop recording session
  stopRecording() {
    if (typeof window === 'undefined' || !window.hj) {
      return;
    }

    try {
      window.hj('trigger', 'stop_recording');
      console.log('Hotjar recording stopped');
    } catch (error) {
      console.error('Error stopping Hotjar recording:', error);
    }
  }

  // Show feedback poll
  showFeedbackPoll(pollId) {
    if (typeof window === 'undefined' || !window.hj) {
      return;
    }

    try {
      window.hj('trigger', pollId);
      this.trackEvent('oasis_feedback_poll_shown', { poll_id: pollId });
    } catch (error) {
      console.error('Error showing feedback poll:', error);
    }
  }

  // Store events locally for backup analysis
  storeEventLocally(eventName, eventData) {
    try {
      const events = JSON.parse(localStorage.getItem('oasis_analytics_events') || '[]');
      events.push({
        event: eventName,
        data: eventData,
        stored_at: new Date().toISOString()
      });

      // Keep only last 100 events to avoid storage bloat
      if (events.length > 100) {
        events.splice(0, events.length - 100);
      }

      localStorage.setItem('oasis_analytics_events', JSON.stringify(events));
    } catch (error) {
      console.error('Error storing event locally:', error);
    }
  }

  // Get locally stored events for analysis
  getStoredEvents() {
    try {
      return JSON.parse(localStorage.getItem('oasis_analytics_events') || '[]');
    } catch (error) {
      console.error('Error retrieving stored events:', error);
      return [];
    }
  }

  // Generate analytics report for solo founder
  generateAnalyticsReport() {
    const events = this.getStoredEvents();
    const report = {
      total_events: events.length,
      revenue_events: events.filter(e => e.event === 'oasis_revenue_event').length,
      api_usage_events: events.filter(e => e.event === 'oasis_api_usage').length,
      funnel_events: events.filter(e => e.event === 'oasis_funnel_step').length,
      subscription_events: events.filter(e => e.event === 'oasis_subscription').length,
      feature_usage_events: events.filter(e => e.event === 'oasis_feature_usage').length,
      date_range: {
        from: events.length > 0 ? events[0].stored_at : null,
        to: events.length > 0 ? events[events.length - 1].stored_at : null
      }
    };

    return report;
  }
}

// React Hook for Hotjar integration
export const useHotjar = () => {
  const hotjar = new OASISHotjarIntegration();

  const initHotjar = () => {
    hotjar.init();
  };

  const identifyUser = (userId, attributes) => {
    hotjar.identify(userId, attributes);
  };

  const trackEvent = (eventName, properties) => {
    hotjar.trackEvent(eventName, properties);
  };

  const trackRevenue = (eventType, amount, metadata) => {
    hotjar.trackRevenue(eventType, amount, metadata);
  };

  const trackFunnelStep = (step, metadata) => {
    hotjar.trackFunnelStep(step, metadata);
  };

  const trackSubscription = (action, tier, metadata) => {
    hotjar.trackSubscription(action, tier, metadata);
  };

  const trackFeatureUsage = (feature, metadata) => {
    hotjar.trackFeatureUsage(feature, metadata);
  };

  return {
    initHotjar,
    identifyUser,
    trackEvent,
    trackRevenue,
    trackFunnelStep,
    trackSubscription,
    trackFeatureUsage,
    hotjar
  };
};

// Hotjar Analytics Dashboard Component
export const HotjarAnalyticsDashboard = () => {
  const hotjar = new OASISHotjarIntegration();
  const report = hotjar.generateAnalyticsReport();

  return {
    report,
    insights: {
      user_engagement: report.feature_usage_events > 0 ? 'Active' : 'Low',
      revenue_tracking: report.revenue_events > 0 ? 'Generating Revenue' : 'No Revenue Yet',
      funnel_performance: report.funnel_events > 10 ? 'Good' : 'Needs Improvement',
      subscription_health: report.subscription_events > 0 ? 'Converting' : 'No Conversions'
    },
    recommendations: [
      report.funnel_events < 5 ? 'Focus on improving user onboarding flow' : null,
      report.revenue_events === 0 ? 'Implement revenue tracking for better insights' : null,
      report.api_usage_events < 10 ? 'Encourage more API usage through better UX' : null
    ].filter(Boolean)
  };
};

// Environment setup helper
export const setupHotjarEnvironment = () => {
  return {
    development: {
      site_id: 'dev-site-id',
      enabled: false // Disable in development
    },
    staging: {
      site_id: 'staging-site-id',
      enabled: true
    },
    production: {
      site_id: process.env.NEXT_PUBLIC_HOTJAR_SITE_ID,
      enabled: true
    }
  };
};

export default OASISHotjarIntegration;
