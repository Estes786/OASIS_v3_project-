// OASIS v3 Money Making Machine - Stripe Integration
// Monetization & Payment Processing for Solo Founder

import Stripe from 'stripe';

// Initialize Stripe with secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// OASIS Pricing Configuration
const OASIS_PRICING = {
  api_call: {
    price: 0.01, // $0.01 per API call
    currency: 'usd'
  },
  premium: {
    price_id: 'price_premium_monthly', // Stripe Price ID
    amount: 999, // $9.99 in cents
    currency: 'usd',
    interval: 'month'
  },
  enterprise: {
    price_id: 'price_enterprise_monthly', // Stripe Price ID
    amount: 9999, // $99.99 in cents
    currency: 'usd',
    interval: 'month'
  },
  data_insights: {
    price: 0.05, // $0.05 per analysis
    currency: 'usd'
  }
};

// Stripe Integration Class for OASIS Money Machine
export class OASISStripeIntegration {
  constructor() {
    this.stripe = stripe;
  }

  // Create customer for new user
  async createCustomer(userData) {
    try {
      const customer = await this.stripe.customers.create({
        email: userData.email,
        name: userData.name,
        metadata: {
          user_id: userData.id,
          source: 'oasis_v3',
          registration_date: new Date().toISOString()
        }
      });

      return {
        success: true,
        customer_id: customer.id,
        customer
      };
    } catch (error) {
      console.error('Error creating Stripe customer:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Create subscription for premium/enterprise plans
  async createSubscription(customerId, priceId, metadata = {}) {
    try {
      const subscription = await this.stripe.subscriptions.create({
        customer: customerId,
        items: [{
          price: priceId,
        }],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          ...metadata,
          created_via: 'oasis_v3_money_machine'
        }
      });

      return {
        success: true,
        subscription_id: subscription.id,
        client_secret: subscription.latest_invoice.payment_intent.client_secret,
        subscription
      };
    } catch (error) {
      console.error('Error creating subscription:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Process pay-per-use charges (API calls, data insights)
  async processPayPerUse(customerId, amount, description, metadata = {}) {
    try {
      const paymentIntent = await this.stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: 'usd',
        customer: customerId,
        description: description,
        metadata: {
          ...metadata,
          service: 'oasis_v3_api',
          processed_at: new Date().toISOString()
        },
        automatic_payment_methods: {
          enabled: true,
        },
      });

      return {
        success: true,
        payment_intent_id: paymentIntent.id,
        client_secret: paymentIntent.client_secret,
        paymentIntent
      };
    } catch (error) {
      console.error('Error processing pay-per-use payment:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Create checkout session for one-time payments
  async createCheckoutSession(customerId, items, successUrl, cancelUrl) {
    try {
      const session = await this.stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        line_items: items,
        mode: 'payment',
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          source: 'oasis_v3_checkout'
        }
      });

      return {
        success: true,
        session_id: session.id,
        checkout_url: session.url,
        session
      };
    } catch (error) {
      console.error('Error creating checkout session:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Handle webhook events from Stripe
  async handleWebhook(rawBody, signature) {
    try {
      const event = this.stripe.webhooks.constructEvent(
        rawBody,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      switch (event.type) {
        case 'payment_intent.succeeded':
          await this.handlePaymentSuccess(event.data.object);
          break;
        
        case 'invoice.payment_succeeded':
          await this.handleSubscriptionPayment(event.data.object);
          break;
        
        case 'customer.subscription.created':
          await this.handleSubscriptionCreated(event.data.object);
          break;
        
        case 'customer.subscription.updated':
          await this.handleSubscriptionUpdated(event.data.object);
          break;
        
        case 'customer.subscription.deleted':
          await this.handleSubscriptionCanceled(event.data.object);
          break;
        
        default:
          console.log(`Unhandled event type: ${event.type}`);
      }

      return { success: true, event };
    } catch (error) {
      console.error('Webhook error:', error);
      return { success: false, error: error.message };
    }
  }

  // Handle successful payment
  async handlePaymentSuccess(paymentIntent) {
    // Update user's account with successful payment
    // This would integrate with your Supabase database
    console.log('Payment succeeded:', paymentIntent.id);
    
    // Example: Update revenue records in Supabase
    // await supabase.from('revenue_records').insert({
    //   user_id: paymentIntent.metadata.user_id,
    //   amount: paymentIntent.amount / 100,
    //   revenue_stream: 'api_calls',
    //   transaction_id: paymentIntent.id,
    //   status: 'completed'
    // });
  }

  // Handle subscription payment
  async handleSubscriptionPayment(invoice) {
    console.log('Subscription payment succeeded:', invoice.id);
    
    // Update user's subscription status
    // Grant access to premium features
  }

  // Handle new subscription
  async handleSubscriptionCreated(subscription) {
    console.log('New subscription created:', subscription.id);
    
    // Update user's tier in database
    // Send welcome email
    // Grant premium access
  }

  // Handle subscription update
  async handleSubscriptionUpdated(subscription) {
    console.log('Subscription updated:', subscription.id);
    
    // Update user's access level based on new subscription
  }

  // Handle subscription cancellation
  async handleSubscriptionCanceled(subscription) {
    console.log('Subscription canceled:', subscription.id);
    
    // Revoke premium access
    // Send cancellation email
  }

  // Get customer's payment methods
  async getPaymentMethods(customerId) {
    try {
      const paymentMethods = await this.stripe.paymentMethods.list({
        customer: customerId,
        type: 'card',
      });

      return {
        success: true,
        payment_methods: paymentMethods.data
      };
    } catch (error) {
      console.error('Error fetching payment methods:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get customer's subscription status
  async getSubscriptionStatus(customerId) {
    try {
      const subscriptions = await this.stripe.subscriptions.list({
        customer: customerId,
        status: 'active',
      });

      return {
        success: true,
        subscriptions: subscriptions.data,
        has_active_subscription: subscriptions.data.length > 0
      };
    } catch (error) {
      console.error('Error fetching subscription status:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Calculate usage-based billing
  async calculateUsageBilling(userId, apiCalls, dataAnalyses) {
    const apiCallsCost = apiCalls * OASIS_PRICING.api_call.price;
    const dataAnalysesCost = dataAnalyses * OASIS_PRICING.data_insights.price;
    const totalCost = apiCallsCost + dataAnalysesCost;

    return {
      api_calls: {
        count: apiCalls,
        unit_price: OASIS_PRICING.api_call.price,
        total: apiCallsCost
      },
      data_analyses: {
        count: dataAnalyses,
        unit_price: OASIS_PRICING.data_insights.price,
        total: dataAnalysesCost
      },
      total_amount: totalCost,
      currency: 'usd'
    };
  }

  // Create usage record for metered billing
  async createUsageRecord(subscriptionItemId, quantity, timestamp = null) {
    try {
      const usageRecord = await this.stripe.subscriptionItems.createUsageRecord(
        subscriptionItemId,
        {
          quantity: quantity,
          timestamp: timestamp || Math.floor(Date.now() / 1000),
          action: 'increment'
        }
      );

      return {
        success: true,
        usage_record: usageRecord
      };
    } catch (error) {
      console.error('Error creating usage record:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

// Frontend integration helpers
export const stripeHelpers = {
  // Format price for display
  formatPrice(amount, currency = 'usd') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase(),
    }).format(amount);
  },

  // Get pricing for display
  getPricing() {
    return {
      api_call: stripeHelpers.formatPrice(OASIS_PRICING.api_call.price),
      premium: stripeHelpers.formatPrice(OASIS_PRICING.premium.amount / 100),
      enterprise: stripeHelpers.formatPrice(OASIS_PRICING.enterprise.amount / 100),
      data_insights: stripeHelpers.formatPrice(OASIS_PRICING.data_insights.price)
    };
  },

  // Calculate monthly revenue projection
  calculateMonthlyProjection(apiCallsPerDay, premiumUsers, enterpriseUsers) {
    const dailyApiRevenue = apiCallsPerDay * OASIS_PRICING.api_call.price;
    const monthlyApiRevenue = dailyApiRevenue * 30;
    const premiumRevenue = premiumUsers * (OASIS_PRICING.premium.amount / 100);
    const enterpriseRevenue = enterpriseUsers * (OASIS_PRICING.enterprise.amount / 100);
    
    return {
      api_calls: monthlyApiRevenue,
      premium_subscriptions: premiumRevenue,
      enterprise_subscriptions: enterpriseRevenue,
      total: monthlyApiRevenue + premiumRevenue + enterpriseRevenue
    };
  }
};

export default OASISStripeIntegration;
