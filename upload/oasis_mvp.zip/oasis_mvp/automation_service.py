from hf_client import sentiment_analysis

def analyze_customer_feedback(feedback_text):
    result = sentiment_analysis(feedback_text)
    if result and isinstance(result, list) and len(result) > 0 and isinstance(result[0], list) and len(result[0]) > 0 and 'label' in result[0][0] and 'score' in result[0][0]:
        # Assuming the model returns a list of lists, where the inner list contains dicts with 'label' and 'score'
        # We'll take the first result's label and score
        sentiment_label = result[0][0]['label']
        sentiment_score = result[0][0]['score']
        return f"Sentiment: {sentiment_label} (Score: {sentiment_score:.2f})"
    return "Error analyzing sentiment."

if __name__ == '__main__':
    feedback1 = "This product is amazing! I love it."
    feedback2 = "I am very disappointed with the service."
    feedback3 = "It's okay, nothing special."

    print(f"Feedback 1: {feedback1}")
    print(analyze_customer_feedback(feedback1))

    print(f"\nFeedback 2: {feedback2}")
    print(analyze_customer_feedback(feedback2))

    print(f"\nFeedback 3: {feedback3}")
    print(analyze_customer_feedback(feedback3))


