import json

CLIENTS_FILE = "clients.json"

def load_clients():
    if not os.path.exists(CLIENTS_FILE):
        return {}
    with open(CLIENTS_FILE, "r") as f:
        return json.load(f)

def save_clients(clients):
    with open(CLIENTS_FILE, "w") as f:
        json.dump(clients, f, indent=4)

def add_client(client_id, name, contact_info):
    clients = load_clients()
    clients[client_id] = {"name": name, "contact_info": contact_info, "projects": []}
    save_clients(clients)
    return f"Client {name} added successfully."

def add_project_to_client(client_id, project_name, project_details):
    clients = load_clients()
    if client_id in clients:
        clients[client_id]["projects"].append({"name": project_name, "details": project_details, "invoices": []})
        save_clients(clients)
        return f"Project {project_name} added to client {clients[client_id]["name"]}."
    return "Client not found."

def generate_invoice(client_id, project_name, amount, due_date):
    clients = load_clients()
    if client_id in clients:
        for project in clients[client_id]["projects"]:
            if project["name"] == project_name:
                invoice = {"amount": amount, "due_date": due_date, "paid": False}
                project["invoices"].append(invoice)
                save_clients(clients)
                return f"Invoice for {project_name} generated for client {clients[client_id]["name"]}. Amount: {amount}, Due: {due_date}"
        return "Project not found for this client."
    return "Client not found."

def get_client_details(client_id):
    clients = load_clients()
    return clients.get(client_id, "Client not found.")

if __name__ == '__main__':
    import os
    # Clean up previous data for demonstration
    if os.path.exists(CLIENTS_FILE):
        os.remove(CLIENTS_FILE)

    print(add_client("client_001", "Acme Corp", "contact@acme.com"))
    print(add_project_to_client("client_001", "Website Content", "Generate blog posts and landing page copy."))
    print(generate_invoice("client_001", "Website Content", 1500, "2025-10-15"))
    print(get_client_details("client_001"))

    print(add_client("client_002", "Beta Solutions", "info@beta.com"))
    print(add_project_to_client("client_002", "Sentiment Analysis Dashboard", "Develop a dashboard for customer feedback."))
    print(generate_invoice("client_002", "Sentiment Analysis Dashboard", 2500, "2025-11-01"))
    print(get_client_details("client_002"))

    print(get_client_details("client_003")) # Non-existent client


