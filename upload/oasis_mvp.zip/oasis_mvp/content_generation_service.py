from hf_client import generate_text

def generate_blog_post(topic, length='medium'):
    prompt = f"Write a {length} blog post about {topic}."
    response = generate_text(prompt, model_id="gpt2") # Using gpt2 as a placeholder
    if response and isinstance(response, list) and 'generated_text' in response[0]:
        return response[0]['generated_text']
    return "Error generating blog post."

def generate_social_media_post(topic, platform='twitter'):
    prompt = f"Write a short {platform} post about {topic}."
    response = generate_text(prompt, model_id="gpt2") # Using gpt2 as a placeholder
    if response and isinstance(response, list) and 'generated_text' in response[0]:
        return response[0]['generated_text']
    return "Error generating social media post."

def generate_email_campaign(product_name, audience, goal):
    prompt = f"Write an email campaign for {product_name} targeting {audience} with the goal of {goal}."
    response = generate_text(prompt, model_id="gpt2") # Using gpt2 as a placeholder
    if response and isinstance(response, list) and 'generated_text' in response[0]:
        return response[0]['generated_text']
    return "Error generating email campaign."

if __name__ == '__main__':
    print("Generating a blog post about AI in healthcare...")
    blog_post = generate_blog_post("AI in healthcare", length="short")
    print(blog_post)

    print("\nGenerating a Twitter post about new product launch...")
    twitter_post = generate_social_media_post("new product launch", platform="twitter")
    print(twitter_post)

    print("\nGenerating an email campaign for a new SaaS product...")
    email_campaign = generate_email_campaign("New SaaS Product", "small businesses", "increase sign-ups")
    print(email_campaign)


