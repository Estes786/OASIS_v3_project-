import os
import requests
from dotenv import load_dotenv

load_dotenv()
HUGGING_FACE_API_KEY = os.getenv("HUGGING_FACE_API_KEY")

API_URL = "https://api-inference.huggingface.co/models/"
HEADERS = {"Authorization": f"Bearer {HUGGING_FACE_API_KEY}"}

def query(payload, model_id):
    response = requests.post(API_URL + model_id, headers=HEADERS, json=payload)
    return response.json()

def generate_text(prompt, model_id="gpt2"):
    payload = {"inputs": prompt}
    return query(payload, model_id)

def sentiment_analysis(text, model_id="distilbert/distilbert-base-uncased-finetuned-sst-2-english"):
    payload = {"inputs": text}
    return query(payload, model_id)

def image_to_text(image_data, model_id="nlpconnect/vit-gpt2-image-captioning"):
    headers = {"Authorization": f"Bearer {HUGGING_FACE_API_KEY}"}
    response = requests.post(API_URL + model_id, headers=headers, data=image_data)
    return response.json()

def text_to_image(prompt, model_id="runwayml/stable-diffusion-v1-5"):
    payload = {"inputs": prompt}
    return query(payload, model_id)


