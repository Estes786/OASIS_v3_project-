import requests
import json
import os

# Replace with your deployed Hugging Face Space URL
# Example: https://your-username-your-space-name.hf.space
OASIS_HF_SPACE_URL = os.getenv("OASIS_HF_SPACE_URL", "https://j6h5i7cg86mz.manus.space") # Default to localhost for testing

API_BASE_URL = f"{OASIS_HF_SPACE_URL}/api"

def call_api(endpoint, method="GET", data=None, files=None):
    url = f"{API_BASE_URL}/{endpoint}"
    headers = {"Content-Type": "application/json"}
    
    try:
        if method == "POST":
            if files:
                response = requests.post(url, files=files)
            else:
                response = requests.post(url, headers=headers, json=data)
        elif method == "GET":
            response = requests.get(url)
        else:
            return {"error": "Unsupported HTTP method"}

        response.raise_for_status() # Raise an exception for HTTP errors
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"API request failed: {e}"}
    except json.JSONDecodeError:
        return {"error": f"Failed to decode JSON response: {response.text}"}

def get_oasis_status():
    return call_api("status")

def generate_text_from_hf(prompt):
    data = {"prompt": prompt}
    return call_api("generate-text", method="POST", data=data)

def analyze_sentiment_from_hf(text):
    data = {"text": text}
    return call_api("analyze-sentiment", method="POST", data=data)

def generate_content_from_hf(topic, content_type):
    data = {"topic": topic, "type": content_type}
    return call_api("generate-content", method="POST", data=data)

def analyze_image_from_hf(image_path):
    if not os.path.exists(image_path):
        return {"error": f"Image file not found: {image_path}"}
    with open(image_path, "rb") as f:
        files = {"image": f.read()}
        return call_api("analyze-image", method="POST", files=files)

def execute_termux_command_on_hf(command):
    data = {"command": command}
    return call_api("termux-command", method="POST", data=data)

def get_revenue_stats_from_hf():
    return call_api("revenue-stats")

if __name__ == "__main__":
    print("--- OASIS Termux Orchestrator ---")
    
    # Example Usage:
    print("\nGetting OASIS status...")
    status = get_oasis_status()
    print(json.dumps(status, indent=2))

    print("\nGenerating text: 'The future of AI is...' ")
    text_gen_result = generate_text_from_hf("The future of AI is...")
    print(json.dumps(text_gen_result, indent=2))

    print("\nAnalyzing sentiment: 'This is a great project!'")
    sentiment_result = analyze_sentiment_from_hf("This is a great project!")
    print(json.dumps(sentiment_result, indent=2))

    print("\nGenerating blog post about 'Quantum Computing'")
    content_gen_result = generate_content_from_hf("Quantum Computing", "blog")
    print(json.dumps(content_gen_result, indent=2))

    # To test image analysis, you would need to provide a local image path
    # print("\nAnalyzing image: /path/to/your/image.jpg")
    # image_analysis_result = analyze_image_from_hf("/path/to/your/image.jpg")
    # print(json.dumps(image_analysis_result, indent=2))

    print("\nExecuting simulated Termux command: 'ls'")
    termux_cmd_result = execute_termux_command_on_hf("ls")
    print(json.dumps(termux_cmd_result, indent=2))

    print("\nGetting revenue statistics...")
    revenue_stats = get_revenue_stats_from_hf()
    print(json.dumps(revenue_stats, indent=2))


