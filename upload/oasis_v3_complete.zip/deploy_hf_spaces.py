#!/usr/bin/env python3
"""
OASIS v3 Hugging Face Spaces Deployment Script
Automates the deployment process to HF Spaces
"""

import os
import json
import shutil
from datetime import datetime

def create_hf_space_files():
    """Create files optimized for HF Spaces deployment"""

    print("🚀 Creating HF Spaces deployment files...")

    # Create deployment directory
    deploy_dir = "hf_spaces_deploy"
    os.makedirs(deploy_dir, exist_ok=True)

    # Copy main app (rename to app.py for HF Spaces)
    shutil.copy2("hf_spaces_app.py", f"{deploy_dir}/app.py")
    print("✅ Copied hf_spaces_app.py → app.py")

    # Copy requirements (rename for HF Spaces)
    shutil.copy2("requirements_hf_spaces.txt", f"{deploy_dir}/requirements.txt")
    print("✅ Copied requirements_hf_spaces.txt → requirements.txt")

    print(f"\n📁 Deployment files created in: {deploy_dir}/")
    print("\n🚀 Next steps:")
    print("1. Create new HF Space at https://huggingface.co/spaces")
    print("2. Upload files from hf_spaces_deploy/ directory")
    print("3. Update Termux config with your HF Space URL")
    print("4. Test the connection and start generating revenue!")

    return deploy_dir

if __name__ == "__main__":
    print("🚀 OASIS v3 Deployment Automation")
    print("=" * 50)

    # Create HF Spaces deployment files
    deploy_dir = create_hf_space_files()

    print("\n✅ Deployment preparation completed!")
    print(f"📁 HF Spaces files: {deploy_dir}/")
    print("\n🚀 Ready to deploy and start generating $10K+/month!")
