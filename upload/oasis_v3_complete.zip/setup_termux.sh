#!/bin/bash
# OASIS v3 Termux Setup Script
# Ultra-lightweight installation for Android/Termux

echo "🚀 OASIS v3 Termux Setup Starting..."
echo "💾 Target footprint: <5MB (urllib only)"

# Update packages
echo "📦 Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Install Python (if not already installed)
echo "🐍 Installing Python..."
pkg install python -y

# Install git for downloading (optional)
pkg install git -y

# Create OASIS directory
echo "📁 Creating OASIS directory..."
mkdir -p ~/oasis_v3
cd ~/oasis_v3

echo "✅ OASIS v3 Termux setup completed!"
echo ""
echo "📋 Next steps:"
echo "1. Copy oasis_orchestrator.py to ~/oasis_v3/"
echo "2. Update oasis_config.json with your HF Spaces URL"
echo "3. Run: python oasis_orchestrator.py"
echo ""
echo "🎯 Revenue Target: $10K+/month"
echo "💎 Ultra-lightweight: <5MB footprint"
