#!/bin/bash
# OASIS v3 - HuggingFace Spaces Deployment

SPACE_NAME="${1:-oasis-v3-ai-platform}"
HF_USERNAME="${2:-your-username}"

echo "🚀 Deploying OASIS v3 to HuggingFace Spaces"
echo "Space: $HF_USERNAME/$SPACE_NAME"

# Install HuggingFace CLI if needed
if ! command -v huggingface-cli &> /dev/null; then
    pip install huggingface_hub[cli]
fi

# Create space
huggingface-cli repo create "$SPACE_NAME" --type space --space_sdk gradio

# Clone and setup
git clone "https://huggingface.co/spaces/$HF_USERNAME/$SPACE_NAME" temp_space
cd temp_space

# Copy files
cp ../huggingface_spaces/* .

# Commit and push
git add .
git commit -m "Deploy OASIS v3 AI Platform"
git push origin main

echo "✅ Deployment complete!"
echo "🔗 Visit: https://huggingface.co/spaces/$HF_USERNAME/$SPACE_NAME"

# Cleanup
cd ..
rm -rf temp_space
