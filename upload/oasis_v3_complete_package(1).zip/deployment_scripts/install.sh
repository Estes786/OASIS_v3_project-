#!/bin/bash
# OASIS v3 - One-Command Installer
# Usage: curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/install.sh | bash

set -e

echo "🚀 OASIS v3 - One-Command Installer"
echo "===================================="

# Check if running on Termux
if [[ "$PREFIX" == *"com.termux"* ]]; then
    echo "📱 Termux environment detected"
    
    # Update packages
    pkg update -y && pkg upgrade -y
    
    # Install essentials
    pkg install -y python git curl wget
    
    # Download and run Termux setup
    curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/termux_setup.sh | bash
    
else
    echo "💻 Standard Linux environment detected"
    
    # Install Python and Git
    if command -v apt &> /dev/null; then
        sudo apt update && sudo apt install -y python3 python3-pip git curl wget
    elif command -v yum &> /dev/null; then
        sudo yum install -y python3 python3-pip git curl wget
    fi
    
    # Download and run standard setup
    curl -sSL https://raw.githubusercontent.com/your-repo/oasis-v3/main/setup.sh | bash
fi

echo "✅ OASIS v3 installation complete!"
echo "🎯 Run 'oasis status' to begin"
