# OASIS v3 API Documentation

## Overview

OASIS v3 provides a RESTful API for AI/ML/DL operations through HuggingFace Spaces.

## Authentication

All requests require an API key:

```bash
curl -H "X-API-Key: your_api_key" https://your-space.hf.space/status
```

## Endpoints

### GET /status
Get system status and health information.

**Response:**
```json
{
    "status": "operational",
    "uptime_seconds": 86400,
    "active_requests": 3,
    "total_requests": 1250
}
```

### POST /run_model
Execute AI/ML/DL models.

**Request:**
```json
{
    "api_key": "your_api_key",
    "model_name": "text_generation",
    "input_data": {
        "prompt": "Write a story about AI",
        "max_length": 100
    }
}
```

**Response:**
```json
{
    "status": "success",
    "output_data": {
        "generated_text": "Once upon a time, in a world where artificial intelligence..."
    },
    "execution_time_ms": 2500
}
```

### POST /upload_data
Upload data files for processing.

### GET /download_results
Download processed results.

## Python SDK

```python
from oasis import OASISOrchestrator

# Initialize
orchestrator = OASISOrchestrator()

# Configure
orchestrator.set_config('hf_space_url', 'https://your-space.hf.space')
orchestrator.set_config('api_key', 'your_api_key')

# Generate text
result = orchestrator.run_ai_model('text_generation', {
    'prompt': 'Hello, world!',
    'max_length': 50
})

# Analyze sentiment
sentiment = orchestrator.run_ai_model('sentiment_analysis', {
    'text': 'I love this product!'
})

# Process image
image_result = orchestrator.run_ai_model('image_processing', {
    'image_url': 'https://example.com/image.jpg',
    'operation': 'analyze'
})
```

## Error Handling

All API responses include error information:

```json
{
    "status": "error",
    "message": "Invalid API key",
    "error_code": "AUTH_INVALID"
}
```

## Rate Limits

- Free tier: 100 requests/hour
- Pro tier: 1000 requests/hour
- Enterprise: Unlimited

## Webhooks

Configure webhooks for real-time notifications:

```json
{
    "webhook_url": "https://your-app.com/webhook",
    "events": ["model_complete", "error"]
}
```
