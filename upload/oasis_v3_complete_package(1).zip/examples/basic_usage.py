#!/usr/bin/env python3
"""
OASIS v3 - Basic Usage Example
"""

from oasis import OASISOrchestrator

def main():
    # Initialize orchestrator
    orchestrator = OASISOrchestrator()
    
    # Configure (replace with your values)
    orchestrator.set_config('hf_space_url', 'https://your-space.hf.space')
    orchestrator.set_config('api_key', 'your_api_key')
    
    # Check status
    print("🔍 Checking system status...")
    status = orchestrator.get_status()
    if status:
        print(f"✅ System is {status.get('status', 'unknown')}")
    
    # Generate text
    print("📝 Generating text...")
    result = orchestrator.run_ai_model('text_generation', {
        'prompt': 'The future of AI is',
        'max_length': 100
    })
    
    if result:
        print(f"Generated: {result.get('generated_text', 'No output')}")
    
    # Analyze sentiment
    print("😊 Analyzing sentiment...")
    sentiment = orchestrator.run_ai_model('sentiment_analysis', {
        'text': 'OASIS v3 is amazing!'
    })
    
    if sentiment:
        print(f"Sentiment: {sentiment}")

if __name__ == '__main__':
    main()
