#!/usr/bin/env python3
"""
OASIS v3 - Business Automation Example
"""

from business_automation import RevenueEngine
from oasis import OASISOrchestrator

def main():
    # Initialize components
    orchestrator = OASISOrchestrator()
    revenue_engine = RevenueEngine()
    
    # Simulate AI service requests
    services = [
        ('text_generation', 'Generate marketing copy', 0.05),
        ('sentiment_analysis', 'Analyze customer feedback', 0.01),
        ('image_processing', 'Process product images', 0.10),
        ('data_analysis', 'Analyze sales data', 0.15)
    ]
    
    total_revenue = 0
    
    for service_type, description, price in services:
        print(f"🤖 Processing: {description}")
        
        # Execute AI service
        result = orchestrator.run_ai_model(service_type, {
            'text': description
        })
        
        if result:
            # Record revenue
            transaction_id = revenue_engine.add_transaction(
                service_type, price, client_id="demo_client"
            )
            total_revenue += price
            print(f"💰 Revenue recorded: ${price:.2f} (ID: {transaction_id})")
    
    # Show daily summary
    daily_revenue = revenue_engine.get_daily_revenue()
    monthly_revenue = revenue_engine.get_monthly_revenue()
    
    print(f"\n📊 Revenue Summary:")
    print(f"Today: ${daily_revenue:.2f}")
    print(f"This month: ${monthly_revenue:.2f}")
    print(f"Session total: ${total_revenue:.2f}")
    
    # Save data
    revenue_engine.save_data()
    print("💾 Revenue data saved")

if __name__ == '__main__':
    main()
