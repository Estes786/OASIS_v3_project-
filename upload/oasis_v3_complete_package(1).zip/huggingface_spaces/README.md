# OASIS v3 - Hugging Face Spaces Application

This is the cloud component of OASIS v3, designed to run on Hugging Face Spaces and provide AI/ML/DL capabilities for the hybrid OASIS system.

## Features

- **Text Generation**: Generate text using transformer models
- **Image Processing**: Basic image analysis and processing
- **Data Analysis**: Mock data analysis capabilities (extensible)
- **RESTful API**: Clean API for integration with Termux orchestrator
- **Authentication**: API key-based authentication
- **CORS Support**: Cross-origin requests enabled

## API Endpoints

### POST /run_model
Execute AI/ML/DL models with input data.

**Request Body:**
```json
{
    "api_key": "your_api_key",
    "model_name": "text_generation|image_processing|data_analysis",
    "input_data": {
        "prompt": "Your text prompt",
        "max_length": 100
    }
}
```

### GET /status
Get application status and health information.

**Query Parameters:**
- `api_key`: Your API key

### POST /upload_data
Upload data files to the application.

**Request Body:**
```json
{
    "api_key": "your_api_key",
    "file_name": "example.txt",
    "file_content": "base64_encoded_content"
}
```

### GET /download_results
Download processed results.

**Query Parameters:**
- `api_key`: Your API key
- `result_id`: ID of the result to download

## Environment Variables

- `OASIS_API_KEY`: API key for authentication (default: "default_api_key_change_me")

## Deployment

This application is designed to run on Hugging Face Spaces. Simply upload the files and set the appropriate environment variables.

## Local Development

```bash
pip install -r requirements.txt
python app.py
```

The application will run on `http://0.0.0.0:7860`

