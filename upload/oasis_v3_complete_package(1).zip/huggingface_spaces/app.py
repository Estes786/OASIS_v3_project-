import os
import json
import base64
from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
from datetime import datetime

# Import AI/ML libraries
import transformers
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import torch
from PIL import Image
import io
import requests

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
API_KEY = os.environ.get('OASIS_API_KEY', 'default_api_key_change_me')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Global variables for models (lazy loading)
text_generation_model = None
text_generation_tokenizer = None

# Application state
app_state = {
    'status': 'operational',
    'uptime_start': datetime.now(),
    'active_requests': 0,
    'total_requests': 0
}

def authenticate_request(request_data):
    """Validate API key from request"""
    api_key = request_data.get('api_key') or request.headers.get('X-API-Key')
    return api_key == API_KEY

def load_text_generation_model():
    """Lazy load text generation model"""
    global text_generation_model, text_generation_tokenizer
    if text_generation_model is None:
        logger.info("Loading text generation model...")
        try:
            # Use a lightweight model suitable for Hugging Face Spaces
            model_name = "microsoft/DialoGPT-medium"
            text_generation_tokenizer = AutoTokenizer.from_pretrained(model_name)
            text_generation_model = AutoModelForCausalLM.from_pretrained(model_name)
            logger.info("Text generation model loaded successfully")
        except Exception as e:
            logger.error(f"Error loading text generation model: {e}")
            # Fallback to pipeline
            text_generation_model = pipeline("text-generation", model="gpt2")
            logger.info("Fallback to GPT-2 pipeline")

@app.route('/', methods=['GET'])
def home():
    """Home endpoint with basic information"""
    return jsonify({
        'name': 'OASIS v3 - Hugging Face Spaces Application',
        'version': '1.0.0',
        'status': app_state['status'],
        'description': 'AI/ML/DL backend for OASIS v3 hybrid system',
        'endpoints': ['/run_model', '/status', '/upload_data', '/download_results']
    })

@app.route('/run_model', methods=['POST'])
def run_model():
    """Execute AI/ML/DL models based on request"""
    app_state['active_requests'] += 1
    app_state['total_requests'] += 1
    
    try:
        data = request.get_json()
        
        # Authentication
        if not authenticate_request(data):
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401
        
        model_name = data.get('model_name')
        input_data = data.get('input_data', {})
        
        if not model_name:
            return jsonify({'status': 'error', 'message': 'model_name is required'}), 400
        
        logger.info(f"Running model: {model_name}")
        
        # Handle different model types
        if model_name == 'text_generation':
            result = handle_text_generation(input_data)
        elif model_name == 'image_processing':
            result = handle_image_processing(input_data)
        elif model_name == 'data_analysis':
            result = handle_data_analysis(input_data)
        else:
            return jsonify({'status': 'error', 'message': f'Unknown model: {model_name}'}), 400
        
        return jsonify({
            'status': 'success',
            'message': f'Model {model_name} executed successfully',
            'output_data': result
        })
    
    except Exception as e:
        logger.error(f"Error in run_model: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    
    finally:
        app_state['active_requests'] -= 1

def handle_text_generation(input_data):
    """Handle text generation requests"""
    prompt = input_data.get('prompt', '')
    max_length = input_data.get('max_length', 100)
    
    if not prompt:
        raise ValueError("prompt is required for text_generation")
    
    load_text_generation_model()
    
    try:
        if isinstance(text_generation_model, transformers.Pipeline):
            # Using pipeline
            result = text_generation_model(prompt, max_length=max_length, num_return_sequences=1)
            generated_text = result[0]['generated_text']
        else:
            # Using model directly
            inputs = text_generation_tokenizer.encode(prompt, return_tensors='pt')
            with torch.no_grad():
                outputs = text_generation_model.generate(inputs, max_length=max_length, pad_token_id=text_generation_tokenizer.eos_token_id)
            generated_text = text_generation_tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        return {
            'generated_text': generated_text,
            'prompt': prompt,
            'max_length': max_length
        }
    except Exception as e:
        logger.error(f"Error in text generation: {e}")
        # Fallback response
        return {
            'generated_text': f"[OASIS v3] Generated response for: {prompt}. (Note: This is a fallback response due to model loading issues.)",
            'prompt': prompt,
            'max_length': max_length,
            'fallback': True
        }

def handle_image_processing(input_data):
    """Handle image processing requests"""
    image_url = input_data.get('image_url', '')
    operation = input_data.get('operation', 'analyze')
    
    if not image_url:
        raise ValueError("image_url is required for image_processing")
    
    try:
        # Download image
        response = requests.get(image_url)
        image = Image.open(io.BytesIO(response.content))
        
        # Basic image analysis
        result = {
            'image_url': image_url,
            'operation': operation,
            'image_size': image.size,
            'image_mode': image.mode,
            'analysis': f"Image processed successfully. Size: {image.size}, Mode: {image.mode}"
        }
        
        if operation == 'resize':
            new_size = input_data.get('new_size', [256, 256])
            resized_image = image.resize(new_size)
            result['new_size'] = new_size
            result['analysis'] = f"Image resized to {new_size}"
        
        return result
    
    except Exception as e:
        logger.error(f"Error in image processing: {e}")
        return {
            'image_url': image_url,
            'operation': operation,
            'error': str(e),
            'analysis': f"Failed to process image: {str(e)}"
        }

def handle_data_analysis(input_data):
    """Handle data analysis requests"""
    dataset_url = input_data.get('dataset_url', '')
    analysis_type = input_data.get('analysis_type', 'summary')
    
    # For now, return a mock analysis
    # In a real implementation, this would load and analyze actual data
    return {
        'dataset_url': dataset_url,
        'analysis_type': analysis_type,
        'results': {
            'summary': 'Mock data analysis completed',
            'rows_analyzed': 1000,
            'columns_analyzed': 10,
            'insights': ['Data appears to be well-structured', 'No missing values detected', 'Suitable for machine learning']
        },
        'note': 'This is a mock analysis. Implement actual data processing logic here.'
    }

@app.route('/status', methods=['GET'])
def get_status():
    """Get application status"""
    api_key = request.args.get('api_key') or request.headers.get('X-API-Key')
    if api_key != API_KEY:
        return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401
    
    uptime_seconds = int((datetime.now() - app_state['uptime_start']).total_seconds())
    
    return jsonify({
        'status': app_state['status'],
        'message': 'OASIS v3 Hugging Face Spaces Application is running',
        'uptime_seconds': uptime_seconds,
        'active_requests': app_state['active_requests'],
        'total_requests': app_state['total_requests']
    })

@app.route('/upload_data', methods=['POST'])
def upload_data():
    """Upload data to the application"""
    try:
        data = request.get_json()
        
        # Authentication
        if not authenticate_request(data):
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401
        
        file_name = data.get('file_name')
        file_content = data.get('file_content')
        
        if not file_name or not file_content:
            return jsonify({'status': 'error', 'message': 'file_name and file_content are required'}), 400
        
        # Decode base64 content
        try:
            decoded_content = base64.b64decode(file_content)
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'Invalid base64 content: {e}'}), 400
        
        # Save file (in a real implementation, you might want to use a proper storage service)
        upload_dir = '/tmp/oasis_uploads'
        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, file_name)
        
        with open(file_path, 'wb') as f:
            f.write(decoded_content)
        
        logger.info(f"File uploaded: {file_name}")
        
        return jsonify({
            'status': 'success',
            'message': f'File {file_name} uploaded successfully',
            'file_path': file_path
        })
    
    except Exception as e:
        logger.error(f"Error in upload_data: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/download_results', methods=['GET'])
def download_results():
    """Download results from the application"""
    api_key = request.args.get('api_key') or request.headers.get('X-API-Key')
    if api_key != API_KEY:
        return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401
    
    result_id = request.args.get('result_id')
    if not result_id:
        return jsonify({'status': 'error', 'message': 'result_id is required'}), 400
    
    try:
        # In a real implementation, you would retrieve the actual file
        # For now, return a mock result
        mock_content = f"This is a mock result file for result_id: {result_id}\nGenerated at: {datetime.now()}"
        encoded_content = base64.b64encode(mock_content.encode()).decode()
        
        return jsonify({
            'status': 'success',
            'message': f'Result {result_id} retrieved successfully',
            'file_name': f'{result_id}.txt',
            'file_content': encoded_content
        })
    
    except Exception as e:
        logger.error(f"Error in download_results: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    logger.info("Starting OASIS v3 Hugging Face Spaces Application...")
    app.run(host='0.0.0.0', port=7860, debug=False)  # Port 7860 is standard for Hugging Face Spaces

