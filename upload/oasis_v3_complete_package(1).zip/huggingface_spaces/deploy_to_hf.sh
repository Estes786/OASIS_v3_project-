#!/bin/bash

# OASIS v3 - One-Command Deployment to Hugging Face Spaces
# This script automates the complete deployment process

set -e  # Exit on any error

echo "🚀 OASIS v3 - Hugging Face Spaces Deployment"
echo "=============================================="

# Configuration
SPACE_NAME="${1:-oasis-v3-ai-platform}"
HF_USERNAME="${2:-your-username}"
SPACE_URL="https://huggingface.co/spaces/${HF_USERNAME}/${SPACE_NAME}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if required tools are installed
check_dependencies() {
    print_status "Checking dependencies..."
    
    if ! command -v git &> /dev/null; then
        print_error "Git is not installed. Please install git first."
        exit 1
    fi
    
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed. Please install Python 3 first."
        exit 1
    fi
    
    print_success "All dependencies are available"
}

# Check if Hugging Face CLI is installed and configured
check_hf_cli() {
    print_status "Checking Hugging Face CLI..."
    
    if ! command -v huggingface-cli &> /dev/null; then
        print_warning "Hugging Face CLI not found. Installing..."
        pip install huggingface_hub[cli]
    fi
    
    # Check if user is logged in
    if ! huggingface-cli whoami &> /dev/null; then
        print_warning "Not logged in to Hugging Face. Please login first:"
        echo "Run: huggingface-cli login"
        echo "Get your token from: https://huggingface.co/settings/tokens"
        exit 1
    fi
    
    print_success "Hugging Face CLI is ready"
}

# Create or update the Hugging Face Space
create_space() {
    print_status "Creating/updating Hugging Face Space: ${SPACE_NAME}"
    
    # Create space if it doesn't exist
    if ! huggingface-cli repo info "spaces/${HF_USERNAME}/${SPACE_NAME}" &> /dev/null; then
        print_status "Creating new space..."
        huggingface-cli repo create "${SPACE_NAME}" --type space --space_sdk gradio
        print_success "Space created: ${SPACE_URL}"
    else
        print_status "Space already exists: ${SPACE_URL}"
    fi
}

# Clone the space repository
clone_space() {
    print_status "Setting up local repository..."
    
    TEMP_DIR="/tmp/oasis_v3_deploy_$$"
    mkdir -p "${TEMP_DIR}"
    cd "${TEMP_DIR}"
    
    print_status "Cloning space repository..."
    git clone "https://huggingface.co/spaces/${HF_USERNAME}/${SPACE_NAME}" .
    
    # Configure git if needed
    if ! git config user.email &> /dev/null; then
        git config user.email "oasis@example.com"
        git config user.name "OASIS v3 Deployer"
    fi
}

# Copy application files
copy_files() {
    print_status "Copying application files..."
    
    # Get the directory where this script is located
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    # Copy main application files
    cp "${SCRIPT_DIR}/app.py" .
    cp "${SCRIPT_DIR}/requirements.txt" .
    cp "${SCRIPT_DIR}/README.md" .
    
    # Create or update README for Hugging Face Spaces
    cat > README.md << 'EOF'
---
title: OASIS v3 AI Platform
emoji: 🌟
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 4.7.1
app_file: app.py
pinned: false
license: mit
---

# OASIS v3 - AI Platform

A powerful AI/ML/DL platform providing multiple capabilities through a unified API.

## Features

- **Text Generation**: Generate text using transformer models
- **Image Processing**: Analyze and process images
- **Data Analysis**: Perform data analysis on datasets
- **RESTful API**: Clean API for integration with external systems
- **Secure**: API key-based authentication

## API Endpoints

- `POST /run_model` - Execute AI/ML/DL models
- `GET /status` - Get application status
- `POST /upload_data` - Upload data files
- `GET /download_results` - Download processed results

## Usage

This application is designed to work with the OASIS v3 Termux orchestrator for hybrid edge-cloud AI computing.

## Configuration

Set the `OASIS_API_KEY` environment variable for authentication.
EOF
    
    # Create a simple Gradio interface wrapper
    cat > gradio_interface.py << 'EOF'
import gradio as gr
import requests
import json

def process_text(prompt, model_type="text_generation"):
    """Process text using OASIS API"""
    try:
        response = requests.post(
            "http://localhost:7860/run_model",
            json={
                "api_key": "default_api_key_change_me",
                "model_name": model_type,
                "input_data": {"prompt": prompt, "max_length": 100}
            }
        )
        result = response.json()
        if result.get("status") == "success":
            return result.get("output_data", {}).get("generated_text", "No output")
        else:
            return f"Error: {result.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error: {str(e)}"

# Create Gradio interface
with gr.Blocks(title="OASIS v3 AI Platform") as demo:
    gr.Markdown("# 🌟 OASIS v3 - AI Platform")
    gr.Markdown("Hybrid AI system with Termux orchestration and cloud processing")
    
    with gr.Tab("Text Generation"):
        text_input = gr.Textbox(label="Enter your prompt", placeholder="Write a story about...")
        text_output = gr.Textbox(label="Generated Text", lines=5)
        text_button = gr.Button("Generate Text")
        text_button.click(process_text, inputs=text_input, outputs=text_output)
    
    with gr.Tab("API Status"):
        status_output = gr.JSON(label="System Status")
        status_button = gr.Button("Check Status")
        
        def get_status():
            try:
                response = requests.get("http://localhost:7860/status?api_key=default_api_key_change_me")
                return response.json()
            except Exception as e:
                return {"error": str(e)}
        
        status_button.click(get_status, outputs=status_output)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860)
EOF
    
    # Update app.py to include Gradio interface
    cat >> app.py << 'EOF'

# Gradio interface for Hugging Face Spaces
try:
    import gradio as gr
    
    def create_gradio_interface():
        """Create Gradio interface for Hugging Face Spaces"""
        def process_text_gradio(prompt, max_length=100):
            """Process text using internal API"""
            try:
                data = {
                    'api_key': API_KEY,
                    'model_name': 'text_generation',
                    'input_data': {'prompt': prompt, 'max_length': max_length}
                }
                
                # Simulate internal API call
                with app.test_client() as client:
                    response = client.post('/run_model', json=data)
                    result = response.get_json()
                    
                    if result.get('status') == 'success':
                        return result.get('output_data', {}).get('generated_text', 'No output')
                    else:
                        return f"Error: {result.get('message', 'Unknown error')}"
            except Exception as e:
                return f"Error: {str(e)}"
        
        def get_status_gradio():
            """Get status using internal API"""
            try:
                with app.test_client() as client:
                    response = client.get(f'/status?api_key={API_KEY}')
                    return response.get_json()
            except Exception as e:
                return {"error": str(e)}
        
        # Create Gradio interface
        with gr.Blocks(title="OASIS v3 AI Platform") as demo:
            gr.Markdown("# 🌟 OASIS v3 - AI Platform")
            gr.Markdown("Hybrid AI system with Termux orchestration and cloud processing")
            
            with gr.Tab("Text Generation"):
                with gr.Row():
                    with gr.Column():
                        text_input = gr.Textbox(
                            label="Enter your prompt", 
                            placeholder="Write a story about AI...",
                            lines=3
                        )
                        max_length_slider = gr.Slider(
                            minimum=10, 
                            maximum=500, 
                            value=100, 
                            label="Max Length"
                        )
                        text_button = gr.Button("Generate Text", variant="primary")
                    
                    with gr.Column():
                        text_output = gr.Textbox(
                            label="Generated Text", 
                            lines=8,
                            interactive=False
                        )
                
                text_button.click(
                    process_text_gradio, 
                    inputs=[text_input, max_length_slider], 
                    outputs=text_output
                )
            
            with gr.Tab("System Status"):
                status_output = gr.JSON(label="System Status")
                status_button = gr.Button("Check Status")
                status_button.click(get_status_gradio, outputs=status_output)
            
            with gr.Tab("API Documentation"):
                gr.Markdown("""
                ## API Endpoints
                
                ### POST /run_model
                Execute AI/ML/DL models
                
                **Request:**
                ```json
                {
                    "api_key": "your_api_key",
                    "model_name": "text_generation|image_processing|data_analysis",
                    "input_data": {
                        "prompt": "Your prompt here",
                        "max_length": 100
                    }
                }
                ```
                
                ### GET /status
                Get application status
                
                **Parameters:**
                - `api_key`: Your API key
                
                ### POST /upload_data
                Upload data files
                
                ### GET /download_results
                Download processed results
                
                ## Termux Integration
                
                Use the OASIS v3 Termux orchestrator to control this application:
                
                ```bash
                # Configure
                oasis config set hf_space_url https://your-space-name.hf.space
                oasis config set api_key your_api_key
                
                # Generate text
                oasis run text_generation --prompt "Hello, OASIS!" --max_length 100
                
                # Check status
                oasis status
                ```
                """)
        
        return demo
    
    # Create and launch Gradio interface if running as main
    if __name__ == '__main__':
        demo = create_gradio_interface()
        demo.launch(server_name='0.0.0.0', server_port=7860, share=False)

except ImportError:
    # Gradio not available, run Flask only
    if __name__ == '__main__':
        logger.info("Starting OASIS v3 Hugging Face Spaces Application...")
        app.run(host='0.0.0.0', port=7860, debug=False)
EOF
    
    # Update requirements.txt to include Gradio
    cat >> requirements.txt << 'EOF'
gradio==4.7.1
EOF
    
    print_success "Application files copied and configured"
}

# Commit and push changes
deploy_changes() {
    print_status "Deploying changes to Hugging Face Spaces..."
    
    git add .
    git commit -m "Deploy OASIS v3 AI Platform - $(date '+%Y-%m-%d %H:%M:%S')" || true
    git push origin main
    
    print_success "Changes deployed successfully!"
}

# Set environment variables
configure_space() {
    print_status "Configuring space environment..."
    
    # Note: Environment variables need to be set manually in the Hugging Face Spaces UI
    print_warning "Please set the following environment variables in your Hugging Face Space settings:"
    echo "  OASIS_API_KEY=your_secure_api_key_here"
    echo ""
    echo "Go to: ${SPACE_URL}/settings"
}

# Cleanup
cleanup() {
    print_status "Cleaning up temporary files..."
    cd /
    rm -rf "${TEMP_DIR}"
    print_success "Cleanup completed"
}

# Main deployment process
main() {
    print_status "Starting OASIS v3 deployment process..."
    
    # Validate arguments
    if [ "$#" -lt 2 ]; then
        echo "Usage: $0 <space-name> <hf-username>"
        echo "Example: $0 oasis-v3-ai-platform myusername"
        exit 1
    fi
    
    check_dependencies
    check_hf_cli
    create_space
    clone_space
    copy_files
    deploy_changes
    configure_space
    cleanup
    
    print_success "🎉 OASIS v3 deployment completed!"
    echo ""
    echo "📍 Your space is available at: ${SPACE_URL}"
    echo "🔧 Don't forget to set the OASIS_API_KEY environment variable"
    echo "⏱️  It may take a few minutes for the space to build and start"
    echo ""
    echo "🚀 Test your deployment:"
    echo "  1. Visit: ${SPACE_URL}"
    echo "  2. Configure Termux orchestrator:"
    echo "     oasis config set hf_space_url ${SPACE_URL}"
    echo "     oasis config set api_key your_api_key"
    echo "  3. Test: oasis status"
}

# Run main function with all arguments
main "$@"

