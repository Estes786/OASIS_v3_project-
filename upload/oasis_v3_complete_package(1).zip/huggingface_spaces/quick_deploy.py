#!/usr/bin/env python3
"""
OASIS v3 - Quick Deployment Script
Python-based deployment for Hugging Face Spaces
"""

import os
import sys
import subprocess
import shutil
import tempfile
import json
from pathlib import Path
from datetime import datetime

class OASISDeployer:
    def __init__(self, space_name, hf_username):
        self.space_name = space_name
        self.hf_username = hf_username
        self.space_url = f"https://huggingface.co/spaces/{hf_username}/{space_name}"
        self.temp_dir = None
        
    def print_status(self, message):
        print(f"🔵 [INFO] {message}")
    
    def print_success(self, message):
        print(f"✅ [SUCCESS] {message}")
    
    def print_warning(self, message):
        print(f"⚠️ [WARNING] {message}")
    
    def print_error(self, message):
        print(f"❌ [ERROR] {message}")
    
    def check_dependencies(self):
        """Check if required tools are available"""
        self.print_status("Checking dependencies...")
        
        required_tools = ['git', 'python3']
        missing_tools = []
        
        for tool in required_tools:
            if not shutil.which(tool):
                missing_tools.append(tool)
        
        if missing_tools:
            self.print_error(f"Missing required tools: {', '.join(missing_tools)}")
            return False
        
        self.print_success("All dependencies are available")
        return True
    
    def install_hf_cli(self):
        """Install and check Hugging Face CLI"""
        self.print_status("Checking Hugging Face CLI...")
        
        try:
            subprocess.run(['huggingface-cli', 'whoami'], 
                         capture_output=True, check=True)
            self.print_success("Hugging Face CLI is ready")
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.print_warning("Installing Hugging Face CLI...")
            try:
                subprocess.run([sys.executable, '-m', 'pip', 'install', 'huggingface_hub[cli]'], 
                             check=True)
                self.print_success("Hugging Face CLI installed")
                
                # Check login status
                try:
                    subprocess.run(['huggingface-cli', 'whoami'], 
                                 capture_output=True, check=True)
                    return True
                except subprocess.CalledProcessError:
                    self.print_warning("Please login to Hugging Face:")
                    print("Run: huggingface-cli login")
                    print("Get your token from: https://huggingface.co/settings/tokens")
                    return False
            except subprocess.CalledProcessError:
                self.print_error("Failed to install Hugging Face CLI")
                return False
    
    def create_space(self):
        """Create Hugging Face Space if it doesn't exist"""
        self.print_status(f"Creating/updating Hugging Face Space: {self.space_name}")
        
        try:
            # Check if space exists
            subprocess.run(['huggingface-cli', 'repo', 'info', f'spaces/{self.hf_username}/{self.space_name}'], 
                         capture_output=True, check=True)
            self.print_status(f"Space already exists: {self.space_url}")
            return True
        except subprocess.CalledProcessError:
            # Space doesn't exist, create it
            try:
                subprocess.run(['huggingface-cli', 'repo', 'create', self.space_name, 
                              '--type', 'space', '--space_sdk', 'gradio'], check=True)
                self.print_success(f"Space created: {self.space_url}")
                return True
            except subprocess.CalledProcessError:
                self.print_error("Failed to create space")
                return False
    
    def setup_repository(self):
        """Clone and setup the repository"""
        self.print_status("Setting up local repository...")
        
        self.temp_dir = tempfile.mkdtemp(prefix='oasis_v3_deploy_')
        os.chdir(self.temp_dir)
        
        try:
            subprocess.run(['git', 'clone', f'https://huggingface.co/spaces/{self.hf_username}/{self.space_name}', '.'], 
                         check=True)
            
            # Configure git if needed
            try:
                subprocess.run(['git', 'config', 'user.email'], capture_output=True, check=True)
            except subprocess.CalledProcessError:
                subprocess.run(['git', 'config', 'user.email', 'oasis@example.com'], check=True)
                subprocess.run(['git', 'config', 'user.name', 'OASIS v3 Deployer'], check=True)
            
            self.print_success("Repository setup completed")
            return True
        except subprocess.CalledProcessError:
            self.print_error("Failed to setup repository")
            return False
    
    def copy_application_files(self):
        """Copy OASIS application files to the repository"""
        self.print_status("Copying application files...")
        
        # Get the directory where the original files are located
        script_dir = Path(__file__).parent
        
        # Files to copy
        files_to_copy = [
            ('app.py', 'app.py'),
            ('requirements.txt', 'requirements.txt'),
            ('README.md', 'README.md')
        ]
        
        for src_file, dst_file in files_to_copy:
            src_path = script_dir / src_file
            if src_path.exists():
                shutil.copy2(src_path, dst_file)
                self.print_status(f"Copied {src_file}")
            else:
                self.print_warning(f"Source file not found: {src_file}")
        
        # Create Hugging Face Spaces README
        self.create_hf_readme()
        
        # Update requirements for Gradio
        self.update_requirements()
        
        # Create Gradio interface
        self.create_gradio_interface()
        
        self.print_success("Application files copied and configured")
        return True
    
    def create_hf_readme(self):
        """Create README.md for Hugging Face Spaces"""
        readme_content = f"""---
title: OASIS v3 AI Platform
emoji: 🌟
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 4.7.1
app_file: app.py
pinned: false
license: mit
---

# OASIS v3 - AI Platform

A powerful AI/ML/DL platform providing multiple capabilities through a unified API.

## Features

- **Text Generation**: Generate text using transformer models
- **Image Processing**: Analyze and process images  
- **Data Analysis**: Perform data analysis on datasets
- **RESTful API**: Clean API for integration with external systems
- **Secure**: API key-based authentication

## API Endpoints

- `POST /run_model` - Execute AI/ML/DL models
- `GET /status` - Get application status
- `POST /upload_data` - Upload data files
- `GET /download_results` - Download processed results

## Usage

This application is designed to work with the OASIS v3 Termux orchestrator for hybrid edge-cloud AI computing.

## Configuration

Set the `OASIS_API_KEY` environment variable for authentication.

## Termux Integration

```bash
# Configure
oasis config set hf_space_url {self.space_url}
oasis config set api_key your_api_key

# Generate text
oasis run text_generation --prompt "Hello, OASIS!" --max_length 100

# Check status
oasis status
```
"""
        
        with open('README.md', 'w') as f:
            f.write(readme_content)
    
    def update_requirements(self):
        """Update requirements.txt to include Gradio"""
        requirements = []
        
        # Read existing requirements
        if os.path.exists('requirements.txt'):
            with open('requirements.txt', 'r') as f:
                requirements = [line.strip() for line in f if line.strip()]
        
        # Add Gradio if not present
        gradio_present = any('gradio' in req.lower() for req in requirements)
        if not gradio_present:
            requirements.append('gradio==4.7.1')
        
        # Write updated requirements
        with open('requirements.txt', 'w') as f:
            for req in requirements:
                f.write(f"{req}\n")
    
    def create_gradio_interface(self):
        """Create or update the Gradio interface in app.py"""
        gradio_code = '''
# Gradio interface for Hugging Face Spaces
try:
    import gradio as gr
    
    def create_gradio_interface():
        """Create Gradio interface for Hugging Face Spaces"""
        def process_text_gradio(prompt, max_length=100):
            """Process text using internal API"""
            try:
                data = {
                    'api_key': API_KEY,
                    'model_name': 'text_generation',
                    'input_data': {'prompt': prompt, 'max_length': max_length}
                }
                
                # Simulate internal API call
                with app.test_client() as client:
                    response = client.post('/run_model', json=data)
                    result = response.get_json()
                    
                    if result.get('status') == 'success':
                        return result.get('output_data', {}).get('generated_text', 'No output')
                    else:
                        return f"Error: {result.get('message', 'Unknown error')}"
            except Exception as e:
                return f"Error: {str(e)}"
        
        def get_status_gradio():
            """Get status using internal API"""
            try:
                with app.test_client() as client:
                    response = client.get(f'/status?api_key={API_KEY}')
                    return response.get_json()
            except Exception as e:
                return {"error": str(e)}
        
        # Create Gradio interface
        with gr.Blocks(title="OASIS v3 AI Platform") as demo:
            gr.Markdown("# 🌟 OASIS v3 - AI Platform")
            gr.Markdown("Hybrid AI system with Termux orchestration and cloud processing")
            
            with gr.Tab("Text Generation"):
                with gr.Row():
                    with gr.Column():
                        text_input = gr.Textbox(
                            label="Enter your prompt", 
                            placeholder="Write a story about AI...",
                            lines=3
                        )
                        max_length_slider = gr.Slider(
                            minimum=10, 
                            maximum=500, 
                            value=100, 
                            label="Max Length"
                        )
                        text_button = gr.Button("Generate Text", variant="primary")
                    
                    with gr.Column():
                        text_output = gr.Textbox(
                            label="Generated Text", 
                            lines=8,
                            interactive=False
                        )
                
                text_button.click(
                    process_text_gradio, 
                    inputs=[text_input, max_length_slider], 
                    outputs=text_output
                )
            
            with gr.Tab("System Status"):
                status_output = gr.JSON(label="System Status")
                status_button = gr.Button("Check Status")
                status_button.click(get_status_gradio, outputs=status_output)
        
        return demo
    
    # Create and launch Gradio interface if running as main
    if __name__ == '__main__':
        demo = create_gradio_interface()
        demo.launch(server_name='0.0.0.0', server_port=7860, share=False)

except ImportError:
    # Gradio not available, run Flask only
    if __name__ == '__main__':
        logger.info("Starting OASIS v3 Hugging Face Spaces Application...")
        app.run(host='0.0.0.0', port=7860, debug=False)
'''
        
        # Append Gradio code to app.py if not already present
        if os.path.exists('app.py'):
            with open('app.py', 'r') as f:
                content = f.read()
            
            if 'gradio' not in content.lower():
                with open('app.py', 'a') as f:
                    f.write(gradio_code)
    
    def deploy_to_space(self):
        """Commit and push changes to Hugging Face Space"""
        self.print_status("Deploying changes to Hugging Face Spaces...")
        
        try:
            subprocess.run(['git', 'add', '.'], check=True)
            
            commit_message = f"Deploy OASIS v3 AI Platform - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            subprocess.run(['git', 'commit', '-m', commit_message], check=False)  # Don't fail if nothing to commit
            
            subprocess.run(['git', 'push', 'origin', 'main'], check=True)
            
            self.print_success("Changes deployed successfully!")
            return True
        except subprocess.CalledProcessError:
            self.print_error("Failed to deploy changes")
            return False
    
    def cleanup(self):
        """Clean up temporary files"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            self.print_status("Cleaning up temporary files...")
            os.chdir('/')
            shutil.rmtree(self.temp_dir)
            self.print_success("Cleanup completed")
    
    def deploy(self):
        """Main deployment process"""
        self.print_status("🚀 Starting OASIS v3 deployment process...")
        
        try:
            if not self.check_dependencies():
                return False
            
            if not self.install_hf_cli():
                return False
            
            if not self.create_space():
                return False
            
            if not self.setup_repository():
                return False
            
            if not self.copy_application_files():
                return False
            
            if not self.deploy_to_space():
                return False
            
            self.print_success("🎉 OASIS v3 deployment completed!")
            print(f"\n📍 Your space is available at: {self.space_url}")
            print("🔧 Don't forget to set the OASIS_API_KEY environment variable")
            print("⏱️  It may take a few minutes for the space to build and start")
            print(f"\n🚀 Test your deployment:")
            print(f"  1. Visit: {self.space_url}")
            print(f"  2. Configure Termux orchestrator:")
            print(f"     oasis config set hf_space_url {self.space_url}")
            print(f"     oasis config set api_key your_api_key")
            print(f"  3. Test: oasis status")
            
            return True
            
        except KeyboardInterrupt:
            self.print_warning("Deployment interrupted by user")
            return False
        except Exception as e:
            self.print_error(f"Deployment failed: {e}")
            return False
        finally:
            self.cleanup()

def main():
    """Main function"""
    if len(sys.argv) != 3:
        print("Usage: python3 quick_deploy.py <space-name> <hf-username>")
        print("Example: python3 quick_deploy.py oasis-v3-ai-platform myusername")
        sys.exit(1)
    
    space_name = sys.argv[1]
    hf_username = sys.argv[2]
    
    deployer = OASISDeployer(space_name, hf_username)
    success = deployer.deploy()
    
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()

