#!/usr/bin/env python3
"""
OASIS v3 - Security Implementation
Provides secure communication, authentication, and data protection
"""

import hashlib
import hmac
import secrets
import time
import json
import base64
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import requests
from urllib.parse import urljoin

class OASISSecurityManager:
    """Manages security aspects of OASIS v3 communication"""
    
    def __init__(self, api_key=None, encryption_key=None):
        self.api_key = api_key or self._generate_api_key()
        self.encryption_key = encryption_key
        self.session_token = None
        self.token_expiry = None
        
    def _generate_api_key(self):
        """Generate a secure API key"""
        return secrets.token_urlsafe(32)
    
    def _generate_encryption_key(self, password, salt=None):
        """Generate encryption key from password"""
        if salt is None:
            salt = secrets.token_bytes(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return key, salt
    
    def encrypt_data(self, data, password=None):
        """Encrypt sensitive data"""
        if password:
            key, salt = self._generate_encryption_key(password)
            fernet = Fernet(key)
            encrypted = fernet.encrypt(json.dumps(data).encode())
            return {
                'encrypted_data': base64.b64encode(encrypted).decode(),
                'salt': base64.b64encode(salt).decode(),
                'encrypted': True
            }
        return data
    
    def decrypt_data(self, encrypted_data, password, salt):
        """Decrypt sensitive data"""
        try:
            salt_bytes = base64.b64decode(salt)
            key, _ = self._generate_encryption_key(password, salt_bytes)
            fernet = Fernet(key)
            
            encrypted_bytes = base64.b64decode(encrypted_data)
            decrypted = fernet.decrypt(encrypted_bytes)
            return json.loads(decrypted.decode())
        except Exception as e:
            raise ValueError(f"Decryption failed: {e}")
    
    def generate_request_signature(self, method, endpoint, data, timestamp):
        """Generate HMAC signature for request authentication"""
        message = f"{method}|{endpoint}|{json.dumps(data, sort_keys=True)}|{timestamp}"
        signature = hmac.new(
            self.api_key.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def verify_request_signature(self, method, endpoint, data, timestamp, signature):
        """Verify HMAC signature for request authentication"""
        expected_signature = self.generate_request_signature(method, endpoint, data, timestamp)
        return hmac.compare_digest(signature, expected_signature)
    
    def is_timestamp_valid(self, timestamp, tolerance_seconds=300):
        """Check if timestamp is within acceptable range"""
        try:
            request_time = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            current_time = datetime.now(request_time.tzinfo)
            time_diff = abs((current_time - request_time).total_seconds())
            return time_diff <= tolerance_seconds
        except Exception:
            return False
    
    def generate_session_token(self, duration_hours=24):
        """Generate a temporary session token"""
        self.session_token = secrets.token_urlsafe(32)
        self.token_expiry = datetime.now() + timedelta(hours=duration_hours)
        return self.session_token
    
    def is_session_valid(self):
        """Check if current session token is valid"""
        return (self.session_token and 
                self.token_expiry and 
                datetime.now() < self.token_expiry)
    
    def sanitize_input(self, data):
        """Sanitize input data to prevent injection attacks"""
        if isinstance(data, dict):
            return {key: self.sanitize_input(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [self.sanitize_input(item) for item in data]
        elif isinstance(data, str):
            # Basic sanitization - remove potentially dangerous characters
            dangerous_chars = ['<', '>', '"', "'", '&', '\x00']
            sanitized = data
            for char in dangerous_chars:
                sanitized = sanitized.replace(char, '')
            return sanitized[:1000]  # Limit string length
        else:
            return data

class SecureOASISClient:
    """Secure client for OASIS v3 communication"""
    
    def __init__(self, base_url, api_key, encryption_password=None):
        self.base_url = base_url.rstrip('/')
        self.security = OASISSecurityManager(api_key)
        self.encryption_password = encryption_password
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'User-Agent': 'OASIS-v3-Client/1.0',
            'X-OASIS-Protocol-Version': '1.0',
            'X-OASIS-Client-Version': '1.0.0'
        })
    
    def _prepare_request(self, method, endpoint, data=None):
        """Prepare secure request with authentication and encryption"""
        timestamp = datetime.now().isoformat() + 'Z'
        request_id = secrets.token_urlsafe(16)
        
        # Sanitize input data
        if data:
            data = self.security.sanitize_input(data)
        
        # Encrypt sensitive data if password is provided
        if self.encryption_password and data:
            data = self.security.encrypt_data(data, self.encryption_password)
        
        # Create request payload
        payload = {
            'api_key': self.security.api_key,
            'timestamp': timestamp,
            'request_id': request_id,
            'endpoint': endpoint,
            'method': method.upper(),
            'data': data or {}
        }
        
        # Generate signature
        signature = self.security.generate_request_signature(
            method.upper(), endpoint, payload['data'], timestamp
        )
        
        # Add signature to headers
        headers = {
            'X-OASIS-Signature': signature,
            'X-OASIS-Timestamp': timestamp,
            'X-OASIS-Request-ID': request_id,
            'Content-Type': 'application/json'
        }
        
        return payload, headers
    
    def _process_response(self, response):
        """Process and validate response"""
        try:
            response.raise_for_status()
            data = response.json()
            
            # Check if response contains encrypted data
            if (isinstance(data.get('data'), dict) and 
                data['data'].get('encrypted') and 
                self.encryption_password):
                
                encrypted_data = data['data']['encrypted_data']
                salt = data['data']['salt']
                data['data'] = self.security.decrypt_data(
                    encrypted_data, self.encryption_password, salt
                )
            
            return data
        
        except requests.exceptions.HTTPError as e:
            if response.status_code == 401:
                raise SecurityError("Authentication failed - invalid API key")
            elif response.status_code == 403:
                raise SecurityError("Access forbidden - insufficient permissions")
            elif response.status_code == 429:
                raise SecurityError("Rate limit exceeded - too many requests")
            else:
                raise SecurityError(f"HTTP error {response.status_code}: {e}")
        
        except json.JSONDecodeError:
            raise SecurityError("Invalid response format")
        
        except Exception as e:
            raise SecurityError(f"Response processing failed: {e}")
    
    def secure_request(self, method, endpoint, data=None, timeout=30):
        """Make a secure request to the OASIS API"""
        url = urljoin(self.base_url + '/', endpoint.lstrip('/'))
        payload, headers = self._prepare_request(method, endpoint, data)
        
        try:
            if method.upper() == 'POST':
                response = self.session.post(url, json=payload, headers=headers, timeout=timeout)
            else:
                # For GET requests, add parameters to URL
                params = {
                    'api_key': payload['api_key'],
                    'timestamp': payload['timestamp'],
                    'request_id': payload['request_id']
                }
                if payload['data']:
                    params.update(payload['data'])
                
                response = self.session.get(url, params=params, headers=headers, timeout=timeout)
            
            return self._process_response(response)
        
        except requests.exceptions.ConnectionError:
            raise SecurityError(f"Connection failed to {url}")
        except requests.exceptions.Timeout:
            raise SecurityError(f"Request timeout after {timeout} seconds")
        except requests.exceptions.RequestException as e:
            raise SecurityError(f"Request failed: {e}")

class SecurityError(Exception):
    """Custom exception for security-related errors"""
    pass

class RateLimiter:
    """Simple rate limiter for API requests"""
    
    def __init__(self, max_requests=100, time_window=3600):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = []
    
    def is_allowed(self):
        """Check if request is allowed under rate limit"""
        now = time.time()
        
        # Remove old requests outside time window
        self.requests = [req_time for req_time in self.requests 
                        if now - req_time < self.time_window]
        
        # Check if under limit
        if len(self.requests) < self.max_requests:
            self.requests.append(now)
            return True
        
        return False
    
    def time_until_reset(self):
        """Get time until rate limit resets"""
        if not self.requests:
            return 0
        
        oldest_request = min(self.requests)
        reset_time = oldest_request + self.time_window
        return max(0, reset_time - time.time())

def generate_secure_config():
    """Generate secure configuration for OASIS v3"""
    config = {
        'api_key': secrets.token_urlsafe(32),
        'encryption_password': secrets.token_urlsafe(24),
        'session_timeout_hours': 24,
        'request_timeout_seconds': 30,
        'rate_limit_requests': 100,
        'rate_limit_window_seconds': 3600,
        'signature_tolerance_seconds': 300
    }
    
    print("🔐 Secure OASIS v3 Configuration Generated:")
    print(f"API Key: {config['api_key']}")
    print(f"Encryption Password: {config['encryption_password']}")
    print("\n⚠️ Store these securely and never share them!")
    
    return config

def main():
    """Example usage of security features"""
    print("🔐 OASIS v3 Security Test")
    
    # Generate secure configuration
    config = generate_secure_config()
    
    # Test security manager
    security = OASISSecurityManager(config['api_key'])
    
    # Test encryption
    test_data = {"sensitive": "information", "user_id": 12345}
    encrypted = security.encrypt_data(test_data, config['encryption_password'])
    print(f"\n🔒 Encrypted data: {encrypted}")
    
    # Test signature generation
    timestamp = datetime.now().isoformat() + 'Z'
    signature = security.generate_request_signature('POST', '/run_model', test_data, timestamp)
    print(f"\n✍️ Request signature: {signature}")
    
    print("\n✅ Security test completed successfully!")

if __name__ == '__main__':
    main()

