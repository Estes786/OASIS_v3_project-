# OASIS v3 - Termux Orchestrator

The lightweight command center for controlling AI/ML/DL applications hosted on Hugging Face Spaces.

## Features

- **Lightweight**: Minimal resource usage on Android devices
- **Powerful**: Control complex AI/ML/DL models remotely
- **Simple**: Easy-to-use command-line interface
- **Secure**: API key-based authentication
- **Flexible**: Support for multiple model types and operations

## Quick Start

### 1. Setup Termux Environment

```bash
# Run the setup script
bash setup_termux.sh
```

### 2. Configure OASIS

```bash
# Set your Hugging Face Space URL
oasis config set hf_space_url https://your-space-name.hf.space

# Set your API key
oasis config set api_key your_api_key_here
```

### 3. Test Connection

```bash
# Check if the Hugging Face Space is running
oasis status
```

### 4. Run AI Models

```bash
# Text generation
oasis run text_generation --prompt "Write a short story about AI" --max_length 200

# Image processing
oasis run image_processing --image_url "https://example.com/image.jpg" --operation "analyze"

# Data analysis
oasis run data_analysis --dataset_url "https://example.com/data.csv" --analysis_type "summary"
```

## Commands

### Model Execution
- `oasis run <model_name> [options]` - Execute AI/ML/DL models

### File Operations
- `oasis upload <local_file> [remote_name]` - Upload files to cloud
- `oasis download <result_id> [local_path]` - Download results from cloud

### System Management
- `oasis status` - Check application status
- `oasis config set <key> <value>` - Set configuration
- `oasis config get <key>` - Get configuration value
- `oasis config show` - Show all configuration
- `oasis help` - Show help information

## Supported Models

### Text Generation
Generate text using transformer models.

**Usage:**
```bash
oasis run text_generation --prompt "Your prompt here" --max_length 100
```

**Parameters:**
- `--prompt`: Text prompt for generation
- `--max_length`: Maximum length of generated text

### Image Processing
Analyze and process images.

**Usage:**
```bash
oasis run image_processing --image_url "URL" --operation "analyze"
```

**Parameters:**
- `--image_url`: URL of the image to process
- `--operation`: Type of operation (analyze, resize, etc.)
- `--new_size`: New size for resize operation (e.g., "[256, 256]")

### Data Analysis
Perform data analysis on datasets.

**Usage:**
```bash
oasis run data_analysis --dataset_url "URL" --analysis_type "summary"
```

**Parameters:**
- `--dataset_url`: URL of the dataset to analyze
- `--analysis_type`: Type of analysis to perform

## Configuration

Configuration is stored in `~/.oasis_config.ini`. Required settings:

- `hf_space_url`: Your Hugging Face Space URL
- `api_key`: API key for authentication
- `timeout`: Request timeout in seconds (default: 30)

## File Structure

```
~/oasis_v3/
├── oasis.py              # Main orchestrator script
├── requirements.txt      # Python dependencies
├── setup_termux.sh      # Termux setup script
└── README.md            # This file
```

## Troubleshooting

### Connection Issues
1. Check your internet connection
2. Verify the Hugging Face Space URL is correct
3. Ensure the Hugging Face Space is running

### Authentication Issues
1. Verify your API key is correct
2. Check if the API key is properly configured

### Model Execution Issues
1. Check if the model name is supported
2. Verify the input parameters are correct
3. Check the Hugging Face Space logs for errors

## Advanced Usage

### Custom Models
To add support for custom models, modify the Hugging Face Spaces application to handle new model types.

### Batch Processing
Use shell scripts to automate batch processing:

```bash
#!/bin/bash
for prompt in "Story 1" "Story 2" "Story 3"; do
    oasis run text_generation --prompt "$prompt" --max_length 100
done
```

### Integration with Termux:API
Use Termux:API for enhanced functionality:

```bash
# Get battery status and include in prompts
battery_level=$(termux-battery-status | jq -r '.percentage')
oasis run text_generation --prompt "Battery at $battery_level%. Write about energy conservation."
```

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the Hugging Face Space logs
3. Verify your configuration settings

