#!/data/data/com.termux/files/usr/bin/bash

# OASIS v3 - Comprehensive Termux Setup Script
# Ultra-Lightweight AI Civilization Builder
# Zero Heavy Dependencies • Maximum Power • Minimal Footprint

set -e  # Exit on any error

# Colors for beautiful output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# ASCII Art Banner
echo -e "${CYAN}"
cat << 'EOF'
   ____    _    ____ ___ ____   __   _____
  / __ \  / \  / ___|_ _/ ___| / /  |___ /
 | |  | |/ _ \ \___ \| |\___ \/ /     |_ \
 | |__| / ___ \ ___) | | ___) / /     ___) |
  \____/_/   \_\____/___|____/_/     |____/

Ultra-Lightweight AI Civilization Builder
EOF
echo -e "${NC}"

echo -e "${GREEN}🌟 Welcome to OASIS v3 - The Future of AI${NC}"
echo -e "${PURPLE}🚀 Termux Orchestrator + HuggingFace Spaces${NC}"
echo -e "${BLUE}💎 Zero Heavy Dependencies • Maximum Power${NC}"
echo ""

# Configuration
OASIS_DIR="$HOME/oasis_v3"
CONFIG_FILE="$OASIS_DIR/oasis_config.json"
LOG_FILE="$OASIS_DIR/logs/setup.log"

# Utility functions
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

success() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - SUCCESS: $1" >> "$LOG_FILE"
    echo -e "${GREEN}✅ $1${NC}"
}

warning() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - WARNING: $1" >> "$LOG_FILE"
    echo -e "${YELLOW}⚠️  $1${NC}"
}

error() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: $1" >> "$LOG_FILE"
    echo -e "${RED}❌ $1${NC}"
}

# Check if running on Termux
check_termux() {
    log "Checking Termux environment..."
    
    if [[ ! "$PREFIX" == *"com.termux"* ]]; then
        warning "Not running in Termux environment"
        warning "This script is optimized for Termux on Android"
        echo -e "${YELLOW}Continue anyway? (y/N): ${NC}"
        read -r response
        if [[ ! "$response" =~ ^[Yy]$ ]]; then
            error "Setup cancelled by user"
            exit 1
        fi
    fi
    
    success "Termux environment verified"
}

# Update Termux packages
update_packages() {
    log "Updating Termux packages..."
    
    echo -e "${BLUE}📦 Updating package lists...${NC}"
    pkg update -y
    
    echo -e "${BLUE}⬆️  Upgrading packages...${NC}"
    pkg upgrade -y
    
    success "Packages updated successfully"
}

# Install essential packages only
install_essentials() {
    log "Installing essential packages..."
    
    echo -e "${BLUE}🔧 Installing Python and Git...${NC}"
    pkg install -y python git curl wget
    
    echo -e "${BLUE}📱 Installing Termux:API (optional)...${NC}"
    pkg install -y termux-api || warning "Termux:API installation failed (optional)"
    
    # Verify Python installation
    if python --version &> /dev/null; then
        success "Python installed: $(python --version)"
    else
        error "Python installation failed"
        exit 1
    fi
    
    success "Essential packages installed"
}

# Create OASIS directory structure
create_directories() {
    log "Creating OASIS directory structure..."
    
    mkdir -p "$OASIS_DIR"/{config,logs,data,scripts,business,ai_models}
    mkdir -p "$OASIS_DIR"/logs/{daily,monthly,errors}
    mkdir -p "$OASIS_DIR"/data/{uploads,downloads,cache}
    mkdir -p "$OASIS_DIR"/business/{revenue,clients,analytics}
    
    success "Directory structure created"
}

# Create configuration file
create_config() {
    log "Creating OASIS configuration..."
    
    cat > "$CONFIG_FILE" << 'EOF'
{
    "version": "3.0.0",
    "environment": "termux",
    "hf_spaces": {
        "primary_url": "https://your-space-name.hf.space",
        "backup_url": "https://backup-space.hf.space",
        "api_key": "default_api_key_change_me",
        "timeout": 30
    },
    "business": {
        "pricing": {
            "text_generation": 0.05,
            "sentiment_analysis": 0.01,
            "image_processing": 0.10,
            "data_analysis": 0.15,
            "batch_processing": 0.50
        },
        "revenue_target": {
            "daily": 50,
            "monthly": 1500,
            "yearly": 18000
        }
    },
    "ai_models": {
        "text_generation": "gpt2",
        "sentiment": "cardiffnlp/twitter-roberta-base-sentiment-latest",
        "emotion": "cardiffnlp/twitter-roberta-base-emotion",
        "summarization": "facebook/bart-large-cnn",
        "translation": "Helsinki-NLP/opus-mt-en-es"
    },
    "termux": {
        "max_memory_mb": 512,
        "cache_size_mb": 100,
        "log_retention_days": 30
    },
    "security": {
        "api_key_rotation_days": 30,
        "session_timeout_hours": 24,
        "rate_limit_per_hour": 1000
    }
}
EOF
    
    success "Configuration file created"
}

# Download and setup OASIS orchestrator
setup_orchestrator() {
    log "Setting up OASIS orchestrator..."
    
    # Create the main orchestrator script
    cat > "$OASIS_DIR/oasis.py" << 'EOF'
#!/usr/bin/env python3
"""
OASIS v3 - Ultra-Lightweight Termux Orchestrator
Zero dependencies except Python standard library
"""

import urllib.request
import urllib.parse
import urllib.error
import json
import time
import os
import sys
from datetime import datetime
import hashlib

class OASISOrchestrator:
    def __init__(self, config_file="oasis_config.json"):
        self.config_file = config_file
        self.config = self.load_config()
        self.session_id = self.generate_session_id()
        
        print("🚀 OASIS v3 Orchestrator")
        print(f"📡 HF Spaces: {self.config.get('hf_spaces', {}).get('primary_url', 'Not configured')}")
        print(f"💻 Session: {self.session_id}")
    
    def load_config(self):
        """Load configuration from JSON file"""
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ Config error: {e}")
            return {}
    
    def generate_session_id(self):
        """Generate unique session ID"""
        timestamp = str(int(time.time()))
        return hashlib.md5(timestamp.encode()).hexdigest()[:8]
    
    def make_request(self, endpoint, data=None, method='GET'):
        """Make HTTP request to HuggingFace Spaces"""
        hf_config = self.config.get('hf_spaces', {})
        base_url = hf_config.get('primary_url', '')
        api_key = hf_config.get('api_key', '')
        timeout = hf_config.get('timeout', 30)
        
        if not base_url:
            print("❌ HuggingFace Spaces URL not configured")
            return None
        
        url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        try:
            if method == 'POST' and data:
                data['api_key'] = api_key
                json_data = json.dumps(data).encode('utf-8')
                req = urllib.request.Request(url, data=json_data)
                req.add_header('Content-Type', 'application/json')
            else:
                if data:
                    data['api_key'] = api_key
                    query_string = urllib.parse.urlencode(data)
                    url = f"{url}?{query_string}"
                req = urllib.request.Request(url)
            
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode())
        
        except urllib.error.URLError as e:
            print(f"❌ Connection error: {e}")
            return None
        except Exception as e:
            print(f"❌ Request error: {e}")
            return None
    
    def run_ai_model(self, model_type, input_data):
        """Execute AI model on HuggingFace Spaces"""
        print(f"🤖 Running {model_type} model...")
        
        data = {
            'model_name': model_type,
            'input_data': input_data,
            'session_id': self.session_id
        }
        
        result = self.make_request('run_model', data, 'POST')
        
        if result and result.get('status') == 'success':
            print("✅ Model execution successful")
            return result.get('output_data', {})
        else:
            print(f"❌ Model execution failed: {result.get('message', 'Unknown error') if result else 'No response'}")
            return None
    
    def get_status(self):
        """Get system status"""
        print("🔍 Checking system status...")
        
        result = self.make_request('status')
        
        if result:
            print(f"✅ Status: {result.get('status', 'Unknown')}")
            print(f"⏱️ Uptime: {result.get('uptime_seconds', 0)} seconds")
            print(f"📊 Requests: {result.get('total_requests', 0)}")
            return result
        else:
            print("❌ Status check failed")
            return None

def main():
    """Main CLI interface"""
    if len(sys.argv) < 2:
        print("Usage: python oasis.py <command> [args]")
        print("Commands: status, run, config")
        return
    
    orchestrator = OASISOrchestrator()
    command = sys.argv[1].lower()
    
    if command == 'status':
        orchestrator.get_status()
    elif command == 'run':
        if len(sys.argv) < 4:
            print("Usage: python oasis.py run <model_type> <input_text>")
            return
        model_type = sys.argv[2]
        input_text = sys.argv[3]
        result = orchestrator.run_ai_model(model_type, {'text': input_text})
        if result:
            print(f"📋 Result: {result}")
    else:
        print(f"Unknown command: {command}")

if __name__ == '__main__':
    main()
EOF
    
    chmod +x "$OASIS_DIR/oasis.py"
    success "OASIS orchestrator created"
}

# Setup business automation
setup_business_automation() {
    log "Setting up business automation..."
    
    cat > "$OASIS_DIR/business_engine.py" << 'EOF'
#!/usr/bin/env python3
"""
OASIS v3 Business Automation Engine
Revenue tracking and business process automation
"""

import json
import time
import os
from datetime import datetime, timedelta

class RevenueEngine:
    def __init__(self, config_file="oasis_config.json"):
        self.config_file = config_file
        self.config = self.load_config()
        self.transactions = []
        self.daily_revenue = {}
        
        print("💰 Revenue Engine initialized")
        print(f"🎯 Target: ${self.config.get('business', {}).get('revenue_target', {}).get('monthly', 1500)}/month")
    
    def load_config(self):
        """Load configuration"""
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def add_transaction(self, service_type, amount, client_id="anonymous"):
        """Record a revenue transaction"""
        transaction = {
            "id": f"tx_{int(time.time())}",
            "service": service_type,
            "amount": amount,
            "client_id": client_id,
            "timestamp": datetime.now().isoformat(),
            "date": datetime.now().strftime("%Y-%m-%d")
        }
        
        self.transactions.append(transaction)
        
        # Update daily revenue
        date = transaction["date"]
        if date not in self.daily_revenue:
            self.daily_revenue[date] = 0
        self.daily_revenue[date] += amount
        
        print(f"💰 Transaction recorded: ${amount:.2f} for {service_type}")
        return transaction["id"]
    
    def get_daily_revenue(self, date=None):
        """Get revenue for specific date"""
        if not date:
            date = datetime.now().strftime("%Y-%m-%d")
        return self.daily_revenue.get(date, 0)
    
    def get_monthly_revenue(self, year_month=None):
        """Get revenue for specific month"""
        if not year_month:
            year_month = datetime.now().strftime("%Y-%m")
        
        total = 0
        for date, amount in self.daily_revenue.items():
            if date.startswith(year_month):
                total += amount
        return total
    
    def save_data(self):
        """Save revenue data to file"""
        data = {
            "transactions": self.transactions,
            "daily_revenue": self.daily_revenue,
            "last_updated": datetime.now().isoformat()
        }
        
        with open("business/revenue_data.json", "w") as f:
            json.dump(data, f, indent=2)

if __name__ == '__main__':
    engine = RevenueEngine()
    # Example usage
    engine.add_transaction("text_generation", 0.05)
    engine.add_transaction("sentiment_analysis", 0.01)
    print(f"Today's revenue: ${engine.get_daily_revenue():.2f}")
    engine.save_data()
EOF
    
    chmod +x "$OASIS_DIR/business_engine.py"
    success "Business automation setup complete"
}

# Create aliases and shortcuts
create_aliases() {
    log "Creating aliases and shortcuts..."
    
    # Add aliases to .bashrc
    cat >> "$HOME/.bashrc" << 'EOF'

# OASIS v3 Aliases
alias oasis="python ~/oasis_v3/oasis.py"
alias oasis-status="python ~/oasis_v3/oasis.py status"
alias oasis-business="python ~/oasis_v3/business_engine.py"
alias oasis-config="nano ~/oasis_v3/oasis_config.json"
alias oasis-logs="tail -f ~/oasis_v3/logs/setup.log"

# Quick AI commands
alias ai-text="python ~/oasis_v3/oasis.py run text_generation"
alias ai-sentiment="python ~/oasis_v3/oasis.py run sentiment_analysis"

echo "🌟 OASIS v3 loaded - Type 'oasis status' to begin"
EOF
    
    success "Aliases created"
}

# Create startup script
create_startup_script() {
    log "Creating startup script..."
    
    cat > "$OASIS_DIR/start_oasis.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash

echo "🚀 Starting OASIS v3..."
cd ~/oasis_v3

# Check system status
python oasis.py status

# Start business engine
echo "💰 Initializing business engine..."
python business_engine.py &

echo "✅ OASIS v3 is ready!"
echo "📖 Quick commands:"
echo "  oasis status          - Check system status"
echo "  ai-text 'prompt'      - Generate text"
echo "  ai-sentiment 'text'   - Analyze sentiment"
echo "  oasis-business        - View revenue"
EOF
    
    chmod +x "$OASIS_DIR/start_oasis.sh"
    success "Startup script created"
}

# Create quick deployment script
create_deployment_script() {
    log "Creating deployment script..."
    
    cat > "$OASIS_DIR/deploy_to_hf.py" << 'EOF'
#!/usr/bin/env python3
"""
OASIS v3 - Quick HuggingFace Spaces Deployment
"""

import os
import sys
import subprocess

def deploy_to_huggingface(space_name, username):
    """Deploy OASIS to HuggingFace Spaces"""
    print(f"🚀 Deploying OASIS v3 to {username}/{space_name}")
    
    # Check if HF CLI is installed
    try:
        subprocess.run(['huggingface-cli', 'whoami'], capture_output=True, check=True)
        print("✅ HuggingFace CLI ready")
    except:
        print("📦 Installing HuggingFace CLI...")
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'huggingface_hub[cli]'])
    
    # Create space
    try:
        subprocess.run(['huggingface-cli', 'repo', 'create', space_name, '--type', 'space', '--space_sdk', 'gradio'])
        print(f"✅ Space created: https://huggingface.co/spaces/{username}/{space_name}")
    except:
        print("⚠️ Space might already exist")
    
    print("🎉 Deployment complete!")
    print(f"🔗 Visit: https://huggingface.co/spaces/{username}/{space_name}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python deploy_to_hf.py <space_name> <username>")
        sys.exit(1)
    
    deploy_to_huggingface(sys.argv[1], sys.argv[2])
EOF
    
    chmod +x "$OASIS_DIR/deploy_to_hf.py"
    success "Deployment script created"
}

# Final configuration and testing
final_setup() {
    log "Performing final setup..."
    
    cd "$OASIS_DIR"
    
    # Test Python installation
    if python --version &> /dev/null; then
        success "Python test passed"
    else
        error "Python test failed"
        exit 1
    fi
    
    # Test OASIS orchestrator
    if python oasis.py status &> /dev/null; then
        success "OASIS orchestrator test passed"
    else
        warning "OASIS orchestrator test failed (HF Spaces not configured)"
    fi
    
    success "Final setup complete"
}

# Display completion message
show_completion_message() {
    echo ""
    echo -e "${GREEN}🎉 OASIS v3 Setup Complete!${NC}"
    echo -e "${CYAN}================================${NC}"
    echo ""
    echo -e "${WHITE}📍 Installation Directory:${NC} $OASIS_DIR"
    echo -e "${WHITE}⚙️  Configuration File:${NC} $CONFIG_FILE"
    echo -e "${WHITE}📋 Log File:${NC} $LOG_FILE"
    echo ""
    echo -e "${YELLOW}🚀 Next Steps:${NC}"
    echo -e "${BLUE}1.${NC} Configure your HuggingFace Space URL:"
    echo -e "   ${CYAN}nano $CONFIG_FILE${NC}"
    echo ""
    echo -e "${BLUE}2.${NC} Deploy to HuggingFace Spaces:"
    echo -e "   ${CYAN}python $OASIS_DIR/deploy_to_hf.py oasis-v3 your-username${NC}"
    echo ""
    echo -e "${BLUE}3.${NC} Start OASIS:"
    echo -e "   ${CYAN}bash $OASIS_DIR/start_oasis.sh${NC}"
    echo ""
    echo -e "${BLUE}4.${NC} Test the system:"
    echo -e "   ${CYAN}oasis status${NC}"
    echo -e "   ${CYAN}ai-text 'Hello, OASIS!'${NC}"
    echo ""
    echo -e "${GREEN}💰 Revenue Target: $1K-10K/month${NC}"
    echo -e "${GREEN}🎯 Zero Heavy Dependencies${NC}"
    echo -e "${GREEN}⚡ Ultra-Lightweight Architecture${NC}"
    echo ""
    echo -e "${PURPLE}Welcome to the AI Revolution! 🌟${NC}"
}

# Main execution
main() {
    echo -e "${BLUE}Starting OASIS v3 setup...${NC}"
    
    # Create log directory first
    mkdir -p "$(dirname "$LOG_FILE")"
    
    check_termux
    update_packages
    install_essentials
    create_directories
    create_config
    setup_orchestrator
    setup_business_automation
    create_aliases
    create_startup_script
    create_deployment_script
    final_setup
    show_completion_message
    
    log "OASIS v3 setup completed successfully"
}

# Run main function
main "$@"

