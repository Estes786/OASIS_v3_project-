#!/usr/bin/env python3
"""
OASIS v3 - Termux Orchestrator
A lightweight command center for controlling Hugging Face Spaces AI/ML/DL applications
"""

import os
import sys
import json
import argparse
import requests
import base64
from datetime import datetime
import configparser
from pathlib import Path

class OASISOrchestrator:
    def __init__(self):
        self.config_file = Path.home() / '.oasis_config.ini'
        self.config = configparser.ConfigParser()
        self.load_config()
        
    def load_config(self):
        """Load configuration from file or create default"""
        if self.config_file.exists():
            self.config.read(self.config_file)
        else:
            # Create default configuration
            self.config['DEFAULT'] = {
                'hf_space_url': 'https://your-space-name.hf.space',
                'api_key': 'default_api_key_change_me',
                'timeout': '30'
            }
            self.save_config()
    
    def save_config(self):
        """Save configuration to file"""
        self.config_file.parent.mkdir(exist_ok=True)
        with open(self.config_file, 'w') as f:
            self.config.write(f)
        print(f"Configuration saved to {self.config_file}")
    
    def get_config_value(self, key, default=None):
        """Get configuration value"""
        return self.config.get('DEFAULT', key, fallback=default)
    
    def set_config_value(self, key, value):
        """Set configuration value"""
        self.config.set('DEFAULT', key, value)
        self.save_config()
    
    def make_request(self, endpoint, method='GET', data=None, params=None):
        """Make HTTP request to Hugging Face Spaces application"""
        base_url = self.get_config_value('hf_space_url')
        api_key = self.get_config_value('api_key')
        timeout = int(self.get_config_value('timeout', '30'))
        
        if not base_url or base_url == 'https://your-space-name.hf.space':
            print("❌ Error: Hugging Face Space URL not configured.")
            print("Please run: python oasis.py config set hf_space_url https://your-space-name.hf.space")
            return None
        
        url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        headers = {
            'Content-Type': 'application/json',
            'X-API-Key': api_key
        }
        
        try:
            if method.upper() == 'POST':
                if data:
                    data['api_key'] = api_key
                response = requests.post(url, json=data, headers=headers, timeout=timeout)
            else:
                if not params:
                    params = {}
                params['api_key'] = api_key
                response = requests.get(url, params=params, headers=headers, timeout=timeout)
            
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.ConnectionError:
            print(f"❌ Error: Cannot connect to {url}")
            print("Please check your internet connection and Hugging Face Space URL.")
            return None
        except requests.exceptions.Timeout:
            print(f"❌ Error: Request timed out after {timeout} seconds")
            return None
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP Error: {e}")
            if response.status_code == 401:
                print("Please check your API key configuration.")
            return None
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return None
    
    def run_model(self, model_name, **kwargs):
        """Execute AI/ML/DL model on Hugging Face Spaces"""
        print(f"🚀 Running model: {model_name}")
        print(f"📊 Parameters: {kwargs}")
        
        data = {
            'model_name': model_name,
            'input_data': kwargs
        }
        
        response = self.make_request('run_model', method='POST', data=data)
        
        if response:
            if response.get('status') == 'success':
                print("✅ Model execution successful!")
                output_data = response.get('output_data', {})
                
                # Display results based on model type
                if model_name == 'text_generation':
                    generated_text = output_data.get('generated_text', '')
                    print(f"\n📝 Generated Text:\n{generated_text}\n")
                elif model_name == 'image_processing':
                    analysis = output_data.get('analysis', '')
                    print(f"\n🖼️ Image Analysis:\n{analysis}\n")
                elif model_name == 'data_analysis':
                    results = output_data.get('results', {})
                    print(f"\n📈 Analysis Results:")
                    for key, value in results.items():
                        print(f"  {key}: {value}")
                    print()
                else:
                    print(f"\n📋 Output Data:\n{json.dumps(output_data, indent=2)}\n")
                
                return output_data
            else:
                print(f"❌ Model execution failed: {response.get('message', 'Unknown error')}")
        
        return None
    
    def get_status(self):
        """Get Hugging Face Spaces application status"""
        print("🔍 Checking application status...")
        
        response = self.make_request('status')
        
        if response:
            status = response.get('status', 'unknown')
            uptime = response.get('uptime_seconds', 0)
            active_requests = response.get('active_requests', 0)
            total_requests = response.get('total_requests', 0)
            
            # Convert uptime to human readable format
            hours, remainder = divmod(uptime, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{hours}h {minutes}m {seconds}s"
            
            print(f"✅ Status: {status}")
            print(f"⏱️ Uptime: {uptime_str}")
            print(f"🔄 Active Requests: {active_requests}")
            print(f"📊 Total Requests: {total_requests}")
            
            return response
        
        return None
    
    def upload_file(self, local_path, remote_name=None):
        """Upload file to Hugging Face Spaces"""
        local_path = Path(local_path)
        
        if not local_path.exists():
            print(f"❌ Error: File {local_path} does not exist")
            return None
        
        if not remote_name:
            remote_name = local_path.name
        
        print(f"📤 Uploading {local_path} as {remote_name}...")
        
        try:
            with open(local_path, 'rb') as f:
                file_content = base64.b64encode(f.read()).decode()
            
            data = {
                'file_name': remote_name,
                'file_content': file_content
            }
            
            response = self.make_request('upload_data', method='POST', data=data)
            
            if response and response.get('status') == 'success':
                print(f"✅ File uploaded successfully: {remote_name}")
                return response
            else:
                print(f"❌ Upload failed: {response.get('message', 'Unknown error') if response else 'No response'}")
        
        except Exception as e:
            print(f"❌ Error reading file: {e}")
        
        return None
    
    def download_result(self, result_id, local_path=None):
        """Download result from Hugging Face Spaces"""
        print(f"📥 Downloading result: {result_id}")
        
        params = {'result_id': result_id}
        response = self.make_request('download_results', params=params)
        
        if response and response.get('status') == 'success':
            file_name = response.get('file_name', result_id)
            file_content = response.get('file_content', '')
            
            if not local_path:
                local_path = Path.cwd() / file_name
            else:
                local_path = Path(local_path)
                if local_path.is_dir():
                    local_path = local_path / file_name
            
            try:
                decoded_content = base64.b64decode(file_content)
                with open(local_path, 'wb') as f:
                    f.write(decoded_content)
                
                print(f"✅ Result downloaded: {local_path}")
                return local_path
            
            except Exception as e:
                print(f"❌ Error saving file: {e}")
        else:
            print(f"❌ Download failed: {response.get('message', 'Unknown error') if response else 'No response'}")
        
        return None
    
    def show_help(self):
        """Show help information"""
        help_text = """
🌟 OASIS v3 - Termux Orchestrator

USAGE:
    python oasis.py <command> [arguments]

COMMANDS:
    run <model> [options]     Execute AI/ML/DL model
    status                    Check application status
    upload <file> [name]      Upload file to cloud
    download <id> [path]      Download result from cloud
    config set <key> <value>  Set configuration
    config get <key>          Get configuration value
    config show               Show all configuration
    help                      Show this help

EXAMPLES:
    # Text generation
    python oasis.py run text_generation --prompt "Write a story about AI" --max_length 200
    
    # Image processing
    python oasis.py run image_processing --image_url "https://example.com/image.jpg" --operation "analyze"
    
    # Data analysis
    python oasis.py run data_analysis --dataset_url "https://example.com/data.csv" --analysis_type "summary"
    
    # Configuration
    python oasis.py config set hf_space_url https://your-space-name.hf.space
    python oasis.py config set api_key your_api_key_here
    
    # File operations
    python oasis.py upload /sdcard/data.csv
    python oasis.py download result_123.txt /sdcard/downloads/

CONFIGURATION:
    Configuration is stored in ~/.oasis_config.ini
    Required settings:
    - hf_space_url: Your Hugging Face Space URL
    - api_key: API key for authentication
        """
        print(help_text)

def main():
    orchestrator = OASISOrchestrator()
    
    if len(sys.argv) < 2:
        orchestrator.show_help()
        return
    
    command = sys.argv[1].lower()
    
    if command == 'help' or command == '--help' or command == '-h':
        orchestrator.show_help()
    
    elif command == 'status':
        orchestrator.get_status()
    
    elif command == 'config':
        if len(sys.argv) < 3:
            print("❌ Error: config command requires subcommand (set, get, show)")
            return
        
        subcommand = sys.argv[2].lower()
        
        if subcommand == 'set':
            if len(sys.argv) < 5:
                print("❌ Error: config set requires key and value")
                return
            key, value = sys.argv[3], sys.argv[4]
            orchestrator.set_config_value(key, value)
            print(f"✅ Configuration updated: {key} = {value}")
        
        elif subcommand == 'get':
            if len(sys.argv) < 4:
                print("❌ Error: config get requires key")
                return
            key = sys.argv[3]
            value = orchestrator.get_config_value(key)
            print(f"{key} = {value}")
        
        elif subcommand == 'show':
            print("📋 Current Configuration:")
            for key in orchestrator.config['DEFAULT']:
                value = orchestrator.get_config_value(key)
                # Hide API key for security
                if 'key' in key.lower():
                    value = '*' * len(value) if value else 'Not set'
                print(f"  {key} = {value}")
        
        else:
            print(f"❌ Error: Unknown config subcommand: {subcommand}")
    
    elif command == 'run':
        if len(sys.argv) < 3:
            print("❌ Error: run command requires model name")
            return
        
        model_name = sys.argv[2]
        
        # Parse additional arguments
        kwargs = {}
        i = 3
        while i < len(sys.argv):
            arg = sys.argv[i]
            if arg.startswith('--'):
                key = arg[2:]
                if i + 1 < len(sys.argv) and not sys.argv[i + 1].startswith('--'):
                    value = sys.argv[i + 1]
                    i += 1
                else:
                    value = True
                kwargs[key] = value
            i += 1
        
        orchestrator.run_model(model_name, **kwargs)
    
    elif command == 'upload':
        if len(sys.argv) < 3:
            print("❌ Error: upload command requires file path")
            return
        
        local_path = sys.argv[2]
        remote_name = sys.argv[3] if len(sys.argv) > 3 else None
        orchestrator.upload_file(local_path, remote_name)
    
    elif command == 'download':
        if len(sys.argv) < 3:
            print("❌ Error: download command requires result ID")
            return
        
        result_id = sys.argv[2]
        local_path = sys.argv[3] if len(sys.argv) > 3 else None
        orchestrator.download_result(result_id, local_path)
    
    else:
        print(f"❌ Error: Unknown command: {command}")
        print("Run 'python oasis.py help' for usage information")

if __name__ == '__main__':
    main()

