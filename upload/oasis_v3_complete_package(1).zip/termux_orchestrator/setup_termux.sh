#!/data/data/com.termux/files/usr/bin/bash

# OASIS v3 - Termux Setup Script
# This script sets up the Termux environment for OASIS v3 orchestrator

echo "🌟 OASIS v3 - Termux Setup Starting..."
echo "========================================"

# Update packages
echo "📦 Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Install required packages
echo "🔧 Installing required packages..."
pkg install -y python python-pip git curl wget

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip install --upgrade pip
pip install requests configparser

# Create OASIS directory
echo "📁 Creating OASIS directory..."
mkdir -p ~/oasis_v3
cd ~/oasis_v3

# Download OASIS orchestrator (if not already present)
if [ ! -f "oasis.py" ]; then
    echo "📥 Setting up OASIS orchestrator..."
    # In a real deployment, this would download from a repository
    # For now, we'll create a placeholder
    cat > oasis.py << 'EOF'
#!/usr/bin/env python3
print("OASIS v3 orchestrator placeholder")
print("Please copy the actual oasis.py file to this directory")
EOF
    chmod +x oasis.py
fi

# Create alias for easy access
echo "🔗 Creating OASIS alias..."
echo 'alias oasis="python ~/oasis_v3/oasis.py"' >> ~/.bashrc

# Install Termux:API (optional but recommended)
echo "📱 Installing Termux:API..."
pkg install -y termux-api

# Create initial configuration
echo "⚙️ Creating initial configuration..."
python3 -c "
import configparser
from pathlib import Path

config = configparser.ConfigParser()
config['DEFAULT'] = {
    'hf_space_url': 'https://your-space-name.hf.space',
    'api_key': 'default_api_key_change_me',
    'timeout': '30'
}

config_file = Path.home() / '.oasis_config.ini'
with open(config_file, 'w') as f:
    config.write(f)

print(f'Configuration created at {config_file}')
"

echo ""
echo "✅ OASIS v3 Termux setup completed!"
echo "========================================"
echo ""
echo "📋 Next steps:"
echo "1. Configure your Hugging Face Space URL:"
echo "   oasis config set hf_space_url https://your-space-name.hf.space"
echo ""
echo "2. Set your API key:"
echo "   oasis config set api_key your_api_key_here"
echo ""
echo "3. Test the connection:"
echo "   oasis status"
echo ""
echo "4. Run your first AI model:"
echo "   oasis run text_generation --prompt \"Hello, OASIS!\""
echo ""
echo "📖 For more help:"
echo "   oasis help"
echo ""
echo "🔄 Restart Termux or run 'source ~/.bashrc' to use the 'oasis' command"

