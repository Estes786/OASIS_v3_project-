#!/usr/bin/env python3
"""
OASIS v3 - Termux:API Integration Module
Provides integration with Termux:API for enhanced device functionality
"""

import subprocess
import json
import os
from datetime import datetime

class TermuxAPI:
    """Wrapper for Termux:API functionality"""
    
    def __init__(self):
        self.api_available = self._check_api_availability()
    
    def _check_api_availability(self):
        """Check if Termux:API is available"""
        try:
            subprocess.run(['termux-battery-status'], 
                         capture_output=True, check=True, timeout=5)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return False
    
    def _run_command(self, command, timeout=10):
        """Run a Termux:API command and return the result"""
        if not self.api_available:
            return None
        
        try:
            result = subprocess.run(command, 
                                  capture_output=True, 
                                  text=True, 
                                  check=True, 
                                  timeout=timeout)
            return result.stdout.strip()
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            print(f"⚠️ Termux:API command failed: {e}")
            return None
    
    def get_battery_status(self):
        """Get battery status information"""
        output = self._run_command(['termux-battery-status'])
        if output:
            try:
                return json.loads(output)
            except json.JSONDecodeError:
                return None
        return None
    
    def get_device_info(self):
        """Get device information"""
        info = {}
        
        # Battery status
        battery = self.get_battery_status()
        if battery:
            info['battery_percentage'] = battery.get('percentage', 'Unknown')
            info['battery_status'] = battery.get('status', 'Unknown')
            info['battery_temperature'] = battery.get('temperature', 'Unknown')
        
        # Network info
        wifi_info = self._run_command(['termux-wifi-connectioninfo'])
        if wifi_info:
            try:
                wifi_data = json.loads(wifi_info)
                info['wifi_ssid'] = wifi_data.get('ssid', 'Unknown')
                info['wifi_signal_strength'] = wifi_data.get('rssi', 'Unknown')
            except json.JSONDecodeError:
                pass
        
        return info
    
    def send_notification(self, title, content, priority='default'):
        """Send a notification"""
        command = ['termux-notification', 
                  '--title', title, 
                  '--content', content,
                  '--priority', priority]
        
        return self._run_command(command) is not None
    
    def vibrate(self, duration=1000):
        """Vibrate the device"""
        command = ['termux-vibrate', '-d', str(duration)]
        return self._run_command(command) is not None
    
    def get_location(self):
        """Get device location (requires location permission)"""
        output = self._run_command(['termux-location'], timeout=30)
        if output:
            try:
                return json.loads(output)
            except json.JSONDecodeError:
                return None
        return None
    
    def take_photo(self, camera='0', output_file=None):
        """Take a photo using device camera"""
        if not output_file:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"/sdcard/DCIM/oasis_photo_{timestamp}.jpg"
        
        command = ['termux-camera-photo', '-c', camera, output_file]
        result = self._run_command(command, timeout=30)
        
        if result is not None and os.path.exists(output_file):
            return output_file
        return None
    
    def get_clipboard(self):
        """Get clipboard content"""
        return self._run_command(['termux-clipboard-get'])
    
    def set_clipboard(self, text):
        """Set clipboard content"""
        command = ['termux-clipboard-set', text]
        return self._run_command(command) is not None
    
    def speak_text(self, text, language='en'):
        """Use text-to-speech to speak text"""
        command = ['termux-tts-speak', '-l', language, text]
        return self._run_command(command) is not None
    
    def get_sensor_data(self, sensor='all'):
        """Get sensor data"""
        command = ['termux-sensor', '-s', sensor, '-n', '1']
        output = self._run_command(command, timeout=15)
        if output:
            try:
                return json.loads(output)
            except json.JSONDecodeError:
                return None
        return None

# Enhanced OASIS orchestrator with Termux:API integration
class EnhancedOASISOrchestrator:
    """OASIS orchestrator with Termux:API integration"""
    
    def __init__(self, base_orchestrator):
        self.base = base_orchestrator
        self.termux_api = TermuxAPI()
    
    def get_device_context(self):
        """Get device context for AI models"""
        context = {
            'timestamp': datetime.now().isoformat(),
            'termux_api_available': self.termux_api.api_available
        }
        
        if self.termux_api.api_available:
            device_info = self.termux_api.get_device_info()
            context.update(device_info)
        
        return context
    
    def run_model_with_context(self, model_name, include_device_context=False, **kwargs):
        """Run model with optional device context"""
        if include_device_context:
            device_context = self.get_device_context()
            
            # Add device context to prompt for text generation
            if model_name == 'text_generation' and 'prompt' in kwargs:
                original_prompt = kwargs['prompt']
                context_info = []
                
                if 'battery_percentage' in device_context:
                    context_info.append(f"Battery: {device_context['battery_percentage']}%")
                
                if 'wifi_ssid' in device_context:
                    context_info.append(f"WiFi: {device_context['wifi_ssid']}")
                
                if context_info:
                    context_str = " | ".join(context_info)
                    kwargs['prompt'] = f"[Device Context: {context_str}] {original_prompt}"
        
        return self.base.run_model(model_name, **kwargs)
    
    def notify_completion(self, model_name, success=True):
        """Send notification when model execution completes"""
        if self.termux_api.api_available:
            if success:
                title = "OASIS v3 - Success"
                content = f"Model '{model_name}' completed successfully"
                priority = 'default'
            else:
                title = "OASIS v3 - Error"
                content = f"Model '{model_name}' failed to execute"
                priority = 'high'
                self.termux_api.vibrate(500)  # Short vibration for errors
            
            self.termux_api.send_notification(title, content, priority)
    
    def smart_upload_photo(self, camera='0'):
        """Take a photo and upload it for processing"""
        if not self.termux_api.api_available:
            print("❌ Termux:API not available for camera access")
            return None
        
        print("📸 Taking photo...")
        photo_path = self.termux_api.take_photo(camera)
        
        if photo_path:
            print(f"✅ Photo saved: {photo_path}")
            
            # Upload photo to Hugging Face Spaces
            result = self.base.upload_file(photo_path, f"camera_photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
            
            if result:
                print("📤 Photo uploaded successfully")
                return photo_path
        
        print("❌ Failed to take or upload photo")
        return None
    
    def voice_to_text_generation(self):
        """Use device microphone for voice input (placeholder)"""
        # Note: Termux:API doesn't have direct speech-to-text
        # This is a placeholder for future implementation
        print("🎤 Voice input not yet implemented")
        print("💡 Suggestion: Use termux-microphone-record and external STT service")
        return None

def main():
    """Example usage of Termux:API integration"""
    api = TermuxAPI()
    
    print("🔍 Checking Termux:API availability...")
    if api.api_available:
        print("✅ Termux:API is available")
        
        # Get device info
        device_info = api.get_device_info()
        print(f"📱 Device Info: {device_info}")
        
        # Send test notification
        api.send_notification("OASIS v3", "Termux:API integration test successful!")
        
    else:
        print("❌ Termux:API not available")
        print("💡 Install with: pkg install termux-api")
        print("💡 Also install the Termux:API app from F-Droid or Google Play")

if __name__ == '__main__':
    main()

