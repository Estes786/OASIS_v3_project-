#!/usr/bin/env python3
"""
OASIS v3 - Integration Tests
"""

import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from termux_orchestrator.oasis import OASISOrchestrator

class TestOASISIntegration(unittest.TestCase):
    
    def setUp(self):
        self.orchestrator = OASISOrchestrator()
    
    def test_configuration_loading(self):
        """Test configuration loading"""
        config = self.orchestrator.load_config()
        self.assertIsInstance(config, dict)
    
    def test_session_id_generation(self):
        """Test session ID generation"""
        session_id = self.orchestrator.generate_session_id()
        self.assertIsInstance(session_id, str)
        self.assertEqual(len(session_id), 8)
    
    def test_status_endpoint(self):
        """Test status endpoint (requires HF Spaces)"""
        # This test requires a configured HF Spaces URL
        # Skip if not configured
        hf_url = self.orchestrator.config.get('hf_spaces', {}).get('primary_url', '')
        if not hf_url or 'your-space' in hf_url:
            self.skipTest("HuggingFace Spaces not configured")
        
        result = self.orchestrator.get_status()
        self.assertIsNotNone(result)

if __name__ == '__main__':
    unittest.main()
